<template>
  <div class="Video-wrapper gg-flex-3  gg-flex-2">
    <div class="Video-header gg-flex-3">
      <div class="Video-header-title">Meeting</div>
      <div class="Video-header-mid gg-flex-3">
        <!-- 摄像头 -->
        <div class="Video-header-mid-item gg-flex-1" :title="item.title" :key="index" v-for="(item,index) in headerMenuList" @click="headerMenuToggle(item)">
          <div class="Video-header-mid-item-icon " :class="item.class" :style="headerMenuActive==item.id?'background-image: url('+item.clickIcon+');':''"></div>
        </div>

      </div>
      <div class="Video-header-right gg-flex-3">
        <div class="Video-header-right-minimize gg-flex-1">
          <img draggable="false" class="minimize" src="../assets/images/minimize-icon.png" alt="">
        </div>
        <div class="Video-header-right-Finish gg-flex-1">
          <img draggable="false" class="Finish" src="../assets/images/Finish-icon.png" alt="">
        </div>
      </div>
    </div>

    <div class="Video-main">
      <!-- 翻页 -->
      <img class="video-last-page" draggable="false" src="../assets/images/video-last-page.png" alt="">
      <img class="video-next-page" draggable="false" src="../assets/images/video-next-page.png" alt="">

      <div class="Video-main-fourPlayerMode gg-flex-3">
        <div class="Video-main-fourPlayerMode-item gg-flex-3 gg-flex-2">
          <!-- 主持人 -->
          <img class="Video-Host" draggable="false" src="../assets/images/Host-icon.png" alt="">
          <!-- 底部工具栏 + name -->
          <div class="Video-footer-toolbar-box gg-flex-3">
            <div class="Video-footer-name">Su Xinyi</div>

            <!-- <div class="Video-footer-toolbar gg-flex-3">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-video-icon" draggable="false" src="../assets/images/video-box-Inside-video-icon.png" alt="">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-audio-icon" draggable="false" src="../assets/images/video-box-Inside-audio-icon.png" alt="">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-fullScreen-icon" draggable="false" src="../assets/images/video-box-Inside-fullScreen-icon.png" alt="">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-menu-icon" draggable="false" src="../assets/images/video-box-Inside-menu-icon.png" alt="">
            </div> -->
          </div>
        </div>
        <div class="Video-main-fourPlayerMode-item gg-flex-3 gg-flex-2">
          <!-- 主持人 -->
          <!-- <img  class="Video-Host" draggable="false"  src="../assets/images/Host-icon.png" alt=""> -->
          <!-- 底部工具栏 + name -->
          <div class="Video-footer-toolbar-box gg-flex-3">
            <div class="Video-footer-name">Ekene Obasey</div>

            <div class="Video-footer-toolbar gg-flex-3">
              <img class="Video-footer-toolbar-icon Video-footer-toolbar-video-icon" draggable="false" src="../assets/images/video-box-Inside-video-icon.png" alt="">
              <img class="Video-footer-toolbar-icon Video-footer-toolbar-audio-icon" draggable="false" src="../assets/images/video-box-Inside-audio-icon.png" alt="">
              <img class="Video-footer-toolbar-icon Video-footer-toolbar-fullScreen-icon" draggable="false" src="../assets/images/video-box-Inside-fullScreen-icon.png" alt="">
              <img class="Video-footer-toolbar-icon Video-footer-toolbar-menu-icon" draggable="false" src="../assets/images/video-box-Inside-menu-icon.png" alt="">
            </div>
          </div>
        </div>
        <div class="Video-main-fourPlayerMode-item gg-flex-3 gg-flex-2">
          <!-- 主持人 -->
          <!-- <img  class="Video-Host" draggable="false"  src="../assets/images/Host-icon.png" alt=""> -->
          <!-- 底部工具栏 + name -->
          <div class="Video-footer-toolbar-box gg-flex-3">
            <div class="Video-footer-name">Uruewa Himona</div>

            <!-- <div class="Video-footer-toolbar gg-flex-3">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-video-icon" draggable="false" src="../assets/images/video-box-Inside-video-icon.png" alt="">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-audio-icon" draggable="false" src="../assets/images/video-box-Inside-audio-icon.png" alt="">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-fullScreen-icon" draggable="false" src="../assets/images/video-box-Inside-fullScreen-icon.png" alt="">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-menu-icon" draggable="false" src="../assets/images/video-box-Inside-menu-icon.png" alt="">
            </div> -->
          </div>
        </div>
        <div class="Video-main-fourPlayerMode-item gg-flex-3 gg-flex-2">
          <!-- 主持人 -->
          <!-- <img  class="Video-Host" draggable="false"  src="../assets/images/Host-icon.png" alt=""> -->
          <!-- 底部工具栏 + name -->
          <div class="Video-footer-toolbar-box  ">

            <div class="Video-footer-toolbar gg-flex-3" style="margin-left: 24px;margin-bottom: 13px;">
              <img class="Video-footer-toolbar-icon Video-footer-toolbar-video-icon" draggable="false" src="../assets/images/video-box-Inside-video-icon.png" alt="">
              <img class="Video-footer-toolbar-icon Video-footer-toolbar-audio-icon" draggable="false" src="../assets/images/video-box-Inside-audio-icon.png" alt="">
              <!-- <img class="Video-footer-toolbar-icon Video-footer-toolbar-fullScreen-icon" draggable="false" src="../assets/images/video-box-Inside-fullScreen-icon.png" alt="">
                 <img class="Video-footer-toolbar-icon Video-footer-toolbar-menu-icon" draggable="false" src="../assets/images/video-box-Inside-menu-icon.png" alt=""> -->
            </div>
            <div class="Video-footer-name">Uruewa Himona</div>

          </div>
        </div>
      </div>
      <!-- 成员列表 -->
      <div class="Video-userList-box gg-flex-3" v-if="ShowVideoUserList" @click="showUserList">
        <img class="Video-Subassembly-hide" draggable="false" src="../assets/images/video-hide.png" alt="">
        <div class="Video-userList  gg-flex-3  gg-flex-2" @click.stop>
          <div class="Video-userList-header">
            <div class="Video-userList-header-name">Meeting number (4/5)</div>
          </div>
          <div class="Video-userList-main  gg-flex-3  gg-flex-2">
            <div class="Video-userList-main-header gg-flex-3">
              <div class="Video-userList-main-Name">Name</div>
              <div class="Video-userList-main-Admin">Admin</div>
              <div class="Video-userList-main-Microphone">Microphone</div>
              <div class="Video-userList-main-Camera">Camera</div>
            </div>
            <div class="Video-userList-main-list-box ">
              <el-scrollbar style="height:100%" ref="userListScrollbar">
                <dir class="Video-userList-main-list  gg-flex-3">
                  <div class="Video-userList-main-list-Name  gg-flex-3">
                    <img class="Video-userList-item-icon" src="../assets/images/women.png" draggable="false" alt="">
                    <div class="Video-userList-item-name">Lucas</div>
                  </div>
                  <div class="Video-userList-main-Admin  gg-flex-1">
                    <img draggable="false" class="video-userList-Admin-icon" src="../assets/images/video-userList-Admin-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Microphone  gg-flex-1">
                    <img draggable="false" class="video-userList-Microphone-icon" src="../assets/images/video-userList-Microphone-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Camera  gg-flex-1">
                    <img draggable="false" class="video-userList-Camera-icon" src="../assets/images/video-userList-Camera-icon.png" alt="">
                  </div>
                </dir>
                <dir class="Video-userList-main-list  gg-flex-3">
                  <div class="Video-userList-main-list-Name  gg-flex-3">
                    <img class="Video-userList-item-icon" src="../assets/images/women.png" draggable="false" alt="">
                    <div class="Video-userList-item-name">Afonso Pinto</div>
                  </div>
                  <div class="Video-userList-main-Admin  gg-flex-1">
                    <img draggable="false" class="video-userList-Admin-icon" src="../assets/images/video-userList-Admin-disable-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Microphone  gg-flex-1">
                    <img draggable="false" class="video-userList-Microphone-icon" src="../assets/images/video-userList-Microphone-disable-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Camera  gg-flex-1">
                    <img draggable="false" class="video-userList-Camera-icon" src="../assets/images/video-userList-Camera-disable-icon.png" alt="">
                  </div>
                </dir>
                <dir class="Video-userList-main-list  gg-flex-3">
                  <div class="Video-userList-main-list-Name  gg-flex-3">
                    <img class="Video-userList-item-icon" src="../assets/images/women.png" draggable="false" alt="">
                    <div class="Video-userList-item-name">Nandi</div>
                  </div>
                  <div class="Video-userList-main-Admin  gg-flex-1">
                    <img draggable="false" class="video-userList-Admin-icon" src="../assets/images/video-userList-Admin-disable-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Microphone  gg-flex-1">
                    <img draggable="false" class="video-userList-Microphone-icon" src="../assets/images/video-userList-Microphone-disable-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Camera  gg-flex-1">
                    <img draggable="false" class="video-userList-Camera-icon" src="../assets/images/video-userList-Camera-disable-icon.png" alt="">
                  </div>
                </dir>
                <dir class="Video-userList-main-list  gg-flex-3">
                  <div class="Video-userList-main-list-Name  gg-flex-3">
                    <img class="Video-userList-item-icon" src="../assets/images/women.png" draggable="false" alt="">
                    <div class="Video-userList-item-name">Ohta Kin</div>
                  </div>
                  <div class="Video-userList-main-Admin  gg-flex-1">
                    <img draggable="false" class="video-userList-Admin-icon" src="../assets/images/video-userList-Admin-disable-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Microphone  gg-flex-1">
                    <img draggable="false" class="video-userList-Microphone-icon" src="../assets/images/video-userList-Microphone-disable-icon.png" alt="">
                  </div>
                  <div class="Video-userList-main-Camera  gg-flex-1">
                    <img draggable="false" class="video-userList-Camera-icon" src="../assets/images/video-userList-Camera-disable-icon.png" alt="">
                  </div>
                </dir>
              </el-scrollbar>
            </div>
          </div>

        </div>

      </div>
      <!-- 消息列表 -->
      <div class="Video-message-box gg-flex-3" v-if="ShowVideoMessage" @click="ShowMessage">
        <img class="Video-Subassembly-hide" draggable="false" src="../assets/images/video-hide.png" alt="">
        <div class="Video-message  gg-flex-3  gg-flex-2" @click.stop>
          <div class="Video-message-header">
            <div class="Video-message-header-title">Message</div>
          </div>
          <div class="Video-message-main-list-box ">
            <el-scrollbar style="height:100%" ref="messageScrollbar">
              <div class="Video-message-main-item gg-flex-4  gg-flex-2">
                <div class="Video-message-main-item-name ">Meg Rigden</div>
                <div class="Video-message-main-item-text ">the demand for these</div>
              </div>
              <div class="Video-message-main-item gg-flex-4  gg-flex-2">
                <div class="Video-message-main-item-name ">Gopichand Sana</div>
                <div class="Video-message-main-item-text ">A tachymeter scale</div>
              </div>
              <div class="Video-message-main-item gg-flex-4  gg-flex-2 Video-message-main-item-end">
                <div class="Video-message-main-item-name ">Poseidon</div>
                <div class="Video-message-main-item-text ">14,000</div>
              </div>
              <div class="Video-message-main-item gg-flex-1"><span class="Video-message-main-item-time">16:34</span></div>
              <div class="Video-message-main-item gg-flex-4  gg-flex-2 Video-message-main-item-end">
                <div class="Video-message-main-item-name ">Poseidon</div>
                <div class="Video-message-main-item-text ">Swatch group</div>
              </div>
            </el-scrollbar>
          </div>
          <div class="Video-message-footer-box ">
            <el-input type="textarea" resize='none' placeholder="Enter" v-model="messageContent">
            </el-input>
          </div>
        </div>

      </div>

    </div>

  </div>

</template>
<script>
// import services from '../../static/utils/services'
// import utils from '../../static/utils/utils'

// import filter from '../../static/utils/filter'

// var htmlOverviewMsgTemp = filter.htmlOverviewMsgTemp();
export default {
  name: 'videoPage',
  components: {

  },
  props: {

  },

  data() {
    return {
      // 发送的消息内容
      messageContent: '400 and end at 60',
      // 头部菜单栏切换
      headerMenuActive: '',
      headerMenuList: [
        { id: 'video-icon', title: '摄像头', class: 'Video-header-mid-item-video-icon', clickIcon: require('../assets/images/video-click-icon.png') },
        { id: 'audio-icon', title: '麦克风', class: 'Video-header-mid-item-audio-icon', clickIcon: require('../assets/images/audio-click-icon.png') },
        { id: 'userListDelete-icon', title: '删除成员', class: 'Video-header-mid-item-userListDelete-icon', clickIcon: require('../assets/images/userListDelete-click-icon.png') },
        { id: 'userListAdd-icon', title: '添加成员', class: 'Video-header-mid-item-userListAdd-icon', clickIcon: require('../assets/images/userListAdd-click-icon.png') },
        { id: 'userList-icon', title: '成员列表', class: 'Video-header-mid-item-userList-icon', clickIcon: require('../assets/images/userList-click-icon.png'), callBackName: 'showUserList' },
        { id: 'shareScreen-icon', title: '屏幕共享', class: 'Video-header-mid-item-shareScreen-icon', clickIcon: require('../assets/images/shareScreen-click-icon.png') },
        { id: 'message-icon', title: '聊天', class: 'Video-header-mid-item-message-icon', clickIcon: require('../assets/images/message-click-icon.png'), callBackName: 'ShowMessage' },
        { id: 'raiseYourHand-icon', title: '举手', class: 'Video-header-mid-item-raiseYourHand-icon', clickIcon: require('../assets/images/raiseYourHand-click-icon.png') },
      ],
      // 成员列表是否显示
      ShowVideoUserList: false,
      // 消息列表 是否显示
      ShowVideoMessage:false,
    };
  },
  watch: {

  },
  mounted() {

    // console.log(this.$route.query.params)
    // this.$refs.editDiv.focus();
  },

  methods: {
    headerMenuToggle(msg) {
      this.headerMenuActive = msg.id;
      if (this.headerMenuActive != 'userList-icon') {
        this.ShowVideoUserList = false;
      }
      if (this.headerMenuActive != 'message-icon') {
        this.ShowVideoMessage = false;
      }
      // 传入方法名 调用指定函数 
      this.toolBarFn(msg.callBackName);
    },
    // 传入方法名 调用指定函数 
    toolBarFn(methodName) {
      if (methodName && methodName != '')
        this[methodName]();
    },
    // 成员列表
    showUserList() {
      this.ShowVideoUserList = !this.ShowVideoUserList;
    },
    // 消息
    ShowMessage(){
     this.ShowVideoMessage = !this.ShowVideoMessage;
    },
    hideHistory() {
      this.$emit('hideHistory',)
    },

    //监听 子组件调用 搜索输入框 输入的查询条件
    changeSearch(val) {
      console.log('搜索输入框子组件', val)
    },
  }
};
</script>

<style scoped>
@import "../assets/css/videoPage.css";
/* 隐藏原生的横向滚动条 */
.Video-main /deep/ .el-scrollbar__wrap {
  overflow-x: hidden;
}
.Video-message-footer-box /deep/ .el-textarea {
  height: 100% !important;
}
.Video-message-footer-box /deep/ .el-textarea__inner {
  background: #000;
  height: 100% !important;
  border: 0px;
  padding: 16px;
  font-size: 14px;
  font-family: "Futura-Medium, Futura";
  font-weight: 500;
  color: #ffffff;
  line-height: 19px;
}
.Video-message-footer-box /deep/ .el-textarea__inner::placeholder {
  color: #ffffff;
  opacity: 0.3;
  font-size: 12px;
  /* text-align:right; */
  position: absolute;
  right: 16px;
  bottom: 18px;
}
</style>

