import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

/* Layout */
import Layout from '@/layout'

export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },
  {
    path: '/choice',
    component: () => import('@/views/choice'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    redirect: 'dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'dashboard',
        component: () => import('@/views/dashboard'),
        meta: {
          title: '首页',
          icon: 'dashboard'
        }
      },
      {
        path: 'spaceManagement',
        name: 'spaceManagement',
        hidden: true,
        component: () => import('@/views/dashboard/spaceManagement'),
        meta: {
          title: '控舱管理',
          icon: ''
        }
      },
      {
        path: 'VolumeSet',
        name: 'VolumeSet',
        hidden: true,
        component: () => import('@/views/dashboard/VolumeSet'),
        meta: {
          title: '批量控舱',
          icon: ''
        }
      },
      {
        path: 'spaceDetail',
        name: 'spaceDetail',
        hidden: true,
        component: () => import('@/views/dashboard/details/spaceDetail'),
        meta: {
          title: '控舱详情',
          icon: ''
        }
      },
      {
        path: 'isDouble',
        name: 'isDouble',
        hidden: true,
        component: () => import('@/views/dashboard/details/isDouble'),
        meta: {
          title: '双屏大图',
          icon: ''
        }
      }
    ]
  }
]
export default new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({
    y: 0
  }),
  routes: constantRoutes
})

