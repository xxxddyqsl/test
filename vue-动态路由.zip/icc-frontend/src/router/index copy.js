import Vue from "vue";
import Router from "vue-router";
import Cookies from "js-cookie";
import db from "@/utils/localstorage";
import { getUserRouter } from "@/api/user";

Vue.use(Router);

/* Layout */
import Layout from "@/layout";

export const constantRoutes = [
  {
    path: "/login",
    name: "login",
    component: () => import("@/views/login/index")
  },

  {
    path: "/404",
    component: () => import("@/views/404")
  },
  {
    path: "/choice",
    component: () => import("@/views/choice")
  },
  {
    path: "/",
    component: Layout,
    redirect: "dashboard"
  }
];
const createRouter = () =>
  new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({
      y: 0
    }),
    routes: constantRoutes
  });
const router = createRouter();

const whiteList = ["/login"];
let asyncRouter;

// JWT 用户权限校验，判断 TOKEN 是否在 localStorage 当中
router.beforeEach((to, from, next) => {
  if (whiteList.indexOf(to.path) !== -1) {
    next();
  }
  let token = db.get("TOKEN");
  let user = db.get("SET_USERINFO");
  let userRouter = get("USER_ROUTER");
  // 获取 JWT Token
  if (token.length && user) {
    if (!asyncRouter) {
      if (!userRouter) {
        // 请求获取用户信息
        getUserRouter()
          .then(res => {
            asyncRouter = res.data;
            db.save("USER_ROUTER", asyncRouter);
            go(to, next);
          })
          .catch(err => {
            console.error(err);
          });
      } else {
        asyncRouter = userRouter;
        go(to, next);
      }
    } else {
      next();
    }
  } else {
    next("/login");
  }
});

function go(to, next) {
  router.addRoutes(asyncRouter);
  next({ ...to, replace: true });
}

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter();
  router.matcher = newRouter.matcher; // reset router
}

export default router;
