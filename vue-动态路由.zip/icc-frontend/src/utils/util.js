import BigNumber from 'bignumber.js'
import {
  validatenull
} from './validate'
import store from '../store'
/**
 * 生成随机len位数字
 */
export const randomLenNum = (len, date) => {
  let random = ''
  random = Math.ceil(Math.random() * 100000000000000)
    .toString()
    .substr(0, typeof len === 'number' ? len : 4)
  if (date) random = random + Date.now()
  return random
}

// 计算小数  digit为小数位数
export function numFinancial(num, digit = 2, { isNullishToZero = true } = {}) {
  if (isNullishToZero && [null, undefined].includes(num)) {
    num = 0
  }
  return new BigNumber(num).toFormat(digit)
}

export const initMenu = (router, menu) => { // 解析路由
  if (menu.length === 0) {
    return
  }
  const menus = formatRoutes(menu)
  const unfound = {
    path: '*',
    redirect: '/404',
    hidden: true
  }
  menus.push(unfound)
  router.addRoutes(menus)
  store.commit('ADD_ROUTERS', menus)
}

export const formatRoutes = (aMenu) => {
  const aRouter = []
  aMenu.forEach(oMenu => {
    const {
      path,
      component,
      name,
      hidden,
      label,
      icon,
      url,
      children
    } = oMenu
    if (!validatenull(component)) {
      const oRouter = {
        path: path,
        hidden,
        component(resolve) {
          let componentPath = ''
          if (component === 'Layout') {
            require(['@/layout/index'], resolve)
            return
          } else {
            componentPath = component
          }
          require([`@/views/${componentPath}`], resolve)
        },
        name: name,
        meta: {
          icon: icon,
          title: label,
          url: url
        },

        icon: icon,
        children: validatenull(children) ? [] : formatRoutes(children)
      }
      aRouter.push(oRouter)
    }
  })
  return aRouter
}
