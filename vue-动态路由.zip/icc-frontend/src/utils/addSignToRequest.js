import { getStamp, getRandom } from '@/utils/index'
import { getToken } from '@/utils/auth'
// import __host from '@/utils/hostconfig'
const addSign = params => {
  if (params instanceof FormData) {
    params.append('timestamp', getStamp())
    params.append('rand', getRandom(6))
    // params.append('ak', 'Tt3vYQGnQFRKf97oViAEw1E0FDyc9HHm')
    // params.append('sign', getSign(params))
  } else {
    params.timestamp = getStamp()
    params.rand = getRandom(6)
    // params.ak = 'Tt3vYQGnQFRKf97oViAEw1E0FDyc9HHm'
    // params.sign = getSign(params)
  }
  return params
}
const addToken = params => {
  params.token = getToken()
  return params
}

window._addSign = addSign
window._addToken = addToken
export default addSign

