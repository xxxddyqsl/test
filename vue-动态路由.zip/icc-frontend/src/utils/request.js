import axios from 'axios'
import { Loading, Message } from 'element-ui'

// import Cookies from "js-cookie";
// import store from '@/store'
import db from '@/utils/localstorage'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style

// import addSign from '@/utils/addSignToRequest'

// create an axios instance
// 为保持与现有代码兼容，这里将 /api/v1/ 前缀添加到 baseURL 中
let loading
let num = 0
let isRefreshing = false // 标记是否正在刷新 token
let requests = [] // 存储待重发请求的数组
NProgress.configure({ showSpinner: false })
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  withCredentials: true, // send cookies when cross-domain requests
  timeout: 15000 // request timeout
})

// request拦截器
service.interceptors.request.use(

  config => {
    if (db.get('TOKEN')) {
      config.headers.Authentication = 'Bearer ' + db.get('TOKEN').accessToken
    }
    num++
    if (sessionStorage.getItem('loading') != 1) {
      loading = Loading.service({
        lock: true,
        text: '稍等一下，努力加载中~~',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
    }
    if (['get', 'delete'].includes(config.method)) {
      config.params = config.params || {}
    } else if (['post', 'put'].includes(config.method)) {
      config.data = config.data || {}
    }
    return config
  },
  error => {
    if (loading) loading.close()
    sessionStorage.setItem('loading', '0')
    Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  response => {
    const res = response
    num--
    if (num === 0) {
      loading && loading.close()
    }
    NProgress.done()
    if (res.data.code !== '200') {
      Message({
        message: res.data.message || 'error',
        type: 'error',
        duration: 5 * 1000
      })
      return res
    } else {
      return res
    }
  },
  error => {
    num--
    if (loading) loading.close()
    sessionStorage.setItem('loading', '0')
    if (error && error.response) {
      if (
        error.response.status === 502 &&
        error.response.status === 500 &&
        error.response.status === 501
      ) {
        Message({
          message: '内部服务器错误,请联系管理员',
          type: 'error',
          duration: 5 * 1000
        })
      } else if (
        error.response.status === 401 &&
        !error.config.url.includes('/auth/refresh') &&
        !error.config.url.includes('/login')
      ) {
        const { config } = error
        if (!isRefreshing) {
          isRefreshing = true
          return axios({
            url: '/auth/api/v1/refresh',
            method: 'get',
            headers: {
              Authorization: 'Bearer ' + db.get('TOKEN').refreshToken
            }
          })
            .then(res => {
              db.save('TOKEN', JSON.stringify(res.data.data))
              config.headers.Authorization = `Bearer ${res.accessToken}`
              requests.forEach(cb => cb(res.accessToken))
              requests = [] // 重新请求完清空
              return service(config)
            })
            .catch(error1 => {
              console.log('抱歉，您的登录状态已失效，请重新登录！')
              return Promise.reject(error1)
            })
            .finally(() => {
              isRefreshing = false
            })
        } else {
          // 返回未执行 resolve 的 Promise
          return new Promise(resolve => {
            // 用函数形式将 resolve 存入，等待刷新后再执行
            requests.push(token => {
              config.headers.Authorization = `Bearer ${token}`
              resolve(service(config))
            })
          })
        }
      } else if (error.response.status === 400) {
        Message({
          message: error.response.data.message,
          type: 'error',
          duration: 5 * 1000
        })
      }
    }
    // TODO: 如果 Response 是 401 应弹出登录对话框，要求用户再次输入身份凭据
    NProgress.done()
    return Promise.reject(error)
  }
)

export default service
