<template>
  <div class="pageBox">
    <!-- 预警信息 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="form" size="small">
          <el-form-item>
            <el-select v-model="form.flightNbr" clearable filterable placeholder="请选择航班号">
              <el-option v-for="item in flightNoList" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-date-picker
              v-model="form.flightDate"
              type="date"

              placeholder="航班日期"
              value-format="yyyy-MM-dd HH:mm:ss"
              style="width:120px"
            />
          </el-form-item>
          <el-form-item>
            <el-input v-model="form.value" placeholder="规则编号" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="query">查询</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData2" border>
        <el-table-column prop="hbh" label="航班号" />
        <el-table-column prop="hbrq" label="航班日期" />
        <el-table-column prop="gzbh" label="规则编号" />
        <el-table-column prop="zl" label="指令">
          <template slot-scope="scope">
            <span>
              {{ scope.row.zl }}
            </span>
            <span style="color:red">S</span>
          </template>
        </el-table-column>
        <el-table-column prop="ctgzh" label="冲突规则号" />
        <el-table-column prop="ctzl" label="冲突指令">
          <template slot-scope="scope">
            <span>
              {{ scope.row.ctzl }}
            </span>
            <span style="color:red">R</span>
          </template>
        </el-table-column>
        <el-table-column prop="ctrq" label="冲突日期" />
        <el-table-column label="操作" min-width="160">
          <el-button type="primary" style="margin:0 5px" size="mini">未读</el-button>
          <el-button type="primary" style="margin:0 5px" size="mini">前往</el-button>
        </el-table-column>
      </el-table>
      <div style="display:flex; align-items: center; ">

        <el-pagination background layout="total, prev, pager, next" :total="10" />
      </div>
    </div>
  </div>
</template>

<script>
import { get, selectFlightNoList, selectRouteRodeList } from '@/api/earlyWarningInformation.js'

export default {
  data() {
    return {
      form: {
        flightRoute: '', // 航线
        flightNbr: '', // 航班号
        flightDate: '' // 航班日期
      },
      flightNoList: [], // 航班号下拉列表
      routeCodeList: [], // 航段下拉列表
      pageSize: 10, // 页码个数
      pageNum: 1, // 页数
      total: 0, // 总数
      number: 0,
      radio1: '1',
      dialogAddNew: false,
      tableData: [],
      tableData1: [{
        hx: 'SHA-LZH',
        jzhbh: 'TS1001',
        hbrq: '2021.01.03',
        jzqfsk: '07:18',
        jzhbyj: '258',
        bhsyxhb: 'YY9141、YY9142',
        yjsj: '2021.09.18  16:40'
      },
      {
        hx: 'SHA-LZH',
        jzhbh: 'TS1002',
        hbrq: '2021.01.03',
        jzqfsk: '07:18',
        jzhbyj: '258',
        bhsyxhb: 'YY9141、YY9142',
        yjsj: '2021.09.18  16:40'
      },
      {
        hx: 'SHA-LZH',
        jzhbh: 'TS1003',
        hbrq: '2021.01.03',
        jzqfsk: '07:18',
        jzhbyj: '258',
        bhsyxhb: 'YY9141、YY9142',
        yjsj: '2021.09.18  16:40'
      },
      {
        hx: 'SHA-LZH',
        jzhbh: 'TS1004',
        hbrq: '2021.01.03',
        jzqfsk: '07:18',
        jzhbyj: '258',
        bhsyxhb: 'YY9141、YY9142',
        yjsj: '2021.09.18  16:40'
      }, {
        hx: 'SHA-LZH',
        jzhbh: 'TS1005',
        hbrq: '2021.01.03',
        jzqfsk: '07:18',
        jzhbyj: '258',
        bhsyxhb: 'YY9141、YY9142',
        yjsj: '2021.09.18  16:40'
      }, {
        hx: 'SHA-LZH',
        jzhbh: 'TS1006',
        hbrq: '2021.01.03',
        jzqfsk: '07:18',
        jzhbyj: '258',
        bhsyxhb: 'YY9141、YY9142',
        yjsj: '2021.09.18  16:40'
      }],
      tableData2: [{
        hbh: 'YY7237',
        hbrq: '2020.07.05',
        gzbh: 5201111,
        zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/',
        ctgzh: 5202222,
        ctzl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/',
        ctrq: '2021.06.10'
      },
      {
        hbh: 'YY7238',
        hbrq: '2020.07.05',
        gzbh: 5203333,
        zl: 'ICM:N/YY7238/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/',
        ctgzh: 5204444,
        ctzl: 'ICM:N/YY7238/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/',
        ctrq: '2021.06.10'
      }
      ]

    }
  },

  created() {
    selectFlightNoList().then(res => {
      if (res.data.code == '200') {
        this.flightNoList = res.data.data
      }
    })
    selectRouteRodeList().then(res => {
      if (res.data.code == '200') {
        this.routeCodeList = res.data.data
      }
    })
    this.init()
  },
  methods: {
    goToSpaceDetail(id) {
      // 跳转调舱
      this.$router.push({
        path: '/spaceDetail',
        query: { id }
      })
    },
    query() {
      this.pageNum = 1
      this.init()
    },
    reSet() {
      this.form = {
        flightRoute: '', // 航线
        flightNbr: '', // 航班号
        flightDate: '' // 航班日期
      }
      this.pageNum = 1
      this.init()
    },
    init() {
      get({
        ...this.form,
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(res => {
        if (res.data.code == '200') {
          console.log(res.data.data)
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.init()
    },
    goEarlyWarningRules() {
      this.$router.push({ name: 'earlyWarningRules' })
    },
    goCompetitionWarning() {
      this.$router.push({ name: 'competitionWarning' })
    }
  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}
@media screen and (max-width: 1500px) {
  .seachBox{
    flex-direction: column;
    justify-content: start;
    align-items: start;
  }
  .title_left{
    margin-bottom: 10px;
    min-width: 460px;
  }
}

</style>

