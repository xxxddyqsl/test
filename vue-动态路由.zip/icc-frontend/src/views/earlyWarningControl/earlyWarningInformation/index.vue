<template>
  <div class="pageBox">
    <!-- 指标预警信息 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="form" size="small">
          <el-form-item>
            <el-select v-model="form.flightNbr" clearable filterable placeholder="请选择航班号">
              <el-option v-for="item in flightNoList" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.flightRoute" clearable filterable placeholder="请选择航线">
              <el-option v-for="item in routeCodeList" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="form.flightDate"
              type="date"

              placeholder="航班日期"
              value-format="yyyy-MM-dd HH:mm:ss"
              style="width:120px"
            />
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.flightNbr" clearable filterable placeholder="指标类型">
              <el-option v-for="item in flightNoList" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="query">查询</el-button>

            <el-button type="primary" @click="goEarlyWarningRules">预警规则</el-button>

          </el-form-item>

        </el-form>
      </div>
    </div>

    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="route" label="航线" />
        <el-table-column prop="flightNbr" label="航班号" />
        <el-table-column prop="flightDate" label="航班日期" />
        <el-table-column prop="flightAtdTime" label="航班起飞时刻" />
        <el-table-column prop="targetType" label="指标类型" />
        <el-table-column prop="alarmInfo" label="预警信息" />
        <el-table-column prop="targetInfo" label="指标信息" />
        <el-table-column prop="complete" label="当前完成" />
        <el-table-column prop="upToTakeOff" label="截止起飞时间" />
        <el-table-column prop="alarmMoment" label="预警时刻" />
        <el-table-column label="操作" min-width="160">
          <template slot-scope="scope">
            <el-button :disabled="scope.row.status == '1'" type="primary" size="mini" :style="{background: scope.row.status == '0' ? 'red' : ''}" @click="changeState(scope.row)">{{ scope.row.status == '0' ? '未读' : '已读' }}</el-button>
            <el-button type="primary" style="margin:0 5px" size="mini" @click="goToSpaceDetail(scope.row)">调舱</el-button>
          </template>

        </el-table-column>
      </el-table>
      <el-pagination background layout="total, prev, pager, next" :page-size="pageSize" :total="total" :current-page="pageNum" @current-change="handleCurrentChange" />
    </div>
  </div>
</template>

<script>
import { get, selectFlightNoList, selectRouteRodeList, setList } from '@/api/earlyWarningInformation.js'

export default {
  data() {
    return {
      form: {
        flightRoute: '', // 航线
        flightNbr: '', // 航班号
        flightDate: '' // 航班日期
      },
      flightNoList: [], // 航班号下拉列表
      routeCodeList: [], // 航段下拉列表
      pageSize: 10, // 页码个数
      pageNum: 1, // 页数
      total: 0, // 总数
      number: 0,
      radio1: '1',
      dialogAddNew: false,
      tableData: [], //列表数据
    }
  },

  created() {
    this.init()
    this.selectRouteRodeList()
    this.selectFlightNoList()
  },
  methods: {
    /**
     * 获取航班下拉字典
     */
     selectFlightNoList(){
      selectFlightNoList().then(res => {
        if (res.data.code == '200') {
          this.flightNoList = res.data.data
        }
      })
     },
    /**
     * 获取航线下拉字典
     */
    selectRouteRodeList(){
      selectRouteRodeList().then(res => {
          if (res.data.code == '200') {
            this.routeCodeList = res.data.data
          }
      })
    },
    /**
    *更改状态
    */
    changeState(v) {
      this.$confirm(`此操作将永久标记这条数据状态为 '已读' , 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        setList(v.id).then(res => {
          if (res.data.code == '200') {
            this.init()
            this.$message({
              type: 'success',
              message: `标记这条数据状态为 '已读' 成功!`
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: `已取消标记这条数据状态为 '已读' `
        })
      })
    },
    /**
     * 跳转调舱
     */
    goToSpaceDetail(v) {
      this.$router.push({
        path: '/spaceDetail',
        query: { flightDate: v.flightDate.replace(/\./g, '-') || '' , flightNo: v.flightNbr}
      })
    },
    /**
     * 查询
     */
    query() {
      this.pageNum = 1
      this.init()
    },
    /**
     * 重置
     */
    reSet() {
      this.form = {
        flightRoute: '', // 航线
        flightNbr: '', // 航班号
        flightDate: '' // 航班日期
      }
      this.pageNum = 1
      this.init()
    },
    /**
     * 初始化列表
     */
    init() {
      get({
        ...this.form,
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(res => {
        if (res.data.code == '200') {
          console.log(res.data.data)
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    },
    /**
     * 切换分页
     */
    handleCurrentChange(val) {
      this.pageNum = val
      this.init()
    },
    /**
     * 跳转预警规则
     */
    goEarlyWarningRules() {
      this.$router.push({ name: 'earlyWarningRules' })
    }

  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}

</style>

