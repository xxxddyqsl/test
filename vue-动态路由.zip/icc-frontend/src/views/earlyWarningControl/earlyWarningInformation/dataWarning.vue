<template>
  <div class="pageBox">
    <!-- 数据预警信息 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="form" size="small">
          <el-form-item>
            <el-input v-model="form.dataName" size="small" placeholder="请输入数据名称" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.dataType" clearable filterable placeholder="请输入数据类型">
              <el-option v-for="(item, i) in dataTypeList" :key="i" :label="item.dataType" :value="item.dataType" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.dataSource" clearable filterable placeholder="请输入数据来源">
              <el-option v-for="(item, i) in dataSourceList" :key="i" :label="item.dataSource" :value="item.dataSource" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="query">查询</el-button>
            <el-button type="primary" @click="reSet">重置</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-table :data="tableData" border>
      <el-table-column prop="dataName" label="数据名称" />
      <el-table-column prop="dataType" label="数据类型" />
      <el-table-column prop="dataSource" label="数据来源" />
      <el-table-column prop="dataPercentOfPass" label="数据合格率">
        <template slot-scope="scope">
          <div>
            {{ scope.row.dataPercentOfPass }}%
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="latestAlarmTime" label="最新预警时间">
        <template slot-scope="scope">
          <div>
            {{ scope.row.latestAlarmTime.slice(0, -3) || '--' }}
          </div>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="pageNum"
      :page-size="pageSize"
      layout="total, prev, pager, next"
      :total="total"
      @current-change="handleCurrentChange"
    />
  </div>

</template>

<script>
import { getDataAlarm, getDataType, getDataSource } from '@/api/earlyWarningInformation.js'

export default {
  data() {
    return {
      form: {
        dataName: '', // 数据名称
        dataType: '', // 数据类型
        dataSource: '' // 数据来源
      },
      dataTypeList: [], // 数据类型列表
      dataSourceList: [], // 数据来源列表
      pageSize: 10, // 页码个数
      pageNum: 1, // 页数
      total: 0, // 总数
      dialogAddNew: false,
      tableData: []

    }
  },

  created() {
    this.init()
    this.getDataType()
    this.getDataSource()
  },
  methods: {
    /**
    *切换分页
    */
    handleCurrentChange(val) {
      this.pageNum = val
      this.init()
    },
    /**
     * 查询
     */
    query() {
      this.pageNum = 1
      this.init()
    },
    /**
    *获取数据类型下拉
    */
    getDataType() {
      getDataType().then(res => {
        if (res.data.code == '200') {
          this.dataTypeList = res.data.data
        }
      })
    },
    /**
    *获取数据来源下拉
    */
    getDataSource() {
      getDataSource().then(res => {
        if (res.data.code == '200') {
          this.dataSourceList = res.data.data
        }
      })
    },
    /**
    *重置查询
    */
    reSet() {
      this.form = {
        dataName: '', // 书籍名称
        dataType: '', // 数据类型
        dataSource: '' // 数据来源
      }
      this.pageNum = 1
      this.init()
    },
    /**
    *初始化列表
    */
    init() {
      getDataAlarm({
        ...this.form,
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(res => {
        if (res.data.code == '200') {
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    }

  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}

</style>

