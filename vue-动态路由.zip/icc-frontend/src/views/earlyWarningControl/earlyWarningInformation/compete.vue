<template>
  <div class="pageBox">
    <!-- 预警中心 / 指令预警 -->
    <div class="seachBox">
      <div class="title_left"></div>
      <div class="title_right">
        <el-form :inline="true" :model="form">
            <el-form-item>
            <el-select v-model="form.flightNo" size="mini" placeholder="请选择航班号" clearable filterable>
              <el-option
                v-for="(item,i) in flightNoList"
                :key="i"
                :label="item.flightNo"
                :value="item.flightNo"
              />
            </el-select>
            </el-form-item>
            <el-form-item>
              <el-select v-model="form.routeCode" size="mini" placeholder="请选择航线" clearable filterable>
                <el-option
                  v-for="(item,i) in routeCodeList"
                  :key="i"
                  :label="item.routeCode"
                  :value="item.routeCode"
                />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-date-picker
                v-model="form.flightDate"
                type="date"
                size="small"
                placeholder="航班日期"
                value-format="yyyy-MM-dd"
                style="width:180px"
              />
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="query">查询</el-button>
                <el-button type="primary" size="mini" @click="reSet">重置</el-button>
                <el-button type="primary" size="mini" @click="goCompetitionWarning">预警规则</el-button>
            </el-form-item>
        </el-form>
      </div>

    </div>

    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="routeCode" label="竞争航线" />
        <el-table-column prop="flightNo" label="竞争航班号" />
        <el-table-column prop="flightDate" label="航班日期" />
        <el-table-column prop="aircraftType" label="机型" />
        <el-table-column prop="departureTime" label="航班起飞时刻" />
        <el-table-column prop="lowestPrice" label="最低销售价格" />
        <el-table-column prop="messageWarring" label="预警信息" />
        <el-table-column prop="affectedFlights" label="本航受影响航班" />
        <el-table-column prop="warringTime" label="预警时刻" />
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button :disabled="scope.row.status" type="primary" size="mini" :style="{background: !scope.row.status ? 'red' : ''}" @click="changestatus(scope.row)">{{ !scope.row.status ? '未读' : '已读' }}</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        background
        :current-page="pageNum"
        :page-size="pageSize"
        layout="total, prev, pager, next"
        :total="total"
        @current-change="handleCurrentChange"
      />

    </div>
  </div>
</template>

<script>
import { getList, getRouteCode, getFlightNo, setList } from '@/api/competitionWarning'

export default {
  data() {
    return {
      form: {
        routeCode: '', // 航线
        flightNo: '', // 航班号
        flightDate: '' // 航班日期
      },
      flightNoList: [], // 航班号下拉列表
      routeCodeList: [], // 航段下拉列表
      pageSize: 10, // 页码个数
      pageNum: 1, // 页数
      total: 0, // 总数
      tableData: [] // 列表数据
    }
  },

  created() {
    this.init()
    this.getRouteCode()
    this.getFlightNo()
  },
  methods: {
    /**
     * 跳转规则页
     */
    goCompetitionWarning() {
      this.$router.push({ name: 'competitionWarning' })
    },
    /**
    *查询
    */
    query() {
      this.pageNum = 1
      this.init()
    },
    /**
    *切换分页
    */
    handleCurrentChange(val) {
      this.pageNum = val
      this.init()
    },
    /**
    *初始化列表
    */
    init() {
      getList({
        pageSize: this.pageSize,
        pageNum: this.pageNum,
        ...this.form
      }).then(res => {
        if (res.data.code == '200') {
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    },
    /**
    *航线列表字典
    */
    getRouteCode() {
      getRouteCode().then(res => {
        if (res.data.code == '200') {
          this.routeCodeList = res.data.data
        }
      })
    },

    /**
    *航班列表字典
    */
    getFlightNo() {
      getFlightNo().then(res => {
        if (res.data.code == '200') {
          this.flightNoList = res.data.data
        }
      })
    },
    /**
    *重置按钮
    */
    reSet() {
      this.form = {
        routeCode: '', // 航线
        flightNo: '', // 航班号
        flightDate: '' // 航班日期
      }
      this.query()
    },

    /**
    *更改状态
    */
    changestatus(v) {
      this.$confirm(`此操作将永久标记这条数据状态为 '已读' , 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        setList(v.id).then(res => {
          if (res.data.code == '200') {
            this.init()
            this.$message({
              type: 'success',
              message: `标记这条数据状态为 '已读' 成功!`
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: `已取消标记这条数据状态为 '已读' `
        })
      })
    }
  }

}

</script>

<style scoped >

 .title_right{
    display: flex;
    justify-content: flex-end;
  }
</style>

