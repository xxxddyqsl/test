
<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left" />
      <!-- 预警监管 -->
      <div class="title_right">
        <el-form :inline="true" :model="form">
          <el-form-item>
            <el-switch
              v-model="form.state"
              active-text="未读"
              inactive-text="所有"
              active-value="0"
              inactive-value=" "
            />
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.route" size="mini" placeholder="请选择航线" clearable filterable>
              <el-option
                v-for="(item, i) in selectRouteRodeList"
                :key="i"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.flightNo" size="mini" placeholder="请选择航班号" clearable filterable>
              <el-option
                v-for="(item,i) in selectFlightList"
                :key="i"
                :label="item.flightNumber"
                :value="item.flightNumber"
              />
            </el-select>

          </el-form-item>
          <el-form-item>
            <el-select v-model="form.warningType" size="mini" placeholder="请选择预警类型" clearable filterable>
              <el-option v-for="item in selectList" :key="item.code" :value="item.name" :label="item.name" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="form.flightDate"
              size="mini"
              type="date"
              placeholder="航班日期"
              clearable
              value-format="yyyy-MM-dd"
            />
          </el-form-item>
          <el-form-item>
            <el-input v-model="form.administrators" size="mini" style="width:120px" placeholder="航线管理员" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="query">查询</el-button>
            <el-button type="primary" size="mini" @click="reSet">重置</el-button>
            <el-button type="primary" size="mini" @click="goRegulatoryRules">监管规则</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 表格 -->
    <div class="table-box">

      <el-table
        ref="multipleTable"
        border
        :data="tableData"
      >

        <el-table-column label="航班号" prop="flightNo" align="center" />
        <el-table-column label="航线" prop="route" align="center" />
        <el-table-column label="航班日期" prop="flightDate" align="center" />
        <el-table-column label="起飞时刻" prop="flightAtdTime" align="center" />
        <el-table-column label="预警信息类型" prop="warningType" align="center" />
        <el-table-column label="超时未读预警信息" prop="warningInfo" align="center" />
        <el-table-column label="航线管理员" prop="administrators" align="center" />
        <el-table-column label="预警时刻" prop="warningInfo" align="center" />

        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" :disabled="scope.row.state == 1" :style="{background: scope.row.state == '0' ? 'red' : ''}" @click="changeState(scope.row)">{{ scope.row.state == '0' ?'未读' : '已读' }}</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        background
        :current-page="pageNum"
        :page-size="pageSize"
        layout="total, prev, pager, next"
        :total="total"
        @current-change="handleCurrentChange"
      />
    </div>

  </div>
</template>

<script>

import { getSelectFlightList, getSelectRouteRodeList } from '@/api/spaceManagement'
import { getTreeitemsSelect, getWarningSupervise, changeState } from '@/api/flightCompetitionManagementDetails'

export default {
  data() {
    return {
      selectFlightList: [], // 航班列表
      selectRouteRodeList: [], // 航段列表
      pageNum: 1, // 当前页码
      pageSize: 10, // 每页数量
      total: 0, // 总数
      form: {
        state: '', // 状态
        route: '', // 航线
        flightNo: '', // 航班
        warningType: '', // 预警类型
        flightDate: '', // 日期
        administrators: ''// 航线管理员
      },
      selectList: [], // 预警监管条件下拉

      tableData: [] // 表格数据

    }
  },
  created() {
    this.getWarningSupervise()
    this.getSelectFlightList()
    this.getSelectRouteRodeList()
    this.getTreeitemsSelect()
  },
  methods: {
    /**
    *重置
    */
    reSet() {
      this.form = {
        state: '', // 状态
        route: '', // 航线
        flightNo: '', // 航班
        warningType: '', // 预警类型
        flightDate: '', // 日期
        administrators: ''// 航线管理员
      }
      this.query()
    },
    /**
    *更改状态
    */
    changeState(v) {
      this.$confirm(`此操作将永久标记这条数据状态为 ${v.state == '1' ? '未读' : '已读'}, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        changeState(v.id, { state: v.state == '0' ? '1' : '0' }).then(res => {
          if (res.data.code == '200') {
            this.getWarningSupervise()
            this.$message({
              type: 'success',
              message: `标记这条数据状态为${v.state == '1' ? '未读' : '已读'}成功!`
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: `已取消标记这条数据状态为${v.state == '1' ? '未读' : '已读'}`
        })
      })
    },
    /**
    *查询
    */
    query() {
      this.pageNum = 1
      this.getWarningSupervise()
    },
    /**
    *切换分页
    */
    handleCurrentChange(val) {
      this.pageNum = val
      this.getWarningSupervise()
    },
    /**
    *获取航线列表
    */
    getWarningSupervise() {
      getWarningSupervise({
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        ...this.form
      }).then(res => {
        if (res.data.code == 200) {
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    },

    /**
    *获取航线列表
    */
    getSelectFlightList() {
      getSelectFlightList().then(res => {
        if (res.data.code == 200) {
          this.selectFlightList = res.data.data
        }
      })
    },

    /**
    *获取航段列表
    */
    getSelectRouteRodeList() {
      getSelectRouteRodeList().then(res => {
        if (res.data.code == 200) {
          this.selectRouteRodeList = res.data.data
        }
      })
    },

    /**
    *预警监管条件下拉字典
    */
    getTreeitemsSelect() {
      getTreeitemsSelect({ code: 'jggztj' }).then(res => {
        if (res.data.code == '200') {
          this.selectList = res.data.data.dictionaryItemVOS
        }
      })
    },
    /**
    *跳转预警规则页面
    */
    goRegulatoryRules() {
      this.$router.push({ name: 'regulatoryRules' })
    }

  }
}
</script>

<style   scoped>

</style>

