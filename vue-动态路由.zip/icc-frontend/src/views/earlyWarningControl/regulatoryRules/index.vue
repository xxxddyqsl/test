<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left">
        <h3>预警监管规则</h3>
      </div>
      <div class="title right">
        <el-form :inline="true">
          <el-form-item>  <el-button type="primary" size="mini" @click="add">添加</el-button> </el-form-item>
          <el-form-item>  <el-button type="primary" size="mini" @click="deletes">删除</el-button> </el-form-item>
          <el-form-item>  <el-button type="primary" size="mini" @click="beRevised">编辑</el-button> </el-form-item>
          <el-form-item>  <el-button type="primary" size="mini" @click="() => $router.go(-1)">返回</el-button> </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="content">
      <div class="left">
        <div class="title">规则表</div>
        <ul>
          <li v-for="v in list" :key="v.id" :class="active == v.id ? 'active' : ''"> <i :class="v.focus == 1 ? 'el-icon-star-on' : 'el-icon-star-off' " @click="setStars(v)" /> <span @click="change(v)"> {{ v.tag }}</span></li>
        </ul>
      </div>
      <div class="right">
        <div class="top">
          <div class="title">本航适用航班</div>
          <div class="list" style="border: 1px">
            <el-table :data="ruleRefPoList" stripe border>
              <el-table-column prop="flightLeg" label="航段" width="300" />
              <el-table-column prop="ruleFlightNoVoList" label="航班号">
                <template slot-scope="scope">
                  <span v-if="scope.row.ruleFlightNoVoList">
                    <span v-for="(v,i) in scope.row.ruleFlightNoVoList" :key="i">{{ v.flightNo }} &nbsp;</span>
                  </span>
                </template>
              </el-table-column>
            </el-table>
          </div>

        </div>
        <div class="bottom">
          <div class="title">预警监管条件</div>
          <div class="list" style="border: 1px">
            <div v-for="(v,i) in superviseRuleRefVOS" :key="i" class="li">
              {{ i >= 1 ? 'OR&nbsp;' : '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' }}
              <span>{{ v.regulatoryConditions.name }}</span>
              未处理超过告警时间
              <span>{{ v.value }}</span> 分钟
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 添加修改弹窗 -->

    <el-dialog v-dialogDrag :title="dialogTitle" width="1100px" :visible.sync="dialog">
      <el-form ref="form" :model="dialogForm" :rules="rules" label-width="110px">

        <el-form-item label="规则名称" prop="tag">
          <el-input v-model="dialogForm.tag" style="width: 700px;margin-left:25px" placeholder="请输入规则名称" />
        </el-form-item>
        <el-form-item label="本航适用航班" prop="ruleRefPoList">
          <el-cascader ref="flightNo" v-model="dialogForm.ruleRefPoList" style="width: 400px;margin-left:25px" :props="flightListProps" :show-all-levels="false" :options="flightList" clearable collapse-tags />
        </el-form-item>
        <el-form-item label="预警监管条件" prop="superviseRuleRefVOS">

          <div v-for="(v, i) in dialogForm.superviseRuleRefVOS" :key="i" style="margin-bottom: 10px">
            <span :style="{color: i==0 ? '#fff': '#333'}">OR</span>
            <el-select v-model="v.regulatoryConditions" style="width: 200px;margin-right: 10px" placeholder="请选择预警类型" clearable filterable>
              <el-option v-for="item in selectList" :key="item.code" :value="item.code" :label="item.name" />
            </el-select>
            未处理超过告警时间
            <el-input v-model="dialogForm.superviseRuleRefVOS[i].value" placeholder="请输入" style="width: 100px;margin-right: 10px" /> 分钟

            <el-button size="mini" @click.prevent="removeDomain(v)">取消</el-button>
            <el-button v-if="i+1 == dialogForm.superviseRuleRefVOS.length" type="primary" size="mini" @click.prevent="addDomain">添加</el-button>

          </div>

        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button style="margin:0 5px" @click="callOff">取 消</el-button>
        <el-button style="margin:0 5px" type="primary" @click="makeSure">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { getMarketCRules, getMarketCRulesRight, getFlightList, setStar, addSet, deletesSet, getTreeitemsSelect } from '@/api/flightCompetitionManagementDetails'
export default {
  data() {
    return {
      list: [], // 左侧列表
      ruleRefPoList: [], // 本航适用航班
      superviseRuleRefVOS: [], // 显示规则
      active: '', //当前激活
      activeName: '',//当前激活规则名
      flightList: [],//航班列表
      dialog: false,//弹窗状态
      dialogTitle: '',//弹窗标题
      dialogForm: {//规则数据
        tag: '',
        ruleRefPoList: [],
        superviseRuleRefVOS: [
          { regulatoryConditions: '', value: '' },
          { regulatoryConditions: '', value: '' }
        ]
      },
      rules: {
        tag: [{ required: true, message: '请输入规则名称', trigger: 'blur' }],
        ruleRefPoList: [{ required: true, message: '请选择本航适用航班', trigger: 'blur' }],
        superviseRuleRefVOS: [{ required: true, message: '指标预警条件不能有空选项', trigger: 'blur',
          validator: (rule, value, callback) => {
            const bool = value.every(v => {
              return (v.regulatoryConditions && v.value)
            })
            if (bool) {
              callback()
            } else {
              callback(new Error('不能为空'))
            }
          }
        }]
      },
      flightListProps: {
        label: 'flightNo',
        value: 'flightNo',
        children: 'alarmRuleFlightNoVoList',
        multiple: true
        // emitPath: false
      },
      selectList: []//列表数据
    }
  },

  created() {
    this.init()
    this.getFlightList()
    this.getTreeitemsSelect()
  },
  methods: {
    /**
    *获取航班列表
    */
    getFlightList() {
      getFlightList().then(res => {
        if (res.data.code == '200') {
          this.flightList = res.data.data
        }
      })
    },
    /**
    *预警监管条件下拉字典
    */
    getTreeitemsSelect() {
      getTreeitemsSelect({ code: 'jggztj' }).then(res => {
        if (res.data.code == '200') {
          this.selectList = res.data.data.dictionaryItemVOS
        }
      })
    },
    /**
     * 获取规则表
     */
    init() {
      getMarketCRules({ ruleType: 'regulatoryRules' }).then(res => {
        if (res.data.code == '200') {
          this.list = res.data.data
          this.active = res.data.data.length > 0 ? res.data.data[0].id : ''
          this.activeName = res.data.data.length > 0 ? res.data.data[0].tag : ''
          this.get({ ruleType: 'regulatoryRules', id: this.active })
        }
      })
    },
    /** 删除*/
    deletes() {
      this.$confirm(`此操作将永久'删除'这条规则, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deletesSet(this.active).then(res => {
            if (res.data.code == 200) {
              // 获取规则表
              this.init()
              this.$message({
                type: 'success',
                message: `'删除'成功!`
              })
            } else {
              this.$message({
                type: 'warning',
                message: res.data.message
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: `已取消'删除'操作`
          })
        })
    },
    /**
     * 取消规则
     */
    removeDomain(item) {
      var index = this.dialogForm.superviseRuleRefVOS.indexOf(item)
      if (index !== -1) {
        this.dialogForm.superviseRuleRefVOS.splice(index, 1)
      }
    },
    /**
     * 添加规则
     */
    addDomain() {
      this.dialogForm.superviseRuleRefVOS.push({ regulatoryConditions: '', value: '' })
    },
    /**
     * 是否标记
     */
    setStars(v) {
      this.$confirm(`此操作将永久 '${v.focus == '0' ? '标记' : '取消标记'}' 这条数据, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          setStar(v.id).then(res => {
            if (res.data.code == 200) {
              getMarketCRules({ ruleType: 'regulatoryRules' }).then(res => {
                if (res.data.code == '200') {
                  this.list = res.data.data
                }
              })
              this.$message({
                type: 'success',
                message: ` '${v.focus == '0' ? '标记' : '取消标记'}' 成功!`
              })
            } else {
              this.$message({
                type: 'warning',
                message: res.data.message
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: `已取消 '${v.focus == '0' ? '标记' : '取消标记'} ' 操作`
          })
        })
    },
    /**
     * 获取适用航班
     */
    get(params) {
      getMarketCRulesRight(params).then(res => {
        console.log('获取适用')
        if (res.data.code == '200') {
          this.ruleRefPoList = res.data.data.ruleRefPoList
          this.superviseRuleRefVOS = res.data.data.superviseRuleRefVOS
        }
      })
    },
    /**
     * 切换规则表
     */
    change(v) {
      this.active = v.id
      this.activeName = v.tag
      this.get({ ruleType: 'regulatoryRules', id: v.id })
    },
    /**
     * 添加规则
     */
    add(v) {
      this.dialogTitle = '添加预警监管规则'
      this.dialog = true
      this.dialogFormSet()
    },
    /**
     * 修改
     */
    beRevised() {
      this.dialogTitle = '修改预警监管规则'
      this.dialog = true
      this.dialogFormSet()

      this.dialogForm.tag = this.activeName
      var arr = []
      this.ruleRefPoList.length > 0 && this.ruleRefPoList.map(item => {
        console.log(item)
        if (item.ruleFlightNoVoList) {
          item.ruleFlightNoVoList.map(j => {
            arr.push([item.flightLeg, j.flightNo])
          })
        } else {
          arr.push([item.flightLeg])
        }
      })

      this.dialogForm.ruleRefPoList = arr

      var superviseRuleRefVOSArr = []
      this.superviseRuleRefVOS.length > 0 && this.superviseRuleRefVOS.map(v => {
        superviseRuleRefVOSArr.push(
          {

            regulatoryConditions: v.regulatoryConditions.code,
            value: v.value
          }
        )
      })
      this.dialogForm.superviseRuleRefVOS = superviseRuleRefVOSArr
    },

    /**
     * 确认
     */
    makeSure() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.dialogForm.ruleRefPoList = this.dialogForm.ruleRefPoList.map(v => {
            return {
              flightLeg: v[0] ? v[0] : null,
              flightNo: v[1] ? v[1] : null
            }
          })
          if (this.dialogTitle == '添加预警监管规则') {
            addSet({ ...this.dialogForm, ruleType: 'regulatoryRules', state: '0' }).then(res => {
              console.log(res)
              if (res.data.code == '200') {
                this.$message({
                  type: 'success',
                  message: `'添加'成功!`
                })
                // 获取规则表
                this.init()
              }
            })
          } else {
            addSet({ ...this.dialogForm, id: this.active, ruleType: 'regulatoryRules', state: '1' }).then(res => {
              if (res.data.code == '200') {
                this.$message({
                  type: 'success',
                  message: `'修改'成功!`
                })
                // 获取规则表
                getMarketCRules({ ruleType: 'regulatoryRules' }).then(res => {
                  if (res.data.code == '200') {
                    this.list = res.data.data
                    this.active = this.active
                    this.activeName = this.activeName
                    this.get({ ruleType: 'regulatoryRules', id: this.active })
                  }
                })
              }
            })
          }
          this.dialog = false
        } else {
          return false
        }
      })
    },
    /**
     * 取消
     */
    callOff() {
      this.dialog = false
    },
    /**
     * 重置修改添加表单
     */
    dialogFormSet() {
      this.dialogForm = {
        tag: '',
        ruleRefPoList: [],
        superviseRuleRefVOS: [
          { regulatoryConditions: '', value: '' },
          { regulatoryConditions: '', value: '' }
        ]
      }
      this.$refs['form'] && this.$refs['form'].resetFields()
    }
  }

}

</script>

<style lang="scss" scoped >
.seachBox{
  margin: 0;
  .title_left{
    padding-left: 10px;
    color: #6a758f;
  }
}
.content{
  display: flex;
  font-size: 16px;
  height: 100%;
  justify-content: space-between;

  .left{
    border: 1px solid #eee;
    border-radius: 15px;
    padding:0 0 20px 0;
    max-height: 750px;
    min-width: 250px;
    overflow-y: auto;
    ul{
      padding:  0;
      margin: 5px 0;
      li{
        padding-left: 30px;
        height: 50px;
        line-height: 50px;
        cursor: pointer;
        position: relative;
        span{
          display: inline-block;
          width: 100%;
          overflow: hidden;
          text-overflow:ellipsis;
          white-space: nowrap;
        }
        i{
          position: absolute;
          left: 5px;
          top: 16px;
          &.el-icon-star-on{
            color: #5e56d2;
            font-size: 22px;
            top: 12px;
            left: 3px;
          }
        }

        &:hover{
          background-color: #ebf1ff;
        }
        &.active{
          background-color: #ebf1ff;
        }
      }
    }
  }
  .right{
    border: 1px solid #eee;
    border-radius: 15px;
    width: calc(100% - 300px);
    overflow-y: auto;
    min-width: 850px;
    .top,.bottom{
      .list{
        padding: 10px 30px 10px 100px;
        min-height: 200px;
        border: 1px solid #000;
      }
    }
    .bottom{
      .li{
        height: 50px;
        margin: 10px 0;
        span{
          display: inline-block;
          height: 100%;
          border: 1px solid #eee;
          line-height: 50px;
          margin-right: 20px;
          min-width: 150px;
          padding-left: 20px;
          &:last-child{
            min-width: 100px;
          }
        }
      }
    }
  }
  .title{
    font-weight: 900;
    padding: 10px;
    background-color: #ebf1ff;
  }
}
</style>

