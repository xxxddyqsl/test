<template>
  <div class="pageBox">
    <!-- 预警中心 / 指令预警 -->
      <div class="seachB">
        <div class="title_left"></div>
          <div class="title_right">
            <el-form :inline="true" :model="form">
              <el-form-item>
                <el-select v-model="form.flightNo" size="mini" placeholder="请选择航班号" clearable filterable>
                  <el-option
                    v-for="(item,i) in flightNoList"
                    :key="i"
                    :label="item.flightNo"
                    :value="item.flightNo"
                  />
                </el-select>
              </el-form-item>
              <el-form-item>
                <el-date-picker
                  v-model="form.flightDate"
                  type="date"
                  size="small"
                  placeholder="航班日期"
                  value-format="yyyy-MM-dd"
                  style="width:180px"
                />
              </el-form-item>
                <el-form-item>
                  <el-select v-model="form.conflictRuleCode" size="mini" placeholder="请选择规则编号" clearable filterable>
                    <el-option
                      v-for="(item,i) in conflictRuleCodeList"
                      :key="i"
                      :label="item.conflictRuleCode"
                      :value="item.conflictRuleCode"
                    />
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" size="mini" @click="query">查询</el-button>
                  <el-button type="primary" size="mini" @click="reSet">重置</el-button>
                </el-form-item>
            </el-form>
        </div>
      </div>
    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="flightNo" label="航班号" />
        <el-table-column prop="flightDate" label="航班日期" />
        <el-table-column prop="execRuleCode" label="执行规则编号" />
        <el-table-column prop="execCommand" label="执行指令(调用接口)">
          <template slot-scope="scope">
            <span>
              {{ scope.row.execCommand }}
            </span>
            <!-- <span style="color:red">S</span> -->
          </template>
        </el-table-column>
        <el-table-column prop="conflictRuleCode" label="冲突规则编号" />
        <el-table-column prop="conflictCommand" label="冲突指令(调用接口)">
          <template slot-scope="scope">
            <span>
              {{ scope.row.conflictCommand }}
            </span>
            <!-- <span style="color:red">R</span> -->
          </template>
        </el-table-column>
        <el-table-column prop="conflictDate" label="冲突时刻" />
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button :disabled="scope.row.state" type="primary" size="mini" :style="{background: !scope.row.state ? 'red' : ''}" @click="changeState(scope.row)">{{ !scope.row.state ? '未读' : '已读' }}</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        background
        :current-page="pageNum"
        :page-size="pageSize"
        layout="total, prev, pager, next"
        :total="total"
        @current-change="handleCurrentChange"
      />

    </div>
  </div>
</template>

<script>
import { getList, getConflictRuleCode, getFlightNo, setList } from '@/api/commandWarning'

export default {
  data() {
    return {
      form: {
        conflictRuleCode: '', // 规则冲突号
        flightNo: '', // 航班号
        flightDate: '' // 航班日期
      },
      flightNoList: [], // 航班号下拉列表
      conflictRuleCodeList: [], // 航段下拉列表
      pageSize: 10, // 页码个数
      pageNum: 1, // 页数
      total: 0, // 总数

      dialogAddNew: false,

      tableData: [] // 列表数据

    }
  },

  created() {
    this.init()
    this.getConflictRuleCode()
    this.getFlightNo()
  },
  methods: {
    /**
    *查询
    */
    query() {
      this.pageNum = 1
      this.init()
    },
    /**
    *切换分页
    */
    handleCurrentChange(val) {
      this.pageNum = val
      this.init()
    },
    /**
    *初始化列表
    */
    init() {
      getList({
        pageSize: this.pageSize,
        pageNum: this.pageNum,
        ...this.form
      }).then(res => {
        if (res.data.code == '200') {
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    },
    /**
    *规则列表字典
    */
    getConflictRuleCode() {
      getConflictRuleCode().then(res => {
        if (res.data.code == '200') {
          this.conflictRuleCodeList = res.data.data
        }
      })
    },

    /**
    *航班列表字典
    */
    getFlightNo() {
      getFlightNo().then(res => {
        if (res.data.code == '200') {
          this.flightNoList = res.data.data
        }
      })
    },
    /**
    *重置按钮
    */
    reSet() {
      this.form = {
        conflictRuleCode: '', // 规则冲突号
        flightNo: '', // 航班号
        flightDate: '' // 航班日期
      }
      this.query()
    },

    /**
    *更改状态
    */
    changeState(v) {
      this.$confirm(`此操作将永久标记这条数据状态为 '已读' , 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        setList(v.id).then(res => {
          if (res.data.code == '200') {
            this.init()
            this.$message({
              type: 'success',
              message: `标记这条数据状态为 '已读' 成功!`
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: `已取消标记这条数据状态为 '已读' `
        })
      })
    }
  }

}

</script>

<style scoped >

 .title_right{
    display: flex;
    justify-content: flex-end;
  }
</style>

