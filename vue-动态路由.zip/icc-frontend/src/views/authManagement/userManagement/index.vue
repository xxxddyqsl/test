<template>
  <div class="pageBox">
    <div class="title">
      <div class="titleWord">
        <div style="font: 800 25px/50px ''; margin-left: 18px; margin-top: 18px">用户管理</div>
      </div>
      <div class="addButton">
        <el-button type="primary" size="medium" @click="addUserClick()">添 加</el-button>
      </div>
    </div>
    <div class="add-user" style="display: flex; justify-content: space-between">
      <el-form :inline="true" :model="formSelect" size="small">
        <el-form-item label="用户">
          <el-input v-model="formSelect.username" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="formSelect.status" clearable placeholder="请选择">
            <el-option v-for="(items, indexs) in statusOptions" :key="indexs" :label="items.label" :value="items.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="角色">
          <el-select v-model="formSelect.roleIds" multiple clearable collapse-tags placeholder="请选择" style="width: 188px">
            <el-option v-for="(item, index) in roleOptions" :key="index" :label="item.roleName" :value="item.roleId" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">查询</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="table-style">
      <div style="float: right; font-size: 14px">共：{{ tableData ? tableData.length : 0 }} 个用户</div>
      <el-table :data="tableData" border :header-row-style="{ 'background-color': 'rgb(10, 20, 47)' }" :row-style="{ 'background-color': '#232c47' }" style="width: 100%; color: white">
        <el-table-column prop="username" label="用户名" />
        <el-table-column prop="name" label="姓名" />
        <el-table-column prop="roleName" label="拥有角色">
          <template slot-scope="scope">
            <span>{{ scope.row.role ? scope.row.role.roleName : '' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态">
          <template slot-scope="scope">
            <span v-if="scope.row.status == 0">已禁用</span>
            <span v-if="scope.row.status == 1">有效</span>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="操作">
          <template slot-scope="scope">
            <div>
              <el-button :disabled="scope.row.source == 'LDAP' ? true : false" type="primary" size="mini" @click="handleEditClick(scope.$index, scope.row)">修 改</el-button>
              <el-button type="primary" size="mini" @click="open(scope.$index, scope.row)">删 除</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 编辑用户信息弹框 -->
    <div>
      <el-dialog title="添加新用户" :visible.sync="dialogAddVisible">
        <el-form ref="formAdd" :model="formAdd" :rules="formRules">
          <el-form-item prop="username" label="用户名" :label-width="formLabelWidth">
            <el-input v-model="formAdd.username" placeholder="请输入用户名" />
          </el-form-item>
          <el-form-item prop="name" label="名字" :label-width="formLabelWidth">
            <el-input v-model="formAdd.name" placeholder="请输入名字" />
          </el-form-item>
          <el-form-item prop="roleId" label="角色" :label-width="formLabelWidth">
            <el-select v-model="formAdd.roleId" placeholder="请选择角色">
              <el-option v-for="item in roleOptions" :key="item.roleId" :label="item.roleName" :value="item.roleId" />
            </el-select>
          </el-form-item>
          <el-form-item prop="status" label="状态" :label-width="formLabelWidth">
            <el-switch v-model="formAdd.status" active-text="启用" inactive-text="禁用" />
          </el-form-item>
          <el-form-item prop="phone" label="电话：" :label-width="formLabelWidth">
            <el-input v-model="formAdd.phone" placeholder="请输入手机号或者座机号" />
          </el-form-item>
          <el-form-item prop="email" label="邮箱：" :label-width="formLabelWidth">
            <el-input v-model="formAdd.email" placeholder="请输入邮箱" autocomplete="off" />
          </el-form-item>
          <el-form-item prop="password" label="登录密码" :label-width="formLabelWidth">
            <el-input :key="passwordType2" ref="password2" v-model="formAdd.password" placeholder="请输入密码" autocomplete="off" :type="passwordType2" name="password" />
          </el-form-item>
          <el-form-item prop="pswagain" label="确认密码" :label-width="formLabelWidth">
            <el-input :key="passwordType" ref="password" v-model="formAdd.pswagain" placeholder="请再次输入密码" autocomplete="off" :type="passwordType" name="password" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="background: #495373; color: white" @click="dialogAdd">取 消</el-button>
          <el-button type="primary" @click="handleAddConfirmClick('formAdd')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div>
      <el-dialog title="修改用户" :visible.sync="dialogEditVisible">
        <el-form ref="formEdit" :model="formEdit" :rules="formRules2">
          <el-form-item prop="username" label="用户名" :label-width="formLabelWidth">
            <el-input v-model="formEdit.username" placeholder="请输入用户名" :disabled="true" />
          </el-form-item>
          <el-form-item prop="name" label="名字" :label-width="formLabelWidth">
            <el-input v-model="formEdit.name" placeholder="请输入名字" />
          </el-form-item>
          <el-form-item prop="roleId" label="角色" :label-width="formLabelWidth">
            <el-select v-model="formEdit.roleId" placeholder="请选择角色">
              <el-option v-for="item in roleOptions" :key="item.roleId" :label="item.roleName" :value="item.roleId" />
            </el-select>
          </el-form-item>
          <el-form-item prop="status" label="状态" :label-width="formLabelWidth">
            <el-switch v-model="formEdit.status" active-text="启用" inactive-text="禁用" />
          </el-form-item>
          <el-form-item prop="phone" label="电话：" :label-width="formLabelWidth">
            <el-input v-model="formEdit.phone" placeholder="请输入手机号或者座机号" />
          </el-form-item>
          <el-form-item prop="email" label="邮箱：" :label-width="formLabelWidth">
            <el-input v-model="formEdit.email" placeholder="请输入邮箱" />
          </el-form-item>
          <el-form-item prop="password" label="登录密码" :label-width="formLabelWidth">
            <el-input ref="password2" v-model="formEdit.password" placeholder="请输入密码" autocomplete="off" :type="passwordType2" name="password" />
          </el-form-item>
          <el-form-item prop="pswagain" label="确认密码" :label-width="formLabelWidth">
            <el-input ref="password" v-model="formEdit.pswagain" placeholder="请再次输入密码" autocomplete="off" :type="passwordType" name="password" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="background: #495373; color: white" @click="dialogEdit">取 消</el-button>
          <el-button type="primary" @click="handleEditConfirmClick('formEdit')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { initData, addData, editData, removeData, validate } from '@/api/userManagement'
// import { initData2 } from '@/api/rolesManagement'
export default {
  data() {
    var validateName = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请填写用户名'))
      } else {
        validate(value).then((res) => {
          if (res.data.code === '200') {
            callback()
          } else {
            callback(new Error(res.data.message))
          }
        })
      }
    }
    var phoneValidate = (rule, value, callback) => {
      var RegExp = /^((0\d{2,3}-\d{7,8})|(1[3769584]\d{9}))$/
      if (value === '' || value == null) {
        callback()
      } else if (RegExp.test(value) === false) {
        callback(new Error('请输入正确格式的手机号或座机号'))
      } else {
        callback()
      }
    }
    var emailValidate = (rule, value, callback) => {
      var RegExp = /^[A-Za-z\d\u4e00-\u9fa5]+([-_.]+[A-Za-z\d\u4e00-\u9fa5]+)*@([A-Za-z\d\u4e00-\u9fa5])+\.[A-Za-z\d\u4e00-\u9fa5]{1,5}$/
      if (value === '' || value == null) {
        callback()
      } else if (RegExp.test(value) === false) {
        callback(new Error('请输入正确格式的邮箱'))
      } else {
        callback()
      }
    }
    var validatePass = (rule, value, callback) => {
      var regexp = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,30}$/
      if (value === '') {
        callback(new Error('请输入密码'))
      } else if (regexp.test(value) === false) {
        callback(new Error('密码最少6位，最大30位，必须包含大小写英文字母、数字、特殊符号'))
      } else {
        if (this.formAdd.pswagain !== '') {
          this.$refs.formAdd.validateField('pswagain')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.formAdd.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    // 编辑
    var validatePass1 = (rule, value, callback) => {
      if (value === '') {
        callback()
      } else if (this.formEdit.pswagain !== '') {
        this.$refs.formEdit.validateField('pswagain')
      }
      callback()
    }
    var validatePass3 = (rule, value, callback) => {
      if (value === '') {
        callback()
      } else if (value !== this.formEdit.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      titled: '',
      userId: '',
      offon: false,
      passwordType: 'password',
      passwordType2: 'password',
      dialogAddVisible: false,
      dialogEditVisible: false,
      formLabelWidth: '170px',
      formSelect: { username: '', status: '', roleIds: '' },
      statusOptions: [
        { value: 0, label: '已禁用' },
        { value: 1, label: '有效' }
      ],
      roleOptions: [],
      airportOptions: [],
      formAdd: {
        username: '',
        password: '',
        name: '',
        status: true,
        phone: '',
        email: '',
        pswagain: '',
        roleId: ''
      },
      formEdit: {
        username: '',
        name: '',
        phone: '',
        password: '',
        pswagain: '',
        status: true,
        email: '',
        roleId: ''
      },
      formRules: {
        phone: [{ required: false, validator: phoneValidate, trigger: 'blur' }],
        email: [{ required: false, validator: emailValidate, trigger: ['blur'] }],
        username: [{ required: true, trigger: 'blur', validator: validateName }],
        roleId: [{ required: true, message: '请选择角色', trigger: 'blur' }],
        status: [{ required: true, message: '请选择用户状态', trigger: 'blur' }],
        name: [
          { required: true, message: '该输入框不能为空', trigger: 'blur' },
          { max: 30, message: '最多30个字符', trigger: 'blur' },
          {
            validator: function(rule, value, callback) {
              // 校验中文的正则：/^[\u4e00-\u9fa5]{0,}$/
              if (/^[\u4e00-\u9fa5a-zA-Z-z0-9]+$/.test(value) === false) {
                callback(new Error('请输入中文、数字或字母'))
              } else {
                // 校验通过
                callback()
              }
            },
            trigger: 'blur'
          }
        ],
        password: [{ required: true, trigger: 'blur', validator: validatePass }],
        pswagain: [{ required: true, validator: validatePass2, trigger: 'blur' }]
      },
      formRules2: {
        phone: [{ required: false, validator: phoneValidate, trigger: 'blur' }],
        email: [{ required: false, validator: emailValidate, trigger: ['blur'] }],
        password: [{ trigger: 'blur', validator: validatePass1 }],
        roleId: [{ required: true, message: '请选择角色', trigger: 'blur' }],
        status: [{ required: true, message: '请选择用户状态', trigger: 'blur' }],
        pswagain: [{ validator: validatePass3, trigger: 'blur' }],
        username: [{ required: true, trigger: 'blur' }],
        name: [
          { required: true, message: '该输入框不能为空', trigger: 'blur' },
          { max: 30, message: '最多30个字符', trigger: 'blur' },
          {
            validator: function(rule, value, callback) {
              // 校验中文的正则：/^[\u4e00-\u9fa5]{0,}$/
              if (/^[\u4e00-\u9fa5a-zA-Z-z0-9]+$/.test(value) === false) {
                callback(new Error('请输入中文、数字或字母'))
              } else {
                // 校验通过
                callback()
              }
            },
            trigger: 'blur'
          }
        ]
      },
      data: {},
      tableData: []
    }
  },
  created() {
    this.init()
    this.selectData()
  },
  methods: {
    addUserClick() {
      this.dialogAddVisible = true
    },
    init() {
      initData(this.formSelect).then((response) => {
        this.tableData = response.data.data
      })
    },
    onSubmit() {
      initData(this.formSelect).then((response) => {
        this.$message.success('查询成功')
        this.tableData = response.data.data
      })
    },
    handleEditClick(index, row) {
      this.userId = row.userId
      this.formEdit.username = row.username
      this.formEdit.status = row.status
      this.formEdit.phone = row.phone
      this.formEdit.email = row.email
      this.formEdit.name = row.name

      this.formEdit.roleId = row.role ? row.role.roleId : ''
      this.dialogEditVisible = true
    },
    handleAddConfirmClick(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data = {
            username: this.formAdd.username,
            password: this.formAdd.password,
            name: this.formAdd.name,
            status: this.formAdd.status,
            phone: this.formAdd.phone,
            email: this.formAdd.email,
            pswagain: this.formAdd.pswagain,
            roleId: this.formAdd.roleId
          }
          addData(data).then((response) => {
            if (response.data.code === '200') {
              this.$message.success('新增成功')
              this.init()
            } else {
              this.$message({
                message: '新增失败',
                type: 'error'
              })
            }
          })
          this.dialogAddVisible = false
          this.$refs['formAdd'].resetFields()
        } else {
          return false
        }
      })
    },
    handleEditConfirmClick(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data2 = {
            password: this.formEdit.password,
            name: this.formEdit.name,
            status: this.formEdit.status,
            phone: this.formEdit.phone,
            email: this.formEdit.email,
            roleId: this.formEdit.roleId
          }
          if (this.formEdit.password == '') {
            delete data2.password
          }
          data2.userId = this.userId
          editData(data2).then((response) => {
            if (response.data.code === '200') {
              this.$message.success('编辑成功')
              this.init()
            } else {
              this.$message({
                message: '编辑失败',
                type: 'error'
              })
            }
          })
          this.dialogEditVisible = false
          this.$refs['formEdit'].resetFields()
        } else {
          return false
        }
      })
    },
    selectData() {
      var data = ''
      initData2(data).then((response) => {
        this.roleOptions = response.data.data
      })
    },
    open(index, row) {
      this.$confirm('确认删除这条数据吗？', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消'
      })
        .then(() => {
          removeData(row.userId).then((response) => {
            if (response.data.code === '200') {
              this.init()
            }
            this.$message({
              type: 'success',
              message: '删除成功'
            })
          })
        })
        .catch(() => {})
    },
    dialogAdd() {
      this.dialogAddVisible = false
      this.offon = false
      this.$refs['formAdd'].resetFields()
    },
    dialogEdit() {
      this.dialogEditVisible = false
      this.$refs['formEdit'].resetFields()
    }
  }
}
</script>
<style lang="scss" scoped>
$dark_gray: #889aa4;
.box {
  margin-top: 60px;
}
.add-user {
  width: 100%;
  padding: 20px 0 0 20px;
  .el-form {
    .el-input,
    .el-select {
      width: 150px;
    }
  }
}
.title {
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
  padding: 5px 10px;
  background-color: #0a142f;
}
.titleWord {
  width: 50%;
  display: flex;
  align-items: center;
}
.table-style {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding: 0 20px;
}
.show-pwd {
  position: absolute;
  right: 10px;
  top: 7px;
  font-size: 16px;
  color: $dark_gray;
  cursor: pointer;
  user-select: none;
}
</style>
