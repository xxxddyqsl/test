<template>
  <div class="user-box">
    <div class="title">
      <div class="titleWord">
        <div style="font:800 25px/50px '';margin-left:18px;margin-top:18px">修改密码</div>
      </div>
      <div class="addButton" />
    </div>
    <div class="box">
      <el-form ref="formEdit" :model="formEdit" :rules="formRules">
        <el-form-item prop="oldPassword" label="旧密码" :label-width="formLabelWidth">
          <el-input v-model="formEdit.oldPassword" placeholder="请输入旧密码" :type="passwordType" auto-complete="off" />
        </el-form-item>
        <el-form-item prop="password" label="新密码" :label-width="formLabelWidth">
          <el-input :key="passwordType" ref="password" v-model="formEdit.password" placeholder="请输入新密码" :type="passwordType" name="password" />

        </el-form-item>
        <el-form-item label="确认密码" prop="passwordAgin" :label-width="formLabelWidth">
          <el-input v-model="formEdit.passwordAgin" placeholder="请确认密码" :type="passwordType" />
        </el-form-item>
        <el-form-item style=" text-align: center;">
          <el-button size="small" @click="cancel">取 消</el-button>
          <el-button size="small" type="primary" @click="handleEditConfirmClick('formEdit')">确 定</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { editPass } from '@/api/userManagement'
export default {
  data() {
    var validatePass = (rule, value, callback) => {
      var regexp = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,30}$/
      if (value === '') {
        callback(new Error('请输入密码'))
      } else if (regexp.test(value) === false) {
        callback(new Error('密码最少6位，最大30位，必须包含大小写英文字母、数字、特殊符号'))
      } else {
        if (this.formAdd.pswagain !== '') {
          this.$refs.formAdd.validateField('pswagain')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.formEdit.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      formLabelWidth: '170px',
      passwordType: 'password',
      titled: '',
      formEdit: {
        oldPassword: '',
        passwordAgin: '',
        password: ''
      },
      formRules: {
        oldPassword: [{ required: true, message: '请输入旧密码', trigger: 'blur' }],
        password: [{ required: true, trigger: 'blur', validator: validatePass }],
        passwordAgin: [{ required: true, validator: validatePass2, trigger: 'blur' }]
      },
      data: []
    }
  },
  created() {

  },
  methods: {
    cancel() {
      this.$confirm('本次修改的数据将丢失，确认不保存？', '提示', {
        confirmButtonText: '不保存',
        cancelButtonText: '返回'
      })
        .then(() => {
          this.$router.push({ path: '/dashboard' })
        })
        .catch(() => {})
    },
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    },
    handleEditConfirmClick(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.formEdit.userId = this.$route.query.userId
          editPass(this.formEdit).then(response => {
            if (response.data.code === '200') {
              this.$message.success('编辑成功')
              this.$store.dispatch('user/logout').then(() => { this.$router.push({ path: this.redirect || '/login' }) }).catch(() => {})
            } else {
              this.$message({
                message: '编辑失败',
                type: 'error'
              })
            }
          })
        } else {
          return false
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
$dark_gray: #889aa4;
.user-box {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding: 60px 10px 10px 10px;
}

.box {
  margin: 30px 0;
  margin-bottom: 80px;

  .el-form {
    width: 60%;
    margin: 100px auto;
    .el-tree {
      width: 40%;
    }
    .el-input,
    .el-select {
      width: 40%;
    }
  }
}
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 7px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }
.el-tree-node__labe{
    margin-left: 6px;
}
.boxChart {
  min-height: 500px;
  display: flex;
  flex-wrap: wrap;
}
</style>
