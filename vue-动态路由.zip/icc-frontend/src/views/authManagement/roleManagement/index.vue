<template>
  <div class="pageBox">
    <div class="title">
      <div class="titleWord">
        <div style="font: 800 25px/50px ''; margin-left: 18px; margin-top: 18px">系统角色权限</div>
      </div>
      <div class="addButton">
        <el-button type="primary" size="medium" @click="addUserClick()">添 加</el-button>
      </div>
    </div>
    <div class="add-user" style="display: flex; justify-content: space-between">
      <el-form :inline="true" :model="formSelect" size="small">
        <el-form-item label="名称">
          <el-input v-model="formSelect.name" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">查询</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="table-style">
      <div style="float: right; font-size: 14px">共：{{ tableData ? tableData.length : 0 }} 个角色</div>
      <el-table :data="tableData" border :header-row-style="{ 'background-color': 'rgb(10, 20, 47)' }" :row-style="{ 'background-color': '#232c47' }" style="width: 100%; color: white">
        <el-table-column prop="roleName" label="名称" />
        <el-table-column prop="roleCode" label="角色编码" />
        <el-table-column fixed="right" label="操作">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="handleEditClick(scope.$index, scope.row)">修 改</el-button>
            <el-button type="primary" size="mini" @click="open(scope.$index, scope.row)">删 除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
// import { initData, removeData } from '@/api/rolesManagement'
export default {
  data() {
    return {
      formLabelWidth: '170px',

      roleOptions: [],
      formEdit: {},
      formSelect: {
        name: ''
      },
      data: {},
      tableData: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      }
    }
  },
  watch: {},

  created() {
    this.initial()
  },
  methods: {
    addUserClick() {
      this.$router.push({ path: '/authManagement/editAdd' })
    },
    initial() {
      initData(this.formSelect.name).then((response) => {
        this.tableData = response.data.data
      })
    },
    onSubmit() {
      initData(this.formSelect.name).then((response) => {
        this.tableData = response.data.data
        this.$message.success('查询成功')
      })
    },
    handleEditClick(index, row) {
      this.$router.push({ path: '/authManagement/editAdd', query: { id: row.roleId }})
    },
    open(index, row) {
      this.$confirm('确认要删除这条数据吗？', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          removeData(row.roleId).then((response) => {
            if (response.data) {
              this.initial()
              this.$message({
                type: 'success',
                message: response.data.message
              })
            } else {
              this.$message({
                type: 'error',
                message: response.data.message
              })
            }
          })
        })
        .catch((error) => {
          this.$message({
            type: 'error',
            message: error.response.data.message
          })
        })
    }
  }
}
</script>
<style lang="scss" scoped>
.box {
  margin-top: 60px;
}
.add-user {
  width: 100%;
  padding: 20px 0 0 20px;
  .el-form {
    .el-input,
    .el-select {
      width: 150px;
    }
  }
}
.title {
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
  padding: 5px 10px;
  background-color: #0a142f;
}
.titleWord {
  width: 50%;
  display: flex;
  align-items: center;
}
.table-style {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding: 0 20px;
}
</style>
