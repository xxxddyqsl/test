<template>
  <div class="user-box">
    <div class="box">
      <el-form ref="formEdit" :model="formEdit" :rules="formRules">
        <el-form-item prop="roleName" label="名称" :label-width="formLabelWidth">
          <el-input v-model="formEdit.roleName" placeholder="请输入名字" />
        </el-form-item>
        <el-form-item prop="roleCode" label="角色编码" :label-width="formLabelWidth">
          <el-input v-model="formEdit.roleCode" placeholder="请输入编码" />
        </el-form-item>
        <el-form-item prop="roleType" label="角色类型" :label-width="formLabelWidth">
          <el-select v-model="formEdit.roleType" placeholder="请选择" @change="changeClick(formEdit.roleType)">
            <el-option v-for="(item2,index2) in optionsData" :key="index2" :label="item2.name" :value="item2.id" />
          </el-select>
        </el-form-item>
        <el-form-item v-if="formEdit.roleType==='BRANCH'" prop="airportIds" label="机场" :label-width="formLabelWidth">
          <el-select v-model="formEdit.airportIds" placeholder="请选择" multiple clearable collapse-tags>
            <el-option v-for="(item2,index2) in airportIdoptions" :key="index2" :label="item2.airportName" :value="item2.airportId" />
          </el-select>
        </el-form-item>
        <el-form-item label="选择业务节点" :label-width="formLabelWidth">
          <el-tree ref="tree" :data="data" show-checkbox node-key="pageId" :props="defaultProps" />
        </el-form-item>
        <el-form-item style=" text-align: center;">
          <el-button size="small" style="right:150px" @click="cancel">取 消</el-button>
          <el-button size="small" style="right:60px" type="primary" @click="handleEditConfirmClick('formEdit')">确 定</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
// import { saveData, editData, editSaveData, airportsData, withTypes } from '@/api/rolesManagement'
export default {
  data() {
    return {
      formLabelWidth: '170px',
      titled: '',
      formEdit: {
        roleName: '',
        roleCode: '',
        roleType: '',
        airportIds: []
      },
      airportIds: [],
      airportIdoptions: [],
      optionsData: [
        {
          id: 'BRANCH',
          name: '分子公司'
        },
        {
          id: 'PLAN',
          name: '规划部'
        }, {
          id: 'IT',
          name: '信息部'
        }
      ],
      formRules: {
        roleName: [{ required: true, message: '该输入框不能为空', trigger: 'blur' }, { max: 30, message: '最多30个字符', trigger: 'blur' }, { validator: function(rule, value, callback) {
          // 校验中文的正则：/^[\u4e00-\u9fa5]{0,}$/
          if (/^[\u4e00-\u9fa5a-zA-Z-z0-9]+$/.test(value) === false) {
            callback(new Error('请输入中文、数字或字母'))
          } else {
            // 校验通过
            callback()
          }
        }, trigger: 'blur'
        }],
        airportIds: [{ required: true, message: '该选择不能为空', trigger: 'change' }],
        roleType: [{ required: true, message: '该选择不能为空', trigger: 'change' }],
        roleCode: [{ required: true, message: '该输入框不能为空', trigger: 'blur' }, { max: 30, message: '最多30个字符', trigger: 'blur' }, { validator: function(rule, value, callback) {
          // 校验中文的正则：/^[\u4e00-\u9fa5]{0,}$/
          if (/^[a-zA-Z]+$/.test(value) === false) {
            callback(new Error('请输入字母'))
          } else {
            // 校验通过
            callback()
          }
        }, trigger: 'blur'
        }]
      },
      data: [],
      defaultProps: {
        children: 'children',
        label: 'name'
      }
    }
  },
  watch: {
    'formEdit.roleType': {
      deep: true,
      handler(newName, oldName) {
        this.formEdit.roleType = newName
        this.changeClick(this.formEdit.roleType)
      }
    }
  },
  created() {
    this.airportsData()
    if (this.$route.query.id) {
      editData(this.$route.query.id).then(response => {
        this.$refs.tree.setCheckedKeys(response.data.data.selectedPageIds)
        console.log(this.formEdit.airportIds)
        response.data.data.airports.forEach(element => {
          this.airportIds.push(element.airportId)
        })
        this.formEdit = {
          roleName: response.data.data.roleName,
          roleType: response.data.data.roleType,
          roleCode: response.data.data.roleCode,
          airportIds: this.airportIds
        }
      })
    }
  },
  methods: {
    changeClick(data) {
      withTypes(data).then(res => {
        this.data = res.data.data
      })
    },
    cancel() {
      this.$confirm('本次修改的数据将丢失，确认不保存？', '提示', {
        confirmButtonText: '不保存',
        cancelButtonText: '返回'
      })
        .then(() => {
          this.$router.push({ path: '/authManagement/roleManagement' })
        })
        .catch(() => {})
    },
    handleEditConfirmClick(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.$route.query.id) {
            this.formEdit.roleId = this.$route.query.id
            this.formEdit.pageIds = this.$refs.tree.getHalfCheckedKeys().concat(this.$refs.tree.getCheckedKeys())
            editSaveData(this.formEdit).then(response => {
              if (response.data.code === '200') {
                this.$message.success(response.data.message)
                this.$router.push({ path: '/authManagement/roleManagement' })
              } else {
                this.$message.error(response.data.message)
                this.$router.push({ path: '/authManagement/roleManagement' })
              }
            })
          } else {
            var data = {
              roleName: this.formEdit.roleName,
              roleType: this.formEdit.roleType,
              roleCode: this.formEdit.roleCode,
              airportIds: this.formEdit.airportIds,
              pageIds: this.$refs.tree.getCheckedKeys()
            }
            saveData(data).then(response => {
              if (response.data.code === '200') {
                this.$message.success('新增成功')
                this.$router.push({ path: '/authManagement/roleManagement' })
              } else {
                this.$message.error(response.data.message)
              }
            })
          }
        } else {
          return false
        }
      })
    },
    airportsData() {
      airportsData().then(response => {
        this.airportIdoptions = response.data.data
      })
    },
    dialogEdit() {}
  }
}
</script>
<style lang="scss" scoped>
.user-box {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding: 60px 10px 10px 10px;
}

.box {
  margin: 30px 0;
  margin-bottom: 80px;

  .el-form {
    width: 60%;
    margin: 100px auto;
    .el-tree {
      width: 40%;
    }
    .el-input,
    .el-select {
      width: 40%;
    }
  }
}
.el-tree-node__labe{
    margin-left: 6px;
}
.boxChart {
  min-height: 500px;
  display: flex;
  flex-wrap: wrap;
}
</style>
