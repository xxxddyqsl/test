<template>
  <div class="menuList">
    <div style="margin-bottom: 16px;">
      <el-button type="primary" @click="handleCreateGroup()"
        ><i class="el-icon-plus" size="small"></i> 添加</el-button
      >
    </div>
    <el-table
      :data="menu"
      style="width: 100%;margin-bottom: 20px;"
      row-key="menu_id"
      border
      :default-expand-all="!1"
      :tree-props="{ children: 'sub_menu' }"
    >
      <el-table-column label="ID" prop="menu_id" width="100"></el-table-column>
      <el-table-column
        label="菜单名称"
        prop="menu_name"
        width="120"
      ></el-table-column>
      <el-table-column label="pid" prop="pid" width="60"></el-table-column>
      <el-table-column
        label="组件ID"
        prop="route_url"
        min-width="100"
      ></el-table-column>
      <el-table-column
        label="接口地址"
        prop="api_url"
        min-width="120"
      ></el-table-column>
      <el-table-column
        label="排序"
        prop="sort_id"
        width="100"
      ></el-table-column>
      <el-table-column
        label="学科ID"
        prop="subject_id"
        width="100"
      ></el-table-column>
      <el-table-column label="操作" width="150">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleeditMenu(scope.row)"
            ><i class="el-icon-edit"></i
          ></el-button>
          <el-button
            size="mini"
            @click="hanleDeleteComfirm(scope.row)"
            type="danger"
            ><i class="el-icon-delete"></i
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :visible.sync="dialogConfirm">
      <el-form
        ref="tempMenu"
        label-position="right"
        :rules="rules"
        label-width="120px"
        style="margin-left:50px"
        :model="tempMenu"
      >
        <el-form-item label="菜单名称" class="demo-ruleForm" prop="menu_name">
          <el-input style="width: 80%" v-model="tempMenu.menu_name"></el-input>
        </el-form-item>
        <el-form-item label="菜单：" v-if="treeStatus == 'open'">
          <el-tree
            style="margin-left:50px"
            :data="menuall"
            show-checkbox
            node-key="menu_id"
            check-strictly
            ref="tree"
            @check-change="handleClick"
            :props="defaultProps"
          >
          </el-tree>
        </el-form-item>
        <el-form-item label="组件地址" class="demo-ruleForm">
          <el-input style="width: 80%" v-model="tempMenu.route_url"></el-input>
        </el-form-item>
        <el-form-item label="接口地址" class="demo-ruleForm">
          <el-input style="width: 80%" v-model="tempMenu.api_url"></el-input>
        </el-form-item>
        <el-form-item label="排序" class="demo-ruleForm" prop="sort_id">
          <el-input style="width: 80%" v-model="tempMenu.sort_id"></el-input>
        </el-form-item>
        <el-form-item label="学科ID" class="demo-ruleForm">
          <el-input style="width: 80%" v-model="tempMenu.subject_id"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button
          v-if="editStatus == 'create'"
          @click="createNewGroup('tempMenu')"
          type="primary"
          :disabled="isDisabled"
          >确定</el-button
        >
        <el-button
          v-if="editStatus == 'edit'"
          @click="editMenu(currentMenuId)"
          type="primary"
          :disabled="isDisabled"
          >确定</el-button
        >
        <el-button @click="dialogConfirm = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<style lang="scss" scoped>
.menuList {
  padding: 16px;
}
</style>
<script>
// import { mapGetters } from 'vuex'
// import treeTable from '@/components/TreeTable'
// import treeToArray from './customEval'
// import { menuAdd, menuInfo, menuDel, menuEdit } from '@/api/table.js'

export default {
  name: "treeTableDemo",
  components: { treeTable },
  data() {
    return {
      dialogConfirm: false,
      updateStatus: "update",
      editStatus: "",
      treeStatus: "",
      columns: [
        {
          text: "ID",
          value: "menu_id"
        },
        {
          text: "菜单名称",
          value: "menu_name"
        },
        {
          text: "父ID",
          value: "pid"
        },
        {
          text: "组件ID",
          value: "route_url"
        },
        {
          text: "接口地址",
          value: "api_url"
        },
        {
          text: "菜单状态",
          value: "is_menu"
        }
      ],
      data: [
        {
          id: 0,
          event: "事件1",
          timeLine: 50,
          comment: "无"
        },
        {
          id: 1,
          event: "事件1",
          timeLine: 100,
          comment: "无",
          children: [
            {
              id: 2,
              event: "事件2",
              timeLine: 10,
              comment: "无"
            },
            {
              id: 3,
              event: "事件3",
              timeLine: 90,
              comment: "无",
              children: [
                {
                  id: 4,
                  event: "事件4",
                  timeLine: 5,
                  comment: "无"
                },
                {
                  id: 5,
                  event: "事件5",
                  timeLine: 10,
                  comment: "无"
                },
                {
                  id: 6,
                  event: "事件6",
                  timeLine: 75,
                  comment: "无",
                  children: [
                    {
                      id: 7,
                      event: "事件7",
                      timeLine: 50,
                      comment: "无",
                      children: [
                        {
                          id: 71,
                          event: "事件71",
                          timeLine: 25,
                          comment: "xx"
                        },
                        {
                          id: 72,
                          event: "事件72",
                          timeLine: 5,
                          comment: "xx"
                        },
                        {
                          id: 73,
                          event: "事件73",
                          timeLine: 20,
                          comment: "xx"
                        }
                      ]
                    },
                    {
                      id: 8,
                      event: "事件8",
                      timeLine: 25,
                      comment: "无"
                    }
                  ]
                }
              ]
            }
          ]
        }
      ],
      tempMenu: {
        menu_name: "",
        pid: "",
        route_url: "",
        api_url: "",
        is_menu: "",
        sort_id: "",
        subject_id: ""
      },
      tempEdit: {
        menu_id: "",
        menu_name: "",
        pid: "",
        route_url: "",
        api_url: "",
        is_menu: "",
        sort_id: "",
        subject_id: ""
      },
      tempMenuAdd: {
        menu_name: "",
        pid: "",
        route_url: "",
        api_url: "",
        is_menu: "",
        sort_id: "",
        subject_id: ""
      },
      currentMenuId: "",
      selectPid: {
        pid: ""
      },
      parentId: {
        pid: ""
      },
      defaultProps: {
        children: "sub_menu",
        label: "menu_name"
      },
      i: 0,
      rules: {
        menu_name: [
          { required: true, message: "请输入菜单名称", trigger: "change" }
        ],
        sort_id: [{ required: true, message: "请输入排序", trigger: "change" }]
      },
      isSubmit: false,
      isDisabled: false
    };
  },
  methods: {
    getMenuList() {
      this.$store.dispatch("getMenuList").then(response => {});
    },
    getMenuAll() {
      this.$store.dispatch("getMenuAll").then(response => {});
    },
    // 刷新
    // handleUpdate(){
    //   this.updateStatus = 'update'
    //   this.updateData()
    // },
    // 刷新成功
    updateData() {
      this.$store.dispatch("getMenuList").then(response => {
        if (this.updateStatus == "update") {
          this.$notify({
            title: "成功",
            message: "刷新成功",
            type: "success",
            duration: 2000
          });
        }
      }),
        this.getMenuAll();
    },
    resetTemp() {
      this.tempMenu = {
        menu_name: "",
        pid: "",
        route_url: "",
        api_url: "",
        is_menu: "",
        sort_id: "",
        subject_id: ""
      };
      this.defalutCheckedNode = [];
    },
    // 添加
    handleCreateGroup() {
      this.resetTemp();
      this.editStatus = "create";
      this.treeStatus = "open";
      this.dialogConfirm = true;
      this.getMenuAll();
      this.$nextTick(() => {
        this.$refs["tempMenu"].clearValidate();
      });
    },
    // 下拉框pid
    handleClick(data, checked, node) {
      // console.log(data.pid)
      this.parentId.pid = data.pid;
      if (checked) {
        this.$refs.tree.setCheckedNodes([]);
        this.$refs.tree.setCheckedNodes([data]);
        // console.log(this.$refs.tree.getCheckedKeys())
        this.selectPid.pid = this.$refs.tree.getCheckedKeys()[0];
        // console.log(this.selectPid.pid)
        // 交叉点击节点
      }
      // this.i++;
      // if(this.i%2==0){
      //   //console.log(this.i)
      //   if(checked){
      //     this.$refs.tree.setCheckedNodes([]);
      //     this.$refs.tree.setCheckedNodes([data]);
      //     // console.log(this.$refs.tree.getCheckedKeys())
      //     this.selectPid.pid =this.$refs.tree.getCheckedKeys()[0]
      //      console.log(this.selectPid.pid)
      //     //交叉点击节点
      //   }else{
      //     this.$refs.tree.setCheckedNodes([]);
      //     this.selectPid.pid =this.$refs.tree.getCheckedKeys()[0]
      //     console.log(this.selectPid.pid)
      //     //点击已经选中的节点，置空
      //   }
      // }
    },
    // handleNodeClick(data) {
    //   // console.log(data.menu_id)
    //   this.selectPid.pid = data.menu_id
    //   console.log(this.selectPid.pid)
    // },
    // 确定添加
    createNewGroup(formName) {
      console.log(this.$refs.tree.getCheckedKeys() + "9999");
      console.log(this.selectPid.pid);
      if (this.selectPid.pid == "") {
        this.tempMenuAdd.menu_name = this.tempMenu.menu_name;
        this.tempMenuAdd.route_url = this.tempMenu.route_url;
        this.tempMenuAdd.api_url = this.tempMenu.api_url;
        this.tempMenuAdd.menu_id = this.$refs.tree.getCheckedKeys();
        this.tempMenuAdd.sort_id = this.tempMenu.sort_id;
        this.tempMenuAdd.subject_id = this.tempMenu.subject_id;
        this.tempMenuAdd.pid = 0;
        this.tempMenuAdd.is_menu = 1;
      } else {
        if (this.parentId.pid == 0) {
          this.tempMenuAdd.menu_name = this.tempMenu.menu_name;
          this.tempMenuAdd.route_url = this.tempMenu.route_url;
          this.tempMenuAdd.api_url = this.tempMenu.api_url;
          this.tempMenuAdd.menu_id = this.$refs.tree.getCheckedKeys();
          this.tempMenuAdd.sort_id = this.tempMenu.sort_id;
          this.tempMenuAdd.subject_id = this.tempMenu.subject_id;
          this.tempMenuAdd.pid = this.selectPid.pid;
          this.tempMenuAdd.is_menu = 1;
        } else if (this.parentId.pid > 0) {
          this.tempMenuAdd.menu_name = this.tempMenu.menu_name;
          this.tempMenuAdd.route_url = this.tempMenu.route_url;
          this.tempMenuAdd.api_url = this.tempMenu.api_url;
          this.tempMenuAdd.menu_id = this.tempMenu.menu_id;
          this.tempMenuAdd.sort_id = this.tempMenu.sort_id;
          this.tempMenuAdd.subject_id = this.tempMenu.subject_id;
          this.tempMenuAdd.pid = this.selectPid.pid;
          this.tempMenuAdd.is_menu = 0;
        }
      }
      this.$refs[formName].validate(valid => {
        if (valid && !this.isSubmit) {
          this.isSubmit = true;
          this.isDisabled = true;
          console.log(this.tempMenuAdd);
          this.DoubleDefault = true;
          menuAdd(this.tempMenuAdd)
            .then(response => {
              this.isSubmit = false;
              if (this.timer) clearTimeout(this.timer);
              this.timer = setTimeout(() => {
                this.isDisabled = false;
              }, 2000);
              if (response.code == 200) {
                this.dialogConfirm = false;
                this.updateStatus = "after";
                this.updateData();
                this.$notify({
                  title: "成功",
                  message: "创建成功",
                  type: "success",
                  duration: 2000
                });
              }
            })
            .catch(() => {
              console.log("error");
              this.isSubmit = false;
              if (this.timer) clearTimeout(this.timer);
              this.timer = setTimeout(() => {
                this.isDisabled = false;
              }, 2000);
            });
        } else {
          this.$message({
            message: "提交失败，请填写完整信息",
            type: "warning"
          });
          return false;
        }
      });
    },
    child1(e) {
      console.info(e);
    },
    // 删除
    hanleDeleteComfirm(row) {
      this.$confirm("删除后可能无法恢复, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        center: true
      })
        .then(() => {
          this.deleteGroup(row);
        })
        .catch(() => {});
    },
    // 确定删除
    deleteGroup(row) {
      var delInfo = {};
      delInfo.menu_id = row.menu_id;
      console.log(delInfo);
      menuDel(delInfo).then(reponse => {
        this.updateStatus = "after";
        this.updateData();
        this.$notify({
          title: "成功",
          message: "删除成功",
          type: "success",
          duration: 2000
        });
      });
    },
    // 编辑
    handleeditMenu(row) {
      this.editStatus = "edit";
      this.treeStatus = "close";
      this.dialogConfirm = true;
      this.currentMenuId = row.menu_id;
      menuInfo({ menu_id: this.currentMenuId }).then(response => {
        this.tempMenu = response.data;
        this.defalutCheckedNode = response.data.roles
          ? response.data.roles.split(",").map(function(data) {
              return +data;
            })
          : "";
        console.log(this.defalutCheckedNode);
        this.defalutCheckedNode &&
          this.$refs.tree.setCheckedKeys(this.defalutCheckedNode);
        this.tempMenu.menu_name = response.data.menu_name;
      });
    },
    // 确定编辑
    editMenu(menu_id) {
      let Info = { ...this.tempMenu, menu_id: menu_id };
      this.$refs["tempMenu"].validate(valid => {
        if (valid && !this.isSubmit) {
          this.isSubmit = true;
          this.isDisabled = true;
          menuEdit(Info)
            .then(response => {
              this.isSubmit = false;
              if (this.timer) clearTimeout(this.timer);
              this.timer = setTimeout(() => {
                this.isDisabled = false;
              }, 2000);
              if (response.code == 200) {
                this.$store.dispatch("getMenuList").then(response => {
                  this.dialogConfirm = false;
                  this.$notify({
                    title: "成功",
                    message: "修改成功",
                    type: "success",
                    duration: 2000
                  });
                });
              }
            })
            .catch(() => {
              console.log("error");
              this.isSubmit = false;
              if (this.timer) clearTimeout(this.timer);
              this.timer = setTimeout(() => {
                this.isDisabled = false;
              }, 2000);
            });
          for (const v of this.menu) {
            if (v.menu_id === this.tempEdit.menu_id) {
              const index = this.menu.indexOf(v);
              console.log(index);
              this.menu.splice(index, 1, this.tempEdit);
              break;
            }
          }
          this.dialogConfirm = false;
        } else {
          this.$message({
            message: "提交失败，请填写完整信息",
            type: "warning"
          });
          return false;
        }
      });
    }
  },
  created() {
    this.getMenuList();
  },
  computed: {
    ...mapGetters(["menu", "menuall"])
  }
};
</script>
