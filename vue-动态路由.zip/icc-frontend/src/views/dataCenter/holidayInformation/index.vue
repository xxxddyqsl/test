<template>
  <div>
    <div class="">
      <!-- <div class="title_left" /> -->
      <div class="">
        <el-form :inline="true">
          <el-form-item>
            <el-select
              v-model="year"
              placeholder="请选择年份"
              size="mini"
              style="width: 120px"
            >
              <el-option
                v-for="item in yearList"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="yearDate"
              placeholder="请选择节日"
              clearable
              size="mini"
              style="width: 120px"
            >
              <el-option
                v-for="item in selectoption"
                :key="item.holidayName"
                :label="item.holidayName"
                :value="item.holidayName"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              size="mini"
              @click="init('查询')"
            >查询</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="goDefinition"
            >节假日定义</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="holidayName" label="节假日" />
        <el-table-column prop="holidayType" label="节假日属性" />
        <el-table-column prop="holidayScope" label="节假日范围">
          <template slot-scope="scope">
            {{ scope.row.beginDate }} 至 {{ scope.row.endDate }}
          </template>
        </el-table-column>
        <el-table-column prop="holidayDate" label="节日日期">
          <template slot-scope="scope">
            {{ scope.row.holidayDateBeginDate
            }}{{
              scope.row.holidayDateBeginDate === scope.row.holidayDateEndDate
                ? ""
                : " 至 " + scope.row.holidayDateEndDate
            }}
          </template>
        </el-table-column>
        <el-table-column prop="holidayDays" label="节假日天数" />
        <el-table-column prop="updateTime" label="更新日期" />
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              style="margin: 0 5px"
              type="primary"
              size="mini"
              @click="amendClick(scope.row)"
            >修改</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        :page-size="page.pageSize"
        layout="total, prev, pager, next"
        :total="page.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
    <div>
      <el-dialog v-dialogDrag :title="title" :visible.sync="dialogFormVisible">
        <el-form ref="formEdit" :model="formEdit" :rules="formRules">
          <el-form-item
            prop="holidayYear"
            label="年份："
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="formEdit.holidayYear"
              placeholder="请输入"
              disabled
            />
          </el-form-item>
          <el-form-item
            prop="holidayName"
            label="节假日名称："
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="formEdit.holidayName"
              placeholder="请输入"
              disabled
            />
          </el-form-item>
          <el-form-item
            prop="holidayType"
            label="节假日属性："
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="formEdit.holidayType"
              placeholder="请输入"
              disabled
            />
          </el-form-item>
          <el-form-item
            prop="holidayScopeDate"
            label="节假日范围："
            :label-width="formLabelWidth"
          >
            <el-date-picker
              v-model="formEdit.holidayScopeDate"
              :picker-options="pickerOptions"
              type="daterange"
              range-separator="至"
              value-format="yyyy-MM-dd"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            />
          </el-form-item>
          <el-form-item
            v-if="formEdit.holidayType !== '自定义节假日'"
            prop="holidayDate"
            label="节假日日期："
            :label-width="formLabelWidth"
          >
            <el-date-picker
              v-model="formEdit.holidayDate"
              :picker-options="pickerOptions2"
              type="daterange"
              range-separator="至"
              value-format="yyyy-MM-dd"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button
            type="primary"
            @click="handleEditClick('formEdit')"
          >确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { initData, update, selectOption } from '@/api/holidayInformation'
export default {
  data() {
    return {
      title: '新增',

      dialogFormVisible: false,
      tableData: [],
      yearDate: '',
      year: new Date().getFullYear(),
      selectoption: '',
      formEdit: {
        holidayYear: '',
        holidayName: '',
        holidayType: '',
        holidayScopeDate: '',
        holidayDate: ''
      },
      date: new Date(),
      formLabelWidth: '120px',
      formRules: {
        holidayDate: [
          { required: true, message: '请输入时间', trigger: 'change' }
        ],
        holidayScopeDate: [
          { required: false, message: '请输入时间', trigger: 'change' }
        ]
      },
      pickerOptions: {
        disabledDate: (time) => {
          return (
            time.getTime() >
              new Date(
                (this.year ? this.year : new Date().getFullYear()) + ' 12-31'
              ).getTime() ||
            time.getTime() <
              new Date(
                (this.year ? this.year : new Date().getFullYear()) + ' 01-01'
              ).getTime()
          )
        }
      },
      pickerOptions2: {
        disabledDate: (time) => {
          return (
            time.getTime() <
              new Date(this.formEdit.holidayScopeDate[0]).getTime() ||
            time.getTime() >
              new Date(this.formEdit.holidayScopeDate[1]).getTime()
          )
        }
      },
      page: {
        pageSize: 10,
        pageNum: '1',
        currentPage: '1',
        total: 0
      },
      yearList: []
    }
  },
  created() {
    this.init()
    this.selectOptionFcn()
    for (var i = 1; i < 2036; i++) {
      if (i > 2014) {
        this.yearList.push(i)
      }
    }
  },
  methods: {
    // 初始化
    init(params) {
      var data = {
        holidayName: this.yearDate,
        holidayYear: this.year
      }
      var condition = Object.assign(data, this.page)
      initData(condition).then((res) => {
        this.tableData = res.data.data.rows
        this.page.total = res.data.data.total
        if (params) {
          this.$message.success('查询成功')
        }
      })
    },
    addNew() {
      this.dialogAddNew = true
    },
    goDefinition() {
      this.$router.push({ path: '/dataCenter/definition' })
    },
    /**
     * 打开修改弹窗
     */
    amendClick(data) {
      this.dialogFormVisible = true
      this.formEdit.holidayYear = data.holidayYear
      this.formEdit.holidayName = data.holidayName
      this.formEdit.holidayType = data.holidayType
      if (data.beginDate) {
        this.formEdit.holidayScopeDate = [data.beginDate, data.endDate]
      } else {
        this.formEdit.holidayScopeDate = []
      }
      if (data.holidayDateBeginDate) {
        this.formEdit.holidayDate = [
          data.holidayDateBeginDate,
          data.holidayDateEndDate
        ]
      } else {
        this.formEdit.holidayDate = []
      }
      this.id = data.id
      this.form.title = '修改'
    },
    /**
     * 确定修改
     */
    handleEditClick() {
      this.$refs['formEdit'].validate((valid) => {
        if (valid) {
          var data = {
            id: this.id,
            holidayYear: this.formEdit.holidayYear,
            holidayName: this.formEdit.holidayName,
            holidayType: this.formEdit.holidayType,
            scopeBeginDate: this.formEdit.holidayScopeDate[0],
            scopeEndDate: this.formEdit.holidayScopeDate[1],
            holidayBeginDate: this.formEdit.holidayDate[0],
            holidayEndDate: this.formEdit.holidayDate[1]
          }
          update(data).then((res) => {
            if (res.data.code == 200) {
              this.$message.success('修改成功')
              this.dialogFormVisible = false
              this.init()
            } else {
              this.$message({
                type: 'error',
                message: res.data.message
              })
            }
          })
        }
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.init()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.init()
    },
    /**
     * 下拉框
     */
    selectOptionFcn() {
      selectOption(this.date.getFullYear()).then((res) => {
        this.selectoption = res.data.data
      })
    }
  }
}
</script>

<style scoped lang="scss">
.box {
  margin-top: 60px;
}

#calendar {
  width: 400px;
  height: 450px;
  margin: 0 auto;
  box-shadow: 0 0 10px 0;
  border-radius: 10px;
  padding: 10px;
  position: relative;
  top: -100px;
  z-index: 9699;
  background-color: #fff;
}
::v-deep .fc-body {
  .fc-scroller {
    height: auto !important;
    tr {
      td {
        span {
          float: none;
          width: 100%;
          height: 20px;
          display: block;
          text-align: center;
        }
      }
    }
  }
}
 ::v-deep .el-form-item{
    margin-bottom: 0;
  }
</style>
