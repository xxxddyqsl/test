<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form  :inline="true">
          <el-form-item>
            <el-input v-model="holidayName" placeholder="节假日名称" size="mini" style="width: 120px" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="holidayType" clearable size="mini" style="width: 120px">
              <el-option
                v-for="item in holidayTypeoptions"
                :key="item"
                :label="item"
                :value="item"
                placeholder="节假日属性"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="init">查询</el-button>
            <el-button type="primary" size="mini" @click="addUser">新增</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="black"
            >返回</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData">
        <el-table-column prop="holidayName" label="节假日名称" />
        <el-table-column prop="holidayType" label="节假日属性" />
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button style="margin:0 5px" type="primary" size="mini" @click="amendClick(scope.row)">修改</el-button>
            <el-button style="margin:0 5px" type="primary" size="mini" @click="deleteClick(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div style="display: flex; align-items: center">
        <!-- style="display:inline-block"  -->
        <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />

      </div>
    </div>

    <div>
      <el-dialog v-dialogDrag :title="title" :visible.sync="dialogFormVisible">
        <el-form ref="formEdit" :model="formEdit" :rules="formRules">
          <el-form-item prop="holidayName" label="节假日名称：" :label-width="formLabelWidth">
            <el-input v-model="formEdit.holidayName" placeholder="请输入" />
          </el-form-item>
          <el-form-item prop="holidayType" label="节假日属性：" :label-width="formLabelWidth">
            <el-select v-model="formEdit.holidayType" placeholder="请选择">
              <el-option v-for="item in holidayTypeoptions" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="handleEditClick('formEdit')">确 定</el-button>
        </div>
      </el-dialog>
    </div>

  </div>
</template>
<script>
import { initData, addHoliday, updateHoliday, deleteHoliday } from '@/api/holidayInformation'
export default {
  data() {
    return {
      form: {},
      dialogFormVisible: false,
      dialogAddNew: false,
      title: '新增',
      id: '',
      formLabelWidth: '120px',
      formEdit: {
        holidayName: '',
        holidayType: ''
      },
      tableData: [],
      formRules: {
        holidayName: [{ required: true, message: '请输入', trigger: 'blur' }],
        holidayType: [{ required: true, message: '请选择', trigger: 'change' }]
      },
      holidayName: '',
      holidayType: '',
      holidayTypeoptions: [
        '传统节假日',
        '自定义节假日'
      ],
      page: {
        pageSize: 100,
        pageNum: '1',
        currentPage: '1',
        total: 0
      },
      date: new Date(),
      events: [],
      showRili: false
   
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      var data = {
        holidayName: this.holidayName,
        holidayType: this.holidayType,
        holidayYear: this.date.getFullYear()
      }
      var condition = Object.assign(data, this.page)
      initData(condition).then(res => {
        this.tableData = res.data.data.rows
        this.page.total = res.data.data.total
      })
    },
    addNew() {
      this.dialogAddNew = true
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.init()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.init()
    },
    /**
     * 打开修改弹窗
     */
    amendClick(data) {
      this.dialogFormVisible = true
      this.title = '修改'
      this.formEdit.holidayName = data.holidayName
      this.formEdit.holidayType = data.holidayType
      this.id = data.id
    },
    /**
     * 打开修添加弹窗
     */
    addUser() {
      this.dialogFormVisible = true
      this.formEdit.holidayName = ''
      this.formEdit.holidayType = ''
      this.isAdd = true
      this.title = '添加'
    },
    /**
     * 确定修改
     */
    handleEditClick(formEdit) {
      if (this.title === '修改') {
        this.$refs['formEdit'].validate((valid) => {
          if (valid) {
            var params = {
              holidayName: this.formEdit.holidayName,
              holidayType: this.formEdit.holidayType,
              id: this.id
            }
            updateHoliday(params).then((response) => {
              if (response.data.code === '200') {
                this.$message.success('修改成功')
                this.init()
                this.dialogFormVisible = false
                this.$refs[formEdit].resetFields()
              } else {
                this.$message({
                  type: 'error',
                  message: response.data.message
                })
              }
            })
          }
        })
      } else {
        this.$refs['formEdit'].validate((valid) => {
          if (valid) {
            this.formEdit
            addHoliday(this.formEdit).then((response) => {
              if (response.data.code === '200') {
                this.$message.success('添加成功')
                this.init()
                this.$refs[formEdit].resetFields()
              } else {
                this.$message({
                  type: 'error',
                  message: response.data.message
                })
              }
            })
            this.dialogFormVisible = false
          }
        })
      }
    },

    /**
     * 删除
     */
    deleteClick(data) {
      this.$confirm(`此操作将永久删除, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deleteHoliday({ id: data.id }).then(res => {
            if (res.data.code == 200) {
              this.init()
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    black() {
      this.$router.go(-1)
    }
  }
}
</script>

<style scoped lang="scss">

</style>

