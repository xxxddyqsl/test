<template>
  <div class="">
    <!-- 数据资产 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form v-model="formselect" :inline="true">
          <el-form-item>
            <el-switch
              v-model="formselect.value1"
              active-text="全部"
              inactive-text="不正常"
            />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formselect.holidayName" placeholder="数据名称" size="mini" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formselect.holidayType" clearable size="mini">
              <el-option
                v-for="item in options"
                :key="item"
                :label="item"
                :value="item"
                placeholder="数据来源"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formselect.holidayType" clearable size="mini">
              <el-option
                v-for="item in options"
                :key="item"
                :label="item"
                :value="item"
                placeholder="数据类型"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>

          </el-form-item>

        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData">
        <el-table-column prop="holidayName" label="数据名称" />
        <el-table-column prop="holidayType" label="数据类型" />
        <el-table-column prop="holidayName" label="数据来源" />
        <el-table-column prop="holidayType" label="数据合格率" />
        <el-table-column prop="holidayName" label="最新监控时间" />
      </el-table>
      <div style="display: flex; align-items: center">
        <!-- style="display:inline-block"  -->
        <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />

      </div>
    </div>
  </div>
</template>
<script>

export default {
  data() {
    return {
      id: '',
      formLabelWidth: '120px',
      formselect: {
        holidayName: '',
        holidayType: '',
        value1: '全部'
      },
      tableData: [],
      options: [],
      page: {
        pageSize: 10,
        pageNum: '1',
        currentPage: '1',
        total: 0
      }
    }
  },
  created() {

  },
  methods: {

    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
    }

  }
}
</script>

<style scoped lang="scss">

</style>

