
<template>
  <div class="pageBox">
    <div>
      <el-radio-group v-model="radio">
        <el-radio-button label="数据资产" />
        <el-radio-button label="数据应用" />
      </el-radio-group>
    </div>
    <div v-show="radio=='数据资产'">
      <assets />
    </div>
    <div v-show="radio=='数据应用'">
      <application />
    </div>
  </div>

</template>

<script>

import assets from './components/assets'
import application from './components/application'
export default {
  components: {
    assets,
    application
  },
  data() {
    return {
      radio: '数据资产'

    }
  },
  created() {

  },
  methods: {

  }

}

</script>
<style lang="scss" scoped>
.pageBox{

  .box{
height: 20px;
  }
}
</style>
