
<template>
  <div>
    <!-- 舱位 -->
    <div class="">
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model=" formInline.code" size="mini" style="width:120px" placeholder="舱位编码" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onDataChange">添加</el-button>
          </el-form-item>
          <el-form-item>
            <ExcelExport :url-data="urlData" size="mini" name="Excel模板" style="display:inline-block" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="daoRu">导入</el-button>
          </el-form-item>
          <el-form-item>
            <ExcelExport :url-data="urlDataOut" :form-data="formSelect" size="mini" name="导出" style="display:inline-block" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="PhysicalClassCorrespondence">机型销售舱位表</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="cabinTypeName" label="物理舱位名称" />
        <el-table-column prop="name" label="销售舱位名称" />
        <el-table-column prop="code" label="销售舱位编码" />
        <el-table-column prop="level" label="内部舱位等级" />
        <el-table-column prop="remarks" label="备注" />
        <el-table-column label="操作" min-width="160">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="onEditBtn(scope.row)">修改</el-button>
            <el-button type="primary" size="mini" @click="onDleteBtn(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    </div>
    <div>
      <el-dialog v-dialogDrag :title="title" :visible.sync="dialogChange" width="30%" top="8%">
        <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="120px">

          <el-form-item label="物理舱位名称" prop="cabinTypeName">
            <el-select v-model="taskForm.cabinTypeName" collapse-tags placeholder="请选择">
              <el-option v-for="item in cabinTypeName" :key="item.id" :label="item.cabinTypeName" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item label="销售舱位名称" prop="name">
            <el-input v-model="taskForm.name" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item label="销售舱位编码" prop="code">
            <el-input v-model="taskForm.code" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item label="内部等级排序" prop="level">
            <el-select v-model="taskForm.level" collapse-tags placeholder="请选择">
              <el-option v-for="item in level" :key="item.id" :label="item.code" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item label="备注">
            <el-input v-model="taskForm.remarks" style="width:200px" type="textarea" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button size="small" @click="dialogChange = false">取 消</el-button>
          <el-button size="small" type="primary" @click="onMakeSure('taskForm')">确 定</el-button>
        </div>
      </el-dialog>

    </div>
    <div>
      <!-- 文件上传 -->
      <el-dialog v-dialogDrag title="" :visible.sync="dialogVisibleImport" width="30%" top="8%">
        <el-form ref="importForm" :model="importForm" label-width="120px">

          <el-form-item label="请选择文件">
            <el-upload
              ref="upload"
              action=""
              :on-remove="handleRemove"
              :on-change="fileChange"
              :limit="1"
              :before-remove="beforeRemove"
              :auto-upload="false"
              :on-exceed="handleExceed"
              :file-list="upload.fileList"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button size="small" @click="dialogVisibleImport = false">取 消</el-button>
          <el-button size="small" type="primary" @click="addimportForm('importForm')">确 定</el-button>
        </div>
      </el-dialog>

    </div>
  </div>
</template>

<script>
import { ClassList, cabinTypeList, cabinLever, cabinAdd, cabinDelete, cabinEdit, RuButton } from '@/api/dataCenter'
import ExcelExport from '@/components/excel-export/index.vue'
export default {
  components: {
    ExcelExport
  },
  data() {
    return {
      // 文件下载列表
      dataFileList: [],
      // 表单参数
      // 上传参数
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 设置上传的请求头部
        headers: {
          // Authorization:
          //       'Bearer ' +
          //       JSON.parse(localStorage.getItem('TOKEN')).accessToken
        },
        // // 上传的地址
        url: process.env.VUE_APP_BASE_API + '/admin/api/v1/airport/upload',
        // 上传的文件列表
        fileList: []
      },
      importForm: {},
      formSelect: {},
      urlData: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/cabin/template',
      urlDataOut: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/cabin/export',
      title: '',
      formInline: { code: '' },
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      input: '',
      options: [{ value: 1,
        label: '数据名称' }],
      options1: [{ value: 1,
        label: '数据来源' }],
      tableData: [],
      dialogChange: false,
      taskForm: {
        cabinTypeName: '',
        name: '',
        level: '',
        remarks: '',
        code: ''
      },
      rules: {
        cabinTypeName: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        name: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        level: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        code: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ]

      },
      cabinTypeName: [],
      level: [],
      editId: '',
      dialogVisibleImport: false

    }
  },
  created() {
    this.ClassLists()
    this.init()
  },
  methods: {
    // 查询按钮
    onQuery() {
      this.formSelect = {
        code: this.formInline.code,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
      this.ClassLists('查询')
    },
    // 删除按钮
    onDleteBtn(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        cabinDelete(item.id).then(res => {
          if (res.data.code === '200') {
            this.ClassLists()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 导入按钮
    handleRemove(file, fileList) {
      for (const i in this.picList) {
        if (this.picList[i].key === file.uid) {
          this.picList.splice(i, 1)
        }
      }
      this.upload.fileList = fileList
    },
    fileChange(file, fileList) {
      this.upload.fileList = fileList
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`)
    },
    handleExceed(files, fileList) {
      this.$message.warning(`最多上传 1 个文件`)
    },
    addimportForm(importForm) {
      this.$refs['importForm'].validate(valid => {
        if (valid) {
          const formData = new FormData()
          this.upload.fileList.forEach(file => {
            formData.append('excelFile', file.raw)
          })

          // formData.append('rosterSettingName', this.importForm.input)
          RuButton(formData).then(res => {
            this.dialogVisibleImport = false
            if (res.data.code === '200') {
              this.$message({
                type: 'success',
                message: '导入成功!'
              })
            }
          })
        }
      })
    },
    daoRu() {
      this.dialogVisibleImport = true
    },

    // 弹窗确定按钮
    onMakeSure(formName) {
      if (this.title === '添加') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              cabinTypeId: this.taskForm.cabinTypeName,
              code: this.taskForm.code,
              level: Number(this.taskForm.level),
              name: this.taskForm.name,
              remarks: this.taskForm.remarks
            }
            cabinAdd(data).then(res => {
              if (res.data.code === '200') {
                this.ClassLists('添加')
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '修改') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              id: this.editId,
              cabinTypeId: this.taskForm.cabinTypeName,
              code: this.taskForm.code,
              level: Number(this.taskForm.level),
              name: this.taskForm.name,
              remarks: this.taskForm.remarks
            }
            cabinEdit(data).then(res => {
              if (res.data.code === '200') {
                this.ClassLists('修改')
              }
            })
          } else {
            return false
          }
        })
      }
    },
    // 修改按钮
    onEditBtn(item) {
      this.dialogChange = true
      this.title = '修改'
      this.taskForm.cabinTypeName = item.cabinTypeId
      this.taskForm.code = item.code
      this.taskForm.level = item.level
      this.taskForm.name = item.name
      this.taskForm.remarks = item.remarks
      this.editId = item.id
    },
    // 添加按钮
    onDataChange() {
      this.title = '添加'
      this.dialogChange = true
    },
    init() {
      cabinTypeList().then(res => {
        if (res.data.code === '200') {
          this.cabinTypeName = res.data.data || []
        }
      })

      const data = {
        code: 'CABIN_LEVEL'
      }
      cabinLever(data).then(res => {
        if (res.data.code === '200') {
          this.level = res.data.data || []
        }
      })
    },
    goClassTypeManagementDetails() {
      this.$router.push({ name: 'classTypeManagementDetails' })
    },
    PhysicalClassCorrespondence() {
      this.$router.push({ name: 'PhysicalClassCorrespondence' })
    },
    ClassLists(val) {
      var data = {
        code: this.formInline.code,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
      ClassList(data).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows || []
          this.page.total = res.data.data.total
          if (val === '添加') {
            this.$message.success('添加成功')
            this.dialogChange = false
          }
          if (val === '查询') {
            this.$message.success('查询成功')
          }
          if (val === '修改') {
            this.$message.success('修改成功')
            this.dialogChange = false
          }
        }
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.ClassLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.ClassLists()
    }

  }

}

</script>

<style lang='scss' scoped >
 ::v-deep .el-form-item{
    margin-bottom: 0;
  }
</style>

