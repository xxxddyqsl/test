
<template>
  <div>
    <!-- 机型-->
    <div class="">
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" size="mini" style="width:120px" placeholder="机型编码" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.fly" clearable size="mini" style="width:150px" placeholder="应用航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="findFlyStation">查询</el-button>
            <el-button type="primary" size="mini" @click="onReset">重置</el-button>
            <el-button type="primary" size="mini" @click="goPhysicalClassManagement">物理舱位管理</el-button>
            <el-button type="primary" size="mini" @click="addFlyStation">添加</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>

    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="aircraftName" label="机型名称" />
        <el-table-column prop="aircraftCode" label="机型编码" />
        <el-table-column prop="flightArea" label="应用区域" />
        <!-- <el-table-column prop="spaceLayout" label="物理机舱布局" /> -->
        <el-table-column label="物理机舱布局">
          <template slot-scope="scope">
            <span v-for=" (item,index) in scope.row.cabinTypeList" :key="index">{{ scope.row.cabinTypeList.length -1 ==index ? item.cabinTypeName :item.cabinTypeName + ' / ' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="remarks" label="备注" />
        <el-table-column label="操作" min-width="160">
          <template slot-scope="scope">
            <el-button type="primary" style="margin:0 5px" size="mini" @click="edit(scope.row)">修改</el-button>
            <el-button type="primary" style="margin:0 5px" size="mini" @click="Delete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    </div>
    <!-- 添加机型按钮 -->
    <div>
      <el-dialog v-dialogDrag title="添加机型" width="30%" :visible.sync="dialogAddNew">
        <el-form ref="task_form" :model="task_form" :rules="rules" label-width="150px">
          <el-form-item label="机型名称" prop="aircraftName">
            <el-input v-model="task_form.aircraftName" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="机型编码" prop="aircraftCode">
            <el-input v-model="task_form.aircraftCode" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="应用航线" prop="flightArea">
            <el-select v-model="task_form.flightArea" size="mini" clearable style="width:200px" placeholder="应用航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item label="物理舱位布局" prop="spaceLayout">
            <el-select v-model="task_form.spaceLayout" size="mini" :collapse-tags="true" multiple clearable style="width:200px" placeholder="应用航线">
              <el-option v-for="item in editList" :key="item.id" :label="item.cabinTypeName" :value="item.cabinTypeCode" />
            </el-select>
          </el-form-item>
          <el-form-item label="备注">
            <el-input v-model="task_form.remarks" size="mini" type="textarea" style="width:180px" placeholder="请输入" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="dialogAddNew = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary" @click="makeSure('task_form')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <!-- 修改机型按钮 -->
    <div>
      <el-dialog v-dialogDrag title="修改机型" width="30%" :visible.sync="edit_dialogAddNew">
        <el-form ref="edit_task_form" :model="edit_task_form" :rules="edit_rules" label-width="150px">
          <el-form-item label="机型名称" prop="aircraftName">
            <el-input v-model="edit_task_form.aircraftName" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="机型编码" prop="aircraftCode">
            <el-input v-model="edit_task_form.aircraftCode" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="应用航线" prop="flightArea">
            <el-select v-model="edit_task_form.flightArea" size="mini" clearable style="width:200px" placeholder="应用航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item label="物理舱位布局" prop="spaceLayout">
            <el-select v-model="edit_task_form.spaceLayout" size="mini" multiple clearable style="width:200px" placeholder="物理舱位布局">
              <el-option v-for="item in editList" :key="item.id" :label="item.cabinTypeName" :value="item.cabinTypeCode" />
            </el-select>
          </el-form-item>
          <el-form-item label="备注">
            <el-input v-model="edit_task_form.remarks" type="textarea" size="mini" style="width:180px" placeholder="请输入" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="edit_dialogAddNew = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary" @click="edit_makeSure('edit_task_form')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <el-dialog
      :title="title"
      :visible.sync="dialogFormVisible"
      append-to-body
    >
      <el-form ref="form" :model="form" label-width="120px">
        <el-form-item label="机型名称：" prop="jxmc">
          <el-input v-model="form.jxmc" placeholder="请输入机型名称" />
        </el-form-item>
        <el-form-item label="机型编码：" prop="jxbm">
          <el-input v-model="form.jxbm" placeholder="请输入机型编码" />
        </el-form-item>
        <el-form-item label="物理机舱布局：" prop="wljcbj">
          <el-input v-model="form.wljcbj" placeholder="请输入物理机舱布局" />
        </el-form-item>
        <el-form-item label="备注：" prop="companyCode">
          <el-input v-model="form.bz" placeholder="请输入备注" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
      </div>

    </el-dialog>
  </div>
</template>

<script>
import { ModelList, addModelList, deleteModelList, editModelList, cabinTypeList, acTypeList } from '@/api/dataCenter'
import router from '@/router'
export default {
  data() {
    return {
      edit_dialogAddNew: false,
      dialogAddNew: false,
      task_form: {
        aircraftName: '',
        aircraftCode: '',
        flightArea: '',
        spaceLayout: [],
        remarks: '',
        fcabinNumber: '',
        gcabinNumberL: '',
        jcabinNumber: '',
        ycabinNumber: ''

      },
      edit_task_form: {
        aircraftName: '',
        aircraftCode: '',
        flightArea: '',
        spaceLayout: [],
        remarks: '',
        fcabinNumber: '',
        gcabinNumberL: '',
        jcabinNumber: '',
        ycabinNumber: ''

      },
      edit_rules: {
        aircraftName: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        aircraftCode: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        flightArea: [
          { required: true, message: '不能为空', trigger: 'change' }
        ],
        spaceLayout: [
          { required: true, message: '不能为空', trigger: 'change' }
        ]

      },
      rules: {
        aircraftName: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        aircraftCode: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        flightArea: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        spaceLayout: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ]

      },

      formInline: {
        input: '',
        fly: ''
      },
      fly: [],
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      title: '',
      dialogFormVisible: false,
      input: '',
      form: {},
      tableData: [],
      edit_id: '',
      editList: [],
      words: []
    }
  },
  created() {
    this.init()
    this.ModelLists()
    this.cabinTypeLists()
  },
  methods: {
    // 初始化
    init() {
      const data = {
        code: 'FLIGHT_AREA'
      }
      acTypeList(data).then(res => {
        if (res.data.code === '200') {
          this.fly = res.data.data || []
        }
        console.log(res)
      })
    },
    // 重置按钮
    onReset() {
      this.formInline = {
        input: '',
        fly: ''
      }
      this.ModelLists()
    },
    // 物理舱位管理列表
    cabinTypeLists() {
      var data = {
        // aircraftCode: this.formInline.input || '',
        // flightArea: this.formInline.fly || '',
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }

      cabinTypeList(data).then(res => {
        if (res.data.code === '200') {
          this.editList = res.data.data || []
        }
      })
    },
    // 修改按钮
    edit(item) {
      const Domestic = 'DOMESTIC'
      const Foreing = 'FOREIGN'
      this.edit_id = item.id
      this.edit_dialogAddNew = true
      this.edit_task_form.aircraftName = item.aircraftName
      if (item.flightArea === '国内') {
        this.edit_task_form.flightArea = Domestic
      } else if (item.flightArea === '国外') {
        this.edit_task_form.flightArea = Foreing
      }
      this.edit_task_form.aircraftCode = item.aircraftCode
      this.edit_task_form.spaceLayout = [...item.spaceLayout]
      this.edit_task_form.remarks = item.remarks
    },
    // 修改确认按钮
    edit_makeSure(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data = {
            id: this.edit_id,
            aircraftName: this.edit_task_form.aircraftName,
            aircraftCode: this.edit_task_form.aircraftCode,
            flightArea: this.edit_task_form.flightArea,
            spaceLayout: this.edit_task_form.spaceLayout,
            remarks: this.edit_task_form.remarks
          }
          editModelList(data).then(res => {
            if (res.data.code === '200') {
              this.edit_dialogAddNew = false
              this.ModelLists()
              this.$message({
                type: 'success',
                message: '修改成功!'
              })
            }
          })
        } else {
          return false
        }
      })
    },
    // 删除按钮
    Delete(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteModelList(item.id).then(res => {
          if (res.data.code === '200') {
            this.ModelLists()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 添加按钮
    addFlyStation() {
      this.dialogAddNew = true
    },
    // 添加确定按钮
    makeSure(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data = {
            aircraftName: this.task_form.aircraftName,
            aircraftCode: this.task_form.aircraftCode,
            flightArea: this.task_form.flightArea,
            spaceLayout: this.task_form.spaceLayout,
            remarks: this.task_form.remarks,
            fcabinNumber: this.task_form.fcabinNumber,
            gcabinNumberL: this.task_form.gcabinNumberL,
            jcabinNumber: this.task_form.jcabinNumber,
            ycabinNumber: this.task_form.ycabinNumber
          }
          addModelList(data).then(res => {
            if (res.data.code === '200') {
              this.dialogAddNew = false
              this.ModelLists()
              this.task_form.aircraftName = ''
              this.task_form.aircraftCode = ''
              this.task_form.flightArea = ''
              this.task_form.spaceLayout = ''
              this.task_form.remarks = ''
              this.$message({
                type: 'success',
                message: '新增成功!'
              })
            }
          })
        } else {
          return false
        }
      })
    },
    // 查询按钮
    findFlyStation() {
      this.ModelLists()
    },
    // 机型列表
    ModelLists() {
      var data = {
        aircraftCode: this.formInline.input || '',
        flightArea: this.formInline.fly || '',
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }

      ModelList(data).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows || []
          this.page.total = res.data.data.total
        }
      })
    },
    goPhysicalClassManagement() {
      this.$router.push({ name: 'physicalClassManagement' })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.ModelLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.ModelLists()
    }

  }

}

</script>

<style lang='scss' scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    /* border:1px solid #fff */
}
 ::v-deep .el-form-item{
    margin-bottom: 0;
  }

</style>

