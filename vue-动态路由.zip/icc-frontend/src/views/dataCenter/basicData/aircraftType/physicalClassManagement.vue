
<template>
  <div class="pageBox">
    <!-- 物理仓位管理details-->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <div>
          <el-form :inline="true">
            <el-button type="primary" size="mini" @click="addFlyStation">添加</el-button>
            <el-button type="primary" size="mini" @click="goback">返回</el-button>
          </el-form>
        </div>
      </div>
    </div>

    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="cabinTypeName" label="物理舱位名称" />
        <el-table-column prop="cabinTypeCode" label="物理舱位编码" />
        <el-table-column prop="cabinTypeLevel" label="舱位等级排序" />
        <el-table-column label="两舱属性">
          <template slot-scope="scope">
            <span v-if="scope.row.twoCabin==true">是</span>
            <span v-if="scope.row.twoCabin==false">否</span>
          </template>
        </el-table-column>
        <el-table-column prop="remarks" label="备注" />
        <el-table-column label="操作" min-width="160">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="edit(scope.row)">修改</el-button>
            <el-button type="primary" size="mini" @click="Delete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    </div>
    <!-- 添加物理舱位按钮 -->
    <div>
      <el-dialog v-dialogDrag title="添加物理舱位" width="30%" :visible.sync="dialogAddNew">
        <el-form ref="task_form" :model="task_form" :rules="rules" label-width="150px">
          <el-form-item label="物理舱位名称" prop="cabinTypeName">
            <el-input v-model="task_form.cabinTypeName" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="物理舱位编码" prop="cabinTypeCode">
            <el-input v-model="task_form.cabinTypeCode" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="舱位等级" prop="cabinTypeLevel">
            <el-select v-model="task_form.cabinTypeLevel" size="mini" clearable style="width:200px" placeholder="应用航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item label="两舱属性" prop="twoCabin">
            <el-select v-model="task_form.twoCabin" size="mini" clearable style="width:200px" placeholder="应用航线">
              <el-option v-for="item in twoCabins" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>

          <el-form-item label="备注">
            <el-input v-model="task_form.remarks" size="mini" type="textarea" style="width:200px" placeholder="请输入" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="dialogAddNew = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary" @click="makeSure('task_form')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <!--修改物理舱位按钮 -->
    <div>
      <el-dialog v-dialogDrag title="修改物理舱位" width="30%" :visible.sync="editDialogAddNew">
        <el-form ref="edit_task_form" :model="edit_task_form" :rules="edit_rules" label-width="150px">
          <el-form-item label="物理舱位名称" prop="cabinTypeName">
            <el-input v-model="edit_task_form.cabinTypeName" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="物理舱位编码" prop="cabinTypeCode">
            <el-input v-model="edit_task_form.cabinTypeCode" size="mini" style="width:200px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="舱位等级" prop="cabinTypeLevel">
            <el-select v-model="edit_task_form.cabinTypeLevel" size="mini" clearable style="width:200px" placeholder="应用航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item label="两舱属性" prop="twoCabin">
            <el-select v-model="edit_task_form.twoCabin" size="mini" clearable style="width:200px" placeholder="应用航线">
              <el-option v-for="item in twoCabins" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item label="备注">
            <el-input v-model="edit_task_form.remarks" size="mini" type="textarea" style="width:200px" placeholder="请输入" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="editDialogAddNew = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary" @click="editMakeSure('edit_task_form')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <el-dialog
      :title="title"
      :visible.sync="dialogFormVisible"
      append-to-body
    >
      <el-form ref="form" :model="form" label-width="120px">
        <el-form-item label="机型名称：" prop="jxmc">
          <el-input v-model="form.jxmc" placeholder="请输入机型名称" />
        </el-form-item>
        <el-form-item label="机型编码：" prop="jxbm">
          <el-input v-model="form.jxbm" placeholder="请输入机型编码" />
        </el-form-item>
        <el-form-item label="物理机舱布局：" prop="wljcbj">
          <el-input v-model="form.wljcbj" placeholder="请输入物理机舱布局" />
        </el-form-item>
        <el-form-item label="备注：" prop="companyCode">
          <el-input v-model="form.bz" placeholder="请输入备注" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
      </div>

    </el-dialog>
  </div>
</template>

<script>
import { cabinTypeList, addcabinTypeList, EditCabinTypeList, DeleteCabinTypeList } from '@/api/dataCenter'
export default {
  data() {
    return {
      twoCabins: [{ id: 1, label: '是', value: true }, { id: 2, label: '否', value: false }],
      editDialogAddNew: false,
      dialogAddNew: false,
      task_form: {
        cabinTypeName: '',
        cabinTypeCode: '',
        cabinTypeLevel: '',
        twoCabin: '',
        remarks: ''

      },
      edit_task_form: {
        cabinTypeName: '',
        cabinTypeCode: '',
        cabinTypeLevel: '',
        twoCabin: '',
        remarks: ''
      },
      edit_rules: {
        twoCabin: [{ required: true, message: '不能为空', trigger: 'change' }],
        cabinTypeName: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        cabinTypeCode: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        cabinTypeLevel: [
          { required: true, message: '不能为空', trigger: 'change' }
        ]

      },
      rules: {
        twoCabin: [{ required: true, message: '不能为空', trigger: 'change' }],
        cabinTypeName: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        cabinTypeCode: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        cabinTypeLevel: [
          { required: true, message: '不能为空', trigger: 'change' }
        ]

      },
      Vip_fly: [
        { id: 1, label: '超级头等舱', value: '超级头等舱' },
        { id: 2, label: '头等舱', value: '头等舱' },
        { id: 3, label: '公务舱', value: '头公务舱等舱' },
        { id: 4, label: '超级经济舱', value: '超级经济舱' },
        { id: 5, label: '经济舱', value: '经济舱' }
      ],
      formInline: {
        input: '',
        fly: ''
      },
      fly: [
        { id: 1, label: 1, value: 1 },
        { id: 2, label: 2, value: 2 },
        { id: 3, label: 3, value: 3 },
        { id: 4, label: 4, value: 4 },
        { id: 5, label: 5, value: 5 }

      ],
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      title: '',
      dialogFormVisible: false,
      input: '',
      form: {},
      tableData: [],
      edit_id: ''
    }
  },
  created() {
    this.cabinTypeLists()
  },
  methods: {
    // 删除按钮
    Delete(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        DeleteCabinTypeList(item.id).then(res => {
          console.log(res)
          if (res.data.code === '200') {
            this.cabinTypeLists()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },

    // 修改按钮
    edit(item) {
      console.log(item)
      // debugger
      this.editDialogAddNew = true
      this.edit_id = item.id
      this.edit_task_form.twoCabin = item.twoCabin
      this.edit_task_form.cabinTypeName = item.cabinTypeName
      this.edit_task_form.cabinTypeCode = item.cabinTypeCode
      this.edit_task_form.cabinTypeLevel = item.cabinTypeLevel
      this.edit_task_form.remarks = item.remarks
    },
    // 修改按钮确定

    editMakeSure(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data = {
            id: this.edit_id,
            twoCabin: this.edit_task_form.twoCabin,
            cabinTypeName: this.edit_task_form.cabinTypeName,
            cabinTypeCode: this.edit_task_form.cabinTypeCode,
            cabinTypeLevel: this.edit_task_form.cabinTypeLevel,
            remarks: this.edit_task_form.remarks
          }
          EditCabinTypeList(data).then(res => {
            console.log(res)
            if (res.data.code === '200') {
              this.editDialogAddNew = false
              this.cabinTypeLists()
              this.$message({
                type: 'success',
                message: '修改成功!'
              })
            }
          })
        } else {
          return false
        }
      })
    },
    // 添加按钮
    addFlyStation() {
      this.dialogAddNew = true
    },
    // 添加确定按钮
    makeSure(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data = {
            twoCabin: this.task_form.twoCabin,
            cabinTypeName: this.task_form.cabinTypeName,
            cabinTypeCode: this.task_form.cabinTypeCode,
            cabinTypeLevel: this.task_form.cabinTypeLevel,
            remarks: this.task_form.remarks
          }
          addcabinTypeList(data).then(res => {
            if (res.data.code === '200') {
              this.dialogAddNew = false
              this.cabinTypeLists()
              this.$message({
                type: 'success',
                message: '添加成功!'
              })
            }
          })
        } else {
          return false
        }
      })
    },

    // 物理舱位管理列表
    cabinTypeLists() {
      var data = {
        // aircraftCode: this.formInline.input || '',
        // flightArea: this.formInline.fly || '',
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }

      cabinTypeList(data).then(res => {
        console.log(res)
        this.tableData = []
        this.tableData = res.data.data
        this.page.total = res.data.data.length
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.cabinTypeLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.cabinTypeLists()
    },
    goback() {
      // this.$router.go(-1)
      this.$router.push({ name: 'basicData', query: { radio: '机型' }})
    }

  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}

</style>

