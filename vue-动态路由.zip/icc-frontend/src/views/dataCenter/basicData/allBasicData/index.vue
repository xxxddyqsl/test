
<template>
  <div class="pageBox">
    <div class="page_box">
      <el-radio-group v-model="radio">
        <el-radio-button label="航站" />
        <el-radio-button label="航线" />
        <el-radio-button label="机型" />
        <el-radio-button label="销售舱位" />
        <el-radio-button label="航空公司" />
      </el-radio-group>
    </div>
    <div v-if="radio=='航站'">
      <Terminal />
    </div>
    <div v-if="radio=='航线'">
      <RouterControl />
    </div>
    <div v-if="radio=='机型'">
      <AircraftType />
    </div>
    <div v-if="radio=='销售舱位'">
      <ShippingSpace />
    </div>
    <div v-if="radio=='航空公司'">
      <AviationDepartment />
    </div>

  </div>

</template>

<script>

import Terminal from '../terminal/index.vue'
import RouterControl from '../flightRouterControl/index.vue'
import AircraftType from '../aircraftType/index.vue'
import ShippingSpace from '../shippingSpace/index.vue'
import AviationDepartment from '../aviationDepartment/index.vue'
export default {
  components: {
    Terminal,
    RouterControl,
    AircraftType,
    ShippingSpace,
    AviationDepartment
  },
  data() {
    return {
      radio: this.$route.query.radio || '航站'

    }
  },
  created() {
    // if (this.$route.query.radio) {
    //   this.radio = this.$route.query.radio
    // }
  },
  methods: {

  }

}

</script>

<style lang='scss' scoped>
// .pageBox{
//   position: relative;
//   .page_box{
//   position: absolute;
//   top: 65px;
//   left: 10px;

// }
// }

</style>
