
<template>
  <div>
    <!-- 航站 -->
    <div class="">
      <div class="title_left" />
      <div class="title_right">
        <el-form
          :inline="true"
          :model="formInline"
        >
          <el-form-item>
            <el-input
              v-model="formInline.name"
              size="mini"
              style="width:180px"
              placeholder="航站名称"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="formInline.iataCode"
              size="mini"
              style="width:180px"
              placeholder="三字码"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="formInline.icaoCode"
              size="mini"
              style="width:180px"
              placeholder="四字码"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              size="mini"
              @click="findFlyStation"
            >查询</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="addFlyStation"
            >添加</el-button>
            <ExcelExport
              :url-data="urlData"
              size="mini"
              name="Excel模板"
              style="display:inline-block"
            />
            <el-button
              type="primary"
              size="mini"
              @click="daoRu"
            >导入</el-button>
            <ExcelExport
              :url-data="urlDataExcel"
              size="mini"
              name="导出"
              :form-data="formSelect"
              style="display:inline-block"
            />
          </el-form-item>

        </el-form>

      </div>
    </div>

    <el-table
      :data="tableData"
      border
      stripe
    >
      <el-table-column
        prop="name"
        label="航站名称"
      />
      <el-table-column
        prop="iataCode"
        label="三字码"
      />
      <el-table-column
        prop="icaoCode"
        label="四字码"
      />

      <el-table-column
        label="操作"
        min-width="160"
      >
        <template slot-scope="scope">
          <el-button
            type="primary"
            style="margin:0 5px"
            size="mini"
            @click="edit(scope.row)"
          >修改</el-button>
          <el-button
            type="primary"
            style="margin:0 5px"
            size="mini"
            @click="Delete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      background
      :page-size="page.pageSize"
      layout="total, prev, pager, next"
      :total="page.total"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
    <!-- 添加航站按钮 -->
    <div>
      <el-dialog
        v-dialogDrag
        title="添加航站"
        width="30%"
        :visible.sync="dialogAddNew"
      >
        <el-form
          ref="task_form"
          :model="task_form"
          :rules="rules"
          label-width="200px"
        >
          <el-form-item
            label="航站"
            prop="name"
          >
            <el-input
              v-model="task_form.name"
              size="mini"
              style="width:180px"
              placeholder="请输入"
            />
          </el-form-item>
          <el-form-item
            label="三字码"
            prop="iataCode"
          >
            <el-input
              v-model="task_form.iataCode"
              size="mini"
              style="width:180px"
              placeholder="请输入"
            />
          </el-form-item>
          <el-form-item
            label="四字码"
            prop="icaoCode"
          >
            <el-input
              v-model="task_form.icaoCode"
              size="mini"
              style="width:180px"
              placeholder="请输入"
            />
          </el-form-item>
        </el-form>
        <div
          slot="footer"
          class="dialog-footer"
        >
          <el-button
            style="margin:0 5px"
            @click="dialogAddNew = false"
          >取 消</el-button>
          <el-button
            style="margin:0 5px"
            type="primary"
            @click="makeSure('task_form')"
          >确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <!-- 修改按钮 -->
    <div>
      <el-dialog
        v-dialogDrag
        title="修改航站信息"
        width="30%"
        :visible.sync="EditDialogAddNew"
      >
        <el-form
          ref="edit_task_form"
          :model="edit_task_form"
          :rules="rules"
          label-width="200px"
        >
          <el-form-item
            label="航站"
            prop="name"
          >
            <el-input
              v-model="edit_task_form.name"
              size="mini"
              style="width:180px"
              placeholder="请输入"
            />
          </el-form-item>
          <el-form-item
            label="三字码"
            prop="iataCode"
          >
            <el-input
              v-model="edit_task_form.iataCode"
              size="mini"
              style="width:180px"
              placeholder="请输入"
            />
          </el-form-item>
          <el-form-item
            label="四字码"
            prop="icaoCode"
          >
            <el-input
              v-model="edit_task_form.icaoCode"
              size="mini"
              style="width:180px"
              placeholder="请输入"
            />
          </el-form-item>
        </el-form>
        <div
          slot="footer"
          class="dialog-footer"
        >

          <el-button
            style="margin:0 5px"
            @click="EditDialogAddNew = false"
          >取 消</el-button>
          <el-button
            style="margin:0 5px"
            type="primary"
            @click="edit_makeSure('edit_task_form')"
          >确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div>
      <!-- 文件上传 -->
      <el-dialog
        v-dialogDrag
        title=""
        :visible.sync="dialogVisibleImport"
        width="30%"
        top="8%"
      >
        <el-form
          ref="ImportForm"
          :model="ImportForm"
          label-width="120px"
        >

          <el-form-item label="请选择文件">
            <el-upload
              ref="upload"
              action=""
              :on-remove="handleRemove"
              :on-change="fileChange"
              :limit="1"
              :before-remove="beforeRemove"
              :auto-upload="false"
              :on-exceed="handleExceed"
              :file-list="upload.fileList"
            >
              <el-button
                size="small"
                type="primary"
              >点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
        <div
          slot="footer"
          class="dialog-footer"
        >
          <el-button
            size="small"
            @click="dialogVisibleImport = false"
          >取 消</el-button>
          <el-button
            size="small"
            type="primary"
            @click="addImportForm('ImportForm')"
          >确 定</el-button>
        </div>
      </el-dialog>

    </div>
  </div>
</template>

<script>
import { TerminalList, addFLyCLass, editFLyCLass, deleteFLyCLass, daoRuButton } from '@/api/dataCenter'
import ExcelExport from '@/components/excel-export/index.vue'
export default {
  components: {
    ExcelExport
  },
  data() {
    return {
      // 文件下载列表
      dataFileList: [],
      // 表单参数
      // 上传参数
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 设置上传的请求头部
        headers: {
          // Authorization:
          //       'Bearer ' +
          //       JSON.parse(localStorage.getItem('TOKEN')).accessToken
        },
        // // 上传的地址
        url: process.env.VUE_APP_BASE_API + '/admin/api/v1/airport/upload',
        // 上传的文件列表
        fileList: []
      },
      ImportForm: {},
      dialogVisibleImport: false,
      urlData: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/airport/template',
      urlDataExcel: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/airport/export',
      formInline: {
        name: '',
        iataCode: '',
        icaoCode: ''
      },
      task_form: {
        name: '',
        iataCode: '',
        icaoCode: ''
      },
      edit_task_form: {
        name: '',
        iataCode: '',
        icaoCode: ''
      },
      rules: {
        name: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        iataCode: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        icaoCode: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ]
      },
      EditDialogAddNew: false,
      dialogAddNew: false,
      input: '',
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      editId: '',
      tableData: [],
      formSelect: {}
    }
  },
  created() {
    this.TerminalLists()
  },
  methods: {

    // 导入按钮
    handleRemove(file, fileList) {
      for (const i in this.picList) {
        if (this.picList[i].key === file.uid) {
          this.picList.splice(i, 1)
        }
      }
      this.upload.fileList = fileList
    },
    fileChange(file, fileList) {
      this.upload.fileList = fileList
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`)
    },
    handleExceed(files, fileList) {
      this.$message.warning(`最多上传 1 个文件`)
    },
    addImportForm(ImportForm) {
      this.$refs['ImportForm'].validate(valid => {
        if (valid) {
          const formData = new FormData()
          this.upload.fileList.forEach(file => {
            formData.append('excelFile', file.raw)
          })
          // formData.append('rosterSettingName', this.ImportForm.input)
          daoRuButton(formData).then(res => {
            this.dialogVisibleImport = false
            if (res.data.code === '200') {
              this.$message({
                type: 'success',
                message: '导入成功!'
              })
            }
          })
        }
      })
    },
    daoRu() {
      this.dialogVisibleImport = true
    },

    // 删除按钮
    Delete(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        var data = {
          id: item.id
        }
        deleteFLyCLass(data).then(res => {
          if (res.data.code === '200') {
            this.TerminalLists()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },

    // 查询按钮
    findFlyStation() {
      this.TerminalLists()
      this.formSelect = {
        stationName: this.formInline.name,
        iataCode: this.formInline.iataCode,
        icaoCode: this.formInline.icaoCode,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
    },
    // 修改按钮
    edit(item) {
      this.EditDialogAddNew = true
      this.editId = item.id
      this.edit_task_form.name = item.name
      this.edit_task_form.iataCode = item.iataCode
      this.edit_task_form.icaoCode = item.icaoCode
    },
    // 航站修改按钮
    edit_makeSure(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data = {
            id: this.editId,
            name: this.edit_task_form.name,
            iataCode: this.edit_task_form.iataCode,
            icaoCode: this.edit_task_form.icaoCode
          }
          editFLyCLass(data).then(res => {
            if (res.data.code === '200') {
              this.EditDialogAddNew = false
              this.TerminalLists()
              this.$message({
                type: 'success',
                message: '修改成功!'
              })
            }
          })
        } else {
          return false
        }
      })
    },
    // 添加航站按钮
    addFlyStation() {
      this.dialogAddNew = true
    },
    // 添加航站确认按钮
    makeSure(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var data = {
            name: this.task_form.name,
            iataCode: this.task_form.iataCode,
            icaoCode: this.task_form.icaoCode
          }
          addFLyCLass(data).then(res => {
            if (res.data.code === '200') {
              this.dialogAddNew = false
              this.TerminalLists()
              this.task_form.name = ''
              this.task_form.iataCode = ''
              this.task_form.icaoCode = ''
              this.$message({
                type: 'success',
                message: '添加成功!'
              })
            }
          })
        } else {
          return false
        }
      })
    },

    add(type) {
      this.title = type
      this.dialogFormVisible = true
    },
    // 航站列表
    TerminalLists() {
      var data = {
        stationName: this.formInline.name,
        iataCode: this.formInline.iataCode,
        icaoCode: this.formInline.icaoCode,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
      TerminalList(data).then(res => {
        console.log(res)
        this.tableData = []
        this.tableData = res.data.data.rows
        this.page.total = res.data.data.total
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.TerminalLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.TerminalLists()
    }

  }

}

</script>

<style lang='scss' scoped >
.box {
  margin-top: 60px;
}
.title {
  height: 50px;
  font-size: 20px;
  /* border:1px solid #fff */
}

 ::v-deep .el-form-item{
    margin-bottom: 0;
  }

</style>

