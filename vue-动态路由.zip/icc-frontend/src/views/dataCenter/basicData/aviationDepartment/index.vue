
<template>
  <div>
    <!-- 航司 -->
    <div class="">
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.airlineName" size="mini" style="width:180px" placeholder="航空公司名称" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.airlineCode" size="mini" style="width:180px" placeholder="二字码" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onAdd">添加</el-button>
          </el-form-item>
          <el-form-item>
            <ExcelExport :url-data="urlDataExcel" size="mini" name="Excel模板" style="display:inline-block" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="daoRu">导入</el-button>
          </el-form-item>
          <el-form-item>
            <ExcelExport :url-data="urlDataOut" size="mini" :form-data="formSelect" name="导出" style="display:inline-block" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onReset">重置</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-table :data="tableData" border stripe>
      <el-table-column prop="airlineName" label="航空公司名称" />
      <el-table-column prop="airlineCode" label="二字码" />
      <el-table-column label="操作" min-width="160">
        <template slot-scope="scope">
          <el-button type="primary" style="margin:0 5px" size="mini" @click="onEdit(scope.row)">修改</el-button>
          <el-button type="primary" style="margin:0 5px" size="mini" @click="onDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    <!-- 添加航站按钮 -->
    <div>
      <el-dialog v-dialogDrag :title="title" width="30%" :visible.sync="dialogAddNew">
        <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="150px">
          <el-form-item label="航空公司名称" prop="airlineName">
            <el-input v-model="taskForm.airlineName" size="mini" style="width:180px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="二字码" prop="airlineCode">
            <el-input v-model="taskForm.airlineCode" size="mini" style="width:180px" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="备注" prop="condition">
            <el-input v-model="taskForm.remarks" size="mini" style="width:180px" placeholder="请输入" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="dialogAddNew = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary" @click="onMakeSure('taskForm')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div>
      <!-- 文件上传 -->
      <el-dialog v-dialogDrag title="" :visible.sync="dialogVisibleImport" width="30%" top="8%">
        <el-form ref="ImportForm" :model="ImportForm" label-width="120px">

          <el-form-item label="请选择文件">
            <el-upload
              ref="upload"
              action=""
              :on-remove="handleRemove"
              :on-change="fileChange"
              :limit="1"
              :before-remove="beforeRemove"
              :auto-upload="false"
              :on-exceed="handleExceed"
              :file-list="upload.fileList"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button size="small" @click="dialogVisibleImport = false">取 消</el-button>
          <el-button size="small" type="primary" @click="addImportForm('ImportForm')">确 定</el-button>
        </div>
      </el-dialog>

    </div>
  </div>
</template>

<script>
import { queryDictionaryManagement, addsDictionaryManagement, deleteDictionaryManagement, editDictionaryManagement, daoRuDictionaryManagement } from '@/api/dataCenter'
import ExcelExport from '@/components/excel-export/index.vue'
export default {
  components: {
    ExcelExport
  },
  data() {
    return {
      // 文件下载列表
      dataFileList: [],
      // 表单参数
      // 上传参数
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 设置上传的请求头部
        headers: {
          // Authorization:
          //       'Bearer ' +
          //       JSON.parse(localStorage.getItem('TOKEN')).accessToken
        },
        // // 上传的地址
        url: process.env.VUE_APP_BASE_API + '/admin/api/v1/airport/upload',
        // 上传的文件列表
        fileList: []
      },
      ImportForm: {},
      title: '',
      dialogVisibleImport: false,
      formSelect: {},
      urlDataExcel: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/airline/template',
      urlDataOut: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/airline/export',
      formInline: {
        airlineCode: '',
        airlineName: '',
        condition: ''
      },

      taskForm: {
        airlineCode: '',
        airlineName: '',
        remarks: ''
      },

      rules: {
        airlineName: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        airlineCode: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ]
        // remarks: [
        //   { required: true, message: '不能为空', trigger: 'blur' }

        // ]
      },
      EditDialogAddNew: false,
      dialogAddNew: false,
      input: '',
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      editId: '',
      tableData: []
    }
  },
  created() {
    this.TerminalLists()
  },
  methods: {
    // 重置按钮
    onReset() {
      this.clear()
      this.TerminalLists()
    },

    // 清除数据
    clear() {
      this.taskForm = {
        airlineCode: '',
        airlineName: '',
        remarks: ''
      }
    },
    // 导入按钮
    handleRemove(file, fileList) {
      for (const i in this.picList) {
        if (this.picList[i].key === file.uid) {
          this.picList.splice(i, 1)
        }
      }
      this.upload.fileList = fileList
    },
    fileChange(file, fileList) {
      this.upload.fileList = fileList
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`)
    },
    handleExceed(files, fileList) {
      this.$message.warning(`最多上传 1 个文件`)
    },
    addImportForm(ImportForm) {
      this.$refs['ImportForm'].validate(valid => {
        if (valid) {
          const formData = new FormData()
          this.upload.fileList.forEach(file => {
            formData.append('excelFile', file.raw)
          })
          // formData.append('rosterSettingName', this.ImportForm.input)
          daoRuDictionaryManagement(formData).then(res => {
            this.dialogVisibleImport = false
            if (res.data.code === '200') {
              this.$message({
                type: 'success',
                message: '导入成功!'
              })
            }
          })
        }
      })
    },
    daoRu() {
      this.dialogVisibleImport = true
    },

    // 删除按钮
    onDelete(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteDictionaryManagement(item.id).then(res => {
          if (res.data.code === '200') {
            this.TerminalLists()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },

    // 查询按钮
    onQuery() {
      this.formSelect = {
        airlineCode: this.formInline.airlineCode,
        airlineName: this.formInline.airlineName,
        condition: this.formInline.condition,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
      this.TerminalLists('查询')
    },
    // 修改按钮
    onEdit(item) {
      this.title = '修改航空公司'
      this.dialogAddNew = true
      this.editId = item.id
      this.taskForm.airlineName = item.airlineName
      this.taskForm.airlineCode = item.airlineCode
      this.taskForm.remarks = item.remarks
    },

    // 添加航站按钮
    onAdd() {
      this.title = '添加航空公司'
      this.dialogAddNew = true
    },
    // 添加航站确认按钮
    onMakeSure(formName) {
      if (this.title === '添加航空公司') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            var data = {
              airlineName: this.taskForm.airlineName,
              airlineCode: this.taskForm.airlineCode,
              remarks: this.taskForm.remarks
            }
            addsDictionaryManagement(data).then(res => {
              if (res.data.code === '200') {
                this.dialogAddNew = false
                this.TerminalLists()
                this.clear()
                this.$message({
                  type: 'success',
                  message: '添加成功!'
                })
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '修改航空公司') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            var data = {
              id: this.editId,
              airlineName: this.taskForm.airlineName,
              airlineCode: this.taskForm.airlineCode,
              remarks: this.taskForm.remarks
            }
            editDictionaryManagement(data).then(res => {
              if (res.data.code === '200') {
                this.dialogAddNew = false
                this.TerminalLists()
                this.clear()
                this.$message({
                  type: 'success',
                  message: '添加成功!'
                })
              }
            })
          } else {
            return false
          }
        })
      }
    },
    // 航空公司列表
    TerminalLists(v) {
      var data = {
        airlineCode: this.formInline.airlineCode,
        airlineName: this.formInline.airlineName,
        condition: this.formInline.condition,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
      queryDictionaryManagement(data).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows || []
          this.page.total = res.data.data.total
          if (v === '查询') {
            this.tableData.length >0 ? this.$message.success('查询成功') : this.$message.info('暂无数据')
          }
        }
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.TerminalLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.TerminalLists()
    }

  }

}

</script>

<style lang='scss' scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    /* border:1px solid #fff */
}
.el-form-item__error{
  top: 76% !important;
}
 ::v-deep .el-form-item{
    margin-bottom: 0;
  }

</style>

