<template>

  <div class="">
    <el-radio-group v-model="radio1">
      <el-radio-button label="市场价格查询" />
      <el-radio-button label="最低运价趋势" />
      <el-radio-button label="最低运价对比" />
      <el-radio-button label="历史运价走势" />
      <el-radio-button label="运价监控" />
    </el-radio-group>
    <div v-if="radio1=='市场价格查询'" key="5" style="margin-top:20px; ">
      <div style="border-bottom:2px solid #31A6A9; ">
        <div style="border-bottom:1px dashed ">
          <el-form :inline="true" :model="formSelect" size="small">
            <el-form-item>
              <el-input v-model="formSelect.name" style="width:120px">
                <svg slot="prefix" class="icon" aria-hidden="true">
                  <use xlink:href="#icon-feijizhong" />
                </svg>
              </el-input>
            </el-form-item>
            <el-form-item>
              <el-input v-model="formSelect.nextName" style="width:120px">
                <svg slot="prefix" class="icon" aria-hidden="true">
                  <use xlink:href="#icon-feijizhong" />
                </svg>
              </el-input>
            </el-form-item>
            <el-form-item>
              <i class=" el-icon-plus" style="cololr:#33AAA8" />
            </el-form-item>
            <el-form-item>
              <el-select v-model="formSelect.status" style="width:80px" placeholder="国内">
                <el-option v-for="(items, index) in statusOptions" :key="index" :label="items.label" :value="items.value" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-select v-model="formSelect.nextStatus" style="width:80px" placeholder="单程">
                <el-option v-for="(items, index) in nextStatusOptions" :key="index" :label="items.label" :value="items.value" />
              </el-select>
            </el-form-item>

            <el-form-item label="停留">
              <el-select v-model="formSelect.roleIds" style="width:80px" placeholder="1天">
                <el-option v-for="(item, index) in roleOptions" :key="index" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-date-picker v-model="formSelect.startTime" type="date" placeholder="选择日期" />
            </el-form-item>
            <el-form-item>
              <el-date-picker v-model="formSelect.endTime" type="date" placeholder="选择日期" />
            </el-form-item>
            <el-form-item label="航司">
              <el-input v-model="formSelect.Hsi" placeholder="多个航司用/分隔" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary">查询</el-button>
              <el-button type="primary">重置</el-button>
            </el-form-item>
            <el-form-item>
              <el-select v-model="formSelect.Bji" style="width:120px" placeholder="添加标记">
                <el-option v-for="(item, index) in roleOptions" :key="index" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
          </el-form>
        </div>
        <div>
          <el-form ref="form" :model="form" label-width="80px">
            <el-form-item label="舱位:">
              <el-radio v-model="radio" label="1">超级经济舱</el-radio>
              <el-radio v-model="radio" label="2">经济舱</el-radio>
              <el-radio v-model="radio" label="3">公务舱</el-radio>
              <el-radio v-model="radio" label="4">商务舱</el-radio>
            </el-form-item>

            <el-form-item label="起飞时段:" style="width:800px">
              <el-slider v-model="setShut" range show-stops :max="48" :step="1" :marks="shutDownMarks" :format-tooltip="formatTooltip" />
              <span />
            </el-form-item>
            <el-form-item label="直飞/中转:">
              <el-checkbox>直飞</el-checkbox>
              <el-button size="mini" type="primary">含共享</el-button>
              <span />
            </el-form-item>
            <el-form-item label="班期:">
              <el-checkbox v-for="(item ,index) in week" :key="index" v-model="item.checked" @change="Checked(item,index)">{{ item.aa }}</el-checkbox>
              <span />
            </el-form-item>
            <el-form-item label="航空公司:">
              <el-checkbox v-for="(item ,index) in hkgs" :key="index" v-model="item.checked" @change="Checkeds(item,index)">{{ item.aa }}</el-checkbox>
              <span />
            </el-form-item>
            <el-form-item label="渠道:">
              <el-checkbox>携程</el-checkbox>
              <span />
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div>

        <el-table :data="tableData11" style="width: 100%" border>
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-table :data="props.row.sg">
                <el-table-column prop="yj" label="运价" />
                <el-table-column prop="dyc" label="对应舱位和折扣" />
                <el-table-column prop="jgpt" label="价格平台">
                  <template slot-scope="scope">
                    <span>{{ scope.row.jgpt }}</span>
                  </template>
                </el-table-column>

              </el-table>
            </template>
          </el-table-column>
          <el-table-column label="航线" prop="hx" />
          <el-table-column label="他航航班号" prop="wh" />
          <el-table-column label="是否经停" prop="sf" />
          <el-table-column label="起飞日期" prop="qf" />
          <el-table-column label="起飞时刻" prop="qfs" />
          <el-table-column label="最低运价" prop="zg" />
          <el-table-column label="对应舱位与折扣" prop="dy" />
        </el-table>

        <el-pagination background layout="total, prev, pager, next" :total="10" />
      </div>
    </div>

    <div v-if="radio1=='最低运价趋势'" key="4 " style="margin-top:20px;">
      <div class="center-middle">
        价格趋势
        <lineCharts :chart-data="chartData" />
      </div>

      <div>
        航班信息
        <ul style="  display: flex; justify-content: space-between;list-style: none;">
          <li
            v-for="(item,index) in wekks"
            :key="index"
            style="width:140px ;border:1px solid #ccc"
          >
            <p style="text-align:center">{{ item.aa }}</p>
            <p style="text-align:center">{{ item.ab }}</p>
          </li>
        </ul>
        <div>

          <el-table :data="tableData" style="width: 100%" border>
            <el-table-column prop="bh" label="编号" />
            <el-table-column prop="hbh" label="航班号" />
            <el-table-column prop="hbrq" label="航班日期" />
            <el-table-column prop="qfsj" label="起飞时间" />
            <el-table-column prop="kts" label="跨天数" />
            <el-table-column prop="ddsj" label="到达时间" />
            <el-table-column prop="date" label="中转城市" />
            <el-table-column prop="pj" label="票价(￥)" />
            <el-table-column prop="zk" label="折扣" />
            <el-table-column prop="qd" label="渠道" />
            <el-table-column prop="gxrq" label="更新日期" />
          </el-table>
        </div>
      </div>
    </div>
    <div v-if="radio1=='最低运价对比'" key="3" style="margin-top:20px;">
      最低价报表
      <el-table
        ref="multipleTable"
        border
        :span-method="objectSpanMethod"
        :cell-class-name="tableRowClassName"
        :data="tableData1"

        @cell-mouse-leave="cellMouseLeave"
        @cell-mouse-enter="cellMouseEnter"
      >
        <el-table-column prop="name" label="离港日期" align="center" />
        <el-table-column prop="value" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value }}
              <i v-if="parseInt(scope.row.value)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value)>5?'#38C78C':'red'}">
              {{ scope.row.value }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value1" label="04-12" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value1 }}
              <i v-if="parseInt(scope.row.value1)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value1)>5?'#38C78C':'red'}">
              {{ scope.row.value1 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value2" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value2 }}
              <i v-if="parseInt(scope.row.value2)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value2)>5?'#38C78C':'red'}">
              {{ scope.row.value2 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value3" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value3 }}
              <i v-if="parseInt(scope.row.value3)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value3)>5?'#38C78C':'red'}">
              {{ scope.row.value3 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value4" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value4 }}
              <i v-if="parseInt(scope.row.value4)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value4)>5?'#38C78C':'red'}">
              {{ scope.row.value4 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value5" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value5 }}
              <i v-if="parseInt(scope.row.value5)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value5)>5?'#38C78C':'red'}">
              {{ scope.row.value5 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value6" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value6 }}
              <i v-if="parseInt(scope.row.value6)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value6)>5?'#38C78C':'red'}">
              {{ scope.row.value6 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value7" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value7 }}
              <i v-if="parseInt(scope.row.value7)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value7)>5?'#38C78C':'red'}">
              {{ scope.row.value7 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value8" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value8 }}
              <i v-if="parseInt(scope.row.value8)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value8)>5?'#38C78C':'red'}">
              {{ scope.row.value8 }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value9" label="04-21" align="center">
          <template slot-scope="scope">
            <span v-if="!scope.row.status">
              {{ scope.row.value9 }}
              <i v-if="parseInt(scope.row.value9)>400" style="color:#38C78C" class="iconfont icon-circle-arrow-top" />
              <i v-else style="color:red" class=" iconfont icon-circle-arrow-btm-copy" />
            </span>
            <span v-else :style="{ color:parseInt(scope.row.value9)>5?'#38C78C':'red'}">
              {{ scope.row.value9 }}%
            </span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div v-if="radio1=='历史运价走势'" key="1" style="margin-top:20px">
      <div style="border-bottom:1px dashed ">

        <el-form :inline="true" :model="formSelect1" size="small">
          <el-form-item>
            <el-input v-model="formSelect1.name" style="width:120px">
              <svg slot="prefix" class="icon" aria-hidden="true">
                <use xlink:href="#icon-feijizhong" />
              </svg>
            </el-input>
          </el-form-item>

          <el-form-item>
            <el-input v-model="formSelect1.nextName" style="width:120px">
              <svg slot="prefix" class="icon" aria-hidden="true">
                <use xlink:href="#icon-feijizhong" />
              </svg>
            </el-input>
          </el-form-item>

          <el-form-item label="采集日期:">
            <el-date-picker v-model="formSelect1.Times" type="date" placeholder="选择日期" />
          </el-form-item>

          <el-form-item label="起飞日期">
            <el-date-picker v-model="formSelect1.date" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary">查询</el-button>
            <el-button type="primary">重置</el-button>
          </el-form-item>

        </el-form>
      </div>
      <div style="border-bottom:2px solid #32A8AB  ">
        <div style="margin-left:100px;">
          <el-form ref="form" :model="form">
            <el-form-item label="舱位:">
              <el-radio v-model="radio" label="1">超级经济舱</el-radio>
              <el-radio v-model="radio" label="2">公务舱/头等舱</el-radio>

            </el-form-item>

            <el-form-item label="起飞时段:" label-width="75px" style="width:800px">
              <el-slider v-model="setShut" range show-stops :max="48" :step="1" :marks="shutDownMarks" :format-tooltip="formatTooltip" />
              <span />
            </el-form-item>
            <el-form-item label="直飞/中转:">
              <el-checkbox>直飞</el-checkbox>
              <el-button size="mini" type="primary">含共享</el-button>
              <span />
            </el-form-item>
            <el-form-item label="班期:">
              <el-checkbox v-for="(item ,index) in week" :key="index" v-model="item.checked" @change="Checked(item,index)">{{ item.aa }}</el-checkbox>
              <span />
            </el-form-item>
            <el-form-item label="渠道:">
              <el-checkbox>携程</el-checkbox>
              <span />
            </el-form-item>
            <el-form-item label="航空公司:">
              <el-select v-model="value" size="mini" placeholder="航空公司">
                <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
              <el-select v-model="value" size="mini" placeholder="航班号">
                <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="center-middle" style="margin-top:50px">
        价格趋势
        <lineCharts :chart-data="chartData" />
      </div>
    </div>
    <div v-if="radio1=='运价监控'" key="2" style="border:2px solid #32A8AB ;margin-top:20px ;min-height:800px">

      <div
        style=" display: flex;justify-content: space-between; margin-top:30px ;"
      >
        <el-form :inline="true" :model="formSelect1" size="small">
          <el-form-item>
            <div style="display:flex;  width:300px;border:1px solid #ccc;height:40px; margin-left:30px; align-items: center;">
              <span style="width:150px;text-align: center;">起飞到达城市</span>
              <el-divider direction="vertical" />
              <span style="width:150px;text-align: center;">-</span>
            </div>
          </el-form-item>
          <el-form-item>
            <el-select v-model="value" style="width:80px;" placeholder="全部">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>

          <el-form-item label="区域:">
            <el-select v-model="value" style="width:80px;" placeholder="全部">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item label="航班号:">

            <el-input v-model="input" style="width:100px;" placeholder="" />

          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" icon="el-icon-search" />
          </el-form-item>

        </el-form>
        <div>
          <el-button type="primary" size="mini" icon="el-icon-circle-plus" />
          <el-button type="primary" size="mini" icon="el-icon-edit-outline" />
          <el-button type="primary" size="mini" icon="el-icon-circle-close" />
        </div>
      </div>

      <el-table ref="multipleTable" :data="tableData2" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55" />

        <el-table-column prop="qfct" label="起飞城市" align="center" />
        <el-table-column prop="ddct" label="到达城市" align="center" />
        <el-table-column prop="qy" label="区域" align="center" />
        <el-table-column prop="yjtj" label="预警条件" align="center" />
        <el-table-column prop="cjr" label="创建人" align="center" />
        <el-table-column prop="cjsj" label="创建时间" align="center" />

        <el-table-column label="状态" align="center">
          <el-button size="mini" type="primary">预警</el-button>
        </el-table-column>
        <el-table-column prop="hbrq" label="航班日期" align="center" />
        <el-table-column prop="yjsj" label="预警时间" align="center" />
        <el-table-column align="center">
          <template slot-scope="scope">
            <el-switch v-model="valuee" active-color="#13ce66" inactive-color="#ff4949" />
          </template>
        </el-table-column>

      </el-table>
    </div>

  </div>
</template>

<script :src="icon"></script>
<script>
  import lineCharts from '@/components/echarts/lineCharts/index'
export default {
   components: {
    lineCharts
  },
  data() {
    return {
         tableData11: [
        {
          hx: 'PVG-TAO',
          wh: 'TS9141',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        },
        {
          hx: 'PVG-TAO',
          wh: 'TS9142',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9143',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9144',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9145',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9146',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9147',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }
      ],
      valuee:'',
      tableData2:[
        {
          qfct:'SHA',
          ddct:'SZX',
          qy:'国内',
          yjtj:'在未来45天内任意2天，联航量最低价低于CZ中任意一个航空公司的最低价',
          cjr:'knrms',
          cjsj:'2020-06-22 10:51:23',
          hbrq:'2021-12-11',
          yjsj:'2021-03-16 14:57:00'
      }, {
          qfct:'SHA',
          ddct:'SZX',
          qy:'国内',
          yjtj:'在未来45天内任意2天，联航量最低价低于CZ中任意一个航空公司的最低价',
          cjr:'knrms',
          cjsj:'2020-06-22 10:51:23',
          hbrq:'2021-12-11',
          yjsj:'2021-03-16 14:57:00'
      }, {
          qfct:'SHA',
          ddct:'SZX',
          qy:'国内',
          yjtj:'在未来45天内任意2天，联航量最低价低于CZ中任意一个航空公司的最低价',
          cjr:'knrms',
          cjsj:'2020-06-22 10:51:23',
          hbrq:'2021-12-11',
          yjsj:'2021-03-16 14:57:00'
      }, {
          qfct:'SHA',
          ddct:'SZX',
          qy:'国内',
          yjtj:'在未来45天内任意2天，联航量最低价低于CZ中任意一个航空公司的最低价',
          cjr:'knrms',
          cjsj:'2020-06-22 10:51:23',
          hbrq:'2021-12-11',
          yjsj:'2021-03-16 14:57:00'
      },],
      value:'',
      input:'',
      options:[],
      formSelect1:{
         name:'CAN',
        nextName:'CTU',
        Times:'',
        date:""
      },
      tableData:[{
        bh:1,
        hbh:'3U8740',
        hbrq:'2020-08-14',
        qfsj:'21:55',
        kts:1,
        ddsj:'00:15',
        pj:'560',
        zk:'0.32',
        qd:'携程',
        gxrq:'2020-10=08 20:15'
      },
      {
        bh:2,
        hbh:'3U8740',
        hbrq:'2020-08-14',
        qfsj:'21:55',
        kts:1,
        ddsj:'00:15',
        pj:'560',
        zk:'0.32',
        qd:'携程',
        gxrq:'2020-10=08 20:15'
      },{
        bh:3,
        hbh:'3U8740',
        hbrq:'2020-08-14',
        qfsj:'21:55',
        kts:1,
        ddsj:'00:15',
        pj:'560',
        zk:'0.32',
        qd:'携程',
        gxrq:'2020-10=08 20:15'
      },],
      tableData1:[
     {
       name:'MU',
       value:'450',
        status:false,
       value1:'400',
       value2:'400',
       value3:'400',
       value4:'500',
       value5:'400',
       value6:'400',
       value7:'400',
       value8:'400',
       value9:'500',
     },
     {
       name:'MU',
       status:true,
       value:'10.3',
       value1:'2',
       value2:'2',
       value3:'2',
       value4:'22.5',
       value5:'2',
       value6:'2',
       value7:'2',
       value8:'2',
       value9:'22.5',
       },
            {
       name:'ZH',
       value:'1240',
       status:false,
       value1:'1240',
       value2:'1240',
       value3:'1240',
       value4:'1240',
       value5:'1240',
       value6:'1240',
  value7:'1240',
       value8:'1240',
       value9:'1240',
     },
     {
       name:'ZH',
       value:'203.9',
      status:true,
       value1:'203.9',
       value2:'203.9',
       value3:'203.9',
       value4:'203.9',
       value5:'203.9',
       value6:'203.9',
       value7:'203.9',
       value8:'203.9',
       value9:'203.9',
       },
        ],
     hoverOrderArr: [],
      OrderIndexArr: [],

      OrderIndexArr2: [],
      OrderIndexArr3: [],
      hoverOrderArr: [],
      rowIndex: '-1',
      chartData:{},
      wekks:[
        {aa:'08-10',ab:'星期一'},
         {aa:'08-10',ab:'星期二'},
          {aa:'08-10',ab:'星期三'},
           {aa:'08-10',ab:'星期四'},
            {aa:'08-10',ab:'星期五'},
             {aa:'08-10',ab:'星期六'},
              {aa:'08-10',ab:'星期天'},

               {aa:'08-10',ab:'星期一'},
         {aa:'08-10',ab:'星期二'},
          {aa:'08-10',ab:'星期三'},
           {aa:'08-10',ab:'星期四'},
            {aa:'08-10',ab:'星期五'},
        ],
        week: [
        { aa: '全选', checked: false },
        { aa: 'Sun', checked: false },
        { aa: 'Mon', checked: false },
        { aa: 'Tue', checked: false },
        { aa: 'Wed', checked: false },
        { aa: 'Thu', checked: false },
        { aa: 'Fri', checked: false },
        { aa: 'Sat', checked: false }
      ],
      hkgs:[
         { aa: '全选', checked: false },
        { aa: 'JD', checked: false },
        { aa: '3U', checked: false },
        { aa: 'BL', checked: false },
        { aa: 'SC', checked: false },
        { aa: 'MU', checked: false },
        { aa: 'KY', checked: false },
        { aa: 'HU', checked: false },
          { aa: 'ZH', checked: false },
        { aa: 'CZ', checked: false },
        { aa: 'TV', checked: false },
          { aa: 'CA', checked: false },
        { aa: 'EU', checked: false }
      ],
      form:{},
       radio: '1',
       formSelect: {
        name:'CAN',
        nextName:'CTU',
        status:'',
        nextStatus:'',
        roleIds:'',
        startTime:'2020-08-10',
        endTime:'2020-08-25',
        Hsi:'',
        Bji:''
      },
      setShut:[12,16],
      shutDownMarks:{
        0:'00:00',
        24:{
          style:{
            color:'#1989FA'
          },
           label: this.$createElement('strong', '12:00')
        },
        48:'24:00'
       },
      roleOptions:[{value:1,label:'1天'},{value:2,label:'2天'},{value:3,label:'3天'},{value:4,label:'7天'},],
      statusOptions:[{value:1,label:'国内'},{value:2,label:'国外'}],
      nextStatusOptions:[{value:1,label:'单程'},{value:2,label:'往返'}],
      icon :require('@/icons/font_8vhasmts0ah/iconfont'),
      radio1: '市场价格查询',
      radio1s:'航司比价',
    }
  },
    created() {
    this.getOrderNumber()
  },
  methods: {

formatTooltip(val){
  console.log(val);
  let hour =0
  let min = 0
  let ms = val * 1800
  hour = parseInt(ms / 3600)
  if(hour <10 ){
    hour = '0' + hour.toString()
  }else{
     hour =  hour.toString()
  }
  min = ms % 3600
  if(min ===0){
    min = '00'
  }else{
    min = '30'
  }
  let time = hour + ':' + min
  console.log(time);
  return time
},
  Checked(item, index) {
      if (item.aa == '全选') {
        this.week.forEach(value => {
          value.checked = true
        })
      }
      if (item.aa != '全选') {
        this.week[0].checked = false
      }
      if (this.week[1].checked == true && this.week[2].checked == true && this.week[3].checked == true && this.week[4].checked == true && this.week[5].checked == true && this.week[6].checked == true && this.week[7].checked == true) {
        this.week[0].checked = true
      }
    },
      Checkeds(item, index) {
      if (item.aa == '全选') {
        this.hkgs.forEach(value => {
          value.checked = true
        })
      }
      if (item.aa != '全选') {
        this.hkgs[0].checked = false
      }
      if (this.hkgs[1].checked == true && this.hkgs[2].checked == true && this.hkgs[3].checked == true && this.hkgs[4].checked == true && this.hkgs[5].checked == true && this.hkgs[6].checked == true &&
      this.hkgs[7].checked == true  && this.hkgs[8].checked == true && this.hkgs[9].checked == true && this.hkgs[10].checked == true && this.hkgs[11].checked == true && this.hkgs[12].checked == true) {
        this.hkgs[0].checked = true
      }
    },
       // 寻找应该合并行
    getOrderNumber() {
      const OrderObj = {}
      this.tableData1.forEach((element, index) => {
        element.rowIndex = index
        if (OrderObj[element.name]) {
          OrderObj[element.name].push(index)
        } else {
          OrderObj[element.name] = []
          OrderObj[element.name].push(index)
        }
      })

      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const k in OrderObj) {
        console.log('k', k, OrderObj[k])
        if (OrderObj[k].length > 1) {
          this.OrderIndexArr.push(OrderObj[k])
        }
      }
    },
      // 合并单元格
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        for (let i = 0; i < this.OrderIndexArr.length; i++) {
          const element = this.OrderIndexArr[i]
          for (let j = 0; j < element.length; j++) {
            const item = element[j]
            if (rowIndex == item) {
              if (j == 0) {
                return {
                  rowspan: element.length,
                  colspan: 1
                }
              } else if (j != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      } else if (columnIndex === 1) {
        for (let i = 0; i < this.OrderIndexArr2.length; i++) {
          const element2 = this.OrderIndexArr2[i]
          for (let h = 0; h < element2.length; h++) {
            const item2 = element2[h]
            if (rowIndex == item2) {
              if (h == 0) {
                return {
                  rowspan: element2.length,
                  colspan: 1
                }
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      } else if (columnIndex === 2) {
        for (let i = 0; i < this.OrderIndexArr3.length; i++) {
          const element3 = this.OrderIndexArr3[i]
          for (let h = 0; h < element3.length; h++) {
            const item3 = element3[h]
            if (rowIndex == item3) {
              if (h == 0) {
                return {
                  rowspan: element3.length,
                  colspan: 1
                }
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      }
    },
       tableRowClassName({ row, rowIndex }) {
      const arr = this.hoverOrderArr
      for (let i = 0; i < arr.length; i++) {
        if (rowIndex == arr[i]) {
          return 'hovered-row'
        }
      }
    },
       cellMouseLeave(row, column, cell, event) {
      this.rowIndex = '-1'
      this.hoverOrderArr = []
    },
     cellMouseEnter(row, column, cell, event) {
      this.rowIndex = row.rowIndex
      this.hoverOrderArr = []
      this.OrderIndexArr.forEach(element => {
        if (element.indexOf(this.rowIndex) >= 0) {
          this.hoverOrderArr = element
        }
      })
    },
  }
}
</script>

<style lang="scss" scoped>
.icon {
  width: 30px;
  height: 30px;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-right: 5px;
  display: flex;
  justify-content: space-between;

}
.activeColor{
  color: red;
}
</style>
