
<template>
  <div>
    <!-- 舱线 -->
    <div class="">
      <div class="title_right">
        <el-form ref="queryForm" :inline="true" size="small" label-width="100px" :model="queryForm">
          <el-form-item>
            <el-input v-model="queryForm.routesCode" size="mini" style="width: 120px" placeholder="航线" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="query">查询</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="addUser()">添加</el-button>
          </el-form-item>
          <el-form-item>
            <ExcelExport :url-data="urlDataExcel" size="mini" name="Excel模板" style="display:inline-block" />
            <el-button type="primary" size="mini" @click="onDaoRu">导入</el-button>
            <ExcelExport :url-data="urlDataOut" size="mini" :form-data="formSelect" name="导出" style="display:inline-block" />
          </el-form-item>
        </el-form>

      </div>
    </div>

    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="routesCode" label="航线" />
        <el-table-column prop="distance" label="航距(公里)" />
        <!-- <el-table-column prop="id" label="ID" /> -->
        <el-table-column label="操作" min-width="160">
          <template slot-scope="scope">
            <el-button type="primary" style="margin: 0 5px" size="mini" @click="amendClick(scope.row)">修改</el-button>
            <el-button type="primary" style="margin: 0 5px" size="mini" @click="deleteClick(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination background layout="total,prev, pager, next" :current-page="pageNum" :total="total" :page-size="pageSize" @current-change="sizeChange" />
    </div>
    <div>
      <el-dialog v-dialogDrag :title="form.title" width="30%" :visible.sync="dialogFormVisible">

        <el-form ref="form" :model="form" :rules="rules" label-width="150px">

          <el-form-item v-for="(v,i) in form.params" :key="i" :label="'航站'+ i" :prop="v.iataCode">
            <el-select v-model="v.iataCode" size="mini" clearable placeholder="请选择航站">
              <el-option v-for="(items, indexs) in optList" :key="indexs" :label="items.stationName" :value="items.iataCode" />
            </el-select>
            <span v-if="i+1 == form.params.length">
              <el-button v-if="i>1" size="mini" @click.prevent="removeDomain(v)">-</el-button>
              <el-button size="mini" @click.prevent="addDomain">+</el-button>
            </span>
          </el-form-item>

          <el-form-item label="航距(公里)" prop="distance">
            <el-input v-model="form.distance" size="mini" placeholder="请输入航距" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="amend">确 定</el-button>
        </div>

      </el-dialog>
    </div>
    <div>
      <!-- 文件上传 -->
      <el-dialog v-dialogDrag title="" :visible.sync="dialogVisibleImport" width="30%" top="8%">
        <el-form ref="ImportForm" :model="ImportForm" label-width="120px">

          <el-form-item label="请选择文件">
            <el-upload
              ref="upload"
              action=""
              :on-remove="handleRemove"
              :on-change="fileChange"
              :limit="1"
              :before-remove="beforeRemove"
              :auto-upload="false"
              :on-exceed="handleExceed"
              :file-list="upload.fileList"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button size="small" @click="dialogVisibleImport = false">取 消</el-button>
          <el-button size="small" type="primary" @click="addImportForm('ImportForm')">确 定</el-button>
        </div>
      </el-dialog>

    </div>
  </div>
</template>

<script>
import { initTable, removeData, getEit, eitDatafcn, addDatafcn, initSelect } from '@/api/flightRouterControl'
import { flightDaoRuBtn } from '@/api/dataCenter'
import ExcelExport from '@/components/excel-export/index.vue'
export default {
  components: {
    ExcelExport
  },
  data() {
    // var var reg=/^[1-9]+\d*$/
    var validatePass = (rule, value, callback) => {
      var reg = /^[1-9]+\d*$/ // 大于等于0的正整数
      if (value === '') {
        callback(new Error('不能为空'))
      } else if (reg.test(value) !== true) {
        callback(new Error('请输入大于0的正整数!'))
      } else {
        callback()
      }
    }
    return {
      // 文件下载列表
      dataFileList: [],
      // 表单参数
      // 上传参数
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 设置上传的请求头部
        headers: {
          // Authorization:
          //       'Bearer ' +
          //       JSON.parse(localStorage.getItem('TOKEN')).accessToken
        },
        // // 上传的地址
        url: process.env.VUE_APP_BASE_API + '/admin/api/v1/airport/upload',
        // 上传的文件列表
        fileList: []
      },
      ImportForm: {},
      dialogVisibleImport: false,
      urlDataExcel: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/routes/template',
      urlDataOut: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/routes/export',
      queryForm: {
        routesCode: ''
      },
      form: {
        title: '',
        params: [
          { iataCode: '', stationId: '', stationName: '' },
          { iataCode: '', stationId: '', stationName: '' }
        ],
        distance: ''
      },
      optList: [],
      tableData: [],
      pageNum: 1,
      pageSize: 10,
      total: 0,
      dialogFormVisible: false,
      isAdd: true,
      rules: {
        iataCode: [{ required: true, message: '不能为空', trigger: 'blur' }],
        distance: [{ required: true, validator: validatePass, trigger: 'blur' }]
      },
      formSelect: {}

    }
  },
  created() {
    this.getList()
    this.getSelect()
  },
  methods: {
    // 导入按钮
    handleRemove(file, fileList) {
      for (const i in this.picList) {
        if (this.picList[i].key === file.uid) {
          this.picList.splice(i, 1)
        }
      }
      this.upload.fileList = fileList
    },
    fileChange(file, fileList) {
      this.upload.fileList = fileList
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`)
    },
    handleExceed(files, fileList) {
      this.$message.warning(`最多上传 1 个文件`)
    },
    addImportForm(ImportForm) {
      this.$refs['ImportForm'].validate(valid => {
        if (valid) {
          const formData = new FormData()
          this.upload.fileList.forEach(file => {
            formData.append('excelFile', file.raw)
          })
          // formData.append('rosterSettingName', this.ImportForm.input)
          flightDaoRuBtn(formData).then(res => {
            this.dialogVisibleImport = false
            if (res.data.code === '200') {
              this.$message({
                type: 'success',
                message: '导入成功!'
              })
            }
          })
        }
      })
    },
    onDaoRu() {
      this.dialogVisibleImport = true
    },

    removeDomain(item) {
      var index = this.form.params.indexOf(item)
      if (index !== -1) {
        this.form.params.splice(index, 1)
      }
    },
    addDomain() {
      this.form.params.push({
        iataCode: '', stationId: '', stationName: ''
      })
    },
    getSelect() {
      initSelect().then(res => {
        this.optList = JSON.parse(JSON.stringify(res.data.data.rows).replace(/id/g, 'stationId').replace(/name/g, 'stationName'))
      })
    },
    amendClick(data) {
      this.dialogFormVisible = true
      this.isAdd = false
      this.form.title = '修改航线'
      getEit(data.id).then(res => {
        this.form = res.data.data
        this.form.title = '修改航线'
      })
    },
    /**
     * 打开添加弹窗
     */
    addUser() {
      this.dialogFormVisible = true
      this.form = {
        title: '',
        params: [
          { iataCode: '', stationId: '', stationName: '' },
          { iataCode: '', stationId: '', stationName: '' }
        ],
        distance: ''
      }
      this.isAdd = true
      this.form.title = '添加航线'
    },
    /**
     * 确定修改
     */
    amend() {
      this.form.params.forEach((item, i) => {
        item.stationOrder = i
        this.optList.forEach(v => {
          if (v.iataCode === item.iataCode) {
            item.stationId = v.stationId
            item.stationName = v.stationName
          }
        })
      })
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.dialogFormVisible = false
          if (!this.isAdd) {
            // 修改操作
            eitDatafcn(this.form).then(res => {
              if (res.data.code === '200') {
                this.getList()
                this.$message({
                  type: 'success',
                  message: '修改成功!'
                })
              }
            })
          } else {
            // 添加操作
            addDatafcn(this.form).then(res => {
              if (res.data.code === '200') {
                this.pageNum = 1
                this.getList()
                this.$message({
                  type: 'success',
                  message: '添加成功!'
                })
              }
            })
          }
        }
      })
    },

    /**
     * 删除
     */
    deleteClick(data) {
      this.$confirm(`此操作将永久删除这条数据, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          removeData(data).then(res => {
            if (res.data.code === '200') {
              this.getList()
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },

    /**
     * 获取列表
     */
    getList() {
      initTable({
        ...this.queryForm,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then((res) => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    },
    /**
     * 查询
     */
    query() {
      this.formSelect = {
        routesCode: this.queryForm.routesCode,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }
      this.pageNum = 1
      this.getList()
    },
    sizeChange(i) {
      this.pageNum = i
      this.getList()
    }

  }

}

</script>

<style lang='scss' scoped >
.box {
  margin-top: 60px;
}
.title {
  height: 50px;
  font-size: 20px;
  /* border:1px solid #fff */
}

 ::v-deep .el-form-item{
    margin-bottom: 0;
  }
</style>

