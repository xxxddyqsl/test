
<template>
  <div>
    <!-- 互联网运价 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-select v-model="formInline.value" placeholder="航线" size="mini">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.value1" placeholder="航线" size="mini">
              <el-option v-for="item in options1" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker v-model="formInline.value2" type="date" placeholder="起飞日期" size="mini" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <el-table :data="tableData" style="width: 100%" border>
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-table :data="props.row.sg" border>
            <el-table-column label="运价">
              <template slot-scope="scope">
                <span>{{ scope.row.yj }}</span>
              </template>
            </el-table-column>
            <el-table-column label="对应舱位和折扣">
              <template slot-scope="scope">
                <span>{{ scope.row.dyc }}</span>
              </template>
            </el-table-column>
            <el-table-column label="价格平台">
              <template slot-scope="scope">
                <span>{{ scope.row.jgpt }}</span>
              </template>
            </el-table-column>

          </el-table>
        </template>
      </el-table-column>
      <el-table-column label="航线" prop="hx" />
      <el-table-column label="他航航班号" prop="wh" />
      <el-table-column label="是否经停" prop="sf" />
      <el-table-column label="起飞日期" prop="qf" />
      <el-table-column label="起飞时刻" prop="qfs" />
      <el-table-column label="最低运价" prop="zg" />
      <el-table-column label="对应舱位与折扣" prop="dy" />
    </el-table>

    <el-pagination background layout="total, prev, pager, next" :total="10" />

  </div>
</template>

<script>
export default {
  data() {
    return {
      formInline: {
        value: '',
        value1: '',
        value2: ''
      },
      value: '',
      options: [{
        value: 1,
        label: '航线'
      }],
      value1: '',
      options1: [{
        value: 1,
        label: '外航航班号'
      }],
      value2: '',
      tableData: [
        {
          hx: 'PVG-TAO',
          wh: 'TS9141',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        },
        {
          hx: 'PVG-TAO',
          wh: 'TS9142',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9143',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9144',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9145',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9146',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }, { yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }, {
          hx: 'PVG-TAO',
          wh: 'TS9147',
          sf: '',
          qf: '2021.10.01',
          qfs: '07:10',
          zd: '500',
          dy: '经济舱7.4折',
          sg: [{ yj: '1390', dyc: '经济舱5.4折', jgpt: '携程' }]
        }
      ]
    }
  }
}

</script>

<style scoped >
.box{
    margin-top: 60px
}

</style>

