
<template>
  <div class="pageBox">
    <!-- 舱位类型管理详情 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.name" size="mini" style="width:180px" placeholder="机型名称" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.flightArea" size="mini" clearable style="width:180px" placeholder="应用航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
            <el-button type="primary" size="mini" @click="onReset">重置</el-button>
            <el-button type="primary" size="mini" @click="goBack">返回</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="aircraftName" label="机型名称" />
        <el-table-column prop="flightArea" label="航线属性" />
        <el-table-column prop="" label="销售舱位表">

          <template slot-scope="scope">
            <div v-for=" item in scope.row.saleCabin " :key="item.id">
              <span>{{ item.cabinTypeName }}:{{ item.cabinTypeCode }}</span>&nbsp;&nbsp;
              <span v-if="item.cabinVOList.length!=0">
                <span v-for="(it,index) in item.cabinVOList" :key="it.id">{{ item.cabinVOList.length-1==index ?it.code:it.code+ '/' }}</span>
              </span>
            </div>
          </template>

        </el-table-column></el-table>
      <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    </div>

  </div>
</template>

<script>
import { saleCabinPageList, acTypeList } from '@/api/dataCenter'
export default {
  data() {
    return {
      formInline: {
        name: '',
        flightArea: ''
      },
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      tableData: [],
      fly: []

    }
  },
  created() {
    this.init()
    this.saleCabinPageLists()
  },
  methods: {
    // 初始化
    init() {
      const data = {
        code: 'FLIGHT_AREA'
      }
      acTypeList(data).then(res => {
        if (res.data.code === '200') {
          this.fly = res.data.data || []
        }
      })
    },
    // 重置按钮
    onReset() {
      this.formInline = {
        name: '',
        flightArea: ''
      }
      this.saleCabinPageLists()
    },
    // 查询按钮
    onQuery() {
      this.saleCabinPageLists('查询')
    },
    goBack() {
      // this.$router.go(-1)
      this.$router.push({ name: 'basicData', query: { radio: '销售舱位' }})
    },
    // 舱位列表 Class list 的details
    saleCabinPageLists(item) {
      var data = {
        aircraftName: this.formInline.name,
        flightArea: this.formInline.flightArea,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }

      saleCabinPageList(data).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows || []
          this.page.total = res.data.data.total
          if (item === '查询') {
            this.$message.success('查询成功')
          }
        }
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.saleCabinPageLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.saleCabinPageLists()
    }
  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}

</style>

