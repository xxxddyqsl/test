
<template>
  <div class="pageBox">
    <!-- 舱位类型管理详情 -->
    <div class="seachBox">
      <div class="title_left">
        <el-radio-group v-model="radio1">
          <el-radio-button label="F类舱" />
          <el-radio-button label="U类舱" />
          <el-radio-button label="J类舱" />
          <el-radio-button label="W类舱" />
          <el-radio-button label="Y类舱" />

        </el-radio-group>
      </div>
      <div class="title_right">
        <el-form :inline="true">
          <el-button type="primary" size="mini">添加</el-button>
          <el-button type="primary" size="mini" @click="goBack">返回</el-button>
        </el-form>
      </div>
    </div>

    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="cabinTypeName" label="舱位类型名称" />
        <el-table-column prop="cabinTypeCode" label="舱位类型编码" />
        <el-table-column prop="cabinTypeLevel" label="舱位类型等级" />
        <el-table-column prop="relationCabin" label="嵌套关系" />
        <el-table-column prop="remarks" label="备注" />
        <el-table-column label="操作" min-width="160">
          <el-button type="primary" size="mini">修改</el-button>
          <el-button type="primary" size="mini">删除</el-button>
        </el-table-column>
      </el-table>
      <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    </div>

  </div>
</template>

<script>
import { ClassListDetails } from '@/api/dataCenter'
export default {
  data() {
    return {
      radio1: 'F类舱',
      page: {
        pageNum: 1,
        pageSize: 10,
        total: '20'
      },
      options: [{ value: 1,
        label: '数据名称' }],
      options1: [{ value: 1,
        label: '数据来源' }],
      tableData: []
    }
  },
  created() {
    this.ClassLists()
  },
  methods: {
    goBack() {
      this.$router.go(-1)
    },
    // 舱位列表 Class list 的details
    ClassLists() {
      var data = {
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }

      ClassListDetails(data).then(res => {
        console.log(res)
        this.tableData = []
        this.tableData = res.data.data.rows
        this.page.total = res.data.data.total
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.ClassLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.ClassLists()
    }
  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    /* border:1px solid #fff */
}
.title_right{
    margin-right: 0;
    /* width: 15%; */
    height: 100%;
    float: right;
    display: flex;
    align-items: center;
    justify-content: space-around;

}

</style>

