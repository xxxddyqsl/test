
<template>
  <div class="pageBox">
    <div>
      <el-radio-group v-model="radio">
        <el-radio-button label="航季航班计划" />
        <el-radio-button label="近期航班计划" />
      </el-radio-group>
    </div>
    <div v-if="radio=='近期航班计划'">
      <Template />
    </div>
    <div v-if="radio=='航季航班计划'">
      <Information />
    </div>
  </div>

</template>

<script>

import Template from '../flightBenchmarkingTemplate/index.vue'
import Information from '../flightPlanInformation/index.vue'
export default {
  components: {
    Template,
    Information
  },
  data() {
    return {
      radio: '航季航班计划'

    }
  },
  created() {

  },
  methods: {

  }

}

</script>

