
<template>
  <div class="pageBox">
    <!-- 近期航班计划 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formInline">

          <el-form-item>
            <el-date-picker v-model="formInline.flightDate" value-format="yyyy-MM-dd HH:mm:ss" size="mini" type="date" style="width:150px" placeholder="日期" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.flightNumber" size="mini" style="width:150px" placeholder="航班号" />
          </el-form-item>
          <el-form-item>
            <el-time-picker v-model="formInline.plannedArrivalTime" format="HH:mm" value-format="HH:mm" size="mini" style="width:150px" arrow-control placeholder="时间点" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.flightRoute" filterable size="mini" style="width:150px" placeholder="航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.routesCode" :value="item.routesCode" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.aircraftType" size="mini" style="width:150px" placeholder="机型">
              <el-option v-for="item in acType" :key="item.id" :label="item.aircraftName" :value="item.aircraftCode" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.flightStatus" size="mini" style="width:150px" placeholder="状态">
              <el-option v-for="item in status" :key="item.id" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
            <el-button type="primary" size="mini" @click="onReset">航班计划库</el-button>
          </el-form-item>

        </el-form>

      </div>
    </div>
    <el-table :data="tableData" border>
      <el-table-column label="序号" type="index" width="50" />
      <el-table-column label="起飞日期">
        <template slot-scope="scope">
          {{ scope.row.flightDate.slice(0,10) }}
        </template>
      </el-table-column>
      <el-table-column label="航班号">
        <template slot-scope="scope">
          {{ scope.row.carrierIataCd }}{{ scope.row.flightNumber }}
        </template>
      </el-table-column>
      <el-table-column prop="plannedDepartureTime" label="计划起飞时间" />
      <el-table-column prop="plannedArrivalTime" label="计划到达时间" />
      <el-table-column prop="flightRoute" label="航线" />
      <el-table-column prop="aircraftType" label="机型" />
      <el-table-column prop="segment" label="航段" />
      <el-table-column label="起飞站">
        <template slot-scope="scope">
          {{ scope.row.schDepAptCn }}({{ scope.row.schDepApt }})
        </template>
      </el-table-column>
      <el-table-column label="到达站">
        <template slot-scope="scope">
          {{ scope.row.schArrAptCn }}({{ scope.row.schArrApt }})
        </template>
      </el-table-column>
      <el-table-column prop="flightArea" label="国内国外" />
      <el-table-column prop="flightStatus" label="状态" />
      <el-table-column label="对比航班">
        <template slot-scope="scope">
          {{ scope.row.flightHistoryFlightNumber }}
          <span><i class="el-icon-edit" @click="onComparisonFlight(scope.row)" /></span>
        </template>
      </el-table-column>
    </el-table>
    <div style="display:flex; align-items: center; ">
      <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />

    </div>
    <!-- 对比航班弹窗 -->
    <el-dialog v-dialogDrag title="调整对标航班" width="80%" :visible.sync="dialogComparisonFlight">
      <div>
        <el-form ref="comparisonFlightForm" :inline="true" :model="comparisonFlightForm">
          <el-form-item label="条件:" label-width="45px">
            <el-select v-model="comparisonFlightForm.flightLine" size="mini" filterable placeholder="航线">
              <el-option v-for="item in fly" :key="item.id" :label="item.routesCode" :value="item.routesCode" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="comparisonFlightForm.flightCode" size="mini" filterable placeholder="航班号">
              <el-option v-for="(item,i) in flightNo" :key="i" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="comparisonFlightForm.acType" size="mini" placeholder="机型">
              <el-option v-for="item in acType" :key="item.id" :label="item.aircraftName" :value="item.aircraftCode" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker v-model="comparisonFlightForm.date" size="mini" value-format="yyyy-MM-dd HH:mm:ss" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" />
          </el-form-item>
          <el-form-item>
            <el-time-picker v-model="comparisonFlightForm.time" size="mini" format="HH:mm" value-format="HH:mm" placeholder="任意时间点" />
          </el-form-item>
          <el-form-item>
            <el-button size="mini" type="primary" @click="onIconQuery">查询</el-button>
            <el-button size="mini" type="primary" @click="onIconReset">重置</el-button>
          </el-form-item>
        </el-form>
        <el-form :inline="true" :model="flightForm" class="result">
          <el-form-item label="结果:" label-width="45px">
            <el-select v-model="flightForm.flight" size="mini" placeholder="请选择">
              <el-option
                v-for="item in iconList"
                :key="item.id"
                :label="`${item.flightRoute + ' ' }${item.carrierIataCd }${item.flightNumber + ' ' } ${item.aircraftType+ ' ' }${item.plannedArrivalTime + ' ' }`"
                :value="`${item.flightHistoryId }`"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button size="mini" type="primary" @click="OnWrite">填入</el-button>
          </el-form-item>
        </el-form>
        <el-table :data="flightFormData">
          <el-table-column prop="flightDate" label="条件">
            <template slot-scope="scope">
              <span v-if="scope.row.id!=null"> 航季航班</span>
              <span v-else> 历史航班</span>
            </template>
          </el-table-column>
          <el-table-column prop="flightRoute" label="航线" />
          <el-table-column prop="flightNumber" label="航班号" />
          <el-table-column prop="aircraftType" label="机型" />
          <el-table-column prop="flightDate" label="起飞日期">
            <template slot-scope="scope">
              {{ scope.row.flightDate.slice(0,11) }}
            </template>
          </el-table-column>
          <el-table-column prop="week" label="星期" />
          <el-table-column prop="plannedArrivalTime" label="起飞时间" />
          <el-table-column prop="nominalIncome" label="销售额" />
          <el-table-column label="座公里收入">
            <template slot-scope="scope">
              {{ scope.row.rask ?numFinancial(scope.row.rask,2) :'' }}
            </template>
          </el-table-column>
          <el-table-column prop="plf" label="客座率">
            <template slot-scope="scope">
              {{ scope.row.plf ?numFinancial(scope.row.plf,2) :'' }}
            </template>
          </el-table-column>
          <el-table-column prop="transferRate" label="中转率" />
        </el-table>

      </div>
      <div slot="footer" class="dialog-footer">
        <el-button style="margin:0 5px" @click="dialogComparisonFlight = false">取 消</el-button>
        <el-button style="margin:0 5px" type="primary" @click="onMakeSure()">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { RecentFlightPlanList, stateList, lightAcType, flyAcType, iconList, iconTableList, iconMakeSure, flightNoList, iconWrite } from '@/api/dataCenter'
import { numFinancial } from '@/utils/util'

export default {
  data() {
    return {
      flightFormData: [],
      flightForm: {
        flight: ''
      },
      comparisonFlightForm: {
        flightLine: '',
        flightCode: '',
        acType: '',
        date: '',
        time: ''
      },
      dialogComparisonFlight: false,
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      fly: [],
      acType: [],
      status: [],
      flightNo: [],
      formInline: {
        flightStatus: '',
        aircraftType: '',
        flightRoute: '',
        plannedArrivalTime: '',
        abnormal: false,
        flightDate: '',
        flightNumber: ''
      },
      tableData: [],
      iconList: [],
      iconId: ''
    }
  },

  created() {
    this.flightNoLists()
    this.stateLists()
    this.lightAcTypes()
    this.flyAcTypes()
    this.RecentFlightPlanLists()
  },
  methods: {
    numFinancial(num, index) {
      return numFinancial(Number(num), index)
    },
    // 点击小图标里面的重置按钮
    onIconReset() {
      this.comparisonFlightForm = {
        flightLine: '',
        flightCode: '',
        acType: '',
        date: '',
        time: ''
      }
    },
    // 填入确定按钮
    onMakeSure() {
      const data = {
        id: this.iconId,
        flightHistoryId: this.flightForm.flight || ''

      }
      iconMakeSure(data).then(res => {
        console.log(res)
        if (res.data.code === '200') {
          this.RecentFlightPlanLists()
          this.$message.success('填入成功')
        } else {
          this.$message.error('填入失败')
        }
      })
      this.dialogComparisonFlight = false
    },
    //  填入按钮
    OnWrite() {
      const data = {
        id: this.flightForm.flight == null ? '' : this.flightForm.flight // 下拉框
      }
      iconWrite(data).then(res => {
        if (res.data.code === '200') {
          if (this.flightFormData.length === 2) {
            this.flightFormData.pop()
          }
          var concat = []
          concat = this.flightFormData.concat(res.data.data)
          this.flightFormData = concat
        }
      })
    },
    // 对比航班图标里的查询按钮
    onIconQuery() {
      const data = {
        aircraftTypeName: this.comparisonFlightForm.acType, // 飞机机型
        flightDate: this.comparisonFlightForm.date.toString(), //  时间范围
        flightNumber: this.comparisonFlightForm.flightCode, // 航班号
        routesCode: this.comparisonFlightForm.flightLine, // 航线
        departureTime: this.comparisonFlightForm.time.replace(/:/g, '') //  航班时间
      }
      iconList(data).then(res => {
        if (res.data.code === '200') {
          this.iconList = res.data.data || []

          this.iconList.length>0 ? this.$message.success('查询成功') : this.$message.info('暂无数据')
        } else {
          this.$message.error('查询失败')
        }
      })
    },
    // 点击对比航班图标
    onComparisonFlight(item) {
      if (item) {
        this.iconId = item.id
        this.dialogComparisonFlight = true
      }
      const data = {
        id: this.iconId || ''
      }
      iconTableList(data).then(res => {
        if (res.data.code === '200') {
          this.flightFormData = res.data.data || []
        }
      })
    },
    // 页面重置按钮
    onReset() {
      this.$router.push({ path: '/dataCenter/flightPlanInformation' })
    },
    // 查询按钮
    onQuery() {
      this.RecentFlightPlanLists('查询')
    },
    // 航班近期计划  航线机型
    lightAcTypes() {
      lightAcType().then(res => {
        if (res.data.code === '200') {
          this.fly = res.data.data || []
        }
      })
    },
    // 航班号
    flightNoLists() {
      const data = {
        flightNo: ''
      }
      flightNoList(data).then(res => {
        if (res.data.code === '200') {
          this.flightNo = res.data.data || []
        }
      })
    },
    // 机型
    flyAcTypes() {
      flyAcType().then(res => {
        if (res.data.code === '200') {
          this.acType = res.data.data || []
        }
      })
    },
    // 航班近期计划  状态
    stateLists() {
      stateList().then(res => {
        if (res.data.code === '200') {
          this.status = res.data.data.rows || []
        }
      })
    },
    // 近期航班计划表格数据
    RecentFlightPlanLists(v) {
      const data = {
        abnormal: this.formInline.abnormal,
        flightDate: this.formInline.flightDate === '' ? '' : this.formInline.flightDate,
        flightNumber: this.formInline.flightNumber,
        plannedDepartureTime: this.formInline.plannedArrivalTime.replace(':', ''),
        aircraftType: this.formInline.aircraftType,
        flightRoute: this.formInline.flightRoute,
        flightStatus: this.formInline.flightStatus,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
      RecentFlightPlanList(data).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows || []
          this.page.total = res.data.data.total
          if (v === '查询') {
            this.tableData.length>0 ? this.$message.success('查询成功') : this.$message.info('暂无数据')
          }
        } else {
          this.$message.error('查询失败')
        }
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.RecentFlightPlanLists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.RecentFlightPlanLists()
    }
  }
}

</script>

<style lang="scss" scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
}
.title_right{
    margin-right: 0;
    height: 100%;
    float: right;
}
.result{
  ::v-deep .el-input {
 width: 400px !important;
  }
}

</style>

