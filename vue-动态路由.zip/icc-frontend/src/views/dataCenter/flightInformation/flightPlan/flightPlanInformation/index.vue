
<template>
  <div>
    <!-- 航季航班计划 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">

        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.name" size="mini" style="width:180px" placeholder="文件名称" />
          </el-form-item>
          <el-form-item>
            <el-date-picker v-model="formInline.date" value-format="yyyy-MM-dd" size="mini" type="date" placeholder="选择日期" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.state" size="mini" placeholder="状态">
              <el-option
                v-for="item in stateList"
                :key="item.id"
                :label="item.name"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
            <el-button type="primary" size="mini" @click="onReset">重置</el-button>
            <ExcelExport
              :url-data="urlData"
              size="mini"
              name="Excel模板"
              style="display:inline-block"
            />
            <el-button type="primary" size="mini" @click="daoRu">导入</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>

    <el-table :data="tableData" border>
      <el-table-column label="文件名称">
        <!-- <label @click="Godetails" /> -->
        <template slot-scope="scope">
          <div @click="Godetails(scope.row)">
            {{ scope.row.name }}
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="startTime" label="开始时间" />
      <el-table-column prop="endTime" label="结束时间" />
      <el-table-column prop="updateTime" label="修改时间" />
      <el-table-column prop="createTime" label="创建时间" />
      <el-table-column prop="createUser" label="创建者" />
      <el-table-column prop="state" label="状态" />
      <el-table-column label="操作" width="140">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="onDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />

    <!-- 文件上传 -->
    <el-dialog v-dialogDrag title="" :visible.sync="dialogVisibleImport" width="30%" top="8%">
      <el-form ref="ImportForm" :model="ImportForm" label-width="120px">

        <el-form-item label="请选择文件">
          <el-upload
            ref="upload"
            action=""
            :on-remove="handleRemove"
            :on-change="fileChange"
            :limit="1"
            :before-remove="beforeRemove"
            :auto-upload="false"
            :on-exceed="handleExceed"
            :file-list="upload.fileList"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="dialogVisibleImport = false">取 消</el-button>
        <el-button size="small" type="primary" @click="addImportForm('ImportForm')">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { quarterlylightlanist, updateImportDatas, quarterlylightlanistDelete, quarterlylightlanistState } from '@/api/dataCenter'
import ExcelExport from '@/components/excel-export/index.vue'
export default {
  components: {
    ExcelExport
  },
  data() {
    return {
      // 文件下载列表
      dataFileList: [],
      // 表单参数
      // 上传参数
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 设置上传的请求头部
        headers: {
          // Authorization:
          //       'Bearer ' +
          //       JSON.parse(localStorage.getItem('TOKEN')).accessToken
        },
        // // 上传的地址
        // url: process.env.VUE_APP_BASE_API + '/system/treatment/upload',
        // 上传的文件列表
        fileList: []
      },
      ImportForm: {},
      dialogVisibleImport: false,
      urlData: `${process.env.VUE_APP_BASE_API}` + 'admin/api/v1/seasonPlan/template',
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      formInline: {
        state: '',
        date: '',
        name: ''
      },
      tableData: [],
      planId: '',
      stateList: []

    }
  },
  created() {
    this.quarterlylightlanists()
    this.quarterlylightlanistStates()
  },
  methods: {
    // 状态下拉框
    quarterlylightlanistStates() {
      quarterlylightlanistState({ code: 'FLIGHT_PLAN_STATUS' }).then(res => {
        if (res.data.code === '200') {
          this.stateList = res.data.data || []
        }
        console.log(res)
      })
    },
    // 重置按钮
    onReset() {
      this.formInline = {
        state: '',
        date: '',
        name: ''
      }
      this.quarterlylightlanists()
    },
    // 查询按钮
    onQuery() {
      this.quarterlylightlanists()
    },
    // 删除按钮
    onDelete(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        quarterlylightlanistDelete(item.id).then(res => {
          if (res.data.code === '200') {
            this.quarterlylightlanists()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    handleRemove(file, fileList) {
      for (const i in this.picList) {
        if (this.picList[i].key === file.uid) {
          this.picList.splice(i, 1)
        }
      }
      this.upload.fileList = fileList
    },
    fileChange(file, fileList) {
      this.upload.fileList = fileList
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`)
    },
    handleExceed(files, fileList) {
      this.$message.warning(`最多上传 1 个文件`)
    },
    addImportForm(ImportForm) {
      this.$refs['ImportForm'].validate(valid => {
        if (valid) {
          const formData = new FormData()
          this.upload.fileList.forEach(file => {
            formData.append('file', file.raw)
          })
          updateImportDatas(formData).then(response => {
            this.dialogVisibleImport = false
            if (response.data.code == '200') {
              this.$message({
                type: 'success',
                message: '导入成功!'
              })
            }
          })
        }
      })
    },
    daoRu() {
      this.dialogVisibleImport = true
    },
    // 航季航班计划列表
    quarterlylightlanists() {
      var data = {
        name: this.formInline.name,
        date: this.formInline.date,
        state: this.formInline.state,
        condition: '',
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }
      quarterlylightlanist(data).then(res => {
        this.tableData = res.data.data.rows || []
        this.page.total = res.data.data.total
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.quarterlylightlanists()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.quarterlylightlanists()
    },

    Godetails(row) {
      this.planId = row.id
      this.$router.push({ name: 'details1', query: { planId: this.planId }})
    }
  }
}

</script>

<style scoped >
.box{
    margin-top: 60px
}
.title_right{
    margin: 60px 0 0 0;
    /* background-color: aqua; */
}
</style>

