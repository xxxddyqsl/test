
<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">

        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" size="mini" style="width:180px" placeholder="对比名称" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini" @click="addNew">新增</el-button>
          </el-form-item>
        </el-form>

      </div>
    </div>

    <el-table :data="tableData" border>
      <el-table-column label="对比名称">
        <template slot-scope="scope">
          <div @click="Godetails">
            {{ scope.row.mo }}
          </div>
        </template>
      </el-table-column>
      <!-- <el-table-column prop="mo" label="对比名称" /> -->
      <el-table-column prop="yuan" label="航季航班区间" />
      <!-- <el-table-column prop="dong" label="历史航班区间" /> -->
      <el-table-column prop="dong">
        <template slot="header">
          <span> 历史航班区间 </span>
          <el-tooltip content="涵盖初期设置的主要历史航班期间以及手动调整的历史航班区间" placement="top">
            <i class="el-icon-question help-icon" />
          </el-tooltip>
        </template>
      </el-table-column>

      <el-table-column prop="xiu" label="修改时间" />
      <el-table-column prop="chuang" label="创建时间" />
      <el-table-column prop="chuangs" label="创建者" width="100" />
      <el-table-column min-width="230">
        <template slot="header">
          <span> 操作 </span>
          <el-tooltip content="提交的前提为航季航班100%完成与确认对比" placement="top">
            <i class="el-icon-question help-icon" />
          </el-tooltip>
        </template>
        <el-button type="primary" size="mini">已提交</el-button>
        <el-button type="primary" size="mini">修改</el-button>
        <el-button type="primary" size="mini">删除</el-button>
      </el-table-column>

    </el-table>

    <el-pagination background layout="total, prev, pager, next" :total="10" />

    <!-- 新增弹窗 -->
    <el-dialog v-dialogDrag title="航班对标计划" width="30%" :visible.sync="dialogAddNew">
      <el-form ref="task_form" :model="task_form" :rules="rules1" label-width="200px">
        <el-form-item label="名称" prop="deskId">
          <el-input v-model="task_form.input" size="mini" style="width:180px" placeholder="请输入" />
        </el-form-item>
        <el-form-item label="标准航班计划" prop="skills">
          <el-select v-model="task_form.skills" placeholder="请选择航班计划">
            <el-option v-for="item in BZ_flightPlan" :key="item.id" :value="item.value" :label="item.label" />
          </el-select>
        </el-form-item>
        <el-form-item label="模板航班计划" prop="skills">
          <el-select v-model="task_form.skills" placeholder="请选择航班计划">
            <el-option v-for="item in MB_flightPlan" :key="item.skillId" :value="item.value" :label="item.label" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button style="margin:0 5px" @click="dialogAddNew = false">取 消</el-button>
        <el-button style="margin:0 5px" type="primary">确 定</el-button>
      </div>

    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      BZ_flightPlan: [{ id: 1, label: '', value: 1 }],
      MB_flightPlan: [{ id: 1, label: '', value: 1 }],
      formInline: {
        input: ''
      },
      task_form: {
        input: '',
        deskId: '',
        skills: '',
        newDate: this.$route.query.date
      },
      rules1: {
        deskId: [
          { required: true, message: '不能为空', trigger: 'change' }
        ],
        skills: [
          { required: true, message: '不能为空', trigger: 'change' }
        ],

        newDate: [
          { required: true, message: '请选择时间', trigger: 'change' }
        ]
      },
      dialogAddNew: false,
      tableData: [
        { mo: '2022航班计划比较', yuan: '2022.01.01-2022.12.31', dong: '2022.01.01-2022.12.31', xiu: '2021.05.21 10.04:44', chuang: '2021-05-20 15:27:31', chuangs: '管理员' }
      ]

    }
  },
  methods: {
    addNew() {
      this.dialogAddNew = true
    },
    Godetails() {
      this.$router.push({ name: 'flightBenchmarkingTemplateDetails' })
    }
  }
}

</script>

<style lang="scss" scoped >
.box{
    margin-top: 60px
}

</style>

