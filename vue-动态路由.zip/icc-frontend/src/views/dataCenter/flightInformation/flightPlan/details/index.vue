
<template>
  <div class="pageBox">
    <!-- 详情 -->
    <div class="title">
      <div class="title_left">
        <!-- YY航空公司夏秋航班计划(2021.03.29-2021.10.28) -->
        {{ leftTop }}{{ leftTopTime }}
      </div>
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" size="mini" style="width:120px" placeholder="航班号" />
          </el-form-item>
          <el-form-item>
            <el-time-picker v-model="formInline.value1" size="mini" style="width:130px" placeholder="任意时间点" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.hangLine" size="mini" style="width:120px" placeholder="航线">
              <el-option v-for="item in hangLine" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.acType" size="mini" style="width:120px" placeholder="机型">
              <el-option v-for="item in acType" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.banqi" multiple collapse-tags size="mini" style="width:120px" placeholder="班期">
              <el-option v-for="item in banqi" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini" @click="goBack">返回</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>

    <el-table :data="tableData">
      <el-table-column type="index" width="50" />

      <el-table-column prop="fltn" label="航班号" />
      <el-table-column prop="dltm" label="计划起飞时间" />
      <el-table-column prop="altm" label="计划到达时间" />
      <el-table-column label="航线" align="left">
        <template slot-scope="scope">
          {{ scope.row.lctycn }}———{{ scope.row.octycn }}
        </template>
      </el-table-column>
      <el-table-column prop="sfty" label="机型" />
      <el-table-column prop="freq" label="班期" />

      <el-table-column prop="type" label="国际国内" />
    </el-table>
    <div style="display:flex; align-items: center; ">

      <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
      <span>当前显示第 {{ page.pageNum }} 页</span>

    </div>
  </div>
</template>

<script>
import { quarterlylightlanistDetail } from '@/api/dataCenter'
export default {
  data() {
    return {
      leftTop: '',
      leftTopTime: '',
      page: {
        pageNum: 1,
        pageSize: 10,
        total: ''
      },
      formInline: {
        input: '',
        value1: '',
        hangLine: '',
        acType: '',
        banqi: ''
      },
      hangLine: [{ id: 1, label: '航线', value: 1 }],
      acType: [{ id: 1, label: '机型', value: 1 }],
      banqi: [{ id: 1, label: '1', value: 1 }, { id: 2, label: '2', value: 2 }, { id: 3, label: '3', value: 3 }, { id: 4, label: '4', value: 4 }, { id: 5, label: '5', value: 5 }],
      tableData: []
    }
  },
  created() {
    this.quarterlylightlanistDetails()
  },
  methods: {
    // 航季航班计划详细信息
    quarterlylightlanistDetails() {
      var data = {
        id: this.$route.query.planId,
        // id: 1493127609322610738,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize

      }
      quarterlylightlanistDetail(data).then(res => {
        console.log(res)
        this.leftTop = res.data.data.planName,
        this.leftTopTime = res.data.data.date,
        this.tableData = res.data.data.rows
        this.page.total = res.data.data.total
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.quarterlylightlanistDetails()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.quarterlylightlanistDetails()
    },

    goBack() {
      this.$router.go(-1)
    }
  }
}

</script>

<style scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    /* border:1px solid #fff */
}

.title_right{
    margin-right: 0;
    /* width: 65%; */
    height: 100%;
    display: flex;
    justify-content: space-around;
    align-items: center;

}

</style>

