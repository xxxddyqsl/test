
<template>
  <div class="pageBox">
    <div class="title">
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-select v-model="formInline.flyLight" size="mini" style="width:150px" placeholder="航季航线">
              <el-option v-for="item in flyLight" :key="item.id" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.flyClass" size="mini" style="width:150px" placeholder="航季航班" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini" @click="goBack">返回</el-button>
          </el-form-item>
        </el-form>

      </div>
    </div>

    <el-table :data="tableData" style="width: 100%">
      <el-table-column label="航季航线" prop="flyLight" />
      <el-table-column label="航季航班" prop="flyClass" />
      <el-table-column label="对比历史航线" prop="checkFlyLight" />
      <el-table-column label="对比历史航班" prop="checkFlyClass" />
      <el-table-column label="操作">
        <el-button type="primary" size="mini">调整</el-button>
      </el-table-column>
    </el-table>
  </div>

</template>

<script>
export default {
  data() {
    return {
      formInline: {
        flyLight: '',
        flyClass: ''
      },
      flyLight: [{ id: 1, label: '航季航线', value: '1' }],

      tableData: [
        { flyLight: 'PVG-PKX', flyClass: 'YY9141', checkFlyLight: 'PVG-PKX、SHA-PKX', checkFlyClass: 'YY9141、YY8848' },
        { flyLight: 'SHA-PKX', flyClass: 'YY9142', checkFlyLight: 'SHA-PKX', checkFlyClass: 'YY9142' }
      ]

    }
  },
  methods: {
    goBack() {
      this.$router.go(-1)
    }

  }
}

</script>

<style scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    /* border:1px solid #fff */
}

.title_right{
    margin-right: 0;
    /* width: 8%; */
    height: 100%;

}

</style>

