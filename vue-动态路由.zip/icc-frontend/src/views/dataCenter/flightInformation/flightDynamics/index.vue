
<template>
  <div class="pageBox">
    <!-- 航班动态 -->
    <div class="title">
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-date-picker v-model="formInline.value" type="date" size="mini" placeholder="选择关键日期" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input" size="mini" style="width:180px" placeholder="搜索关键字" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini">Excel模板</el-button>
            <el-button type="primary" size="mini">导入</el-button>
            <el-button type="primary" size="mini">拼合</el-button>
            <el-button type="primary" size="mini">获取航班最新动态</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>

    <el-table :data="tableData2">
      <el-table-column prop="hbh" label="航班日期" />
      <el-table-column prop="hbrq" label="承运人" />
      <el-table-column prop="gzbh" label="航班号" />
      <el-table-column prop="zl" label="国际国内" />
      <el-table-column prop="ctgzh" label="航班性质" />
      <el-table-column prop="ctzl" label="机型" />
      <el-table-column prop="cyrq" label="机号" />
      <el-table-column prop="hbh" label="起飞站" />
      <el-table-column prop="hbrq" label="到达站" />
      <el-table-column prop="gzbh" label="计划起飞时刻" />
      <el-table-column prop="zl" label="预计起飞时刻" />
      <el-table-column prop="ctgzh" label="实际起飞时刻" />
      <el-table-column prop="ctzl" label="计划到达时刻" />
      <el-table-column prop="cyrq" label="预计到达时刻" />
      <el-table-column prop="ctzl" label="实际到达时刻" />
      <el-table-column prop="cyrq" label="VIP" />
      <!-- <el-table-column label="操作">
        <el-button type="primary" style="margin:0 5px" size="mini">未读</el-button>
        <el-button type="primary" style="margin:0 5px" size="mini">前往</el-button>
      </el-table-column> -->
    </el-table>
    <div style="display:flex; align-items: center; ">

      <el-pagination background layout="prev, pager, next" :total="10" />
      <span>共 27 条数据 3 页  当前显示第 1 页</span>

    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      formInline: { value: '', input: '' },
      tableData2: []
    }
  }
}

</script>

<style scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    /* border:1px solid #fff */
}
.title_right{
    margin-right: 0;
    width: 50%;
    height: 100%;
    float: right;
    display: flex;
    align-items: center;
    justify-content: space-around;

}

</style>

