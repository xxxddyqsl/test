
<template>
  <div class="pageBox">
    <!-- 数据质量监控 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" size="mini" style="width:120px" placeholder="数据名称" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.value" size="mini" style="width:120px">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.value1" clearable size="mini" style="width:120px">
              <el-option v-for="item in options1" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData">
        <el-table-column prop="sjmc" label="数据名称" align="center" />
        <el-table-column prop="sjlx" label="数据类型" align="center" />
        <el-table-column prop="sjly" label="数据来源" align="center" />
        <el-table-column prop="sjzl" label="数据质量" align="center" />
        <el-table-column prop="sj" label="最新监控时间" align="center" />

      </el-table>
      <el-pagination background layout="total, prev, pager, next" :total="10" />
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      formInline: {
        input: '',
        value: '',
        value1: ''
      },
      options: [{ value: 1,
        label: '数据名称' }],
      options1: [{ value: 1,
        label: '数据来源' }],
      tableData: [{
        sjmc: '历史运价',
        sjlx: 'Double',
        sjly: 'T-card',
        sjzl: '合格',
        sj: '2021-10-01 07：18'
      }, {
        sjmc: '现用运价',
        sjlx: 'Double',
        sjly: 'T-card',
        sjzl: '合格',
        sj: '2021-10-01 07：18'
      }, {
        sjmc: '当前订座',
        sjlx: 'Double',
        sjly: 'ICS',
        sjzl: '合格',
        sj: '2021-10-01 07：18'
      }, {
        sjmc: '历史订座',
        sjlx: 'Double',
        sjly: 'ICS',
        sjzl: '合格',
        sj: '2021-10-01 07：18'
      }]
    }
  },
  methods: {
    addNew() {
      this.dialogAddNew = true
    }
  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}

</style>

