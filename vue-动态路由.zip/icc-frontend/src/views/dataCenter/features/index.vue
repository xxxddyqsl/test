
<template>
  <div class="pageBox">
    <div class="page_box">
      <el-radio-group v-model="radio">
        <el-radio-button label="航班优劣势" />
        <el-radio-button label="节假日信息" />
      </el-radio-group>
    </div>
    <div v-show="radio=='航班优劣势'">
      <strengthsWeaknesses />
    </div>
    <div v-show="radio=='节假日信息'">
      <holidayInformation />
    </div>
  </div>

</template>

<script>

import holidayInformation from '../holidayInformation'
import strengthsWeaknesses from '../../businessIntroduction/businessManagement/flightStrengthsAndWeaknessesManagement'
export default {
  components: {
    strengthsWeaknesses,
    holidayInformation
  },
  data() {
    return {
      radio: '航班优劣势'

    }
  },
  created() {

  },
  methods: {

  }

}

</script>

<style  lang='scss' scoped>

</style>
