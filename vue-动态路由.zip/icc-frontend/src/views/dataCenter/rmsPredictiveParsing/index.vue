<template>
  <div class="pageBox">
    <!-- 预警信息 -->
    <div class="title" />
    <Result />
  </div>
</template>

<script>
import Result from '../components/result'
export default {
  components: {
    // ,
    Result
  },
  data() {
    return {
      value2: '',
      input: '航线',
      input1: '航班号',
      img: require('@/assets/rmsyc/u16684.png'),
      img1: require('@/assets/rmsyc/u16687.png'),
      img2: require('@/assets/rmsyc/u16689.png'),
      img3: require('@/assets/rmsyc/u16690.png'),
      imgShow: true
    }
  },
  methods: {
    goEarlyWarningRules() {
      this.$router.push({ name: 'earlyWarningRules' })
    }
  }
}
</script>

<style scoped >
.box {
  margin-top: 60px;
}
.title {
  height: 50px;
  font-size: 20px;
  /* border:1px solid #fff */
}
.title_right {
  margin-right: 0;
  width: 28%;
  height: 100%;
  float: right;
  display: flex;
  align-items: center;
  justify-content: space-around;
}
</style>

