
<template>
  <div class="pageBox">
    <div>
      <el-radio-group v-model="radio">
        <el-radio-button label="竞争航班" />
        <el-radio-button label="市场运价" />
      </el-radio-group>
    </div>
    <div v-show="radio=='竞争航班'">
      <compete />
    </div>
    <div v-show="radio=='市场运价'">
      <internetFreightRate />
    </div>
  </div>

</template>

<script>

import internetFreightRate from '../basicData/aviationBiddingManagement'
import compete from '../../businessIntroduction/businessManagement/flightCompetitionManagement'
export default {
  components: {
    compete,
    internetFreightRate
  },
  data() {
    return {
      radio: '竞争航班'

    }
  },
  created() {

  },
  methods: {

  }

}

</script>
<style lang="scss" scoped>
.pageBox{

  .box{
height: 20px;
  }
}
</style>
