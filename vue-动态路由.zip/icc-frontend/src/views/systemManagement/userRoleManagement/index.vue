
<template>
  <div class="pageBox">
    <!-- 用户角色管理 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form
          :inline="true"
          size="small"
          label-width="60px"
          :model="queryForm"
        >
          <el-form-item>
            <el-input v-model="input" size="mini" placeholder="请输入用户名" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="input" size="mini" placeholder="请输入姓名" />
          </el-form-item>
          <el-form-item>
            <el-select filterable size="mini" clearable placeholder="请选择性别">
              <el-option
                v-for="item in planDeptAirport"
                :key="item.code"
                :label="item.code"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select filterable size="mini" clearable placeholder="请选择城市">
              <el-option
                v-for="item in planDeptAirport"
                :key="item.code"
                :label="item.code"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select filterable size="mini" clearable placeholder="请选择部门">
              <el-option
                v-for="item in planDeptAirport"
                :key="item.code"
                :label="item.code"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select filterable size="mini" clearable placeholder="请选择角色">
              <el-option
                v-for="item in planDeptAirport"
                :key="item.code"
                :label="item.code"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select filterable size="mini" clearable placeholder="请选择状态">
              <el-option
                v-for="item in planDeptAirport"
                :key="item.code"
                :label="item.code"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              style="margin: 0 5px"
              size="mini"
              @click="queryClick"
            >查询</el-button>
            <el-button
              type="primary"
              style="margin: 0 5px"
              size="mini"
              @click="addUser"
            >添加</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <el-table :data="tableData2" border>
      <el-table-column prop="yhm" label="用户名" />
      <el-table-column prop="xm" label="姓名" />
      <el-table-column prop="xb" label="性别" />
      <el-table-column prop="cs" label="城市" />
      <el-table-column prop="bm" label="部门" />
      <el-table-column prop="yyjs" label="拥有角色" />
      <el-table-column prop="zt" label="状态" />
      <el-table-column min-width="160">
        <template slot-scope="scope">
          <el-button
            type="primary"
            style="margin: 0 5px"
            size="mini"
            @click="amendClick(scope.row)"
          >修改</el-button>
          <el-button
            type="primary"
            style="margin: 0 5px"
            size="mini"
            @click="deleteClick(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination background layout="total, prev, pager, next" :total="10" />

    <el-dialog :title="form.title" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="姓名">
          <input v-model="form.xm" type="text">
        </el-form-item>
        <el-form-item label="性别">
          <el-select v-model="form.xb" placeholder="请选择性别">
            <el-option label="男" value="男" />
            <el-option label="女" value="女" />
          </el-select>
        </el-form-item>
        <el-form-item label="城市">
          <el-select v-model="form.cs" placeholder="请选择城市">
            <el-option label="上海" value="上海" />
            <el-option label="苏州" value="苏州" />
          </el-select>
        </el-form-item>
        <el-form-item label="部门">
          <el-select v-model="form.bm" placeholder="请选择部门">
            <el-option label="销售" value="销售" />
            <el-option label="研发" value="研发" />
          </el-select>
        </el-form-item>
        <el-form-item label="拥有角色">
          <el-select v-model="form.yyjs" placeholder="请选择角色权限">
            <el-option label="高级管理员" value="高级管理员" />
            <el-option label="中级管理员" value="中级管理员" />
            <el-option label="低级管理员" value="低级管理员" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="form.zt" placeholder="请选择状态">
            <el-option label="有效" value="有效" />
            <el-option label="已失效" value="已失效" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="amend">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData2: [
        {
          yhm: '***',
          xm: '***',
          xb: '男',
          cs: '上海',
          bm: '**',
          yyjs: '超级管理员',
          zt: '有效',
          id: 12
        },
        {
          yhm: '***',
          xm: '***',
          xb: '男',
          cs: '上海',
          bm: '**',
          yyjs: '超级管理员',
          zt: '有效',
          id: 21
        },
        {
          yhm: '***',
          xm: '***',
          xb: '男',
          cs: '上海',
          bm: '**',
          yyjs: '超级管理员',
          zt: '有效',
          id: 33
        },
        {
          yhm: '***',
          xm: '***',
          xb: '男',
          cs: '上海',
          bm: '**',
          yyjs: '超级管理员',
          zt: '有效',
          id: 42
        },
        {
          yhm: '***',
          xm: '***',
          xb: '男',
          cs: '上海',
          bm: '**',
          yyjs: '超级管理员',
          zt: '有效',
          id: 52
        },
        {
          yhm: '***',
          xm: '***',
          xb: '男',
          cs: '上海',
          bm: '**',
          yyjs: '超级管理员',
          zt: '有效',
          id: 62
        }
      ],
      dialogFormVisible: false,
      form: {},
      isAdd: true,
      queryForm: {
        yhm: '',
        xm: '',
        xb: '',
        cs: '',
        bm: '',
        js: '',
        zt: ''
      }
    }
  },
  methods: {
    /**
     * 根据名称查询查询
     * feat: 系统管理_用户角色管理_增删改查模拟
     */
    queryClick() {
      console.log(Math.round(new Date() / 1000))
      // this.tableData2 = this.tableData2.filter((v) => v.mc == this.input);
    },

    /**
     * 打开修改弹窗
     */
    amendClick(data) {
      this.dialogFormVisible = true
      this.isAdd = false
      this.form = JSON.parse(JSON.stringify(data))
      this.form.title = '修改用户'
      console.log(data)
    },
    /**
     * 打开修添加弹窗
     */
    addUser() {
      this.dialogFormVisible = true
      this.isAdd = true
      this.form.title = '添加用户'
    },
    /**
     * 确定修改
     */
    amend() {
      this.dialogFormVisible = false
      if (!this.isAdd) {
        // 修改操作
        this.tableData2.forEach((v, i) => {
          if (v.id == this.form.id) {
            v.yhm = this.form.yhm
            v.xm = this.form.xm
            v.xb = this.form.xb
            v.cs = this.form.cs
            v.bm = this.form.bm
            v.yyjs = this.form.yyjs
            v.zt = this.form.zt
          }
        })
      } else {
        // 添加操作
        console.log('添加')
        const newUser = {}
        newUser.yhm = this.form.yhm
        newUser.xm = this.form.xm
        newUser.xb = this.form.xb
        newUser.cs = this.form.cs
        newUser.bm = this.form.bm
        newUser.yyjs = this.form.yyjs
        newUser.zt = this.form.zt
        newUser.id = Math.round(new Date() / 1000)
        this.tableData2.push(newUser)
      }
    },

    /**
     * 删除
     */
    deleteClick(data) {
      this.$confirm(`此操作将永久删除管理员${data.xm}, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.tableData2.forEach((v, i) => {
            if (v.id == data.id) {
              this.tableData2.splice(i, 1)
            }
          })
          // 删除操作
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    }
  }
}
</script>

<style lang="scss" scoped >
.box {
  margin-top: 60px;
}

</style>

