
<template>
  <div class="pageBox">
    <!-- 头部表单 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formSelect" size="small">
          <el-form-item>
            <el-input v-model="formSelect.userName" placeholder="请输入用户名" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formSelect.name" placeholder="请输入姓名" />
          </el-form-item>
          <el-form-item label-width="60px">
            <el-date-picker
              v-model="formSelect.date"
              size="small"
              clearable
              value-format="yyyy-MM-dd"
              type="daterange"
              range-separator="|"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="onSubmit">查询</el-button>
            <el-switch
              v-model="newOld"
              active-text="默认"
              inactive-text="看系统日志"
              @change="switchChange"
            />
            <el-tooltip content="默认不看后台系统的日志" placement="top">
              <i class="el-icon-question help-icon" />
            </el-tooltip>
            <el-button
              size="small"
              type="primary"
              @click="exportClick"
            >导出</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 表格展示 -->
    <div class="table-style">
      <el-table
        :data="tableData"
        border
        :header-cell-style="{ background: '#F5F7FA' }"
      >
        <el-table-column type="index" width="45" />
        <el-table-column prop="username" label="用户名" />
        <el-table-column prop="name" label="姓名" />
        <el-table-column prop="ipAddress" label="IP地址" />
        <el-table-column prop="modeMessage" label="功能模块" />
        <el-table-column prop="message" label="日志摘要" />
        <el-table-column prop="updateTime" label="操作时间" />
      </el-table>
      <div class="block">
        <el-pagination
          background
          :current-page="page.currentPage4"
          :page-size="page.pageSize"
          layout="total, prev, pager, next"
          :total="page.totalCount"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      date: '',
      newOld: true,
      page: {
        currentPage4: 1,
        totalCount: 0,
        pageSize: 10
      },
      formLabelWidth: '170px',
      roleOptions: [],
      formEdit: {},
      formSelect: {
        userName: '',
        name: '',
        date: ['', '']
      },
      data: {},
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      value1: '',
      tableData: [
        {
          username: '****',
          name: '****',
          ipAddress: '****',
          modeMessage: '****',
          message: '****',
          updateTime: '****'
        },
        {
          username: '****',
          name: '****',
          ipAddress: '****',
          modeMessage: '****',
          message: '****',
          updateTime: '****'
        },
        {
          username: '****',
          name: '****',
          ipAddress: '****',
          modeMessage: '****',
          message: '****',
          updateTime: '****'
        },
        {
          username: '****',
          name: '****',
          ipAddress: '****',
          modeMessage: '****',
          message: '****',
          updateTime: '****'
        },
        {
          username: '****',
          name: '****',
          ipAddress: '****',
          modeMessage: '****',
          message: '****',
          updateTime: '****'
        },
        {
          username: '****',
          name: '****',
          ipAddress: '****',
          modeMessage: '****',
          message: '****',
          updateTime: '****'
        }
      ]
    }
  },
  created() {
    // 初始化页面
    this.initial()
  },
  methods: {
    /**
     * 导出
     */
    exportClick() {
      console.log('导出按钮')
    },

    /**
     * 每页数量变化函数
     */
    handleSizeChange() {
      console.log('每页数量变化函数')
    },

    /**
     * 切换分页
     */
    handleCurrentChange(val) {
      console.log(val, '切换分页')
    },

    /**
     * 切换按钮
     */
    switchChange() {
      console.log('切换按钮')
    },

    /**
     * 请求数据
     */
    initial() {
      console.log('请求数据')
    },

    /**
     * 表单提交
     */
    onSubmit() {
      console.log('表单提交')
    },

    handleEditClick(index, row) {}
  }
}
</script>

<style
  scoped
  lang="scss">
.block {
  display: flex;
  height: 40px;
  align-items: center;
  justify-content: flex-end;
  font-size: 13px;
}
.box {
  margin-top: 60px;
}

.table-style {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
}
.box {
  margin-top: 60px;
}

</style>

