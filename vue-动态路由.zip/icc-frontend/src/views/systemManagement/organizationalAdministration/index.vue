
<template>
  <div class="pageBox">
    <!-- 组织管理 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <el-input
              v-model="input"
              size="mini"
              style="width: 180px"
              placeholder="请输入航线"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="input2"
              size="mini"
              style="width: 180px"
              placeholder="请输入控仓人员"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="input3"
              size="mini"
              style="width: 180px"
              placeholder="请输入负责人员"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              style="margin: 0 5px"
              size="mini"
              @click="queryClick()"
            >查询</el-button>
            <el-button
              type="primary"
              style="margin: 0 5px"
              size="mini"
              @click="goStructure()"
            >组织架构</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <el-table :data="tableData2" border>
      <el-table-column prop="hx" label="航线" />
      <el-table-column prop="hbl" label="航班量" />
      <el-table-column prop="sfdf" label="是否独飞" />
      <el-table-column prop="ywjz" label="有无竞争" />
      <el-table-column prop="kcry" label="控舱人员" />
      <el-table-column prop="fzry" label="负责人员" />
      <el-table-column prop="gxrq" label="更新日期" />
      <el-table-column prop="gxyh" label="更新用户" />
      <el-table-column min-width="160">
        <template slot-scope="scope">
          <el-button
            type="primary"
            style="margin: 0 5px"
            size="mini"
            @click="amendClick(scope.row)"
          >修改</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination background layout="total, prev, pager, next" :total="10" />

    <el-dialog
      :title="'角色编码' + form.jsbm"
      :visible.sync="dialogFormVisible"
    >
      <el-form :model="form">
        <el-form-item label="名称">
          <el-select v-model="form.mc" placeholder="请选择活动区域">
            <el-option label="高级管理员" value="高级管理员" />
            <el-option label="中级管理员" value="中级管理员" />
            <el-option label="低级管理员" value="低级管理员" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="amend">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData2: [
        {
          hx: 'XIY-BAV',
          hbl: '20',
          sfdf: '是',
          ywjz: '无',
          kcry: '张三 ',
          fzry: '张三',
          gxrq: '2020-07-01',
          gxyh: '区域管理员'
        },
        {
          hx: 'XIY-BAV',
          hbl: '20',
          sfdf: '是',
          ywjz: '无',
          kcry: '张三 ',
          fzry: '张三',
          gxrq: '2020-07-01',
          gxyh: '区域管理员'
        },
        {
          hx: 'XIY-BAV',
          hbl: '20',
          sfdf: '是',
          ywjz: '无',
          kcry: '张三 ',
          fzry: '张三',
          gxrq: '2020-07-01',
          gxyh: '区域管理员'
        },
        {
          hx: 'XIY-BAV',
          hbl: '20',
          sfdf: '是',
          ywjz: '无',
          kcry: '张三 ',
          fzry: '张三',
          gxrq: '2020-07-01',
          gxyh: '区域管理员'
        },
        {
          hx: 'XIY-BAV',
          hbl: '20',
          sfdf: '是',
          ywjz: '无',
          kcry: '张三 ',
          fzry: '张三',
          gxrq: '2020-07-01',
          gxyh: '区域管理员'
        }

      ],
      dialogFormVisible: false,
      form: {},
      input: ''
    }
  },
  methods: {
    goStructure() {

    },
    /**
     * 根据名称查询查询
     */
    queryClick() {
      this.tableData2 = this.tableData2.filter((v) => v.mc == this.input)
    },

    /**
     * 打开修改弹窗
     */
    amendClick(data) {
      this.dialogFormVisible = true
      this.form = JSON.parse(JSON.stringify(data))
    },
    /**
     * 确定修改
     */
    amend() {
      this.dialogFormVisible = false
      this.tableData2.forEach((v, i) => {
        if (v.jsbm == this.form.jsbm) {
          v.mc = this.form.mc
        }
      })
    },

    /**
     * 删除
     */
    deleteClick(data) {
      this.$confirm(`此操作将永久删除管理员${data.jsbm}, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.tableData2.forEach((v, i) => {
            if (v.jsbm == data.jsbm) {
              this.tableData2.splice(i, 1)
            }
          })
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    }
  }
}
</script>

<style scoped >
.box {
  margin-top: 60px;
}

</style>

