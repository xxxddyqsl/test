
<template>
  <div class="pageBox">
    <!-- 头部表单 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formSelect" size="small">
          <el-form-item>
            <el-input v-model="formSelect.label" placeholder="请输入名称" />
          </el-form-item>
          <el-form-item label-width="60px">
            <el-date-picker
              v-model="formSelect.date"
              size="small"
              clearable
              value-format="yyyy-MM-dd"
              type="daterange"
              range-separator="|"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="init('查询')">查询</el-button>
            <el-button type="primary" @click="reset">重置</el-button>
            <el-button type="primary" @click="add">添加</el-button>
            <el-button type="primary" @click="removefn">删除</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 表格展示 -->
    <el-table
      ref="multipleTable"
      :data="tableData"
      style="width: 100%; margin-bottom: 20px"
      row-key="id"
      border
      :default-expand-all="false"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column prop="label" label="名称" sortable width="180" />
      <el-table-column prop="type" label="类型" width="180" />
      <el-table-column prop="path" label="地址" />
      <el-table-column prop="component" label="组件" />
      <el-table-column prop="hidden" label="是否隐藏">
        <template slot-scope="scope">
          {{ scope.row.hidden ? "是" : "否" }}
        </template>
      </el-table-column>

      <el-table-column prop="authority" label="权限" />
      <el-table-column prop="description" label="备注" />

      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="primary"
            style="margin: 0 5px"
            size="mini"
            @click="amendClick(scope.row)"
            >修改</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <div>
      <el-dialog v-dialogDrag :title="title" :visible.sync="editVisible">
        <el-form ref="formEdit" :model="formEdit" :rules="formRules">
          <el-form-item
            v-if="title == '添加'"
            label="父级菜单"
            :label-width="formLabelWidth"
          >
            <el-tree
              ref="tree"
              :data="tableData"
              show-checkbox
              node-key="id"
              :props="defaultProps"
              check-strictly
            />
          </el-form-item>
          <el-form-item prop="type" label="类型" :label-width="formLabelWidth">
            <el-select v-model="formEdit.type" placeholder="请选择">
              <el-option
                v-for="item in options"
                :key="item.code"
                :label="item.name"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            prop="label"
            label="资源名称"
            :label-width="formLabelWidth"
          >
            <el-input v-model="formEdit.label" placeholder="请输入" />
          </el-form-item>
          <el-form-item
            prop="path"
            label="菜单URL"
            :label-width="formLabelWidth"
          >
            <el-input v-model="formEdit.path" placeholder="请输入" />
          </el-form-item>
          <el-form-item
            prop="component"
            label="组件地址"
            :label-width="formLabelWidth"
          >
            <el-input v-model="formEdit.component" placeholder="请输入" />
          </el-form-item>
          <el-form-item
            prop="hidden"
            label="是否隐藏"
            :label-width="formLabelWidth"
          >
            <el-radio v-model="formEdit.hidden" :label="true">是</el-radio>
            <el-radio v-model="formEdit.hidden" :label="false">否</el-radio>
          </el-form-item>
          <el-form-item
            prop="authority"
            label="相关权限"
            :label-width="formLabelWidth"
          >
            <el-input v-model="formEdit.authority" placeholder="请输入" />
          </el-form-item>
          <el-form-item
            prop="weight"
            label="菜单排序"
            :label-width="formLabelWidth"
          >
            <el-input v-model="formEdit.weight" placeholder="请输入" />
          </el-form-item>
          <el-form-item
            prop="description"
            label="备注"
            :label-width="formLabelWidth"
          >
            <el-input v-model="formEdit.description" placeholder="请输入" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button
            style="background: #495373; color: white"
            @click="editVisible = false"
            >取 消</el-button
          >
          <el-button type="primary" @click="handleEditClick('formEdit')"
            >确 定</el-button
          >
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { initTable, addMenu, remove, edit } from "@/api/menuManage";
export default {
  data() {
    return {
      formSelect: { date: [], label: "" },
      defaultProps: {
        children: "children",
        label: "label",
      },
      arryData: [],
      tableData: [],
      options: [
        { name: "菜单", code: "menu" },
        { name: "子菜单", code: "submenu" },
        { name: "按钮", code: "button" },
      ],
      title: "添加",
      editVisible: false,
      ids: [],
      formEdit: {},
      formLabelWidth: "120px",
      formRules: {
        // label: [{ required: true, message: '请输入', trigger: 'blur' }],
        // path: [{ required: true, message: '请输入', trigger: 'blur' }],
        // route: [{ required: true, message: '请输入', trigger: 'blur' }],
        // authority: [{ required: true, message: '请输入', trigger: 'blur' }],
        // weight: [{ required: true, message: '请输入', trigger: 'blur' }],
        // parentId: [{ required: true, message: '请选择', trigger: 'change' }]
      },
    };
  },
  created() {
    this.init();
  },
  methods: {
    init(parmas) {
      var data = {
        label: this.formSelect.label,
        fromDate: this.formSelect.date[0] || "",
        endDate: this.formSelect.date[1] || "",
      };
      initTable(data).then((res) => {
        if (res.data.code === "200") {
          this.tableData = res.data.data;
          if (parmas) {
            this.$message.success("查询成功");
          }
        }
      });
    },

    add() {
      this.title = "添加";
      this.editVisible = true;
      this.formEdit = {
        label: "",
        path: "",
        route: "",
        authority: "",
        weight: "",
        type: "",
        description: "",
        hidden: false,
      };
    },
    reset() {
      this.formSelect = { date: [], label: "" };
      this.init();
    },
    handleSelectionChange(selection) {
      this.ids = [];
      selection.forEach((element) => {
        this.ids.push(element.id);
      });
    },
    amendClick(rows) {
      this.title = "修改";
      this.editVisible = true;
      this.formEdit = Object.assign(rows);
    },
    handleEditClick(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.title == "添加") {
            var data = Object.assign(this.formEdit);
            data.parentId = this.$refs.tree.getCheckedNodes();
            addMenu(data).then((res) => {
              if (res.data.code === "200") {
                this.$message.success("添加成功");
                this.editVisible = false;
                this.init();
              }
            });
          } else {
            var data2 = Object.assign(this.formEdit);
            delete data2.parentId;
            edit(data2).then((res) => {
              if (res.data.code === "200") {
                this.$message.success("修改成功");
                this.editVisible = false;
                this.init();
              }
            });
          }
        } else {
          return false;
        }
      });
    },
    // 删除
    removefn() {
      var data2 = {
        ids: this.ids,
      };
      this.$confirm("确认删除这条数据吗？", "提示", {
        confirmButtonText: "确认",
        cancelButtonText: "取消",
      })
        .then(() => {
          remove(data2).then((response) => {
            if (response.data.code === "200") {
              this.init();
              this.$message({
                type: "success",
                message: "删除成功",
              });
            }
          });
        })
        .catch(() => {});
    },
  },
};
</script>

<style
  scoped
  lang="scss">
</style>

