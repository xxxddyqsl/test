
<template>
  <div class="pageBox">
    <!-- 用户权限管理 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <div style="font-size: 12px">
              名称 &nbsp;<el-input
                v-model="input"
                size="mini"
                style="width: 180px"
                placeholder="请输入"
              />
            </div>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              style="margin: 0 5px"
              size="mini"
              @click="queryClick()"
            >查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <el-table :data="tableData2" border>
      <el-table-column prop="mc" label="名称" />
      <el-table-column prop="jsbm" label="角色编码" />
      <el-table-column>
        <template slot-scope="scope">
          <el-button
            type="primary"
            style="margin: 0 5px"
            size="mini"
            @click="amendClick(scope.row)"
          >修改</el-button>
          <el-button
            type="primary"
            style="margin: 0 5px"
            size="mini"
            @click="deleteClick(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination background layout="total, prev, pager, next" :total="10" />

    <el-dialog
      :title="'角色编码' + form.jsbm"
      :visible.sync="dialogFormVisible"
    >
      <el-form :model="form">
        <el-form-item label="名称">
          <el-select v-model="form.mc" placeholder="请选择活动区域">
            <el-option label="高级管理员" value="高级管理员" />
            <el-option label="中级管理员" value="中级管理员" />
            <el-option label="低级管理员" value="低级管理员" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="amend">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData2: [
        {
          mc: '高级管理员',
          jsbm: 'ADMIN1'
        },
        {
          mc: '中级管理员',
          jsbm: 'BDMIN2'
        },
        {
          mc: '高级管理员',
          jsbm: 'ADMIN3'
        },
        {
          mc: '低级管理员',
          jsbm: 'CDMIN4'
        },
        {
          mc: '高级管理员',
          jsbm: 'ADMIN5'
        },
        {
          mc: '中级管理员',
          jsbm: 'BDMIN6'
        },
        {
          mc: '高级管理员',
          jsbm: 'ADMIN7'
        },
        {
          mc: '低级管理员',
          jsbm: 'CDMIN8'
        },
        {
          mc: '高级管理员',
          jsbm: 'ADMIN9'
        },
        {
          mc: '中级管理员',
          jsbm: 'BDMIN6'
        },
        {
          mc: '高级管理员',
          jsbm: 'ADMIN7'
        },
        {
          mc: '低级管理员',
          jsbm: 'CDMIN8'
        },
        {
          mc: '高级管理员',
          jsbm: 'ADMIN9'
        }

      ],
      dialogFormVisible: false,
      form: {},
      input: ''
    }
  },
  methods: {
    /**
     * 根据名称查询查询
     */
    queryClick() {
      this.tableData2 = this.tableData2.filter((v) => v.mc == this.input)
    },

    /**
     * 打开修改弹窗
     */
    amendClick(data) {
      this.dialogFormVisible = true
      this.form = JSON.parse(JSON.stringify(data))
    },
    /**
     * 确定修改
     */
    amend() {
      this.dialogFormVisible = false
      this.tableData2.forEach((v, i) => {
        if (v.jsbm == this.form.jsbm) {
          v.mc = this.form.mc
        }
      })
    },

    /**
     * 删除
     */
    deleteClick(data) {
      this.$confirm(`此操作将永久删除管理员${data.jsbm}, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.tableData2.forEach((v, i) => {
            if (v.jsbm == data.jsbm) {
              this.tableData2.splice(i, 1)
            }
          })
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    }
  }
}
</script>

<style scoped >
.box {
  margin-top: 60px;
}

</style>

