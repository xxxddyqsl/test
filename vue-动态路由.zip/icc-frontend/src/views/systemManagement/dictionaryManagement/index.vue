
<template>
  <div class="pageBox">
    <!-- 数据字典 -->
    <div class="pageBox_neck">
      <el-button type="primary" size="mini" @click="onRefreshCache">刷新缓存</el-button>
    </div>
    <div class="pageAll">
      <div class="pageLeft">
        <!-- tree -->

        <div class="pageLeftTitle">
          <div>
            根目录
          </div>
          <div>
            <el-button type="primary" size="mini" @click="onRootAdd">添加</el-button>
          </div>

        </div>
        <el-tree :data="data" :props="defaultProps" node-key="id" :expand-on-click-node="false" @node-click="handleNodeClick" />
      </div>
      <div class="pageRight">
        <div class="pageRightTops">
          <div class="name">字典</div>
          <div class="names">
            <div>字典名称:{{ name }}</div>
            <div>字典编号:{{ code }}</div>
            <div>
              <el-button type="primary" size="mini" @click="onDleteRoot">删除科目</el-button>
              <el-button type="primary" size="mini" @click="onEditRoot">编辑科目</el-button>
            </div>
          </div>
        </div>
        <div class="pageRightMind">
          <div class="pageRightMindLeft">
            <div class="pageRightTop">
              <span>科目列表</span>
              <el-button type="primary" size="mini" @click="onAddRootList">添加</el-button>
            </div>
            <div class="pageTable">
              <el-table :data="tableDataT" border>
                <el-table-column prop="name" label="数据字典名称" />
                <el-table-column prop="code" label="数据字典编码" />
                <el-table-column prop="updateUser" label="创建者" />
                <el-table-column prop="updateTime" label="更新时间" />
                <el-table-column prop="createTime" label="创建时间" />
                <el-table-column label="操作" fixed="right">
                  <template slot-scope="scope">
                    <el-button type="primary" style="margin: 3px 5px" size="mini" @click="onEditList(scope.row)">修改</el-button><br>
                    <el-button type="primary" style="margin: 3px 5px" size="mini" @click="onDeleteBtn(scope.row)">删除</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>

          </div>
          <div>
            <div class="pageRightTop">
              <span>科目项列表</span>
              <el-button type="primary" size="mini" @click="onAddRootChild">添加</el-button>
            </div>
            <div class="page_table">
              <el-table :data="tableData" border>
                <el-table-column prop="name" label="数据字典名称" />
                <el-table-column prop="code" label="数据字典编码" />
                <el-table-column prop="updateUser" label="创建者" />
                <el-table-column prop="updateTime" label="更新时间" />
                <el-table-column prop="createTime" label="创建时间" />
                <el-table-column label="操作" fixed="right">
                  <template slot-scope="scope">
                    <el-button type="primary" style="margin: 3px 5px" size="mini" @click="onEditValue(scope.row)">修改</el-button><br>
                    <el-button type="primary" style="margin: 3px 5px" size="mini" @click="onDeleteValue(scope.row)">删除</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>

          </div>
        </div>
      </div>

      <div>
        <el-dialog v-dialogDrag :title="title" width="30%" :visible.sync="dialogAddRootDirectory">
          <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="150px">
            <el-form-item label="数据字典名称" prop="name">
              <el-input v-model="taskForm.name" size="mini" style="width:180px" placeholder="请输入" />
            </el-form-item>
            <el-form-item label="数据字典编码" prop="code">
              <el-input v-model="taskForm.code" size="mini" style="width:180px" placeholder="请输入" />
            </el-form-item>
            <el-form-item v-if="title=='添加科目项列表' || title=='修改科目项列表'" label="排序" prop="weight">
              <el-input v-model="taskForm.weight" size="mini" style="width:180px" placeholder="请输入" />
            </el-form-item>
            <el-form-item label="描述" prop="description">
              <el-input v-model="taskForm.description" size="mini" style="width:180px" placeholder="请输入" />
            </el-form-item>

          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button style="margin:0 5px" @click="dialogAddRootDirectory = false">取 消</el-button>
            <el-button style="margin:0 5px" type="primary" @click="onMakeSure('taskForm')">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>

<script>
import { treeData, rootAddData, queryRootList, deleteRootList, addRootValue, editValue, deleteValues, queryValue, editRoot, refreshCache } from '@/api/dictionaryManagement'
export default {
  data() {
    // var var reg=/^[1-9]+\d*$/
    var validatePass = (rule, value, callback) => {
      var reg = /^[1-9]+\d*$/ // 大于等于0的正整数
      if (value === '') {
        callback(new Error('不能为空'))
      } else if (reg.test(value) !== true) {
        callback(new Error('请输入大于0的正整数!'))
      } else {
        callback()
      }
    }
    return {
      data: [],
      title: '',
      taskForm: { name: '', code: '', description: '', weight: '' },
      parentId: '',
      rules: {
        name: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        code: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        description: [
          { required: true, message: '不能为空', trigger: 'blur' }

        ],
        weight: [
          { required: true, validator: validatePass, trigger: 'blur' }

        ]
      },
      dialogAddRootDirectory: false,
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      tableData: [],
      tableDataT: [],
      name: '',
      code: '',
      rootId: '',
      editListId: '',
      editValueId: ''
    }
  },
  created() {
    this.treeDatas()
  },

  methods: {
    // 刷新缓存按钮
    onRefreshCache() {
      refreshCache().then(res => {
        if (res.data.code === '200') {
          this.$message.success('刷新成功')
        } else {
          this.$message.error('刷新失败')
        }
      })
    },
    // 清除数据
    clear() {
      this.taskForm = {
        name: '', code: '', description: '', weight: ''
      }
    },
    // 修改字典值
    onEditValue(item) {
      this.editValueId = item.id
      this.title = '修改科目项列表'
      this.dialogAddRootDirectory = true
      this.taskForm.name = item.name
      this.taskForm.code = item.code
      this.taskForm.description = item.description
      this.taskForm.weight = item.weight
    },
    // 修改字典
    onEditList(item) {
      this.editListId = item.id
      this.title = '修改科目列表'
      this.dialogAddRootDirectory = true
      this.taskForm.name = item.name
      this.taskForm.code = item.code
      this.taskForm.description = item.description
    },

    // 修改根目录
    onEditRoot() {
      this.title = '修改根目录'
      this.dialogAddRootDirectory = true
    },
    // 删除根目录  删除科目按钮
    onDleteRoot() {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteRootList(this.rootId).then(res => {
          if (res.data.code === '200') {
            this.treeDatas()
            this.$message.success('删除成功')
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 删除科目列表
    onDeleteBtn(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteRootList(item.id).then(res => {
          if (res.data.code === '200') {
            this.queryRootLists()
            this.$message.success('删除成功')
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 删除科目项 按钮
    onDeleteValue(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteValues(item.id).then(res => {
          if (res.data.code === '200') {
            this.queryValues()
            this.$message.success('删除成功')
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 根据字典目录的code查询该字典目录下所有的子级
    queryRootLists() {
      const data = {
        code: this.code
      }
      queryRootList(data).then(res => {
        if (res.data.code === '200') {
          this.tableDataT = res.data.data.children || []
        }
      })
    },
    // 查询s字典值的接口
    queryValues() {
      const data = {
        code: this.code
      }
      queryValue(data).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data || []
        }
      })
    },

    // 科目列表添加按钮
    onAddRootList() {
      this.title = '添加科目列表'
      this.dialogAddRootDirectory = true
      this.clear()
    },
    // 科目列表项添加按钮
    onAddRootChild() {
      this.title = '添加科目项列表'
      this.dialogAddRootDirectory = true
      this.clear()
    },
    // 弹框确定按钮
    onMakeSure(formName) {
      if (this.title === '添加根目录') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              name: this.taskForm.name,
              code: this.taskForm.code,
              description: this.taskForm.description
            }
            rootAddData(data).then(res => {
              if (res.data.code === '200') {
                this.treeDatas()
                this.taskForm = {
                  name: '', code: '', description: '', weight: ''
                }
                this.dialogAddRootDirectory = false
                this.$message.success('新增成功')
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '修改根目录') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              name: this.taskForm.name,
              code: this.taskForm.code,
              description: this.taskForm.description,
              id: this.rootId
            }
            editRoot(data).then(res => {
              if (res.data.code === '200') {
                this.treeDatas()
                this.taskForm = {
                  name: '', code: '', description: '', weight: ''
                }
                this.dialogAddRootDirectory = false
                this.$message.success('修改成功')
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '添加科目列表') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              name: this.taskForm.name,
              code: this.taskForm.code,
              description: this.taskForm.description,
              parentId: this.rootId
            }
            rootAddData(data).then(res => {
              if (res.data.code === '200') {
                this.queryRootLists()
                this.taskForm = {
                  name: '', code: '', description: '', weight: ''
                }
                this.dialogAddRootDirectory = false
                this.$message.success('新增成功')
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '修改科目列表') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              id: this.editListId,
              name: this.taskForm.name,
              code: this.taskForm.code,
              description: this.taskForm.description,
              parentId: this.rootId
            }
            editRoot(data).then(res => {
              if (res.data.code === '200') {
                this.queryRootLists()
                this.taskForm = {
                  name: '', code: '', description: '', weight: ''
                }
                this.dialogAddRootDirectory = false
                this.$message.success('修改成功')
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '添加科目项列表') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              name: this.taskForm.name,
              code: this.taskForm.code,
              description: this.taskForm.description,
              dictionaryId: this.rootId,
              weight: Number(this.taskForm.weight)
            }
            addRootValue(data).then(res => {
              if (res.data.code === '200') {
                this.queryValues()
                this.taskForm = {
                  name: '', code: '', description: '', weight: ''
                }
                this.dialogAddRootDirectory = false
                this.$message.success('新增成功')
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '修改科目项列表') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const data = {
              id: this.editValueId,
              name: this.taskForm.name,
              code: this.taskForm.code,
              description: this.taskForm.description,
              dictionaryId: this.rootId,
              weight: Number(this.taskForm.weight)
            }
            editValue(data).then(res => {
              if (res.data.code === '200') {
                this.queryValues()
                this.taskForm = {
                  name: '', code: '', description: '', weight: ''
                }
                this.dialogAddRootDirectory = false
                this.$message.success('修改成功')
              }
            })
          } else {
            return false
          }
        })
      }
    },
    // onRootAdd 根目录添加按钮
    onRootAdd() {
      this.title = '添加根目录'
      this.dialogAddRootDirectory = true
      this.clear()
    },
    // 树结构
    treeDatas() {
      treeData().then(res => {
        if (res.data.code === '200') {
          this.data = res.data.data || []
        }
      })
    },
    handleNodeClick(data) {
      this.name = data.name
      this.code = data.code
      this.rootId = data.id
      this.tableData = data.dictionaryItemVOS || []
      this.tableDataT = data.children || []
      this.taskForm.name = data.name
      this.taskForm.code = data.code
      this.taskForm.description = data.description
    }
  }
}
</script>

<style lang='scss' scoped >
.pageBox_neck{
  padding: 10px 20px;
  display: flex;
  justify-content:flex-end;
}
.pageAll {
  display: flex;
  justify-content: space-between;
  .pageLeft {

    width: 20%;
    // background-color: blueviolet;
    .pageLeftTitle{
      // border-radius: 10px;s
      padding: 0 20px;
      height: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color:#EBF1FF;
      }
      .el-tree{
      background-color:#FFF;
      }
  }
  .pageRight {
    width: 78%;
    .pageRightMind{
      display: flex;
      justify-content: space-between;
      div{
        flex: 1;
      .pageRightTop {
      height: 50px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 35px;
      background-color: #E6ECFB;
    }
    .pageTable{
      width: 99%;
    }
    .page_table{
      display: flex;
      justify-content: flex-end;
    }
      }
    }
    .pageRightTops{
      .name{
        padding-left: 20px;
        height: 40px;
        line-height:40px;
        background-color: #EBF1FF;
      }
      .names{
        height: 80px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background-color: #FFF;
        font-size: 20px;
         text-align: center;
        div{
          width: 45%;
          white-space: nowrap;
        }
      }
    }
  }
}

</style>

