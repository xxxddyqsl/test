
<template>
  <div class="pageBox">
    <!-- 组织管理 -->
    <div class="seachBox">
      <div class="title_left">
        <el-radio-group v-model="radio1">
          <el-radio-button label="西北分子公司" />
          <el-radio-button label="西南分子公司" />
          <el-radio-button label="华北分子公司" />
          <el-radio-button label="华东分子公司" />
          <el-radio-button label="中部分子公司" />
        </el-radio-group>
      </div>
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" size="mini" style="width:120px" placeholder="航线" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini" @click="addUser">添加</el-button>
            <el-button type="primary" size="mini" @click="goDetails">分子公司管理</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <el-table :data="tableData" border>
      <el-table-column prop="mc" label="区域名称" />
      <el-table-column prop="mc1" label="航线数量" />
      <el-table-column prop="mc2" label="负责航线" />
      <el-table-column prop="mc3" label="区域负责人(区域管理员)" />
      <el-table-column prop="mc4" label="备注" />

      <el-table-column label="操作" min-width="160">
        <template slot-scope="scope">
          <el-button style="margin:0 5px" type="primary" size="mini" @click="amendClick(scope.row)">修改</el-button>
          <el-button style="margin:0 5px" type="primary" size="mini" @click="deleteClick(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination background layout="total, prev, pager, next" :total="10" />

    <el-dialog :title="form.title" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="区域名称">
          <input v-model="form.mc" type="text">
        </el-form-item>
        <el-form-item label="航线数量">
          <input v-model="form.mc1" type="text">
        </el-form-item>
        <el-form-item label="负责航线">
          <input v-model="form.mc2" type="text">
        </el-form-item>
        <el-form-item label="区域负责人">
          <input v-model="form.mc3" type="text">
        </el-form-item>
        <el-form-item label="备注">
          <input v-model="form.mc4" type="text">
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="amend">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      formInline: { input: '' },
      dialogFormVisible: false,
      form: {},
      radio1: '西北分子公司',
      tableData:
      [{
        mc: '陕北区域',

        mc1: 15,

        mc2: 'XIY-KMG、XIY-LXA',

        mc3: '张三'
      }]
    }
  },
  methods: {
    /**
     * 打开修改弹窗
     */
    amendClick(data) {
      this.dialogFormVisible = true
      this.isAdd = false
      this.form = JSON.parse(JSON.stringify(data))
      this.form.title = '修改用户'
    },
    /**
     * 打开修添加弹窗
     */
    addUser() {
      this.dialogFormVisible = true
      this.isAdd = true
      this.form = {}
      this.form.title = '添加用户'
    },
    /**
     * 确定修改
     */
    amend() {
      this.dialogFormVisible = false
    },

    /**
     * 删除
     */
    deleteClick(data) {
      console.log('123')
      this.$confirm(`此操作将永久删除, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          // 删除操作
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    goDetails() {
      this.$router.push({ name: 'organizationManagementDetails' })
    }

  }
}

</script>

<style scoped >
.box{
    margin-top: 60px
}

.neck{
    height: 50px;
}
.neck ul{
     height: 50px;
    list-style-type: none;
    display: flex;
    align-items: center;
}
.neck ul li{
    width: 200px;
    height: 100%;
    line-height:  100%;
    background-color: #ccc;
    margin-right: 2px;
    border:1px solid;
    text-align: center;
    line-height: 50px;
    color: #fff;
}

@media screen and (max-width: 1360px) {
  .seachBox{
    flex-direction: column;
    justify-content: start;
    align-items: start;
  }
  .title_left{
    margin-bottom: 10px;
    min-width: 660px;
  }
}
</style>

