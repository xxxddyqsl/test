
<template>
  <div class="pageBox">
    <!-- 分子公司管理详情 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <el-button type="primary" style="margin:0 5px" size="mini">添加</el-button>
            <el-button type="primary" style="margin:0 5px" size="mini" @click="goBack">返回</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>

    <el-table :data="tableData2">
      <el-table-column prop="mc" label="分子公司名称" />
      <el-table-column prop="jsbm" label="分子公司负责人(区域管理员)" />
      <el-table-column prop="mcc" label="备注" />
      <el-table-column>
        <el-button type="primary" size="mini">修改</el-button>
        <el-button type="primary" size="mini">删除</el-button>
      </el-table-column>
    </el-table>

    <el-pagination background layout="total, prev, pager, next" :total="10" />

  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData2: [{
        mc: '西北分子公司',
        jsbm: '****',
        mcc: '****'
      }, {
        mc: '西南分子公司',
        jsbm: '****',
        mcc: '****'
      }, {
        mc: '华东分子公司',
        jsbm: '****',
        mcc: '****'
      }, {
        mc: '华北分子公司',
        jsbm: '****',
        mcc: '****'
      }]
    }
  },
  methods: {
    goBack() {
      this.$router.go(-1)
    }
  }
}

</script>

<style scoped >

.title{
    height: 50px;
    font-size: 20px;
    /* border:1px solid #fff */
}

</style>

