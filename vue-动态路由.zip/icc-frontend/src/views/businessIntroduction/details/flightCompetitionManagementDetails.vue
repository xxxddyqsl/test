<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left">
        <h3>竞争匹配规则</h3>
      </div>
      <div class="title right">
        <el-form :inline="true">
          <el-form-item>  <el-button type="primary" size="mini" @click="add">添加</el-button> </el-form-item>
          <el-form-item>  <el-button type="primary" size="mini" @click="deletes">删除</el-button> </el-form-item>
          <el-form-item>  <el-button type="primary" size="mini" @click="beRevised">编辑</el-button> </el-form-item>
          <el-form-item>  <el-button type="primary" size="mini" @click="() => $router.go(-1)">返回</el-button> </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="content">
      <div class="left">
        <div class="title">规则表</div>
        <ul>
          <li v-for="v in list" :key="v.id" :class="active == v.id ? 'active' : ''"> <i :class="v.focus == 1 ? 'el-icon-star-on' : 'el-icon-star-off' " @click="setStars(v)" /> <span @click="change(v)"> {{ v.tag }}</span></li>
        </ul>
      </div>
      <div class="right">
        <div class="top">
          <div class="title">本航适用航班</div>
          <div class="list" style="border: 1px">
            <el-table :data="alarmRuleRefVoList" stripe border>
              <el-table-column prop="flightLeg" label="航段" width="300" />
              <el-table-column prop="ruleFlightNoVoList" label="航班号">
                <template slot-scope="scope">
                  <span v-if="scope.row.ruleFlightNoVoList">
                    <span v-for="(v,i) in scope.row.ruleFlightNoVoList" :key="i">{{ v.flightNo }} &nbsp;</span>
                  </span>
                </template>
              </el-table-column>
            </el-table>
          </div>

        </div>
        <div class="bottom">
          <div class="title">竞争匹配条件</div>
          <div class="list" style="border: 1px">
            <div v-for="(v,i) in marketRuleRefPoList" :key="i" class="li">
              <span :style="{color: i==0 ? '#fff': '#333'}">AND</span>
              <span>{{ v.name }}</span>
              <span>{{ v.condition }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 添加修改弹窗 -->

    <el-dialog v-dialogDrag :title="dialogTitle" width="750px" :visible.sync="dialog">
      <el-form ref="form" :model="dialogForm" :rules="rules" label-width="110px">

        <el-form-item label="规则名称" prop="tag">
          <el-input v-model="dialogForm.tag" style="width: 400px;margin-left:35px" placeholder="请输入规则名称" />
        </el-form-item>
        <el-form-item label="本航适用航班" prop="ruleRefPoList">
          <el-cascader ref="flightNo" v-model="dialogForm.ruleRefPoList" style="margin-left:35px" :props="flightListProps" :show-all-levels="false" :options="flightList" clearable collapse-tags />
        </el-form-item>
        <el-form-item label="竞争匹配条件" prop="marketRuleRefPoList">

          <div v-for="(v, i) in dialogForm.marketRuleRefPoList" :key="i" style="margin-bottom: 10px">
            <span :style="{color: i==0 ? '#fff': '#333'}">AND</span>
            <el-select v-model="v.code" style="width: 200px;margin-right: 10px" placeholder="请选择类型" @change="selectClick(v, i)">
              <el-option v-for="item in selectList" :key="item.code" :value="item.code" :label="item.name" />
            </el-select>

            <el-select v-if="v.code !== 'jhqfsj'" v-model="v.data" :disabled="!v.selectList.length>0" multiple filterable collapse-tags style="width: 200px;margin-right: 10px" :placeholder="v.placeholder">
              <el-option v-for="item in v.selectList" :key="item.code" :value="item.code" :label="item.name" />
            </el-select>
            <el-time-picker v-else v-model="v.data" format="HH:mm" value-format="HH:mm:ss" placeholder="请选择计划起飞时间" />

            <el-button size="mini" @click.prevent="removeDomain(v)">取消</el-button>
            <el-button v-if="i+1 == dialogForm.marketRuleRefPoList.length" type="primary" size="mini" @click.prevent="addDomain">添加</el-button>

          </div>

        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button style="margin:0 5px" @click="callOff">取 消</el-button>
        <el-button style="margin:0 5px" type="primary" @click="makeSure">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { getMarketCRules, getMarketCRulesRight, getFlightList, getTreeitemsSelect, setStar, getSelectByConditionType, addSet, deletesSet } from '@/api/flightCompetitionManagementDetails'
export default {
  data() {
    return {
      list: [], // 左侧列表
      alarmRuleRefVoList: [], // 本航适用航班
      marketRuleRefPoList: [], // 显示规则
      active: 1,
      activeName: '',
      flightList: [],
      dialog: false,
      dialogTitle: '',
      dialogForm: {
        tag: '',
        ruleRefPoList: [],
        marketRuleRefPoList: [
          { code: '', data: [], selectList: [], placeholder: '请先选择类型' },
          { code: '', data: [], selectList: [], placeholder: '请先选择类型' }
        ]
      },
      rules: {
        tag: [{ required: true, message: '请输入规则名称', trigger: 'blur' }],
        ruleRefPoList: [{ required: true, message: '请选择本航适用航班', trigger: 'blur' }],
        marketRuleRefPoList: [{ required: true, message: '竞争匹配条件不能有空选项', trigger: 'blur',
          validator: (rule, value, callback) => {
            const bool = value.every(v => {
              return (v.code && v.data && v.data.length > 0)
            })
            if (bool) {
              callback()
            } else {
              callback(new Error('不能为空'))
            }
          }
        }]
      },
      flightListProps: {
        label: 'flightNo',
        value: 'flightNo',
        children: 'alarmRuleFlightNoVoList',
        multiple: true
        // emitPath: false
      },
      selectList: [],
      name: 'dadada'
    }
  },

  created() {
    this.init()
    // 获取航班列表
    getFlightList().then(res => {
      if (res.data.code == '200') {
        this.flightList = res.data.data
      }
    })
    // 获取下拉框字典
    getTreeitemsSelect({ code: 'scjzgz' }).then(res => {
      if (res.data.code == '200') {
        this.selectList = res.data.data.dictionaryItemVOS
      }
    })
  },
  methods: {
    /**
     * 初始化
     */
    init() {
      // 获取规则表
      getMarketCRules({ ruleType: 'marketCompete' }).then(res => {
        if (res.data.code == '200') {
          this.list = res.data.data
          this.active = res.data.data.length > 0 ? res.data.data[0].id : ''
          this.activeName = res.data.data.length > 0 ? res.data.data[0].tag : ''
          this.get({ ruleType: 'marketCompete', id: this.active })
        }
      })
    },
    /**
     * 根据主下拉框获取条件下拉
     */
    selectByConditionType(conditionType, i) {
      getSelectByConditionType({ conditionType }).then(res => {
        if (res.data.code == '200') {
          this.dialogForm.marketRuleRefPoList[i].selectList = res.data.data
        }
      })
    },
    /**
     * 主下拉点击
     */
    selectClick(v, i) {
      let placeholder = ''
      this.selectList.forEach(j => {
        if (v.code == j.code) {
          placeholder = '请选择' + j.name
        }
      })
      this.dialogForm.marketRuleRefPoList[i].placeholder = placeholder
      this.dialogForm.marketRuleRefPoList[i].data = ''
      if (v.code !== 'jhqfsj') {
        this.selectByConditionType(v.code, i)
        this.dialogForm.marketRuleRefPoList[i].data = []
      }
    },
    /**
     * 取消规则
     */
    removeDomain(item) {
      var index = this.dialogForm.marketRuleRefPoList.indexOf(item)
      if (index !== -1) {
        this.dialogForm.marketRuleRefPoList.splice(index, 1)
      }
    },
    // 添加规则
    addDomain() {
      this.dialogForm.marketRuleRefPoList.push({ code: '', data: [], selectList: [], placeholder: '请先选择类型' })
    },
    // 是否标记
    setStars(v) {
      this.$confirm(`此操作将永久 '${v.focus == '0' ? '标记' : '取消标记'}' 这条数据, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          setStar(v.id).then(res => {
            if (res.data.code == 200) {
              // 获取规则表
              getMarketCRules({ ruleType: 'marketCompete' }).then(res => {
                if (res.data.code == '200') {
                  this.list = res.data.data
                }
              })
              this.$message({
                type: 'success',
                message: ` '${v.focus == '0' ? '标记' : '取消标记'}' 成功!`
              })
            } else {
              this.$message({
                type: 'warning',
                message: res.data.message
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: `已取消 '${v.focus == '0' ? '标记' : '取消标记'} ' 操作`
          })
        })
    },
    // 获取适用航班
    get(params) {
      getMarketCRulesRight(params).then(res => {
        if (res.data.code == '200') {
          this.alarmRuleRefVoList = res.data.data.ruleRefPoList
          this.marketRuleRefPoList = res.data.data.marketRuleDetailPoList
        }
      })
    },
    // 切换规则表
    change(v) {
      this.active = v.id
      this.activeName = v.tag
      this.get({ ruleType: 'marketCompete', id: v.id })
    },
    // 添加规则
    add(v) {
      this.dialogTitle = '添加竞争匹配条件'
      this.dialog = true
      this.dialogFormSet()
    },
    deletes() {
      this.$confirm(`此操作将永久'删除'这条规则, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deletesSet(this.active).then(res => {
            if (res.data.code == 200) {
              this.init()
              this.$message({
                type: 'success',
                message: `'删除'成功!`

              })
            } else {
              this.$message({
                type: 'warning',
                message: res.data.message
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: `已取消'删除'操作`
          })
        })
    },
    // 修改
    beRevised() {
      this.dialogTitle = '修改竞争匹配条件'
      this.dialog = true
      this.dialogFormSet()

      this.dialogForm.tag = this.activeName
      var arr = []
      this.alarmRuleRefVoList.length > 0 && this.alarmRuleRefVoList.map(item => {
        if (item.ruleFlightNoVoList) {
          item.ruleFlightNoVoList.map(j => {
            arr.push([item.flightLeg, j.flightNo])
          })
        } else {
          arr.push([item.flightLeg])
        }
      })

      this.dialogForm.ruleRefPoList = arr

      var marketRuleRefPoListArr = []
      this.marketRuleRefPoList.length > 0 && this.marketRuleRefPoList.map(v => {
        this.selectList.forEach(j => {
          if (v.code == j.code) {
            marketRuleRefPoListArr.push({
              placeholder: '请选择' + j.name,
              code: v.code,
              data: v.code !== 'jhqfsj' ? v.condition.split(',') : v.condition + ':00',
              selectList: v.code !== 'jhqfsj' ? v.selectList || [] : []
            })
          }
        })
      })

      this.dialogForm.marketRuleRefPoList = marketRuleRefPoListArr
    },

    // 确认
    makeSure() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.dialogForm.ruleRefPoList = this.dialogForm.ruleRefPoList.map(v => {
            return {
              flightLeg: v[0] ? v[0] : null,
              flightNo: v[1] ? v[1] : null
            }
          })
          // if(this.dialogForm)
          this.dialogForm.marketRuleRefPoList.forEach(v => {
            if (v.code === 'jhqfsj') {
              v.data = [v.data]
            }
          })
          addSet({ ...this.dialogForm, ruleType: 'marketCompete', state: this.dialogTitle == '添加竞争匹配条件' ? 0 : 1, id: this.dialogTitle == '添加竞争匹配条件' ? '' : this.active }).then(res => {
            if (res.data.code == '200') {
              this.$message({
                type: 'success',
                message: `${this.dialogTitle == '添加竞争匹配条件' ? '添加' : '修改'}成功!`
              })
              // 获取规则表
              getMarketCRules({ ruleType: 'marketCompete' }).then(res => {
                if (res.data.code == '200') {
                  this.list = res.data.data
                  this.active = this.dialogTitle == '添加竞争匹配条件' ? res.data.data[0].id : this.active
                  this.activeName = this.dialogTitle == '添加竞争匹配条件' ? res.data.data[0].tag : this.activeName
                  this.get({ ruleType: 'marketCompete', id: this.active })
                }
              })
            }
          })
          this.dialog = false
          console.log(this.dialog)
        } else {
          console.log(this.dialog)
          return false
        }
      })
    },
    // 取消
    callOff() {
      this.dialog = false
    },
    // 重置修改添加表单
    dialogFormSet() {
      this.dialogForm = {
        tag: '',
        ruleRefPoList: [],
        marketRuleRefPoList: [
          { code: '', data: [], selectList: [], placeholder: '请先选择类型' },
          { code: '', data: [], selectList: [], placeholder: '请先选择类型' }
        ]
      }
      this.$refs['form'] && this.$refs['form'].resetFields()
    }
  }

}

</script>

<style lang="scss" scoped >
.seachBox{
  margin: 0;
  .title_left{
    padding-left: 10px;
    color: #6a758f;
  }
}
.content{
  display: flex;
  font-size: 16px;
  height: 100%;
  justify-content: space-between;

  .left{
    border: 1px solid #eee;
    border-radius: 15px;
    padding:0 0 20px 0;
    max-height: 750px;
    min-width: 250px;
    overflow-y: auto;
    ul{
      padding:  0;
      margin: 5px 0;
      li{
        padding-left: 30px;
        height: 50px;
        line-height: 50px;
        cursor: pointer;
        position: relative;
        span{
          display: inline-block;
          width: 100%;
          overflow: hidden;
          text-overflow:ellipsis;
          white-space: nowrap;
        }
        i{
          position: absolute;
          left: 5px;
          top: 16px;
          &.el-icon-star-on{
            color: #5e56d2;
            font-size: 22px;
            top: 12px;
            left: 3px;
          }
        }

        &:hover{
          background-color: #ebf1ff;
        }
        &.active{
          background-color: #ebf1ff;
        }
      }
    }
  }
  .right{
    border: 1px solid #eee;
    border-radius: 15px;
    width: calc(100% - 300px);
    overflow-y: auto;
    min-width: 850px;
    .top,.bottom{
      .list{
        padding: 10px 30px 10px 100px;
        min-height: 200px;
        border: 1px solid #000;
      }
    }
    .bottom{
      .li{
        height: 50px;
        margin: 10px 0;
        span{
          display: inline-block;
          height: 100%;
          line-height: 50px;
          margin-right: 20px;
          padding-left: 10px;
        }
      }
    }
  }
  .title{
    font-weight: 900;
    padding: 10px;
    background-color: #ebf1ff;
  }
}
</style>

