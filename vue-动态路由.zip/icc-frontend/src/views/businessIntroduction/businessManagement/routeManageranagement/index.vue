<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" style="width:120px" size="mini" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input1" style="width:120px" size="mini" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input2" style="width:120px" size="mini" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input3" style="width:120px" size="mini" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini" @click="addUser">添加</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- <div style=" margin:10px; display:flex; justify-content: space-between; align-items: center; ">
      <el-select v-model="value">
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
      </el-select>
      <div style=" width:15%; display:flex; justify-content: space-between; align-items: center; ">
        <el-button type="primary" size="mini">复制</el-button>
        <el-button type="primary" size="mini">添加</el-button>
        <el-button type="primary" size="mini">编辑</el-button>
        <el-button type="primary" size="mini">删除</el-button>
      </div>
    </div> -->
    <div>
      <el-table :data="tableData" border>
        <el-table-column prop="qfz" label="起飞站" />
        <el-table-column prop="ddz" label="到达站" />
        <el-table-column prop="hx" label="航线" />
        <el-table-column prop="hbl" label="航班量" />
        <el-table-column prop="ywjz" label="有无竞争" />
        <el-table-column prop="kcry" label="控舱人员" />
        <el-table-column prop="fzry" label="负责人员" />
        <el-table-column prop="gxrq" label="更新日期" />
        <el-table-column prop="gxyh" label="更新用户" />
        <el-table-column prop="cz" label="操作" min-width="160">
          <template slot-scope="scope">
            <el-button style="margin:0 5px" type="primary" size="mini" @click="amendClick(scope.row)">修改</el-button>
            <el-button style="margin:0 5px" type="primary" size="mini" @click="deleteClick(scope.row)">删除</el-button>
          </template>
        </el-table-column>
        <!-- style="display:inline-block"  -->
        <el-pagination background layout="total, prev, pager, next" :total="10" />
      </el-table></div>

    <el-dialog :title="form.title" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="起飞站">
          <input v-model="form.qfz" type="text">
        </el-form-item>
        <el-form-item label="到达站">
          <input v-model="form.ddz" type="text">
        </el-form-item>
        <el-form-item label="航线">
          <input v-model="form.hx" type="text">
        </el-form-item>
        <el-form-item label="航班量">
          <input v-model="form.hbl" type="text">
        </el-form-item>
        <el-form-item label="有无竞争">
          <input v-model="form.ywjz" type="text">
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="amend">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
export default {
  data() {
    return {
      formInline: {
        input: '始发机场',
        input1: '到达机场',
        input2: '航线',
        input3: '控舱人员'
      },

      dialogFormVisible: false,
      form: {},
      //   checked: false,
      dialogAddNew: false,
      tableData: [
        {
          qfz: 'BAV',
          ddz: 'XIY',
          hx: 'XIY-BAV',
          hbl: '20',
          ywjz: '无',
          kcry: '张三',
          fzry: '张三',
          gxrq: '2020-07-01',
          gxyh: '区域管理员'
        },
        {
          qfz: 'BPE',
          ddz: 'PVG',
          hx: 'PVG-BPE',
          hbl: '22',
          ywjz: '无',
          kcry: '李四、王五',
          fzry: '李四',
          gxrq: '2020-01-01',
          gxyh: '区域管理员'
        }],
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      value1: true,
      options: [{
        value: '选项1',
        label: '不显示过期记录'
      }],
      value: '',
      value2: ''

    }
  },
  methods: {
    /**
     * 打开修改弹窗
     */
    amendClick(data) {
      this.dialogFormVisible = true
      this.isAdd = false
      this.form = JSON.parse(JSON.stringify(data))
      this.form.title = '修改用户'
    },
    /**
     * 打开修添加弹窗
     */
    addUser() {
      this.dialogFormVisible = true
      this.isAdd = true
      this.form.title = '添加用户'
    },
    /**
     * 确定修改
     */
    amend() {
      this.dialogFormVisible = false
    },

    /**
     * 删除
     */
    deleteClick(data) {
      console.log('123')
      this.$confirm(`此操作将永久删除, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          // 删除操作
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    }

  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}

</style>

