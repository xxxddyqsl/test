
<template>
  <div>
    <!-- 航班优劣势管理 -->
    <div>
      <div class="title_right">
        <el-form :inline="true" :model="formInline">

          <el-form-item>
            <el-switch
              v-model="formInline.value"
              active-text="变更航班"
              inactive-text="全部航班"
              @change="valueChange"
            />
          </el-form-item>

          <el-form-item>
            <el-select v-model="formInline.flightNo" clearable filterable placeholder="航班号" size="mini">
              <el-option v-for="(item,i) in flightNoList" :key="i" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item>

            <el-select v-model="formInline.routeCode" filterable clearable placeholder="航段" size="mini">
              <el-option v-for="(item,i) in routeCodeList" :key="i" :label="item" :value="item" />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-select v-model="formInline.competitiveState" clearable placeholder="竞争优劣势" size="mini">
              <el-option v-for="item in advantages" :key="item.id" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
            <el-button type="primary" size="mini" @click="onReset">重置</el-button>

          </el-form-item></el-form>
      </div>
    </div>

    <!-- 表格 -->
    <div class="table-box">
      <el-table
        ref="multipleTable"
        border
        :span-method="objectSpanMethod"
        :cell-class-name="tableRowClassName"
        :data="tableData"
        @cell-mouse-leave="cellMouseLeave"
        @cell-mouse-enter="cellMouseEnter"
      >

        <el-table-column label="航班号/机型" align="center">
          <template slot-scope="scope" width="160">
            <div>{{ scope.row.cancelFlight }}
              <span v-if="scope.row.state !=null">
                <el-tooltip placement="top">
                  <div v-if="scope.row.changeFlight !=null" slot="content">
                    近期新增航班
                  </div>
                  <div v-if="scope.row.cancelFlight !=null" slot="content">
                    近期取消航班
                  </div>
                  <div v-if="scope.row.changeAircraftType !=null" slot="content">
                    近期航班计划中机型为：{{ scope.row.changeAircraftType }}
                  </div>
                  <i class="el-icon-warning-outline" />
                </el-tooltip>
              </span>
              <span v-if="scope.row.seasonState !=null ">
                <el-tooltip class="item" effect="dark" placement="top" content="可选航班计划是与生效年份相关的航班计划">
                  <div slot="content">
                    {{ scope.row.source }}
                  </div>
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>

              <span />/ {{ scope.row.sfty }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="航段" align="center">
          <template slot-scope="scope">
            <p class="stopOver">{{ scope.row.octy }} <span class="span"><span v-if="scope.row.stopOver!=null"> {{ scope.row.stopOver }}</span></span>  {{ scope.row.lcty }}
            </p>
          </template>
        </el-table-column>
        <el-table-column label="计划起飞时间" align="center">
          <template slot-scope="scope">
            {{ scope.row.dltm }}
            <span v-if="scope.row.changePlanTime !=null">
              <el-tooltip placement="top">
                <div slot="content">
                  近期航班计划中计划起飞时间为:{{ scope.row. changePlanTime }}
                </div>
                <i class="el-icon-warning-outline" />
              </el-tooltip>
            </span>

          </template>
        </el-table-column>

        <el-table-column label="竞争优劣势" prop="competitiveName" align="center" />
        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="onAmendClick(scope.row)">修改</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        :page-size="page.pageSize"
        layout="total, prev, pager, next"
        :total="page.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
    <div>
      <el-dialog v-dialogDrag title="修该航班优劣势" width="30%" :visible.sync="dialogFormVisible">
        <el-form ref="form" :model="form" :rules="editRules" label-width="150px">
          <el-form-item label="航班号" prop="flightNumber">
            <div>{{ form.flightNumber }}</div>
          </el-form-item>
          <el-form-item label="机型" prop="aircraftType">
            <div>{{ form.aircraftType }}</div>
          </el-form-item>

          <el-form-item label="航段" prop="flightRoute">
            <div>{{ form.flightRoute }}</div>
          </el-form-item>
          <el-form-item label="经停" prop="stopOver">
            <div>{{ form.stopOver }}</div>
          </el-form-item>
          <el-form-item label="是否独飞" prop="isFlyAlone">
            <div>{{ form.isFlyAlone }}</div>
          </el-form-item>
          <el-form-item label="计划起飞时间" prop="plannedDepartureTime">
            <div>{{ form.plannedDepartureTime }}</div>
          </el-form-item>
          <el-form-item label="竞争优劣势" prop="competitiveName">
            <el-select v-model="form.competitiveName" size="mini" clearable style="width:180px" placeholder="应用航线">
              <el-option v-for="item in advantages" :key="item.id" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="dialogFormVisible = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary" @click="onEditMakeSure('edit_task_form')">确 定</el-button>
        </div>
      </el-dialog>
    </div>

  </div>
</template>

<script>
import { advantagesAndDisadvantagesManagementLst, advantagesAndDisadvantages, advantagesAndDisadvantagesEdit } from '@/api/BusinessManagement'
import { getSelectRouteRodeList, getSelectFlightList } from '@/api/spaceManagement'
export default {
  data() {
    return {
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      formInline: {
        value: false,
        competitiveState: '',
        flightNo: '',
        routeCode: ''

      },
      form: {
        flightNumber: '',
        aircraftType: '',
        flightRoute: '',
        stopOver: '',
        isFlyAlone: '',
        plannedDepartureTime: '',
        competitiveName: ''

      },
      editRules: {
        flightNumber: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        aircraftType: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        flightRoute: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        stopOver: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        isFlyAlone: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        plannedDepartureTime: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        competitiveName: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ]
      },
      dialogFormVisible: false,
      orderIndexArr: [],
      orderIndexArr2: [],
      orderIndexArr3: [],
      hoverOrderArr: [],
      rowIndex: '-1',
      tableData: [],
      advantages: [],
      editId: '',
      flightNoList: [],
      routeCodeList: [],
      changeFlight: 0 // 默认全部航班

    }
  },
  created() {
    this.advantagesAndDisadvantagesManagementLsts()
    this.advantagesAndDisadvantage()
    this.init()
  },
  methods: {
    init() {
      getSelectRouteRodeList().then(res => {
        if (res.data.code === '200') {
          this.routeCodeList = res.data.data || []
        }
      })
      getSelectFlightList().then(res => {
        if (res.data.code === '200') {
          res.data.data.map(v => {
            this.flightNoList.push(v.flightNumber)
          })
        }
      })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.advantagesAndDisadvantagesManagementLsts()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.advantagesAndDisadvantagesManagementLsts()
    },
    // 变更/全部航班和
    valueChange() {
      if (this.formInline.value === true) {
        this.changeFlight = 1
      } else if (this.formInline.value === false) {
        this.changeFlight = 0
      }
      this.advantagesAndDisadvantagesManagementLsts()
    },
    // 重置按钮
    onReset() {
      this.formInline = {
        competitiveState: '',
        flightNo: '',
        routeCode: ''
      }
      this.advantagesAndDisadvantagesManagementLsts()
      this.init()
    },
    // 查询按钮
    onQuery() {
      this.advantagesAndDisadvantagesManagementLsts('查询')
    },
    // select 竞争优劣势 选择框
    advantagesAndDisadvantage() {
      const data = {
        code: 'hbyls'
      }
      advantagesAndDisadvantages(data).then(res => {
        if (res.data.code === '200') {
          this.advantages = res.data.data.dictionaryItemVOS || []
        }
      })
    },
    // 航班优劣势列表
    advantagesAndDisadvantagesManagementLsts(v) {
      var data = {
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize,
        changeFlight: this.changeFlight,
        competitiveState: this.formInline.competitiveState || '', // 优劣势
        flightNo: this.formInline.flightNo || '', // 航班号
        routeCode: this.formInline.routeCode || '' // 航段
      }
      advantagesAndDisadvantagesManagementLst(data).then(res => {
        if (res.data.code === '200') {
          if (res.data.data != null) {
            this.tableData = res.data.data.rows || []
            this.page.total = res.data.data.total
            if (this.tableData.length === res.data.data.rows.length) {
              this.getOrderNumber()
            }
            if (v === '修改') {
              this.$message.success('修改成功')
            }
            if (v === '查询') {
              this.tableData.length>0 ? this.$message.success('查询成功') : this.$message.info('暂无数据')
            }
          } else {
            this.tableData = []
            this.flightNoList = []
            this.routeCodeList = []
          }
        }
      })
    },
    /**
     * 打开修改弹窗
     */
    onAmendClick(data) {
      this.editId = data.id
      this.dialogFormVisible = true
      this.form.flightNumber = data.cancelFlight
      this.form.aircraftType = data.sfty
      this.form.flightRoute = data.octy + '-' + data.lcty
      this.form.stopOver = data.stopOver
      this.form.isFlyAlone = data.isFlyAlone
      this.form.plannedDepartureTime = data.dltm
      if (data.competitiveName === '优势') {
        const code = '1'
        this.form.competitiveName = code
      } else if (data.competitiveName === '极优势') {
        const code = '2'
        this.form.competitiveName = code
      } else
      if (data.competitiveName === '均势') {
        const code = '3'
        this.form.competitiveName = code
      } else
      if (data.competitiveName === '劣势') {
        const code = '4'
        this.form.competitiveName = code
      } else
      if (data.competitiveName === '极劣势') {
        const code = '5'
        this.form.competitiveName = code
      }
    },
    /**
     * 确定修改
     */
    onEditMakeSure() {
      const data = {
        id: this.editId,
        competitiveState: Number(this.form.competitiveName),
        // flightNumber: this.form.flightNumber,
        routeCode: this.form.flightRoute,
        fltn: this.form.flightNumber
      }
      advantagesAndDisadvantagesEdit(data).then(res => {
        if (res.data.code === '200') {
          this.advantagesAndDisadvantagesManagementLsts('修改')
        } else {
          this.$message.error('修改失败')
        }
      })
      this.dialogFormVisible = false
    },

    // 寻找应该合并行
    getOrderNumber() {
      const OrderObj = {}
      this.tableData.forEach((element, index) => {
        element.rowIndex = index
        if (element.seasonState == null) {
          if (OrderObj[element.cancelFlight]) {
            OrderObj[element.cancelFlight].push(index)
          } else {
            OrderObj[element.cancelFlight] = []
            OrderObj[element.cancelFlight].push(index)
          }
        }
      })

      // 将数组长度大于1的值 存储到this.orderIndexArr（也就是需要合并的项）
      for (const k in OrderObj) {
        // console.log('k', k, OrderObj[k])
        if (OrderObj[k].length > 1) {
          this.orderIndexArr.push(OrderObj[k])
        }
      }
    },

    // 合并单元格
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        for (let i = 0; i < this.orderIndexArr.length; i++) {
          const element = this.orderIndexArr[i]
          for (let j = 0; j < element.length; j++) {
            const item = element[j]
            if (rowIndex == item) {
              if (j == 0) {
                return {
                  rowspan: element.length,
                  colspan: 1
                }
              } else if (j != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      } else if (columnIndex === 1) {
        for (let i = 0; i < this.orderIndexArr2.length; i++) {
          const element2 = this.orderIndexArr2[i]
          for (let h = 0; h < element2.length; h++) {
            const item2 = element2[h]
            if (rowIndex == item2) {
              if (h == 0) {
                return {
                  rowspan: element2.length,
                  colspan: 1
                }
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      } else if (columnIndex === 2) {
        for (let i = 0; i < this.orderIndexArr3.length; i++) {
          const element3 = this.orderIndexArr3[i]
          for (let h = 0; h < element3.length; h++) {
            const item3 = element3[h]
            if (rowIndex == item3) {
              if (h == 0) {
                return {
                  rowspan: element3.length,
                  colspan: 1
                }
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      }
    },
    tableRowClassName({ row, rowIndex }) {
      const arr = this.hoverOrderArr
      for (let i = 0; i < arr.length; i++) {
        if (rowIndex == arr[i]) {
          return 'hovered-row'
        }
      }
    },
    cellMouseEnter(row, column, cell, event) {
      this.rowIndex = row.rowIndex
      this.hoverOrderArr = []
      this.orderIndexArr.forEach(element => {
        if (element.indexOf(this.rowIndex) >= 0) {
          this.hoverOrderArr = element
        }
      })
    },

    cellMouseLeave(row, column, cell, event) {
      this.rowIndex = '-1'
      this.hoverOrderArr = []
    }

  }
}
</script>

<style  lang='scss'  scoped>
  .el-table ::v-deep .hovered-row {
      background: #f5f7fa;
    }

::v-deep .el-table td{
padding: 0 !important;
}
.stopOver{
  .span{
  width:50px;
  height: 20px;
  display: inline-block;
  border-bottom: 1px solid;
  transform: translateY(-5px);
  }
}
 ::v-deep .el-form-item{
    margin-bottom: 0;
  }
</style>

