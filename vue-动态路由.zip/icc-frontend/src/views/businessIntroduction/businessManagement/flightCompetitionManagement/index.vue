<template>
  <div class="">
    <div class="page_box">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="form">
          <el-form-item>
            <el-select v-model="form.flightNo" clearable filterable size="small" placeholder="请选择航班号">
              <el-option v-for="item in flightNoList" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.routeCode" clearable filterable size="small" placeholder="请选择航段">
              <el-option v-for="item in routeCodeList" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.condition" clearable filterable size="small" placeholder="请选择竞争条件">
              <el-option v-for="item in dictionaryItemVOS" :key="item.code" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" size="small" @click="query">查询</el-button>
            <el-button type="primary" size="small" @click="reSet">重置</el-button>
            <el-button type="primary" size="small" @click="goFlightCompetitionManagementDetails">竞争匹配规则</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData" border>
        <el-table-column label="航班号/机型">
          <template slot-scope="scope">
            {{ scope.row.flightNo }} / <span>{{ scope.row.sfty }}</span> / <span>{{ scope.row.competitiveName }}</span>
            /  <el-tooltip
              v-if="scope.row.isChange == 1 "
              class="item"
              effect="dark"
              :content="scope.row.isChange == 1 ? scope.row.changeInfo : ''"
              placement="top"
            >
              <i v-if="scope.row.isChange == 1" class="el-icon-warning" />
            </el-tooltip>
            <el-tooltip
              v-if="scope.row.seasonState == 1 "
              class="item"
              effect="dark"
              :content=" scope.row.seasonState == 1 ? scope.row.seasonName : ''"
              placement="top"
            >
              <i v-if="scope.row.seasonState == 1" class="el-icon-question" />
            </el-tooltip>
          </template>

        </el-table-column>

        <el-table-column label="航线" class="route">
          <template slot-scope="scope">
            <div v-if="scope.row.stopOver" style="color: orange;margin-bottom: -15px;font-size: 12px;">{{ scope.row.stopOver }}</div>
            <p>{{ scope.row.schDepApt }}——{{ scope.row.schArrApt }}</p>
            <div>
              <i class="el-icon-folder" style="color: orange" />
            </div>
          </template>

        </el-table-column>
        <el-table-column prop="voList" label="竞争条件">
          <template slot-scope="scope">
            <span v-for="(v,i) in scope.row.voList" :key="i">
              <el-tooltip
                class="item"
                effect="dark"
                :content="v.condition || '暂无'"
                placement="top"
              >
                <span>{{ v.conditionType }}</span>
              </el-tooltip>
              <span v-if="i < scope.row.voList.length - 1">、</span>
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="competingFlights" label="竞争航班" />
      </el-table>
      <el-pagination
        background
        :current-page="pageNum"
        :page-size="pageSize"
        layout="total, prev, pager, next"
        :total="total"
        @current-change="handleCurrentChange"
      />
    </div>

  </div>
</template>

<script>
import { getSelectFlightNoAndRouteCode, getFlightCompetitionManagement, getCondition } from '@/api/flightCompetitionManagementDetails'
export default {
  data() {
    return {
      form: {
        flightNo: '', // 航班号
        routeCode: '', // 航段
        condition: '' // 竞争条件
      },
      tableData: [], // 表格数据
      pageNum: 1, // 当前页码
      pageSize: 10, // 每页数量
      total: 0, // 总数
      flightNoList: [], // 航班号字典
      routeCodeList: [], // 航段字典
      dictionaryItemVOS: [] // 获取竞争条件字典
    }
  },
  created() {
    this.init()
    this.getSelectFlightNoAndRouteCode()
    this.getCondition()
  },
  methods: {
    /**
     *获取竞争条件字典
     */
    getCondition() {
      getCondition({ code: 'scjzgz' }).then(res => {
        if (res.data.code === '200') {
          this.dictionaryItemVOS = res.data.data.dictionaryItemVOS
        }
      })
    },

    /**
     * 航班号航段字典
     */
    getSelectFlightNoAndRouteCode() {
      getSelectFlightNoAndRouteCode().then(res => {
        if (res.data.code === '200') {
          this.flightNoList = res.data.data.flightNoList
          this.routeCodeList = res.data.data.routeCodeList
        }
      })
    },
    /**
     * 查询
     */
    query() {
      this.pageNum = 1
      this.init()
    },
    /**
     * 重置查询
     */
    reSet() {
      this.form = {
        flightNo: '', // 航班号
        routeCode: '', // 航段
        condition: '' // 竞争条件
      }
      this.pageNum = 1
      this.init()
    },
    /**
     * 切换分页
     */
    handleCurrentChange(val) {
      this.pageNum = val
      this.init()
    },
    /**
     * 跳转竞争页面
     */
    goFlightCompetitionManagementDetails() {
      this.$router.push({ name: 'flightCompetitionManagementDetails' })
    },
    /**
    * 获取列表
    */
    init() {
      getFlightCompetitionManagement({
        ...this.form,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        }
      })
    }
  }
}

</script>

<style lang='scss' scoped >
.page_box{
  margin-top: 15px;
}
::v-deep .el-table td{
padding: 0 !important;
}

</style>

