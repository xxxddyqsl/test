<template>
  <div style="padding:2px 0px;">
    <!-- <el-alert :closable="false" title="menu 1"> -->
    <router-view />
    <!-- </el-alert> -->
  </div>
</template>
