<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right" style="margin-right:100px">
        <el-radio-group v-model="view" size="small" @change="change">
          <el-radio-button label="DailyReport">日报</el-radio-button>
          <el-radio-button label="WeeklyReport">周报</el-radio-button>
          <el-radio-button label="MonthlyReport">月报</el-radio-button>
        </el-radio-group>
        <!-- <el-button type="warning" size="mini" style="margin:0 100px" @click="controlCabin">控舱管理</el-button>9 -->
      </div>
    </div>
    <!-- <div class="contentBox">
      <div class="leftContent">
        <div class="title">经情况</div>
        <div class="chartContent">
          <div v-for="item in list" :key="item" class="chart-box">
            <p>{{ item }}</p>
            <PieChart :width="width" :height="height" :chart-data="chartData" />
            <div>
              <p>当日完成度：1840</p>
              <p>整体完成度：1856</p>
              <p>同&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;比：1894</p>
              <p>环&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;比：1901</p>
            </div>
          </div>
        </div>
      </div>
      <div class="middleContent">
        <div class="topIncome">
          <div class="title">实际收入（万元）</div>
          <div class="IncomeBox">
            <div class="income">1949</div>
            <div class="IncomeBox_s">
              <div class="IncomeBox_box">
                <div class="IncomeBox_box_text">预测收入（万元）</div>
                <div class="IncomeBox_box_num">1249</div>
              </div>
              <div class="IncomeBox_box">
                <div class="IncomeBox_box_text">偏离值（万元）</div>
                <div class="IncomeBox_box_num" style="color:#70B603">+15</div>
              </div>
            </div>
          </div>
        </div>
        <div class="center-middle">
          <div class="left-title">
            收入趋势
          </div>
          <lineChart :chart-data="chartData" />
          <div class="middle-bottom-chart" />
        </div>
        <div class="center-middle">
          <div class="left-title">
            座公里收入趋势
            <div class="line" />
          </div>
          <lineChart :chart-data="chartData" />
          <div class="middle-bottom-chart" />
        </div>
      </div>
      <div class="rightContent">
        <div class="title">预警综览</div>
        <div class="table_box">
          <el-table :data="tableData" border style="width: 100%">
            <el-table-column prop="date" label="航班号" />
            <el-table-column prop="name" label="起飞日期" />
            <el-table-column prop="address" label="预警信息类型" />
            <el-table-column prop="address2" label="预警信息概况" />
            <el-table-column prop="name2" label="控舱状态" />
            <el-table-column label="操作" width="180">
              <el-button type="primary" size="mini">未读</el-button>
              <el-button type="primary" size="mini">舱位调整</el-button>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div> -->
    <div v-show="view == 'DailyReport'" class="contentBox">
      <div ref="DailyReport" style="width:100%; height:100%;" />
    </div>
    <div v-show="view == 'WeeklyReport'" class="contentBox">
      <div ref="WeeklyReport" style="width:100%; height:100%;" />
    </div>
    <div v-show="view == 'MonthlyReport'" class="contentBox">
      <div ref="MonthlyReport" style="width:100%; height:100%;" />
    </div>

  </div>
</template>

<script>
// import PieChart from '@/components/echarts/pieChart/pieChart'
// import lineChart from '@/components/echarts/lineChart/index'
import { initTableleua } from '@/api/tableleua.js'
export default {
  components: {
    // PieChart,
    // lineChart
  },
  data() {
    return {
      data: '',
      list: ['销售额收入(万元)', '座公里收入', '客座率', '中转率'],
      chartData: {},
      width: '12rem',
      // lineheight: '18rem',
      // linewidth: '18rem',
      height: '164px',
      view: 'DailyReport'
      // tableData: [
      //   {
      //     date: 'YY9141',
      //     name: '2021.10.01',
      //     address: '销售额指标',
      //     address2: '低于指标10%',
      //     name2: '算法'
      //   },
      //   {
      //     date: 'YY91412',
      //     name: '2021.10.01',
      //     address: '销售额指标',
      //     address2: '低于指标10%',
      //     name2: '算法'
      //   },
      //   {
      //     date: 'YY91414',
      //     name: '2021.10.01',
      //     address: '销售额指标',
      //     address2: '低于指标10%',
      //     name2: '算法'
      //   },
      //   {
      //     date: 'YY91411',
      //     name: '2021.10.01',
      //     address: '销售额指标',
      //     address2: '低于指标10%',
      //     name2: '算法'
      //   },
      //   {
      //     date: 'YY91418',
      //     name: '2021.10.01',
      //     address: '销售额指标',
      //     address2: '低于指标10%',
      //     name2: '算法'
      //   }
      // ]
    }
  },
  mounted() {
    this.change(this.view)
  },
  methods: {
    controlCabin() {
      this.$router.push({ path: '/spaceManagement' })
    },
    change(view) {
      // 获取容器元素
      let containerDiv = null
      if (view === 'DailyReport') { containerDiv = this.$refs.DailyReport }
      if (view === 'WeeklyReport') { containerDiv = this.$refs.WeeklyReport }
      if (view === 'MonthlyReport') { containerDiv = this.$refs.MonthlyReport }
      // 配置选项
      const options = {
        // 隐藏tab栏
        hideTabs: true,
        // 加载后执行的回调函数
        onFirstInteractive: function() {
        },
        // 设置图表模块和容器等宽
        width: '100%',
        // 设置图标模块和容器等高
        height: '800px'
      }
      let url = ''
      initTableleua(`/Homepage-${view}/Homepage-${view}`).then(res => {
        url = res.data.data
        // 实例化一个Talleau视图对象,并传入上述三个参数
        console.log(window.location.origin + url)
        // eslint-disable-next-line no-undef
        var view = new tableau.Viz(containerDiv, url, options)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.seachBox {
  .seach {
    display: flex;
    width: 40%;
    justify-content: space-between;
  }
}
.contentBox {
  width: 100%;
  display: -webkit-box;
  box-sizing: border-box;
  // .leftContent {
  //   flex: 1;
  //   border: 1px solid #000;
  //   margin-right: 8px;
  //   padding: 0 10px;
  //   .title {
  //     width: 100%;
  //     height: 40px;
  //     font: 900 20px/2 '';
  //     padding: 0 15px;
  //     border-bottom: 1px solid #000;
  //   }
  //   .chartContent {
  //     display: flex;
  //     justify-content: space-between;
  //     flex-wrap: wrap;
  //     .chart-box {
  //       width: 40%;
  //       padding-top: 20px;
  //       display: flex;
  //       flex-direction: column;
  //       justify-content: center;
  //       align-items: center;
  //     }
  //   }
  // }
  // .middleContent {
  //   flex: 1;
  //   margin-right: 8px;
  //   border: 1px solid #000;
  //   text-align: left;
  //   padding: 0 10px;
  //   .topIncome {
  //     // height: 25%;
  //     .title {
  //       width: 100%;

  //       height: 40px;
  //       font: 800 20px/2 '';
  //       padding: 0 15px;
  //       border-bottom: 1px solid #000;
  //     }
  //     .IncomeBox {
  //       padding-top: 10px;
  //       .income {
  //         margin: 0 auto;
  //         text-align: center;
  //         width: 60%;
  //         border: 1px solid #2d517f;
  //         box-shadow: 0 0 7px 0 rgba(77, 160, 239, 0.5);
  //         font-family: 'UnidreamLED';
  //         font-size: 45px;
  //         letter-spacing: 20px;
  //       }
  //       .IncomeBox_s {
  //         margin-top: 20px;
  //         display: flex;
  //         justify-content: space-around;
  //         .IncomeBox_box {
  //           width: 200px;
  //           height: 100px;
  //           .IncomeBox_box_text {
  //             height: 40px;
  //             text-align: center;
  //             line-height: 40px;
  //             font-size: 15px;
  //             // color: #AAAAAA;
  //           }
  //           .IncomeBox_box_num {
  //             height: 60px;
  //             line-height: 60px;
  //             text-align: center;
  //             font-size: 19px;
  //           }
  //         }
  //       }
  //     }
  //   }
  //   .center-middle {
  //     margin-top: 10px;
  //     border: 1px solid #000;
  //     .left-title {
  //       font-size: 18px;
  //       line-height: 30px;
  //     }
  //     width: 100%;
  //     height: 290px;
  //     padding: 0 10px;
  //   }
  // }
  // .rightContent {
  //   padding: 0 10px;
  //   border: 1px solid #000;
  //   .title {
  //     width: 100%;

  //     height: 40px;
  //     font: 900 20px/2 '';
  //     padding: 0 15px;
  //     border-bottom: 1px solid #000;
  //   }
  //   flex: 1;
  // }
}
</style>

