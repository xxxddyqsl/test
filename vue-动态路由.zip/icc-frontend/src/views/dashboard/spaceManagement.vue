<template>
  <div class="pageBox">
    <div class="seachBox">
      <div />
      <el-form ref="form" :model="form" :inline="true" size="small">
        <el-form-item prop="roleName">
          <el-switch v-model="form.value1" active-text="我的航班" inactive-text="全部航班" />
        </el-form-item>
        <el-form-item prop="roleName">
          <el-checkbox v-model="form.sign">标记航班</el-checkbox>
        </el-form-item>
        <el-form-item prop="roleName">
          <el-checkbox v-model="form.alarm">告警航班</el-checkbox>
        </el-form-item>
        <el-form-item prop="roleName">
          <el-select v-model="form.route" placeholder="请选择航线" clearable filterable>
            <el-option
              v-for="(item, i) in selectRouteRodeList"
              :key="i"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>
        <el-form-item prop="roleCode">
          <el-select v-model="form.flightNo" placeholder="请选择航班号" clearable filterable>
            <el-option
              v-for="(item,i) in selectFlightList"
              :key="i"
              :label="item.flightNumber"
              :value="item.flightNumber"
            />
          </el-select>

        </el-form-item>
        <el-form-item prop="flightDate">
          <div style=" display: flex;align-items: center">
            <i class="el-icon-caret-left" style="font-size:25px;cursor:pointer" @click="pageUp" />
            <el-date-picker
              v-model="form.flightDate"
              size="small"
              type="date"
              placeholder="航班日期"
              clearable
              value-format="yyyy-MM-dd"
              style="width: 140px"
            />
            <i class="el-icon-caret-right" style="font-size:25px;cursor:pointer" @click="pageDown" />
          </div>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="query">查询</el-button>

        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="multiClick">批量设置</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="$router.go(-1)">返回</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 表格 -->
    <div class="table-box">
      <el-table
        v-if="listTitle.length > 0"
        ref="table"
        :data="tableData"
        border
        style="width: 100%;"

        class="box"
      >

        <template v-for=" (item,i) in listTitle">
          <el-table-column :key="i" prop="address" :render-header="(h, obj) => renderHeader(h, obj, item)">
            <template slot-scope="scope">
              <div v-if="item.week == '航班号/机型'" class="flightNumber" @click="inTo(scope.row)">
                <div>
                  {{ scope.row.flightNumber }}
                </div>
                <div v-if="scope.row.aircraftType || scope.row.competitiveName">
                  <div style="color: orange"> {{ scope.row.aircraftType }}</div>
                  &nbsp;
                  <div style="color: orange">{{ scope.row.competitiveName }}</div>
                </div>

              </div>
              <div v-else-if="item.week == '航段'" class="route">
                <div v-if="scope.row.stopOver" style="color: orange;margin-bottom: -15px;font-size: 12px;">{{ scope.row.stopOver }}</div>
                <div>{{ scope.row.route.replace('-', ' —— ') }}</div>
                <div>
                  <i class="el-icon-folder" style="color: orange" />
                </div>
              </div>

              <div v-else-if="scope.row.data[item.date] && scope.row.data[item.date].statisticsVO" class="columnBox">
                <!-- 单个设置弹窗 -->
                <el-popover
                  placement="right"
                  width="400"
                  trigger="click"
                >
                  <h3 style="color: #F59A23">数据统计概况 </h3>
                  <el-table :data="scope.row.data[item.date].statisticsVO" border size="mini">
                    <el-table-column prop="name" label="参数类型" />
                    <el-table-column prop="value" label="参数值" />
                    <el-table-column prop="isChecked" label="首页展示">
                      <template slot-scope="scope">
                        <el-checkbox
                          :checked="scope.row.isChecked"
                          @change="(val) => changeChecked(val, scope.row.isChecked)"
                        />
                      </template>
                    </el-table-column>
                  </el-table>
                  <h3 style="color: #F59A23">航班状态</h3>
                  <p>正常</p>

                  <div slot="reference" class="left">

                    <template v-for="(v, j) in scope.row.data[item.date].statisticsVO">
                      <div v-if="v.isChecked" :key="j">
                        {{ v.name[0] }}:{{ v.value }}
                      </div>
                    </template>

                  </div>
                </el-popover>

                <div class="boxRight">
                  <i class="el-icon-s-platform" />
                  <i class="el-icon-folder" @click="nextDetail(scope.row,item)" />
                  <i v-if="scope.row.data[item.date].sign" class="el-icon-star-on" @click="scope.row.data[item.date].sign = false" />
                  <i v-if="!scope.row.data[item.date].sign" class="el-icon-star-off" @click="scope.row.data[item.date].sign = true" />
                  <i class="el-icon-circle-check" />
                </div>
              </div>

            </template>
          </el-table-column>
        </template>
      </el-table>
      <el-pagination
        background
        :current-page="pageNum"
        :page-size="pageSize"
        layout="total, prev, pager, next"
        :total="total"
        @current-change="handleCurrentChange"
      />
    </div>
    <!-- 批量设置弹框 -->
    <div>

      <el-dialog v-dialogDrag title="参数展示设置" :visible.sync="dialogData">

        <el-form ref="dataForm" :model="dataForm" :rules="dataRules" label-width="100px" class="demo-dataForm">
          <el-form-item prop="dataDate" label="航班日期" required>
            <el-date-picker v-model="dataForm.dataDate" type="date" placeholder="请选择日期" style="width: 200px" />
          </el-form-item>
          <el-form-item prop="flight" label="航班" required>

            <el-select v-model="dataForm.flight" placeholder="请选择航班号" clearable filterable multiple collapse-tags>
              <el-option
                v-for="(item, i) in selectFlightList"
                :key="i"
                :label="item.flightNumber"
                :value="item.flightNumber"
              />
            </el-select>
          </el-form-item>
        </el-form>
        <el-table :data="dataTable" border size="small">
          <el-table-column prop="name" label="参数类型" />
          <el-table-column prop="id" label="首页展示">

            <template slot-scope="scope">
              <el-checkbox
                :checked="boolValue"
                @change="(val) => selectRowDalog(val, scope.row.name)"
              />
            </template>
          </el-table-column>
        </el-table>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogData = false">取 消</el-button>
          <el-button type="primary" @click="submitFunc()">确 定</el-button>
        </div>
      </el-dialog>
    </div>

  </div>
</template>

<script>
import dayjs from 'dayjs'

import { getHeader, getTable, getSelectFlightList, getSelectRouteRodeList, setVolumeSet } from '@/api/spaceManagement'
export default {
  data() {
    return {
      selectFlightList: [], // 航班列表
      selectRouteRodeList: [], // 航段列表
      boolValue: false,
      dialogData: false,
      form: { // 查询表单
        alarm: '', // 告警航班
        sign: '', // 标记航班
        flightDate: dayjs(new Date()).format('YYYY-MM-DD') || '', // 日期
        route: '', // 航线
        flightNo: '' // 航班

      },
      listTitle: [], // 表头
      multipleRowSelection: [],
      multipleColSelection: [],
      tableData: [], // 表格信息

      pageSize: 10, // 每页个数
      pageNum: 1, // 当前页码
      total: 0, // 总数

      dataForm: {
        dataDate: '',
        flight: ''
      },
      dataTable: [],
      dataRules: {
        dataDate: [
          { required: true, message: '请选择航班日期', trigger: 'blur' }
        ],
        flight: [
          { required: true, message: '请选择航班', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.getSelectFlightList()
    this.getSelectRouteRodeList()
    this.setVolumeSet()
    this.getHeaderList()
  },
  methods: {
    /**
    *切换分页
    */

    handleCurrentChange(val) {
      this.pageNum = val
      this.getTableList()
    },

    /**
    *点击某一块
    */
    aaa(v, i) {
      console.log(v, i, v[i.date])
    },

    /**
    *获取表头
    */

    getHeaderList() {
      this.listTitle = []
      getHeader({
        flightDate: this.form.flightDate || ''
      }).then(res => {
        if (res.data.code == '200') {
          this.listTitle = res.data.data

          this.getTableList()
        }
      })
    },

    /**
    *获取表格数据
    */
    getTableList() {
      getTable({
        ...this.form,
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(res => {
        if (res.data.code == '200') {
          this.tableData = res.data.data.rows
          this.total = res.data.data.total
        } else {
          this.tableData = []
          this.total = 0
        }
      })
    },
    /**
    *获取航线列表
    */
    getSelectFlightList() {
      getSelectFlightList().then(res => {
        if (res.data.code == 200) {
          this.selectFlightList = res.data.data
        }
      })
    },

    /**
    *获取航段列表
    */
    getSelectRouteRodeList() {
      getSelectRouteRodeList().then(res => {
        if (res.data.code == 200) {
          this.selectRouteRodeList = res.data.data
        }
      })
    },
    /**
    *获取航段列表
    */
    setVolumeSet() {
      setVolumeSet({ code: 'cwglcs' }).then(res => {
        if (res.data.code == '200') {
          this.dataTable = res.data.data.dictionaryItemVOS
        }
      })
    },

    /**
    *点击批量控舱
    */

    inTo(v) {
      console.log(v, 'sss')
      this.$router.push({ path: '/VolumeSet', query: { flightNo: v.flightNumber || '', flightDate: v.flightFormatsDate || '' }})
    },

    /**
    *查询
    */
    query() {
      this.pageNum = 1
      this.getHeaderList()
    },

    /**
    *批量设置
    */
    multiClick() {
      this.dialogData = true
    },

    /**
    *表头渲染
    */
    renderHeader(h, { colum, $index }, v) {
      return h('div', {
        attrs: {
          class: 'cells', // ele原来样式
          style: 'justify-content:center; padding: 0; margin: 0; height: 100%; width: 100%; display: flex; '
        },
        domProps: {
          innerHTML: `
            <div style="display: flex; flex-direction: column;">
              <div style="display: ${v.date ? 'block' : 'none'} ;"> ${v.date}</div>
              <div style=""> ${v.week}</div>
            </div>
            <p style="display: ${v.detail ? 'block' : 'none'} ;color: orange;right: 0;margin: auto 0; width: 20px; line-height: 24px; padding: 0;white-space: initial;" >
              ${v.detail}
            </p>`
        }
      })
    },

    /**
    *前7天
    */
    pageUp() {
      if (this.form.flightDate) {
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(-7, 'day')
          .format('YYYY-MM-DD')
      } else {
        this.form.flightDate = dayjs().format('YYYY-MM-DD')
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(-7, 'day')
          .format('YYYY-MM-DD')
      }
    },

    /**
    *后7天
    */
    pageDown() {
      if (this.form.flightDate) {
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(+7, 'day')
          .format('YYYY-MM-DD')
        console.log(this.form.flightDate, 456)
      } else {
        this.form.flightDate = dayjs().format('YYYY-MM-DD')
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(+7, 'day')
          .format('YYYY-MM-DD')
      }
    },

    /**
    *点击星标
    */
    signSwitch(v) {
      v = !v
    },

    /**
    *改变显示类型
    */
    changeChecked(v, isChecked) {
      console.log(v, isChecked)
    },

    /**
    *批量这只确定按钮
    */
    submitFunc() {
      console.log(this.multipleRowSelection)
    },

    /**
    *跳转详情
    */
    nextDetail(v, item) {
      console.log(v, item)
      this.$router.push({
        path: 'spaceDetail', query: { flightNo: v.flightNumber || '', flightDate: item.dates || '' }
      })
    }
  }
}
</script>

<style lang="scss"  scoped>
.box{
  .route,.flightNumber{
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  .flightNumber{
    cursor: pointer;
    div{
      display: flex;
    }
  }

}
.columnBox {
  display: flex;
  flex-wrap: wrap;
  height: 100%;
  div {
    color:#FFF;
  }
  span{
    width: calc(100% - 20px);
    display: block;
    height: 100%;
  }
  .left{
    height: 100%;
    display: flex;
    flex-wrap: wrap;
    cursor: pointer;
    div{
      width: 50%;
      height: 50%;
      display: flex;
      align-items: center;
      padding-left: 5px;
      &:nth-child(1){
        background: red;
      }
      &:nth-child(2) {
        background: rgb(230, 56, 192);
      }
      &:nth-child(3) {
        background: green;
      }
      &:nth-child(4){
        background: blue;
      }
    }
  }

  .boxRight {
    width: 20px;
    background: rgba(0,0,0,.5);
    font-size: 14px;
    height: 100%;
    .el-icon-star-on {
      color: yellow;
    }
    i {
      cursor: pointer;
    }
  }
}

::v-deep .el-table__expanded-cell{
  padding: 0 !important;
 }
 ::v-deep .el-table.box td{
    padding: 0 !important;
    .cell{
      padding: 0 !important;
      height: 80px;
      line-height: 20px;
    }
 }
 ::v-deep .el-table.box th{
    padding: 0 !important;
 }

</style>

