<template>
  <div class="pageBox">
    <div class="seachBox">
      <div>
        <el-radio-group v-model="route" @change="changeRoute">
          <el-radio-button v-for="(item, i) in routeList" :key="i" v-model="route" :label="item" />
        </el-radio-group>
      </div>
      <el-form ref="form" :model="form" :inline="true" size="small">

        <el-form-item prop="date">
          <div style=" display: flex;align-items: center">
            <i class="el-icon-caret-left" style="font-size:25px;cursor:pointer" @click="pageUp" />
            <el-date-picker
              v-model="form.flightDate"
              size="small"
              type="date"
              placeholder="航班日期"
              clearable
              value-format="yyyy-MM-dd"
              style="width: 140px"
            />
            <i class="el-icon-caret-right" style="font-size:25px;cursor:pointer" @click="pageDown" />
          </div>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="query">查询</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="multiClick">编辑</el-button>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="$router.go(-1)">返回概况</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 表格 -->
    <div class="table-box">
      <el-table
        ref="table"
        :data="tableData"
        border
        style="width: 100%"
        default-expand-all
        class="box"
      >
        <el-table-column width="1" type="expand">
          <template slot-scope="props">
            <el-table
              :data="props.row.cabinData"
              align="center"
              border
              stripe
            >
              <el-table-column width="100" align="center" prop="legInfo" label="Class" />
              <el-table-column width="100" align="center" prop="fare" label="Fare" />
              <el-table-column>

                <template slot="header">
                  <span>BKD</span> / &nbsp;
                  <span style="color:#02A7F0">GRS</span> /&nbsp;
                  <span style="color:#F59A23">LSV</span> /&nbsp;
                  <span style="color:#EC808D">LSS</span>&nbsp;
                </template>

                <template v-for=" (item,i) in listTitle">
                  <el-table-column v-if="item.date" :key="i" align="center" :label="item.date">
                    <template slot-scope="scope">
                      <span>{{ scope.row.data[item.date].bkd || '-' }}</span> /
                      <span style="color:#02A7F0">{{ scope.row.data[item.date].grs || '-' }}</span> /
                      <!-- <input v-model="scope.row.cabinData[item.date].lvs" style="color:#F59A23;width:15px;min-width:15px;man-width:30px;border:none"> / -->
                      <span style="color:#F59A23">{{ scope.row.data[item.date].lvs || '-' }}</span> /
                      <span style="color:#EC808D">{{ scope.row.data[item.date].lss || '-' }}</span>
                    </template>
                  </el-table-column>
                </template>
              </el-table-column>

            </el-table>
          </template>
        </el-table-column>
        <template v-for=" (item,i) in listTitle">
          <el-table-column :key="i" :render-header="(h, obj) => renderHeader(h, obj, item)">
            <template slot-scope="scope">
              <div v-if="item.week == '航班号/机型'" class="flightNumber">
                <div>
                  {{ scope.row.flightNumber }}
                </div>
                <div v-if="scope.row.aircraftType || scope.row.competitiveName">
                  <div style="color: orange"> {{ scope.row.aircraftType }}</div>
                  &nbsp;
                  <div style="color: orange">{{ scope.row.competitiveName }}</div>
                </div>

              </div>
              <div v-else-if="scope.row.data[item.date] && scope.row.data[item.date].statisticsVO" class="columnBox">
                <!-- 单个设置弹窗 -->

                <el-popover
                  placement="right"
                  width="400"
                  trigger="click"
                >
                  <h3 style="color: #F59A23">数据统计概况</h3>
                  <el-table :data="scope.row.data[item.date].statisticsVO" border size="mini">
                    <el-table-column prop="name" label="参数类型" />
                    <el-table-column prop="value" label="参数值" />
                    <el-table-column prop="isChecked" label="首页展示">
                      <template slot-scope="scope">
                        <el-checkbox
                          :checked="scope.row.isChecked"
                        />
                      </template>
                    </el-table-column>
                  </el-table>
                  <h3 style="color: #F59A23">航班状态</h3>
                  <p>正常</p>

                  <div slot="reference" class="left">
                    <template v-for="(v, j) in scope.row.data[item.date].statisticsVO">
                      <div v-if="v.isChecked" :key="j">
                        {{ v.name[0] }}:{{ v.value }}
                      </div>
                    </template>
                  </div>
                </el-popover>

                <div class="boxRight">
                  <i class="el-icon-s-platform" />
                  <i class="el-icon-folder" @click="nextDetail(scope.row,item)" />
                  <i v-if="scope.row.data[item.date].sign" class="el-icon-star-on" @click="scope.row.data[item.date].sign = false" />
                  <i v-if="!scope.row.data[item.date].sign" class="el-icon-star-off" @click="scope.row.data[item.date].sign = true" />
                  <i class="el-icon-circle-check" />
                </div>
              </div>
            </template>
          </el-table-column>
        </template>
      </el-table>
    </div>

  </div>
</template>

<script>
import dayjs from 'dayjs'
import { getHeader, getVolTable, getRouteList } from '@/api/spaceManagement'

export default {
  data() {
    return {
      route: '', // 航线
      form: {
        flightDate: this.$route.query.flightDate || '' // 日期
      },
      listTitle: [], // 表头
      multipleRowSelection: [],
      multipleColSelection: [],
      tableData: [ // 表格数据

      ],
      routeList: [ // 航线切换
        'PVG-BPE',
        'BPE-KHG',
        'PVG-KHG'
      ]
    }
  },
  created() {
    this.getHeaderList()
    this.getRouteList()
  },
  methods: {

    /**
    *获取航段列表
    */
    getRouteList() {
      const { flightNo } = this.$route.query
      getRouteList({ flightNo: flightNo || '', ...this.form }).then(res => {
        if (res.data.code == '200') {
          this.routeList = res.data.data
          if (res.data.data.length > 0) {
            this.route = res.data.data[0]
            this.getTableList()
          }
        }
      })
    },
    /**
    *获取表头
    */
    getHeaderList() {
      this.listTitle = []
      getHeader({
        flightDate: this.form.flightDate || '',
        state: '1'
      }).then(res => {
        if (res.data.code == '200') {
          this.listTitle = res.data.data
        }
      })
    },

    /**
    *获取表格数据
    */
    getTableList() {
      const { flightNo } = this.$route.query

      getVolTable({
        ...this.form,
        flightNo: flightNo || '',
        route: this.route || ''
      }).then(res => {
        if (res.data.code == '200') {
          this.tableData = [{ ...res.data.data }]
        } else {
          this.tableData = []
        }
      })
    },
    /**
    *查询
    */
    query() {
      this.getHeaderList()
      this.getTableList()
    },

    changeRoute() {
      this.getTableList()
    },

    // 行选中
    selectRow(flag, code) {
      if (flag) {
        this.multipleRowSelection.push(code)
      }
    },
    multiClick() {
      console.log(this.multipleRowSelection)
      console.log(this.multipleColSelection)
    },

    // 列选中方法
    select(flag, label) {
      if (flag) {
        this.multipleColSelection.push(label)
      }

      console.log(this.multipleRowSelection, 333)
    },

    /**
    *表头渲染
    */
    renderHeader(h, { colum, $index }, v) {
      return h('div', {
        attrs: {
          class: 'cells', // ele原来样式
          style: 'justify-content:center; padding: 0; margin: 0; height: 100%; width: 100%; display: flex; '
        },
        domProps: {
          innerHTML: `
            <div style="display: flex; flex-direction: column;">
              <div style="display: ${v.date ? 'block' : 'none'} ;"> ${v.date}</div>
              <div style=""> ${v.week}</div>
            </div>
            <p style="display: ${v.detail ? 'block' : 'none'} ;color: orange;right: 0;margin: auto 0; width: 20px; line-height: 24px; padding: 0;white-space: initial;" >
              ${v.detail}
            </p>`
        }
      })
    },

    /**
    *前7天
    */
    pageUp() {
      if (this.form.flightDate) {
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(-7, 'day')
          .format('YYYY-MM-DD')
      } else {
        this.form.flightDate = dayjs().format('YYYY-MM-DD')
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(-7, 'day')
          .format('YYYY-MM-DD')
      }
    },

    /**
    *后7天
    */
    pageDown() {
      if (this.form.flightDate) {
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(+7, 'day')
          .format('YYYY-MM-DD')
        console.log(this.form.flightDate, 456)
      } else {
        this.form.flightDate = dayjs().format('YYYY-MM-DD')
        this.form.flightDate = dayjs(this.form.flightDate)
          .add(+7, 'day')
          .format('YYYY-MM-DD')
      }
    },

    // 批量选择
    selectRowDalog(flag, code) {
      if (flag) {
        this.multipleRowSelection.push(code)
      }
    },

    // 提交数据
    submitFunc() {
      console.log(this.multipleRowSelection)
    },
    /**
    *跳转详情
    */
    nextDetail(v, item) {
      console.log(v, item)
      this.$router.push({
        path: 'spaceDetail', query: { flightNo: v.flightNumber || '', flightDate: item.dates || '' }
      })
    }
  }
}
</script>

<style lang="scss"  scoped>
.box{
  .route,.flightNumber{
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  .flightNumber{
    cursor: pointer;
    div{
      display: flex;
    }
  }

}
.columnBox {
  display: flex;
  flex-wrap: wrap;
  height: 100%;
  div {
    color:#FFF;
  }
  span{
    width: calc(100% - 20px);
    display: block;
    height: 100%;
  }
  .left{
    height: 100%;
    display: flex;
    flex-wrap: wrap;
    div{
      width: 50%;
      display: flex;
      align-items: center;
      padding-left: 5px;
      &:nth-child(1){
        background: red;
      }
      &:nth-child(2) {
        background: rgb(230, 56, 192);
      }
      &:nth-child(3) {
        background: green;
      }
      &:nth-child(4){
        background: blue;
      }
    }
  }

  .boxRight {
    width: 20px;
    background: rgba(0,0,0,.5);
    font-size: 14px;
    .el-icon-star-on {
      color: yellow;
    }
    i {
      cursor: pointer;
    }
  }
}

::v-deep .el-table__expanded-cell{
  padding: 0 !important;
 }
 ::v-deep .el-table.box td{
    padding: 0 !important;
    .cell{
      padding: 0 !important;
      height: 80px;
      line-height: 20px;
    }
    &.el-table__expanded-cell{
      .cell{
        line-height: 80px ;
      }
    }
 }
 ::v-deep .el-table.box th{
    padding: 0 !important;
 }

</style>

