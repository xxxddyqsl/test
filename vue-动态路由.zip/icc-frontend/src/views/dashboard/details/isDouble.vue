<template>
  <div class="pageBox">
    <ul>
      <li v-for="(v,i) in list" :key="i">
        <h3>{{ v.title }}</h3>
        <div class="chart" />
      </li>
    </ul>

  </div>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
      list: [
        { title: '历史航班订座、客座率数据' },
        { title: '历史航班销售额、客公里收入趋势' },
        { title: '订座、客座率趋势' },
        { title: '销售额、客公里收入趋势' },
        { title: '上客趋势' },
        { title: '市场竞争数据' },
        { title: '市场热度分析(待定)' },
        { title: '当前&历史影响事件(待定)' }
      ]
    }
  },
  methods: {

  }
}
</script>

<style lang="scss" scoped>
.pageBox{
  width:100vw;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  overflow-y: scroll;
  ul{
    display: flex;
    flex-wrap: wrap;
    li{
      width: 50%;
      height: 400px;
      border: 1px solid #000;
      color: orangered;
      h3{
        text-align: center;
      }
    }
  }
}
</style>

