<template>

  <div class="pageBox">
    <div class="seachBox">
      <div>
        <el-radio-group v-model="route" @change="changeRoute">
          <el-radio-button v-for="item in routeList" :key="item" v-model="route" :label="item" />
        </el-radio-group>
      </div>
      <el-form ref="form" :model="form" :inline="true" size="small">
        <el-form-item prop="roleName">
          <span class="span-box">
            <el-tooltip
              effect="dark"
              placement="right"
            >
              <div slot="content">算法控舱开关作用于全部舱位，不可同时启用算法与规则控舱。</div>
              <i class="el-icon-question" style="color: #2bb1f5;" />
            </el-tooltip>
          </span>
          <el-switch v-model="checked" active-text="算法控舱" />
          <i class="el-icon-d-caret" @click="onClickOne" />
        </el-form-item>

        <el-form-item prop="roleName">
          <span class="span-box">
            <el-tooltip
              effect="dark"
              placement="right"
            >
              <div slot="content">关闭算法控舱默认以有效的规则控舱，若需取消关闭即可，若需调整前往相应的规则模型页面中设置。</div>
              <i class="el-icon-question" style="color: #2bb1f5;" />
            </el-tooltip>
          </span>
          <el-switch v-model="checked1" active-text="规则控舱" />

          <i class="el-icon-d-caret" @click="onClickTwo" />
        </el-form-item>
        <!-- <el-form-item prop="roleName">
          <span>pvg-bpe</span>
        </el-form-item>
        <el-form-item prop="roleName">
          <span>YF911</span>
        </el-form-item>
        <el-form-item prop="roleCode">
          <span>2021-12-01</span>
        </el-form-item> -->
        <el-form-item prop="date">
          <div style=" display: flex;align-items: center">
            <!-- <i class="el-icon-caret-left" style="font-size:25px;cursor:pointer" @click="pageUp" /> -->
            <el-date-picker
              v-model="form.flightDate"
              size="small"
              type="date"
              placeholder="航班日期"
              clearable
              value-format="yyyy-MM-dd"
              style="width: 140px"
            />
            <!-- <i class="el-icon-caret-right" style="font-size:25px;cursor:pointer" @click="pageDown" /> -->
          </div>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="query">查询</el-button>
          <el-button type="primary" @click="isDoubles">{{ isDoubleTitle }}</el-button>
          <el-button type="primary" @click="goVolumeSet">批量控舱</el-button>
          <el-button type="primary" @click="onSubmit">编辑</el-button>
          <!-- <el-button type="primary" @click="onSubmit">保存生效</el-button> -->
          <el-button type="primary" @click="goBack">返回概况</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="contentBox">
      <div class="contentBox-top">
        <div class="contentBox-top-list">
          <span class="active"> AirlineInfo </span>
          <span>{{ flightDetailsVO.octy || '--' }} - {{ flightDetailsVO.lcty || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> Flinght </span>
          <span>{{ flightDetailsVO.fltn || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> Date </span>
          <span>{{ flightDetailsVO.flyDay || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> Dow </span>
          <span>{{ flightDetailsVO.week || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> Time </span>
          <span>{{ flightDetailsVO.dltm || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> Aircraft </span>
          <span>{{ flightDetailsVO.sfty || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> DaysPrior </span>
          <span>{{ flightDetailsVO.daysPrior || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> 需求系数 </span>
          <span>{{ flightDetailsVO.demandCoefficient || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> 销售额 </span>
          <span>{{ flightDetailsVO.salesVolume || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> 座公里收入 </span>
          <span>{{ flightDetailsVO.seatKilometerIncome || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> 客座率 </span>
          <span>{{ flightDetailsVO.passengerLoadFactor || '--' }}</span>
        </div>
        <div class="contentBox-top-list">
          <span class="active"> 中转率 </span>
          <span>{{ flightDetailsVO.transitRate || '--' }}</span>
        </div>
      </div>

      <div class="contentBox-bottom">

        <div class="contentBox-bottomLeft" :style="{width: isDouble ? '100%' : ''}">
          <div class="contentBox-bottomLeft_div">
            <div class="contentBox-bottomLeftTop">
              <el-table :data="odsInvBlcVOList" style="width: 100%" border>
                <el-table-column prop="legInfo" label="Leglnfo" align="center" />
                <el-table-column prop="open" label="Open" align="center" />
                <el-table-column prop="max" label="Max" align="center" />
                <el-table-column prop="cap" label="CAP" align="center" />
                <el-table-column prop="tb" label="T/B" align="center" />
                <el-table-column prop="grs" label="GRS" align="center" />
                <el-table-column prop="lf" label="LF" align="center" />
              </el-table>
            </div>
          </div>
          <div class="contentBox-bottomLeftBotm">
            <el-table id="tableActive" :data="odsInvBlbVOS" style="width: 100%" border>
              <el-table-column prop="legInfo" label="Class" align="center" />
              <el-table-column prop="fare" label="Fare*" align="center" />
              <el-table-column prop="nesting" label="Nesting" align="center" />
              <el-table-column prop="bkd" label="BKD" align="center" />
              <el-table-column prop="grs" label="GRS" align="center" />
              <!-- <el-table-column prop="LSVx" label="LSV" align="center" style="background-color:#0A152F" /> -->
              <el-table-column label="lsv">
                <template slot-scope="scope">
                  <div style="background-color:#0A152F;color: #FFF; text-align: center;">
                    {{ scope.row.lsv || "-" }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column :prop="lsv || '-'" label="LSV(算法推荐)" align="center" />
              <el-table-column prop="lss" label="LSS" align="center" />

              <el-table-column width="200" align="center">
                <template slot="header">
                  <span> 规则控制预览 </span>
                  <el-tooltip content="规则控舱时间由模型规则中设置，若需调整需前往相应的规则模型页面中设置" placement="top">
                    <i class="el-icon-question help-icon" />
                  </el-tooltip>
                </template>
                <template slot-scope="scope">
                  <el-select v-model="scope.row.value11" placeholder="2021.05.01-2021.11.31" size="mini">
                    <el-option v-for="item in options1" :key="item.value" size="mini" :label="item.label" :value="item.value" />
                  </el-select>
                </template>
              </el-table-column>

            </el-table>
          </div>
        </div>

        <div v-show="!isDouble" class="contentBox-bottomRight">

          <div class="contentBox-bottomRightTop">
            <div class="top">

              <div class="select">
                <el-select v-model="optionsRightTop" placeholder="请选择">
                  <el-option
                    v-for="item in optionsRight"
                    :key="item"
                    :label="item"
                    :value="item"
                  />
                </el-select>
              </div>

              <div class="title">
                <span class="span-box">
                  默认
                  <el-tooltip
                    effect="dark"
                    placement="right"
                  >
                    <div slot="content">全部是默认符合起始站，到达站条件的所有航班。</div>
                    <i class="el-icon-question" style="color: #2bb1f5;" />
                  </el-tooltip>
                </span>
                <el-switch v-model="gzsx" active-text="规则筛选" />
                <span class="span-box">
                  <el-tooltip
                    effect="dark"
                    placement="right"
                  >
                    <div slot="content">规则筛选的航班是符合竞争匹配规则的所有航班，若需要调舱规则请前往“航班竞争管理页面”</div>
                    <i class="el-icon-question" style="color: #2bb1f5;" />
                  </el-tooltip>
                </span>
              </div>
            </div>

            <el-table
              id="tableActive"
              :data="tableData"
              style="width: 100%"
              border
            >
              <el-table-column prop="Leglnfo" label="航班号" align="center" />
              <el-table-column prop="Open" label="起飞时间" align="center" />
              <el-table-column prop="Max" label="起飞时间差(分钟)" align="center" />
              <el-table-column prop="CAP" label="运价(元)" align="center" />
              <el-table-column prop="TB" label="运价差(元)" align="center" />
              <el-table-column prop="GRS" label="客座率" align="center" />

            </el-table>
          </div>
          <div class="contentBox-bottomRightBotm">
            <div class="top">

              <div class="select">
                <el-select v-model="optionsRightBot" placeholder="请选择">
                  <el-option
                    v-for="item in optionsRight"
                    :key="item"
                    :label="item"
                    :value="item"
                  />
                </el-select>
              </div>

            </div>
            <img :src="imgSrc" width="100%" height="100%" alt="">
          </div>
        </div>

      </div>
    </div>
    <!-- 算法控舱 弹出框 -->
    <el-dialog
      title="修改控舱算法"
      :visible.sync="dialogVisible"
      width="30%"
    >
      <el-form ref="ruleForm" :model="viewForm" :rules="viewRules" label-width="70px" class="demo-ruleForm">
        <el-form-item label="航班" prop="flight">
          YY9146（2022.01.01）
        </el-form-item>
        <el-form-item label="算法" prop="algorithm">
          <el-radio-group v-model="viewForm.algorithm" class="radioBox">
            <el-radio label="0" class="radio_first">动态规划算法</el-radio>
            <el-radio label="1">RMS算法</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 算法控舱 弹出框 -->
    <el-dialog
      title="修改控舱规则"
      :visible.sync="dialogTwoVisible"
      width="30%"
    >
      <div class="top">
        <div><span>航班 ：</span> <span> YY9146（2022.01.01）</span> </div>
      </div>
      <!-- 表格区域 -->
      <el-table :data="tableData3" style="width: 100%;margin-top: 20px" border>
        <el-table-column prop="aa" label="规则类型" />
        <el-table-column label="优先级">
          <template slot-scope="scope">
            <div style="display:flex;align-items:center">
              <el-select v-model="scope.row.value11" placeholder="1" size="mini">
                <el-option v-for="item in options" :key="item.value" size="mini" :label="item.label" :value="item.value" />
              </el-select>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="bb" label="状态">
          <template slot-scope="scope">
            <el-switch v-model="scope.row.Open" size="mini" />
          </template>
        </el-table-column>
      </el-table>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogTwoVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogTwoVisible = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>

</template>

<script>
import lineChart from '@/components/echarts/lineChart/index'
import EditCell from '@/components/editCell'
import { getFlinghtDetails, getFlinght } from '@/api/spaceDetail'
export default {
  components: { EditCell, lineChart },
  data() {
    return {
      imgSrc: require('@/assets/7.png'),
      gzsx: false,
      optionsRightTop: '订座、客座率趋势',
      optionsRightBot: '订座、客座率趋势',
      optionsRight: [
        '订座、客座率趋势',
        '上客趋势',
        '销售额、客公里收入趋势',
        '市场竞争数据',
        '历史航班订座、客座率数据',
        '历史航班销售额、客公里数据',
        '市场热度分析(待定)',
        '当前&历史影响事件(待定)'
      ],
      isDouble: false,
      isDoubleTitle: '双屏展示',
      options: [{ value: 1, label: 1 }, { value: 2, label: 2 }, { value: 3, label: 3 }],
      options1: [{ value: 1, label: '起飞日期(2021.02.01-2020.05.06)' }, { value: 2, label: '客做率(2021.02.01-2020.05.06)' }],
      value12: true,
      value11: '',
      route: '',
      checked: false,
      chartData: {},
      checked1: false,
      routeList: [], // 切换航段
      flightDetailsVO: {}, // 航班详情
      odsInvBlcVOList: [], // 航节订座记录
      odsInvBlbVOS: [], // 航节子舱位订座数据
      tableData3: [
        { aa: '起飞日期', Open: '', bb: '5201101', value11: '' },
        { aa: '客座率', Open: '', bb: '5202202', value11: '' },
        { aa: '超售', Open: '', bb: '5203303', value11: '' }
      ],
      tableData2: [
        { Class: 'Y', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' },
        { Class: 'B', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' },
        { Class: 'M', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' },
        { Class: 'M', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' },
        { Class: 'E', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' },
        { Class: 'E', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' },
        { Class: 'E', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' },
        { Class: 'H', Fare: '3520', Nesting: 'Y', BKD: '0', GRS: '0', LSVx: '-', LSV: '*', LSS: '10(2)' }
      ],
      tableData: [
        { Leglnfo: 'TS2009', Open: '07:25', Max: '-45', CAP: '230', TB: '-10', GRS: ' 80% ' },
        { Leglnfo: 'LH3021', Open: '07:25', Max: '-45', CAP: '230', TB: '-10', GRS: ' 80% ' },
        { Leglnfo: 'YJ4154', Open: '07:25', Max: '-45', CAP: '230', TB: '-10', GRS: ' 80% ' },
        { Leglnfo: 'HP5873', Open: '07:25', Max: '-45', CAP: '230', TB: '-10', GRS: ' 80% ' },
        { Leglnfo: 'LF6902', Open: '07:25', Max: '-45', CAP: '230', TB: '-10', GRS: ' 80% ' }
      ],
      form: {
        flightDate: this.$route.query.flightDate || '' // 日期
      },
      dialogVisible: false,
      dialogTwoVisible: false,
      viewRules: {
        flight: [{ required: true, message: '请输入航班号', trigger: 'blur' }],
        algorithm: [{ required: true, message: '请选择算法', trigger: 'blur' }]
      },
      viewForm: {
        flight: '',
        algorithm: 0
      }

    }
  },
  created() {
    this.getFlinght()
  },
  methods: {

    /**
    *获取航段列表
    */
    getFlinght() {
      const { flightNo } = this.$route.query
      getFlinght({ flightNo: flightNo || '', ...this.form }).then(res => {
        if (res.data.code == '200') {
          this.routeList = res.data.data
          this.routeList && (this.route = this.routeList[0])
          this.getFlinghtDetails()
        }
      })
    },
    /**
    *  flightDetailsVO: {}, // 航班详情
    *  odsInvBlcVOList: [], // 航节订座记录
    *  odsInvBlbVOS: [], // 航节子舱位订座数据
    */
    getFlinghtDetails() {
      const { flightNo } = this.$route.query
      getFlinghtDetails({
        flightNo: flightNo || '',
        ...this.form,
        route: this.route || ''
      }).then(res => {
        if (res.data.code == '200') {
          this.flightDetailsVO = res.data.data.flightDetailsVO
          this.odsInvBlcVOList = res.data.data.odsInvBlcVOList
          this.odsInvBlbVOS = res.data.data.odsInvBlbVOS
        }
      })
    },
    isDoubles() {
      this.isDouble = !this.isDouble
      // eslint-disable-next-line eqeqeq
      this.isDouble == true && (this.isDoubleTitle = '单屏幕显示')
      // eslint-disable-next-line eqeqeq
      this.isDouble == false && (this.isDoubleTitle = '双屏幕显示')
      const news = this.$router.resolve({ name: 'isDouble' })
      this.isDouble && window.open(news.href, '_blank')
    },
    query() {
      this.getFlinghtDetails()
    },
    goVolumeSet() {
      console.log('批量控舱')
      this.$router.push({ path: '/VolumeSet' })
    },
    goBack() {
      this.$router.go(-1)
    },
    changeRoute() {
      console.log(this.route)
      this.getFlinghtDetails()
    },
    flagClick() {

    },
    // 打开【修改控舱算法】弹窗
    onClickOne() {
      this.dialogVisible = true
    },
    // 打开【修改控舱规则】弹窗
    onClickTwo() {
      this.dialogTwoVisible = true
    }
  }
}
</script>

<style lang="scss"  scoped>
.pageBox{
  .seachBox{
    border-bottom:1px #eee solid ;

  }
  .radioBox{
    display: flex;
    flex-direction: column;
    .radio_first{
      margin-bottom: 10px;
    }
  }
}
.contentBox{

  border: 1px solid #eee;
  .contentBox-top{
    height: 70px;
    padding: 5px 20px;
    width: 100%;
    background: #dee8ff;
    display: flex;
    justify-content: space-between;
    .contentBox-top-list{
        display: flex;
        text-align: center;
        flex-direction:column;
        flex: 1;
        span{
             flex: 1;
        }
        .active{
          font: 800 18px/2 '';
        }
    }
  }
.contentBox-bottom{
    display: flex;
    justify-content: space-between;
    .contentBox-bottomLeft{
        width: 68%;
        .contentBox-bottomLeft_div{
            width: 100%;
            border: red;
        }
    }
    .contentBox-bottomRight{
        width: 32%;
        .title{
          display: flex;
          justify-content: flex-end;
          align-items: center;
        }
        ::v-deep.el-select{
          width: 250px  !important;
          margin: 0 auto;
          display: block;
        }
        ::v-deep.el-input{
          width: 250px  !important;
          .el-input__inner{
            border: none !important;
            text-align: center !important;
          }
        }
    }
}
}
::v-deep .radioBox.el-radio-group{
  background-color: #fff !important;
}
::v-deep .el-table{
  border-radius: 0 !important;
}
</style>
<style scoped>

</style>
