<template>
  <div>
    <div class="content">
      <p>请选择</p>
      <div class="imgBox">
        <div class="zhineng">
          <img src="@/assets/zhineng.png" @click="go">
          <span>智能控舱</span>
        </div>
        <div class="skyone">
          <img src="@/assets/skyone.jpg" @click="go">
          <span>skyone</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Choice',
  data() {
    return {}
  },
  methods: {
    go() {
      this.$router.push({ path: '/dashboard' })
    }
  }
}
</script>

<style lang="scss" scoped>
.content {
  margin: 0 auto;
  width: 500px;
  padding-top: 150px;
  p {
    text-align: center;
    font-size: 40px;
  }
  .imgBox {
    width: 100%;
    display: flex;
        text-align: center;
        font-size: 20px;
    justify-content: space-between;
    img {
      display: block;
      width: 150px;
      height: 150px;
    }
    .skyone {
      cursor: pointer;
    }
    .zhineng {
      cursor: pointer;
    }
  }
}
</style>>

