<template>
  <div class="pageBox">
    <!-- 决策监控 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" style="width:120px" size="mini" placeholder="航线" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input1" style="width:120px" size="mini" placeholder="航班号" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini" @click="goInstructionLogQuery">指令日志查询</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div class="ring">
      <img :src="imgSrc" width="100%" height="100%" alt="">
    </div>
    <el-table :data="tableData">

      <el-table-column prop="jclx" label="决策类型" />
      <el-table-column prop="zx" label="执行/调用次数" />
      <el-table-column prop="pj" label="平均响应时间内" />

    </el-table>

  </div>

</template>

<script>
export default {
  data() {
    return {
      formInline: { input: '', input1: '' },
      imgSrc: require('@/assets/6.png'),
      //   checked: true,
      tableData: [
        {
          jclx: '规则',
          zx: '1818',
          pj: '1.8秒'
        },
        {
          jclx: '算法',
          zx: '1818',
          pj: '1.8秒'
        },
        {
          jclx: '规则',
          zx: '1818',
          pj: '1.8秒'
        }
      ]

    }
  },
  methods: {
    goInstructionLogQuery() {
      this.$router.push({ name: 'instructionLogQuery' })
    }
  }

}

</script>

<style scoped >
.title{
    height: 50px;
    font-size: 20px;
    /* border:1px solid #fff */
}

.ring{
    height: 500px;
    border:1px solid
}

</style>

