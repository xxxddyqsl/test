<template>
  <div class="pageBox">
    <div class="seachBox">
      <div>
        <span>选项：</span>
        <template v-for="(item,index) of list">
          <el-checkbox :key="index" v-model="item.state">{{ item.name }}</el-checkbox>
        </template>
      </div>
      <div>
        <el-button type="primary" size="small" @click="statusFun">生成</el-button>
        <el-button type="primary" size="small">导出</el-button>
      </div>
    </div>
    <el-table
      ref="table"
      :data="tableData"
      :header-cell-style="{'text-align':'center'}"
      :cell-style="{'text-align':'center'}"
      border
    >
      <el-table-column type="index" label="序号" width="50" />
      <el-table-column v-for="(item,i) in listTitle" :key="i" :prop="item.prop" :label="item.name">
        <template v-if="item.children">
          <el-table-column
            v-for="(itm,idx) of item.children"
            :key="idx"
            :prop="itm.prop"
            :label="itm.name"
          />
        </template>
      </el-table-column>
      <!-- <el-table-column v-if="status" label="航班订座">
        <el-table-column prop="date" label="当前" />
        <el-table-column prop="date" label="当前" />
      </el-table-column>-->
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [
        {
          name: '同比日期',
          state: false,
          prop: 'date'
        },
        {
          name: '航班订座',
          state: false,
          prop: 'date'
        },
        {
          name: '客座率',
          state: false,
          prop: 'date'
        },
        {
          name: '预估收入',
          state: false,
          prop: 'date'
        },
        {
          name: '可用座位数',
          state: false,
          prop: 'date'
        },
        {
          name: 'ASK',
          state: false,
          prop: 'date'
        },
        {
          name: 'RASK',
          state: false,
          prop: 'date'
        },
        {
          name: '票价',
          state: false,
          prop: 'date'
        },
        {
          name: '分配指标',
          state: false,
          prop: 'date'
        }
      ],
      status: false,
      listTitle: [],
      tableData: [
        {
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄'
        }
      ]
    }
  },
  beforeUpdate() {

  },
  methods: {
    statusFun() {
      this.listTitle = []
      this.list.forEach((item) => {
        if (item.state) {
          this.listTitle.push(item)
        }
        this.$nextTick(() => {
          // 初始化表格
          this.$refs.table.doLayout()
        })
      })
    }
  }
}
</script>

<style scoped >
</style>

