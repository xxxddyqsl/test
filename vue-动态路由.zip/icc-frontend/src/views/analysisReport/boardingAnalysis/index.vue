<template>
  <div class="pageBox">
    <!-- 上客分析 -->
    <div ref="table" style="width:100%; height:100%;" />
  </div>
</template>

<script>
import { initTableleua } from '@/api/tableleua.js'
export default {

  data() {
    return {
      // imgSrc: require('@/assets/4.png')
    }
  },
  mounted() {
    // 获取容器元素
    const containerDiv = this.$refs.table
    // 配置选项
    const options = {
      // 隐藏tab栏
      hideTabs: true,
      // 加载后执行的回调函数
      onFirstInteractive: function() {
      },
      // 设置图表模块和容器等宽
      width: '100%',
      // 设置图标模块和容器等高
      height: '100%'
    }
    let url = ''
    initTableleua(`/AnalysisReport-PassengerAnalysis/AnalysisReport-PassengerAnalysis`).then(res => {
      url = res.data.data
      // 实例化一个Talleau视图对象,并传入上述三个参数
      const view = new tableau.Viz(containerDiv, url, options)
    })
  }
}
</script>

<style lang="scss" scoped>
.pageBox{
  height: calc(100vh - 10px);
}
</style>
