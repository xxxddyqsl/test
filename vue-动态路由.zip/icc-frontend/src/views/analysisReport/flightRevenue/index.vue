
<template>
  <div class="pageBox">
    <!-- 航班收益指标分析 -->
    <!-- <div class="title">
      <div class="title_right">
        <el-form :inline="true" size="small" label-width="50px">
          <el-form-item label="航线">
            <el-input v-model="input" style="width:180px" size="mini" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="航班">
            <el-input v-model="input1" style="width:180px" size="mini" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="本期">
            <el-date-picker v-model="value1" size="mini" style="width:220px" type="daterange" value-format="yyyy.MM.dd" start-placeholder="2021.03.15" end-placeholder="2021.05.31" @change="yy" />
          </el-form-item>

          <el-form-item label="同期">
            <el-date-picker v-model="value2" size="mini" style="width:220px" type="daterange" value-format="yyyy.MM.dd" start-placeholder="2021.03.16" end-placeholder="2021.04.15" @change="yy1" />
          </el-form-item>

          <el-form-item style="width: 180px">
            <el-button type="primary" style="margin: 0 5px" size="mini">查询</el-button>
            <el-button type="primary" style="margin: 0 5px" size="mini">导出</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div> -->
    <!-- <div class="neck">
      本期: {{ value3 || '2021.03.15-2021.05.31' }} &nbsp; &nbsp;&nbsp;&nbsp;  同期: {{ value4 || '2021.03.16-2021.04.15' }}
    </div> -->

    <!-- :summary-method="getSummaries" -->
    <!-- <el-table
      ref="multipleTable"
      border
      :span-method="objectSpanMethod"
      :cell-class-name="tableRowClassName"
      :data="tableData"
      show-summary
      @cell-mouse-leave="cellMouseLeave"
      @cell-mouse-enter="cellMouseEnter"
    >

      <el-table-column label="航线名称" align="center">
        <template slot-scope="scope" width="160">
          <div>{{ scope.row.name }}</div>
        </template>
      </el-table-column>
      <el-table-column label="航班号" prop="hbh" align="center" />
      <el-table-column label="ASK" prop="ASK" align="center" />
      <el-table-column label="同比" prop="ASKtb" align="center" />
      <el-table-column label="客座率" prop="kzl" align="center" />
      <el-table-column label="同比" prop="kzltb" align="center" />
      <el-table-column label="RASK" prop="RASK" align="center" />
      <el-table-column label="同比" prop="RASKtb" align="center" />
      <el-table-column label="人数" prop="rs" align="center" />
      <el-table-column label="同比" prop="rstb" align="center" />
      <el-table-column label="票价" prop="pj" align="center" />
      <el-table-column label="同比" prop="pjtb" align="center" />
      <el-table-column label="航班收入" prop="hbsr" align="center" />
      <el-table-column label="同比" align="hbsrtb" />
    </el-table> -->
    <!-- <div style="display:flex; align-items: center; ">

      <el-pagination background layout="prev, pager, next" :total="10" />
      <span>共 27 条数据 3 页  当前显示第 1 页</span>

    </div> -->
    <div ref="table" style="width:100%; height:100%;" />
  </div>
</template>

<script>
import { initTableleua } from '@/api/tableleua.js'
export default {
  data() {
    return {
      OrderIndexArr: [],
      OrderIndexArr2: [],
      OrderIndexArr3: [],
      hoverOrderArr: [],
      boolValue: false,
      ischecked: false,
      sign: false,
      rowIndex: '-1',

      dialogData: false,
      position: null,

      multipleRowSelection: [],
      multipleColSelection: [],
      input: '',
      input1: '',
      value1: '',
      value2: '',
      value3: '',
      value4: '',
      tableData: [{
        name: '广州-德宏芒市',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      },
      {
        name: '广州-德宏芒市',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'

      }, {
        name: '浦东-达州',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-达州',

        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-邯郸',

        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-邯郸',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-邯郸',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-邯郸',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-唐山',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-唐山',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-运城',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-运城',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-运城',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }, {
        name: '浦东-运城',
        hbh: 'YY9729',
        ASK: '3,534K',
        ASKtb: '13.3%',
        kzl: '93.0%',
        kzltb: '-0.94pt',
        RASK: '0.863',
        RASKtb: '4.7%',
        rs: 2087,
        rstb: '-1.0%',
        pj: '1461',
        pjtb: '5.8%',
        hbsr: '3.50K',
        hbsrtb: '5.1%'
      }]

    }
  },
  created() {
    // this.getOrderNumber()
  },
  mounted() {
    // 获取容器元素
    const containerDiv = this.$refs.table
    // 配置选项
    const options = {
      // 隐藏tab栏
      hideTabs: true,
      // 加载后执行的回调函数
      onFirstInteractive: function() {
      },
      // 设置图表模块和容器等宽
      width: '100%',
      // 设置图标模块和容器等高
      height: '100%'
    }
    let url = ''
    initTableleua(`/AnalysisReport-FlightRevenueAnalysis/AnalysisReport-FlightRevenueAnalysis`).then(res => {
      url = res.data.data
      // 实例化一个Talleau视图对象,并传入上述三个参数
      const view = new tableau.Viz(containerDiv, url, options)
    })
  },
  methods: {

    yy() {
      this.value3 = this.value1.toString().replace(',', '-')
    },
    yy1() {
      this.value4 = this.value2.toString().replace(',', '-')
    },

    onSubmit() {},
    // getSummaries(param) {
    //   const { columns, data } = param
    //   const sums = []
    //   columns.forEach((column, index) => {
    //     if (index === 0) {
    //       sums[index] = '总价'
    //       return
    //     }
    //     const values = data.map(item => Number(item[column.property]))
    //     if (!values.every(value => isNaN(value))) {
    //       sums[index] = values.reduce((prev, curr) => {
    //         const value = Number(curr)
    //         if (!isNaN(value)) {
    //           return prev + curr
    //         } else {
    //           return prev
    //         }
    //       }, 0)
    //     //   sums[index] += ' 元'
    //     } else {
    //       sums[index] = 'N/A'
    //     }
    //   })

    //   return sums
    // },

    // 寻找应该合并行
    getOrderNumber() {
      const OrderObj = {}
      this.tableData.forEach((element, index) => {
        element.rowIndex = index
        if (OrderObj[element.name]) {
          OrderObj[element.name].push(index)
        } else {
          OrderObj[element.name] = []
          OrderObj[element.name].push(index)
        }
      })

      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const k in OrderObj) {
        console.log('k', k, OrderObj[k])
        if (OrderObj[k].length > 1) {
          this.OrderIndexArr.push(OrderObj[k])
        }
      }
    },

    // 合并单元格
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        for (let i = 0; i < this.OrderIndexArr.length; i++) {
          const element = this.OrderIndexArr[i]
          for (let j = 0; j < element.length; j++) {
            const item = element[j]
            if (rowIndex == item) {
              if (j == 0) {
                return {
                  rowspan: element.length,
                  colspan: 1
                }
              } else if (j != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      } else if (columnIndex === 1) {
        for (let i = 0; i < this.OrderIndexArr2.length; i++) {
          const element2 = this.OrderIndexArr2[i]
          for (let h = 0; h < element2.length; h++) {
            const item2 = element2[h]
            if (rowIndex == item2) {
              if (h == 0) {
                return {
                  rowspan: element2.length,
                  colspan: 1
                }
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      } else if (columnIndex === 2) {
        for (let i = 0; i < this.OrderIndexArr3.length; i++) {
          const element3 = this.OrderIndexArr3[i]
          for (let h = 0; h < element3.length; h++) {
            const item3 = element3[h]
            if (rowIndex == item3) {
              if (h == 0) {
                return {
                  rowspan: element3.length,
                  colspan: 1
                }
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                }
              }
            }
          }
        }
      }
    },
    tableRowClassName({ row, rowIndex }) {
      const arr = this.hoverOrderArr
      for (let i = 0; i < arr.length; i++) {
        if (rowIndex == arr[i]) {
          return 'hovered-row'
        }
      }
    },
    cellMouseEnter(row, column, cell, event) {
      this.rowIndex = row.rowIndex
      this.hoverOrderArr = []
      this.OrderIndexArr.forEach(element => {
        if (element.indexOf(this.rowIndex) >= 0) {
          this.hoverOrderArr = element
        }
      })
    },

    cellMouseLeave(row, column, cell, event) {
      this.rowIndex = '-1'
      this.hoverOrderArr = []
    },
    // 提交数据
    submitFunc() {
      console.log(this.multipleRowSelection)
    }

    // 跳转详情
    // calenderPage() {
    //   this.$router.push({ path: '/indexManagement/indicatorProgress' })
    // }
  }
}

</script>

<style lang="scss" scoped >

// .box{
//     margin-top: 60px
// }
// .title{
//     height: 50px;
//     font-size: 20px;
//     // border:1px solid #fff
// }
// .title_right{
//     width: 65%;
//     float: right;
//    form{
//        display: flex;
//        justify-content: space-around;
//        align-items: center;
//        div{
//            margin: 0;
//            padding: 0;
//             display: flex;
//             align-items: center;
//        }
//    }

// }

// </style>

// <style lang="scss" scoped>
.pageBox{
  height: calc(100vh - 10px);
}
</style>

