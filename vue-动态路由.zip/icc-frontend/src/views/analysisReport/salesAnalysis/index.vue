<template>

  <div class="pageBox">
    <!-- 舱位热点图 -->
    <div>
      <el-radio-group v-model="radio1" @change="change">
        <el-radio-button label="指标曲线" />
        <el-radio-button label="客流曲线" />
        <el-radio-button label="收益分析" />
        <el-radio-button label="舱位分析" />
      </el-radio-group>
    </div>
    <div v-show="radio1=='舱位分析'" class="box">
      <img :src="imgSrc" width="100%" height="100%" alt="">
    </div>
    <div v-show="radio1=='指标曲线'" class="box">
      <div ref="GrowthProgressCurve" style="width:100%; height:100%;" />
    </div>
    <div v-show="radio1=='客流曲线'" class="box">
      <div ref="PassengerAnalysis" style="width:100%; height:100%;" />
    </div>
    <div v-show="radio1=='收益分析'" class="box">
      <div ref="FlightRevenueAnalysis" style="width:100%; height:100%;" />
    </div>
  </div>
</template>

<script>
import { initTableleua } from '@/api/tableleua.js'
export default {
  data() {
    return {
      radio1: '指标曲线',
      imgSrc: require('@/assets/0211117164741.png'),
      urlData: '/GrowthProgressCurve/GrowthProgressCurve'
    }
  },
  mounted() {
    this.change(this.radio1)
  },
  methods: {
    change(view) {
      let containerDiv = null
      if (view == '指标曲线') {
        this.urlData = '/GrowthProgressCurve/GrowthProgressCurve'
        containerDiv = containerDiv = this.$refs.GrowthProgressCurve
      } else if (view == '客流曲线') {
        this.urlData = `/AnalysisReport-PassengerAnalysis/AnalysisReport-PassengerAnalysis`
        containerDiv = containerDiv = this.$refs.PassengerAnalysis
      } else if (view == '收益分析') {
        containerDiv = containerDiv = this.$refs.FlightRevenueAnalysis
        this.urlData = `/AnalysisReport-FlightRevenueAnalysis/AnalysisReport-FlightRevenueAnalysis`
      }
      // 获取容器元素

      // 配置选项
      const options = {
        // 隐藏tab栏
        hideTabs: true,
        // 加载后执行的回调函数
        onFirstInteractive: function() {
        },
        // 设置图表模块和容器等宽
        width: '100%',
        // 设置图标模块和容器等高
        height: '800px'
      }
      let url = ''
      initTableleua(this.urlData).then(res => {
        url = res.data.data
        // 实例化一个Talleau视图对象,并传入上述三个参数
        console.log(window.location.origin + url)
        // eslint-disable-next-line no-undef
        var view = new tableau.Viz(containerDiv, url, options)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.box{
  height: calc(100vh - 10px);
}
</style>

