<template>
  <div class="pageBox">
    <div class="seachBox">
      <div>
        {{ title }}
      </div>
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <el-radio-group
              v-model="radio1"
              class="m-r-10"
              size="mini"
              @change="changeClick"
            >
              <el-radio-button label="年" />
              <el-radio-button label="月" />
            </el-radio-group>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="isShow = !isShow">{{
              isShow ? "进度图" : "进度表"
            }}</el-button>
            <el-button type="primary" size="mini" @click="onGoBack"
              >返回进度首页</el-button
            >
            <el-button type="primary" size="mini" @click="controlCabin"
              >前往控舱管理</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>

    <div class="neck">
      <div style="font-size:35px">
        <!-- <i
          class="el-icon-caret-left"
          style="color:#000;cursor: pointer;"
          @click.stop.prevent="yearLeft"
        /> -->
        <span> {{ years }}年</span>
        <!-- <i
          class="el-icon-caret-right"
          style="color:#000;cursor: pointer;"
          @click.stop.prevent="yearRight"
        /> -->
      </div>
      <h2 style="margin:0;padding:0">
        {{ `销售额指标：${totalPoint}${company}` }}
      </h2>
    </div>

    <div v-if="isShow" class="year-calendar">
      <zp-calendar
        v-for="item in monthData"
        :key="item.num"
        fromsun
        :lines="6"
        class="calendar-box"
        :current-year.sync="years"
        :current-month.sync="item.num * 1"
      >
        <template v-slot:titleSlot>
          <div class="clickTextBtn tltleBox" @click="goDetail(item)">
            <span style="font-size:20px">{{ item.name }}</span>
            {{
              `${item.amountActual}${item.companyActual}/${item.amountPlan}${
                item.companyPlan
              }（${item.rate}%）`
            }}
          </div>
        </template>
      </zp-calendar>
    </div>
    <div v-else class="infinite_list_div">
      <!-- 拆解图 -->
      <lineChart
        id="indicatorJinDuChartRef"
        class="infinite_list_box box_shadow_common"
        :chart-data="chartDataFilter"
        width="100%"
        height="600px"
      />
    </div>
  </div>
</template>

<script>
import zpCalendar from "@/components/packages/calendar";
import lineChart from "@/components/echarts/lineChart/index";
import { selectScheduleType } from "@/api/IndicatorProgress";

export default {
  components: { zpCalendar, lineChart },

  data() {
    return {
      title: this.$route.query.title,
      monthData: [],
      totalPoint: "",
      company: "",
      years: this.getNowFormatDate(),
      radio1: "年",
      isShow: true,
      chartData: {
        textStyle: {
          fontSize: 16
        },
        xAxis: {
          type: "category",
          name: "月份",
          axisLabel: {
            fontSize: 18
          },
          data: []
        },
        yAxis: {
          type: "value",
          name: "亿元",
          axisLabel: {
            fontSize: 18
          }
        },
        legend: {
          data: [{ name: "年数据", icon: "rect" }],
          right: 20
        },
        series: {
          type: "line",
          name: "年数据",
          symbolSize: 8,
          itemStyle: {
            normal: {
              label: { show: true }
            }
          },
          lineStyle: {
            width: 4
          },
          data: []
        }
      }
    };
  },
  computed: {
    chartDataFilter() {
      const dataArr = [];
      const xAxisData = [];
      this.monthData.forEach(i => {
        dataArr.push(i.amountActual);
        xAxisData.push(i.num);
      });
      this.chartData.series.data = dataArr;
      this.chartData.xAxis.data = xAxisData;
      return this.chartData;
    }
  },
  mounted() {
    this.getSelectScheduleTypeData();
  },
  methods: {
    getSelectScheduleTypeData() {
      let info = {
        indicatorsId: this.$route.query.indicatorsId,
        code: this.$route.query.code
      };
      this.$route.query.id && (info.id = this.$route.query.id);
      this.$route.query.flightNo &&
        (info.flightNo = this.$route.query.flightNo);
      selectScheduleType(info)
        .then(res => {
          let response = res.data.data || {};
          this.monthData = response.list || [];
          this.totalPoint = response.total || "";
          this.company = response.company || "";
          this.years = response.year;
          this.title = response.title;
          this.monthData.forEach(i => {
            i.name = `${i.num}月`;
          });
          this.monthData.length &&
            (this.chartData.yAxis.name = this.monthData[0].companyActual);
        })
        .catch(err => {
          console.log(err);
        });
    },
    getNowFormatDate() {
      // 获取当天时间
      var date = new Date();
      //   var seperator1 = '-'
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      //   var currentdate = year + '年' + month + '月' + strDate + '日'
      //   return currentdate
      var currentdate = year;
      return currentdate;
    },
    // yearLeft() {
    //   this.years--;
    // },
    // yearRight() {
    //   this.years++;
    // },
    changeClick(data) {
      if (data == "月") {
        let query = {
          indicatorsId: this.$route.query.indicatorsId,
          code: this.$route.query.code,
          years: this.years,
          month: this.$route.query.month || 1, // 参数没有月份，默认1月
          title: this.$route.query.title
        };
        this.$route.query.id && (query.id = this.$route.query.id);
        this.$route.query.flightNo &&
          (query.flightNo = this.$route.query.flightNo);
        this.$router.push({ name: "MonthDetails", query });
      }
    },
    goDetail(item) {
      let query = {
        years: this.years,
        month: item.num,
        indicatorsId: this.$route.query.indicatorsId,
        code: this.$route.query.code,
        title: this.$route.query.title
      };
      this.$route.query.id && (query.id = this.$route.query.id);
      this.$route.query.flightNo &&
        (query.flightNo = this.$route.query.flightNo);
      this.$router.push({ name: "MonthDetails", query });
    },
    onGoBack() {
      this.$router.push({ name: "flightPerspective" });
    },
    controlCabin() {
      this.$router.push({ path: "/spaceManagement" });
    },
    controlCabin2() {
      this.$router.push({ path: "/indexManagement/daysEchart" });
    }
  }
};
</script>
<style scoped>
.box {
  margin-top: 60px;
}
.year-calendar {
  display: flex;
  width: 100%;
  /* margin-top: 10px; */
  flex-wrap: wrap;
  border-left: 1px solid #000;
  border-top: 1px solid #000;
}
.calendar-box {
  width: 25%;
  border-bottom: 1px solid #000;
  border-right: 1px solid #000;
  box-sizing: border-box;
}
.tltleBox {
  margin-bottom: 10px;
  color: #f59a23;
}
.title {
  height: 50px;
  font-size: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border: 1px solid #000;
}

.neck {
  user-select: none;
  height: 80px;
  display: flex;
  flex-direction: column;
  color: #f59a23;
  align-items: center;
}
.el-calendar {
  background-color: #fff;
  width: 25%;
  height: 200px;
}
.el-calendar__header {
  display: none !important;
}
.infinite_list_div {
  padding: 4px 20px;
}
.infinite_list_box {
  border-radius: 20px;
  padding: 8px 20px;
  overflow: hidden;
  box-sizing: border-box;
}
</style>
