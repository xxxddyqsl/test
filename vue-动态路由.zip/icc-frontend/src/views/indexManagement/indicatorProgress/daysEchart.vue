<template>
  <div class="pageBox">
    <div class="title">
      <div style="margin-left:10px" />
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <el-radio-group v-model="radio1" size="mini" @change="changeClick">
              <el-radio-button label="年" />
              <el-radio-button label="月" />
            </el-radio-group>
          </el-form-item>

          <!-- <el-select v-model="value" clearable placeholder="请选择" size="mini">
          <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" /> </el-select>
        <el-select v-model="value" clearable placeholder="请选择" size="mini">
          <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>  -->
          <el-form-item>
            <el-button type="primary" size="mini" @click="controlCabin2">进度图</el-button>
            <el-button type="primary" size="mini">返回</el-button>
            <el-button type="primary" size="mini" @click="controlCabin">前往控舱管理</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div class="neck">
      <h1 style="margin:0px;margin-top:20px;padding:0">
        <i class="el-icon-caret-left" @click="beforeDay" />
        {{ years }}
        <i class="el-icon-caret-right" @click="nextDay" />
      </h1>
      <h2 style="margin:0;padding:0">销售额指标：1000亿（±0）</h2>
    </div>
    <div style="height:70%;width:100%">
      <Details />
    </div>
  </div>
</template>
<script>
import Details from '@/components/echarts/Details'
export default {
  components: { Details },
  data() {
    return {
      radio1: '',
      count: ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'],
      years: this.getNowFormatDate(),
      options: [],
      value: ''
    }
  },
  created() {
  },
  methods: {
    getNowFormatDate() {
      // 获取当天时间
      var date = new Date()
      return this.myGetDate(date)
    },
    beforeDay() {
      var cc = this.years.replace('年', '-').replace('月', '-').replace('日', '')
      var date = new Date(cc)
      var time = date.getTime()// 当前的毫秒数
      var oneDay = 1000 * 60 * 60 * 24// 一天的毫秒数
      var before = time -= oneDay// 计算前一天的毫秒数
      date.setTime(before)
      this.years = this.myGetDate(date)
    },
    nextDay() {
      var cc = this.years.replace('年', '-').replace('月', '-').replace('日', '')
      var date = new Date(cc)
      var oneDay = 1000 * 60 * 60 * 24// 一天的毫秒数
      var time = date.getTime() + oneDay// 当前的毫秒数
      time = new Date(time)
      this.years = this.myGetDate(time)
    },
    add0(m) {
      return m < 10 ? '0' + m : m
    },
    // 封装日期格式化的方法
    myGetDate(d) {
      return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`
      //   `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`
    //   return d.getFullYear() + '年' + this.add0(d.getFullYear()) + '月' + this.add0(d.getDate()) + '日'
    },
    goDetails() {
      this.$router.push({ name: 'indicatorDisassemblyDetails' })
    },
    goback() {
      this.$router.go(-1)
    },
    changeClick(data) {
      if (data == '月') {
        this.$router.push({ name: 'MonthDetails' })
      } else if (data == '年') {
        this.$router.push({ name: 'indicatorProgress' })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    // border:1px solid #fff
}
.title_right{
    width: 55%;
    display: flex;
    justify-content:space-around;
    align-items: center;
}
.neck{
    height: 80px;
    display: flex;
    flex-direction: column;
    color: #F59A23;
    align-items: center;
}
</style>

