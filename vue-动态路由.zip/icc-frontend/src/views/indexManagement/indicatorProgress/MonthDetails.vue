<template>
  <div class="pageBox">
    <div class="seachBox">
      <div style="margin-left:10px" />
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <el-radio-group
              v-model="radio1"
              class="m-r-10"
              size="mini"
              @change="changeClick"
            >
              <el-radio-button label="年" />
              <el-radio-button label="月" />
            </el-radio-group>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="isShow = !isShow">{{
              isShow ? "进度图" : "进度表"
            }}</el-button>
            <el-button type="primary" size="mini" @click="controlCabin"
              >前往控舱管理</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div v-if="isShow">
      <zp-calendar
        :lines="6"
        :current-year.sync="currentYear"
        :current-month.sync="currentMonth"
        :module-type="1"
        :total="totalPoint"
        :company="company"
        :dayList="dayLists"
        @dayMsg="getDayMsg"
        @dayLists="getDate"
        @monthChangeFn="monthChangeFn"
      />
    </div>
    <div v-else class="infinite_list_div">
      <lineChart
        id="dayJinDuChartRef"
        class="infinite_list_box box_shadow_common"
        :chart-data="chartDataFilter"
        width="100%"
        height="600px"
      />
    </div>
  </div>
</template>

<script>
import zpCalendar from "@/components/packages/calendar/calendaractive";
import lineChart from "@/components/echarts/lineChart/index";
import { selectProgressMonth } from "@/api/IndicatorProgress";

export default {
  components: { zpCalendar, lineChart },
  data() {
    return {
      currentMonth: parseInt(this.$route.query.month),
      currentYear: parseInt(this.$route.query.years),
      company: "",
      value: "",
      radio1: "月",
      isShow: true,
      chartData: {
        textStyle: {
          fontSize: 16
        },
        xAxis: {
          type: "category",
          name: "日",
          axisLabel: {
            fontSize: 18
          },
          data: []
        },
        yAxis: {
          type: "value",
          name: "亿元",
          axisLabel: {
            fontSize: 18
          }
        },
        legend: {
          data: [{ name: "月数据", icon: "rect" }],
          right: 20
        },
        series: {
          type: "line",
          name: "月数据",
          symbolSize: 8,
          itemStyle: {
            normal: {
              label: { show: true }
            }
          },
          lineStyle: {
            width: 4
          },
          data: []
        }
      },
      dayLists: [],
      totalPoint: ""
    };
  },
  computed: {
    chartDataFilter() {
      const dataArr = [];
      const xAxisData = [];
      this.dayLists.forEach(i => {
        dataArr.push(i.amountActual);
        xAxisData.push(i.num);
      });
      this.chartData.series.data = dataArr;
      this.chartData.xAxis.data = xAxisData;
      return this.chartData;
    }
  },
  created() {
    this.getSelectProgressMonthData();
  },
  methods: {
    getSelectProgressMonthData(queryDate) {
      const query = queryDate || this.$route.query;
      let info = {
        indicatorsId: query.indicatorsId,
        code: query.code,
        month: `${query.years}${
          query.month < 10 ? "0" + query.month : query.month
        }`
      };
      query.id && (info.id = query.id);
      query.flightNo && (info.flightNo = query.flightNo);
      selectProgressMonth(info)
        .then(res => {
          let response = res.data.data || {};
          this.totalPoint = response.total || "";
          this.company = response.company || "";
          this.dayLists = response.list || [];
          this.dayLists.forEach(i => {
            i.num = Number(i.num);
          });
          this.dayLists.length &&
            (this.chartData.yAxis.name = this.dayLists[0].companyActual);
        })
        .catch(err => {
          console.log(err);
        });
    },
    getDayMsg(data) {
      let query = {
        type: "progressType",
        indicatorsId: this.$route.query.indicatorsId,
        code: this.$route.query.code,
        years: this.$route.query.years,
        month: this.$route.query.month,
        day: data.num,
        title: this.$route.query.title
      };
      this.$route.query.id && (query.id = this.$route.query.id);
      this.$route.query.flightNo &&
        (query.flightNo = this.$route.query.flightNo);

      this.$router.push({
        name: "nextDetails",
        query
      });
    },
    monthChangeFn(monthValue) {
      this.$route.query.month = monthValue;
      let query = {
        indicatorsId: this.$route.query.indicatorsId,
        code: this.$route.query.code,
        years: this.$route.query.years,
        month: monthValue
      };
      this.$route.query.id && (query.id = this.$route.query.id);
      this.$route.query.flightNo &&
        (query.flightNo = this.$route.query.flightNo);
      this.getSelectProgressMonthData(query);
    },
    changeClick(data) {
      if (data == "年") {
        let query = {
          indicatorsId: this.$route.query.indicatorsId,
          code: this.$route.query.code,
          years: this.$route.query.years,
          month: this.$route.query.month,
          title: this.$route.query.title
        };
        this.$route.query.id && (query.id = this.$route.query.id);
        this.$route.query.flightNo &&
          (query.flightNo = this.$route.query.flightNo);
        this.$router.push({ name: "indicatorProgress", query });
      }
    },
    controlCabin() {
      this.$router.push({ path: "/spaceManagement" });
    },
    controlCabin2() {
      this.$router.push({ path: "/indexManagement/daysEchart" });
    },
    getDate(dayLists) {
      this.dayLists = dayLists;
    }
  }
};
</script>

<style lang="scss" scoped>
.title {
  height: 50px;
  font-size: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border: 1px solid #000;
}
.title_right {
  // width: 55%;
  // display: flex;
  // justify-content: space-around;
  // align-items: center;
}
.neck {
  user-select: none;
  height: 90px;
  font-size: 20px;
  display: flex;
  flex-direction: column;
  color: #f59a23;
  align-items: center;
}
.m-r-10 {
  margin-right: 10px;
}
</style>
