export const headTypeList = ["total", "department", "line", "flights"];

export const headTypeIdList = ["totalId", "departmentId", "lineId", "fltn"];

export const headTypeValueList = [
  "totalValue",
  "departmentValue",
  "lineValue",
  "flightsValue"
];
export const headTypeUnitList = [
  "totalValueUnit",
  "departmentValueUnit",
  "lineValueUnit",
  "flightsValueUnit"
];
