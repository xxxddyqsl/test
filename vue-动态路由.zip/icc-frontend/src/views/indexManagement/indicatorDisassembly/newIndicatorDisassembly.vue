<template>
  <div class="pageBox">
    <el-form :inline="true" :model="formInline">
      <div class="seachBox">
        <div class="title_left">
          <el-form-item>
            <el-select
              v-model="formInline.indicatorId"
              placeholder="请选择销售额"
              size="mini"
              @change="sellListChange"
            >
              <el-option
                v-for="item in sellList"
                :key="item.id"
                :label="item.indicatorsName"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
        </div>
        <div class="title_right">
          <el-form-item>
            <el-select
              v-model="formInline.departmentId"
              clearable
              placeholder="分子公司"
              size="mini"
            >
              <el-option
                v-for="item in departmentList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="formInline.routeCode"
              clearable
              placeholder="航线"
              size="mini"
              remote
              filterable
              :remote-method="lineRemoteMethod"
            >
              <el-option
                v-for="item in lineList"
                :key="item.id"
                :label="item.routesName"
                :value="item.routesCode"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="formInline.flightNo"
              clearable
              placeholder="航班"
              size="mini"
              remote
              filterable
              :remote-method="flyRemoteMethod"
            >
              <el-option
                v-for="item in flyNumList"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onSearch"
              >查询</el-button
            >
            <el-button type="primary" size="mini" @click="cjzb"
              >拆解指标</el-button
            >
            <el-button type="primary" size="mini" @click="onSubmit"
              >确定生效</el-button
            >
          </el-form-item>

          <!-- <el-button type="primary" size="mini" @click="calenderPage">切换至日历视角</el-button> -->
          <!-- <el-button type="primary" size="mini" @click="pageJump">控舱管理</el-button> -->
        </div>
      </div>
    </el-form>
    <!-- 表格 -->
    <div class="table-box">
      <el-table
        ref="multipleTable"
        border
        :span-method="objectSpanMethod"
        :cell-class-name="tableRowClassName"
        :data="tableData"
        @cell-mouse-leave="cellMouseLeave"
        @cell-mouse-enter="cellMouseEnter"
      >
        <el-table-column
          v-for="(item, index) in tableHeadList"
          :key="index"
          :label="item.name"
          :prop="item.code"
          align="center"
          min-width="140"
        >
          <template slot-scope="scope">
            <div class="itemTemplate">
              <div class="itemTemplateLeft">
                <p class="clickTextBtn" @click="onNext(item.code, scope.row)">
                  {{ scope.row[item.code] }}（{{
                    previewValue(item.valueDiff, scope.row)
                  }}）
                </p>
                <div class="textBox">
                  <el-input
                    v-if="item.permission"
                    type="text"
                    v-model.num="scope.row[item.value]"
                    @change="
                      val => {
                        changeFn(val, scope.row, item.code);
                      }
                    "
                  />
                  <span class="textBoxValue" v-else>{{
                    scope.row[item.value]
                  }}</span>
                  <span class="textBoxUnit">{{
                    scope.row[item.valueUnit]
                  }}</span>
                </div>
              </div>
              <div
                class="itemTemplateRight"
                v-if="
                  index + 1 === tableHeadList.length && item.code != 'flights'
                "
                @click="onGetNextHead(scope.row, item.code)"
              >
                <i class="el-icon-arrow-right"></i>
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-dialog
        v-dialogDrag
        title="指标拆解"
        width="40%"
        :visible.sync="dialogzbcj"
      >
        <el-form
          ref="task_form"
          :model="task_form"
          :rules="rules1"
          label-width="200px"
        >
          <el-form-item label="选择已启用指标" prop="deskId">
            <el-select
              v-model="task_form.deskId"
              style="width:300px"
              multiple
              placeholder="请选择"
            >
              <el-option
                v-for="item in newAdd"
                :key="item.id"
                :value="item.id"
                :label="item.value"
              />
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="dialogzbcj = false"
            >取 消</el-button
          >
          <el-button style="margin:0 5px" type="primary">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import dayjs from "dayjs";
import {
  getIndicatorsSplit,
  getIndicatorsSelectList,
  getDepartmentsSelectList,
  getLineList,
  getLineNumRemoteList,
  getLineNumNoPageList,
  indicatorsSplitPreview,
  indicatorsSplitConfirmEffect
} from "@/api/indicatorDisassembly";
import {
  headTypeList,
  headTypeIdList,
  headTypeValueList,
  headTypeUnitList
} from "./common";
import template from "@/components/BulkImport/template.vue";

export default {
  components: { template },
  data() {
    return {
      sellList: [],
      departmentList: [],
      lineList: [],
      flyNumList: [],
      formInline: {
        indicatorId: "",
        departmentId: "",
        routeCode: "",
        flightNo: ""
      },
      newAdd: [],
      task_form: {
        deskId: ""
      },
      dialogzbcj: false,
      OrderIndexArr: [],
      OrderIndexArr2: [],
      OrderIndexArr3: [],
      hoverOrderArr: [],
      boolValue: false,
      ischecked: false,
      sign: false,
      rowIndex: "-1",

      dialogData: false,
      position: null,
      formSelect: {
        date: dayjs().format("YYYY-MM-DD")
      },
      multipleRowSelection: [],
      multipleColSelection: [],
      tableHeadList: [],
      tableData: [],
      rules1: [],
      submitList: [],
      headTypeList,
      headTypeIdList,
      headTypeValueList,
      headTypeUnitList,
      collectChangeData: [],
      submitParams: {}
    };
  },

  watch: {
    $route(to, from) {
      if (to.fullPath.indexOf("indexManagement/newIndicatorDisassembly") > -1) {
        this.initFn();
      }
    }
  },
  created() {},
  mounted() {
    this.initFn();
  },
  methods: {
    initFn() {
      this.getIndicatorsSelectListFn();
      this.getDepartmentsSelectListFn();
      this.lineRemoteMethod();
      this.getLineNumNoPageListFn();
    },
    // 获取销售列表
    getIndicatorsSelectListFn() {
      getIndicatorsSelectList()
        .then(res => {
          const response = res.data.data;
          this.sellList = response || [];
          this.sellList.length &&
            (this.formInline.indicatorId = this.sellList[0].id);
          this.getIndicatorsSplitFn();
        })
        .catch(err => {
          console.log(err);
        });
    },
    sellListChange(val) {
      this.getIndicatorsSplitFn();
    },
    // 分子公司列表
    getDepartmentsSelectListFn() {
      getDepartmentsSelectList()
        .then(res => {
          const response = res.data.data;
          this.departmentList = response || [];
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 获取航线列表
    lineRemoteMethod(query) {
      let info = { code: query ? query : "" };
      getLineList(info)
        .then(res => {
          const response = res.data.data;
          this.lineList = response;
        })
        .catch(err => {
          console.log(err);
        });
    },
    flyRemoteMethod(query) {
      if (!query) return;
      let info = {
        indicatorId: this.formInline.indicatorId,
        flightNo: query
      };
      getLineNumRemoteList(info)
        .then(res => {
          const response = res.data.data;
          this.flyNumList = response;
        })
        .catch(err => {
          console.log(err);
        });
    },
    getLineNumNoPageListFn() {
      getLineNumNoPageList({ id: this.formInline.indicatorId })
        .then(res => {
          const response = res.data.data;
          this.flyNumList = response;
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 查询
    onSearch() {
      this.getIndicatorsSplitFn();
    },
    // 获取指标拆解列表
    getIndicatorsSplitFn() {
      getIndicatorsSplit(this.formInline)
        .then(res => {
          const response = res.data.data;
          this.tableHeadList = response.indicatorHeader || [];
          // this.tableHeadList = [
          //   {
          //     code: "total",
          //     name: "总公司",
          //     permission: false,
          //     value: "totalValue",
          //     valueDiff: "totalValueDiff",
          //     valueUnit: "totalValueUnit"
          //   },
          //   {
          //     code: "department",
          //     name: "分子公司",
          //     permission: true,
          //     value: "departmentValue",
          //     valueDiff: "departmentValueDiff",
          //     valueUnit: "departmentValueUnit"
          //   }
          // ];
          this.tableData = response.indicatorContextList || [];
          this.getOrderNumberTotal();
          this.getOrderNumberdepartment();
          this.getOrderNumberLine();
        })
        .catch(err => {
          console.log(err);
        });
    },

    onNext(headType, row) {
      const index = this.headTypeList.indexOf(headType);
      const idStr = this.headTypeIdList[index];
      const valueStr = this.headTypeValueList[index];
      const unitStr = this.headTypeUnitList[index];

      let query = {
        title: headType,
        totalId: row.totalId,
        flyType: idStr,
        flyValue: row[idStr]
      };
      this.$router.push({
        name: "indicatorDisassembly",
        query
      });
    },
    previewValue(valueDiffType, row) {
      return row[valueDiffType] || "±0";
    },
    changeFn(val, row, code) {
      const index = this.headTypeList.indexOf(code);
      const idStr = this.headTypeIdList[index];
      const valueStr = this.headTypeValueList[index];
      const unitStr = this.headTypeUnitList[index];

      // 去重
      let deleteIndex = this.collectChangeData.findIndex((item, index) => {
        return item[idStr] === row[idStr];
      });
      if (deleteIndex === -1) {
        this.collectChangeData.push({
          [idStr]: row[idStr],
          [valueStr]: row[valueStr] * 1,
          [unitStr]: row[unitStr]
        });
      } else {
        this.collectChangeData[deleteIndex] = {
          [idStr]: row[idStr],
          [valueStr]: row[valueStr] * 1,
          [unitStr]: row[unitStr]
        };
      }

      this.submitParams.level = code;

      this.indicatorsSplitPreviewFn();
    },
    // 查看下一修改栏
    onGetNextHead(row, code) {
      const index = this.headTypeList.indexOf(code);
      this.submitParams.level = this.headTypeList[index + 1];
      this.indicatorsSplitPreviewFn();
    },
    indicatorsSplitPreviewFn() {
      this.submitParams.totalId = this.formInline.indicatorId;
      this.submitParams.paramList = this.collectChangeData;
      indicatorsSplitPreview(this.submitParams)
        .then(res => {
          const response = res.data.data;
          this.tableHeadList = response.indicatorHeader || [];
          // this.tableHeadList = [
          //   {
          //     code: "total",
          //     name: "总公司",
          //     permission: false,
          //     value: "totalValue",
          //     valueDiff: "totalValueDiff",
          //     valueUnit: "totalValueUnit"
          //   },
          //   {
          //     code: "department",
          //     name: "分子公司",
          //     permission: true,
          //     value: "departmentValue",
          //     valueDiff: "departmentValueDiff",
          //     valueUnit: "departmentValueUnit"
          //   }
          // ];
          this.tableData = response.indicatorContextList || [];
          this.getOrderNumberTotal();
          this.getOrderNumberdepartment();
          this.getOrderNumberLine();
        })
        .catch(err => {
          console.log(err);
        });
    },
    cjzb() {
      this.dialogzbcj = true;
    },
    onSubmit() {
      this.tableHeadList.forEach(i => {
        if (i.permission) {
          this.submitParams.level = i.code || "";
        }
      });
      this.submitParams.totalId = this.formInline.indicatorId;
      this.submitParams.paramList = this.collectChangeData;
      indicatorsSplitConfirmEffect(this.submitParams)
        .then(res => {
          const response = res.data.data;
          this.tableHeadList = response.indicatorHeader || [];
          this.tableData = response.indicatorContextList || [];
          this.getOrderNumberTotal();
          this.getOrderNumberdepartment();
          this.getOrderNumberLine();
        })
        .catch(err => {
          console.log(err);
        });
    },

    // 前10天
    pageUp() {
      if (this.formSelect.date) {
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(-10, "day")
          .format("YYYY-MM-DD");
      } else {
        this.formSelect.date = dayjs().format("YYYY-MM-DD");
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(-10, "day")
          .format("YYYY-MM-DD");
      }
    },
    // 后10天
    pageDown() {
      if (this.formSelect.date) {
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(+10, "day")
          .format("YYYY-MM-DD");
        console.log(this.formSelect.date, 456);
      } else {
        this.formSelect.date = dayjs().format("YYYY-MM-DD");
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(+10, "day")
          .format("YYYY-MM-DD");
      }
    },
    // 寻找应该合并行
    getOrderNumberTotal() {
      const OrderObj = {};
      this.tableData.forEach((element, index) => {
        element.rowIndex = index;
        if (OrderObj[element.totalId]) {
          OrderObj[element.totalId].push(index);
        } else {
          OrderObj[element.totalId] = [];
          OrderObj[element.totalId].push(index);
        }
      });

      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const k in OrderObj) {
        console.log("k", k, OrderObj[k]);
        if (OrderObj[k].length > 1) {
          this.OrderIndexArr.push(OrderObj[k]);
        }
      }
    },
    getOrderNumberdepartment() {
      const OrderObj2 = {};
      this.tableData.forEach((element, index) => {
        element.rowIndex = index;
        if (OrderObj2[element.departmentId]) {
          OrderObj2[element.departmentId].push(index);
        } else {
          OrderObj2[element.departmentId] = [];
          OrderObj2[element.departmentId].push(index);
        }
      });
      console.log("OrderObj", OrderObj2);
      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const j in OrderObj2) {
        if (OrderObj2[j].length > 1) {
          this.OrderIndexArr2.push(OrderObj2[j]);
        }
      }
    },
    getOrderNumberLine() {
      const OrderObj3 = {};
      this.tableData.forEach((element, index) => {
        element.rowIndex = index;
        if (OrderObj3[element.lineId]) {
          OrderObj3[element.lineId].push(index);
        } else {
          OrderObj3[element.lineId] = [];
          OrderObj3[element.lineId].push(index);
        }
      });

      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const r in OrderObj3) {
        if (OrderObj3[r].length > 1) {
          this.OrderIndexArr3.push(OrderObj3[r]);
        }
      }
    },

    // 合并单元格
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        for (let i = 0; i < this.OrderIndexArr.length; i++) {
          const element = this.OrderIndexArr[i];
          for (let j = 0; j < element.length; j++) {
            const item = element[j];
            if (rowIndex == item) {
              if (j == 0) {
                return {
                  rowspan: element.length,
                  colspan: 1
                };
              } else if (j != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                };
              }
            }
          }
        }
      } else if (columnIndex === 1) {
        for (let i = 0; i < this.OrderIndexArr2.length; i++) {
          const element2 = this.OrderIndexArr2[i];
          for (let h = 0; h < element2.length; h++) {
            const item2 = element2[h];
            if (rowIndex == item2) {
              if (h == 0) {
                return {
                  rowspan: element2.length,
                  colspan: 1
                };
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                };
              }
            }
          }
        }
      } else if (columnIndex === 2) {
        for (let i = 0; i < this.OrderIndexArr3.length; i++) {
          const element3 = this.OrderIndexArr3[i];
          for (let h = 0; h < element3.length; h++) {
            const item3 = element3[h];
            if (rowIndex == item3) {
              if (h == 0) {
                return {
                  rowspan: element3.length,
                  colspan: 1
                };
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                };
              }
            }
          }
        }
      }
    },
    tableRowClassName({ row, rowIndex }) {
      const arr = this.hoverOrderArr;
      for (let i = 0; i < arr.length; i++) {
        if (rowIndex == arr[i]) {
          return "hovered-row";
        }
      }
    },
    cellMouseEnter(row, column, cell, event) {
      this.rowIndex = row.rowIndex;
      this.hoverOrderArr = [];
      this.OrderIndexArr.forEach(element => {
        if (element.indexOf(this.rowIndex) >= 0) {
          this.hoverOrderArr = element;
        }
      });
    },

    cellMouseLeave(row, column, cell, event) {
      this.rowIndex = "-1";
      this.hoverOrderArr = [];
    }
  }
};
</script>

<style lang="scss" scoped>
.el-table ::v-deep .hovered-row {
  background: #f5f7fa;
}
.textBox {
  display: flex;
  justify-content: center;
  align-items: center;
  ::v-deep .el-input {
    width: 80%;
  }
  .textBoxUnit {
    width: 20%;
  }
}
.itemTemplate {
  display: flex;
  justify-content: center;
  align-items: center;
  .itemTemplateLeft {
    flex: 4;
  }
  .itemTemplateRight {
    cursor: pointer;
    flex: 1;
  }
}
</style>
