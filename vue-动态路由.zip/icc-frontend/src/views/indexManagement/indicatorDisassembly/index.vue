<template>
  <div class="pageBox">
    <div class="title">
      <div style="margin-left:10px">{{ title }}</div>
      <div class="title_right">
        <el-button
          v-if="isShow"
          type="primary"
          size="mini"
          @click="isShow = !isShow"
          >拆解图</el-button
        >
        <el-button
          v-if="!isShow"
          type="primary"
          size="mini"
          @click="isShow = !isShow"
          >拆解表</el-button
        >

        <el-button type="primary" size="mini" @click="onSubmit">保存</el-button>
        <el-button type="primary" size="mini" @click="flightPage"
          >返回</el-button
        >
      </div>
    </div>
    <div class="neck">
      <h1 style="margin:0px;margin-top:20px;padding:0">
        <!-- <i class="el-icon-caret-left" @click="yearLeft" /> -->
        {{ years }}年
        <!-- <i class="el-icon-caret-right" @click="yearRight" /> -->
      </h1>
      <h2 style="margin:0;padding:0">
        销售额指标：{{ yearValue }}{{ yearUnit }}（{{ sumDValue }}）
      </h2>
    </div>
    <!-- 拆解图 -->
    <div v-if="isShow" class="infinite_list_div">
      <div class="infinite_list_box box_shadow_common">
        <ul class="infinite_list">
          <li v-for="(i, index) in monthList" :key="index">
            <div class="clickTextBtn li_top" @click="goDetail(i)">
              {{ i.type }}（<span>{{ i.difference || "±0" }}</span
              >）
            </div>
            <div class="li_bottom">
              调整为：
              <el-input
                v-model.number.trim="i.num"
                class="liBInput"
                placeholder="0"
                @change="
                  val => {
                    changeFn(val, i);
                  }
                "
              />{{ i.unit }}
            </div>
          </li>
        </ul>
      </div>
    </div>
    <!-- 拆解表 -->
    <div v-else class="infinite_list_div">
      <!-- 拆解图 -->
      <lineChart
        id="indicatorChartRef"
        class="infinite_list_box box_shadow_common"
        :chart-data="chartDataFilter"
        width="100%"
        height="600px"
      />
    </div>
  </div>
</template>

<script>
import lineChart from "@/components/echarts/lineChart/index";
import {
  getDetailData,
  detailPreview,
  detailConfirmEffect
} from "@/api/indicatorDisassembly";
import _ from "lodash";

export default {
  components: { lineChart },

  data() {
    return {
      isShow: true,
      imgSrc: require("@/assets/拆解图.png"),
      title: "",
      years: this.getNowFormatDate(),
      yearValue: "",
      yearUnit: "",
      sumDValue: "±0",
      monthList: [],
      collectChangeData: [],
      submitParams: {
        totalId: this.$route.query.totalId
      },
      chartData: {
        textStyle: {
          fontSize: 16
        },
        xAxis: {
          type: "category",
          name: "月份",
          axisLabel: {
            fontSize: 18
          },
          data: []
        },
        yAxis: {
          type: "value",
          name: "亿元",
          axisLabel: {
            fontSize: 18
          }
        },
        legend: {
          data: [{ name: "年数据", icon: "rect" }],
          right: 20
        },
        series: {
          type: "line",
          name: "年数据",
          symbolSize: 8,
          itemStyle: {
            normal: {
              label: { show: true }
            }
          },
          lineStyle: {
            width: 4
          },
          data: []
        }
      }
    };
  },
  computed: {
    chartDataFilter() {
      const dataArr = [];
      const xAxisData = [];
      this.monthList.forEach(i => {
        dataArr.push(i.num);
        xAxisData.push(i.month);
      });
      this.chartData.series.data = dataArr;
      this.chartData.xAxis.data = xAxisData;
      return this.chartData;
    }
  },
  mounted() {
    this.getMonthData();
  },
  methods: {
    getMonthData() {
      let info = {
        totalId: this.$route.query.totalId
      };
      if (this.$route.query.flyType !== "totalId") {
        info[this.$route.query.flyType] = this.$route.query.flyValue;
      }
      getDetailData(info)
        .then(res => {
          const response = res.data.data;
          this.monthList = _.cloneDeep(response.detailList) || [];
          this.years = response.year;
          this.title = response.current;
          this.yearValue = response.currentMoney;
          this.yearUnit = response.currentMoneyUnit;
          response.currentDiff !== null &&
            (this.sumDValue = response.currentDiff);
          if (this.monthList.length) {
            this.chartData.yAxis.name = this.monthList[0].unit;
          }
        })
        .catch(err => {
          console.log(err);
        });
    },

    getNowFormatDate() {
      // 获取当天时间
      var date = new Date();
      //   var seperator1 = '-'
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      //   var currentdate = year + seperator1 + month + seperator1 + strDate
      //   return currentdate
      var currentdate = year;
      return currentdate;
    },
    yearLeft() {
      this.years--;
    },
    yearRight() {
      this.years++;
    },
    goDetail(item) {
      let query = {
        title: this.title,
        totalId: this.$route.query.totalId,
        years: this.years,
        month: item.month,
        flyType: this.$route.query.flyType,
        flyValue: this.$route.query.flyValue
      };
      this.$router.push({
        name: "details",
        query
      });
    },
    onSubmit() {
      detailConfirmEffect(this.submitParams)
        .then(res => {
          const response = res.data.data;
          this.monthList = _.cloneDeep(response.detailList) || [];
          this.years = response.year;
          this.title = response.current;
          this.yearValue = response.currentMoney;
          this.yearUnit = response.currentMoneyUnit;
          response.currentDiff !== null &&
            (this.sumDValue = response.currentDiff);
          if (this.monthList.length) {
            this.chartData.yAxis.name = this.monthList[0].unit;
          }
        })
        .catch(err => {
          console.log(err);
        });
    },
    flightPage() {
      this.$router.push({ name: "newIndicatorDisassembly" });
    },

    changeFn(val, item) {
      // 去重
      let deleteIndex = this.collectChangeData.findIndex((itm, index) => {
        return itm.changeType === item.yyyymm;
      });
      if (deleteIndex === -1) {
        this.collectChangeData.push({
          changeType: item.yyyymm,
          changeValue: val * 1,
          changeValueUnit: item.unit
        });
      } else {
        this.collectChangeData[deleteIndex] = {
          changeType: item.yyyymm,
          changeValue: val * 1,
          changeValueUnit: item.unit
        };
      }

      this.submitParams.paramList = this.collectChangeData;
      this.detailPreviewFn();
    },
    detailPreviewFn() {
      detailPreview(this.submitParams)
        .then(res => {
          const response = res.data.data;
          this.monthList = _.cloneDeep(response.detailList) || [];
          this.years = response.year;
          this.title = response.current;
          this.yearValue = response.currentMoney;
          this.yearUnit = response.currentMoneyUnit;
          response.currentDiff !== null &&
            (this.sumDValue = response.currentDiff);
          if (this.monthList.length) {
            this.chartData.yAxis.name = this.monthList[0].unit;
          }
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>

<style lang="scss" scoped>
.box {
  margin-top: 60px;
}
.title {
  height: 50px;
  font-size: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  /* border:1px solid #fff */
}
.title_right {
  width: 200px;
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.neck {
  height: 80px;
  display: flex;
  flex-direction: column;
  color: #f59a23;
  align-items: center;
}
.infinite_list_div {
  padding: 4px 20px;
}
.infinite_list_box {
  border-radius: 20px;
  padding: 8px 20px;
  overflow: hidden;
  box-sizing: border-box;
}
.infinite_list {
  list-style: none;
  margin-top: 20px;
  display: flex;
  flex-wrap: wrap;
  padding: 0;
}
.infinite_list li {
  width: 25%;
  height: 205px;
  border: 1px solid #ccc;
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  font-size: 18px;
  .li_top {
    margin-bottom: 20px;
    font-weight: 600;
    color: #f59a23;
  }
  .li_bottom {
    .liBInput {
      width: 40px;
      ::v-deep .el-input__inner {
        padding: 0 2px;
        font-size: 20px;
        font-weight: 800;
      }
    }
  }
}
</style>
