
<template>
  <div class="pageBox">
    <!-- 指标估测详情 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right" style="margin-right: 50px">
        <el-button type="primary" size="mini" @click="tableShow">计算结果预览</el-button>
      </div>
    </div>

    <div class="neckBox">
      <el-form ref="form" :model="form"  :rules="rules" label-width="350px">
        <!-- 生效年份 -->
        <el-form-item label="生效年份" prop="effectYear">
          <el-select v-model="form.effectYear" @change="changeEffect" clearable collapse-tags  placeholder="请选择生效年份">
            <el-option v-for="item in effectTimeList" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>

        <el-form-item prop="planList" class="plans">
          <template>
            <span slot="label">
              关联航班计划
              <el-tooltip class="item" effect="dark" placement="left-start" content="可选航班计划是与生效年份相关的航班计划">
                <i class="el-icon-question" />
              </el-tooltip>
            </span>
          </template>

          <el-select v-model="form.planList" filterable  collapse-tags multiple clearable  placeholder="请选择关联航班计划">
            <el-option v-for="item in plansList" :key="item.id" :label="item.name" :value="item.id"  />
          </el-select>
        </el-form-item>
 
        <el-form-item label="关联历史航班区间" prop="joindate">
          <el-date-picker
            v-model="form.joindate"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            placeholder="选择日期"
            value-format="yyyy-MM-dd HH:mm:ss"
          />
        </el-form-item>

        <el-form-item label="新需求系数" prop="coefficient">
          <el-input v-model="form.coefficient" style="width:200px" placeholder="请输入需求系数" />
        </el-form-item>

        <el-form-item label-width="0" prop="indicatorsValue">
          <div class="midBox">
            <el-table
              v-loading="loading"
              :data="tableData"
              style="width: 900px; margin:20px auto"
              border
              element-loading-text="拼命加载中"
              element-loading-spinner="el-icon-loading"
              element-loading-background="rgba(0, 0, 0, 0.8)"
            >
              <el-table-column prop="preOrHist" />
              <el-table-column prop="dateRange" label="日期区间" />
              <el-table-column prop="airlineNum" label="航线数(条)" />
              <el-table-column prop="flightNum" label="航班量(个)" />
              <el-table-column prop="seatKm" label="座公里" />
              <el-table-column prop="indicatorsValue" label="销售额" >
                <template slot-scope="scope" >
                  <el-input v-if="scope.row.preOrHist == '估测'" v-model="form.indicatorsValue"  placeholder="销售额"></el-input>
                  <span v-else>{{scope.row.indicatorsValue}}</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </el-form-item>

        <el-form-item label="优先级" prop="priorityLevel">
          <el-select v-model="form.priorityLevel" placeholder="请选择优先级">
            <el-option v-for="item in priorityLevelList" :key="item.value" :value="item.value" :label="item.label" />
          </el-select>
        </el-form-item>
        <div class="footer">
          <el-button type="info" @click="goBack">取消</el-button>
          <el-button type="primary" @click="subMit">提交</el-button>
        </div>
      </el-form>
    </div>

  </div>
</template>

<script>
import { getTarget, getProblem, getResults, submitResults, plansSelect } from '@/api/indexSetting.js'
export default {
  data() {
    return {
      effectTimeList: [],//生效年份列表
      tableData: [{ preOrHist: '历史' }, { preOrHist: '估测' }],
      // 优先级
      priorityLevelList: [{ label: '1', value: '1' }, { label: '2', value: '2' }, { label: '3', value: '3' }],
      form: {
        effectYear: '', //生效年份
        planList: [], //关联航班计划
        joindate: '', //关联历史航班区间
        joinDateStart: '', //关联历史航班开始时间
        joinDateEnd: '',//关联历史航班结束时间
        coefficient: '1',//需求系数
        indicatorsValue: '' // 销售额
      },
      rules: {
        indicatorsValue: [{ required: false, message: '请输入估测指标值', trigger: 'change' }],
        priorityLevel: [{ required: false, message: '请选择优先级', trigger: 'change' }],
        effectYear: [{ required: true, message: '请选择生效年份', trigger: 'change' }],
        joindate: [{ required: true, message: '请选择关联历史日期', trigger: 'change' }],
        coefficient: [{ required: true, message: '请输入需求系数', trigger: 'change' }],
        planList: [{ required: true, message: '请选择关联航班', trigger: 'change' }]
      },
      plansList: [],//关联航班计划
      submit: {}, //没用到
      loading: false // 预览加载状态
    }
  },
  created() {
    this.getTargets()
    this.plansSelect()
  },
  methods: {
    /**
     * 获取 关联航班计划 下拉列表
     */
    plansSelect(){
      plansSelect({pageSize: '999' , pageNum: '1'}).then(res =>{
        if(res.data.code == '200'){
          this.plansList = res.data.data.rows
        }
      })
    },
    /**
     * 切换生效年份触发事件
     */
    changeEffect(v){
      getProblem({effectYear: v}).then(res =>{
        if(res.data.code == '200'){
          this.form.joindate = [res.data.data.historicalDateStart, res.data.data.historicalDateEnd]
          this.form.planList = res.data.data.ids
        }
      })
    },
    /**
     * 计算结果预览
     */
    tableShow() {
      this.rules.indicatorsValue[0].required = false
      this.rules.priorityLevel[0].required = false
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
          this.form.joinDateStart = this.form.joindate[0]   //关联历史日期结束
          this.form.joinDateEnd = this.form.joindate[1]     //关联历史日期开始 	
          getResults(this.form).then(res => {
            if (res.data.code == 200) {
              this.tableData = res.data.data
              this.tableData.forEach(v =>{
                if(v.preOrHist == '历史'){
                  this.form.indicatorsValue = v.indicatorsValue
                }
              })
              this.loading = false
            }
          })
        }
      })

    },
    /**
     * 返回
     */
    goBack() {
      this.$router.go(-1)
    },
    /**
     * 提交
     */
    subMit() {
      this.rules.indicatorsValue[0].required = true
      this.rules.priorityLevel[0].required = true
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.form.joinDateStart = this.form.joindate[0]   //关联历史日期结束
          this.form.joinDateEnd = this.form.joindate[1]     //关联历史日期开始 	
          this.form.planId = this.form.planList

          submitResults(this.form).then(res => {
            if (res.data.code == '200') {
              this.$router.go(-1)
            }
          })
        }
      })
    },
    /**
     * 获取年份下拉列表
     */
    getTargets() {
      getTarget().then(res => {
        if (res.data.code == 200) {
          this.effectTimeList = res.data.data
        }
      })
    },
  }

}

</script>

<style scoped  lang="scss">
.box{
  margin-top: 60px
}
.neckBox{
  clear: both;
  margin: 40px auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.footer{
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding-right: 100px;
}
::v-deep .el-form{
 margin: 20px auto;
 width: 900px;
}
.plans {
  ::v-deep.el-input{
    width: 350px  !important;
  }
}
</style>

