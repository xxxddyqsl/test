<template>
  <div class="pageBox">
    <div class="title">
      <div style="margin-left:10px">
        {{ title || "" }}
      </div>
      <div class="title_right">
        <el-button
          v-if="isShow"
          type="primary"
          size="mini"
          @click="isShow = !isShow"
          >拆解图</el-button
        >
        <el-button
          v-if="!isShow"
          type="primary"
          size="mini"
          @click="isShow = !isShow"
          >拆解表</el-button
        >
        <el-button
          v-if="routerType !== 'progressType'"
          type="primary"
          size="mini"
          @click="onSubmitFn"
          >保存</el-button
        >
        <el-button type="primary" size="mini" @click="onGoBack">返回</el-button>
      </div>
    </div>
    <div class="neck">
      <h1>
        <!-- <i
          v-if="leftMonthBtnShow"
          class="el-icon-caret-left changeBtn"
          @click="preDay"
        /> -->
        {{ titleFilter }}
        <!-- <i
          v-if="rightMonthBtnShow"
          class="el-icon-caret-right changeBtn"
          @click="nextDay"
        /> -->
      </h1>
      <h2>{{ `销售额指标：${totalPoint}${company}` }}</h2>
    </div>
    <div v-if="isShow" style="height:70%;width:100%">
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column
          :prop="routerType === 'progressType' ? 'flightNo' : 'type'"
          label="航班号"
        />
        <el-table-column label="销售额指标">
          <template slot-scope="scope">
            <span v-if="routerType === 'progressType'">{{
              `${scope.row.amountActual}${scope.row.companyActual} / ${
                scope.row.amountPlan
              }${scope.row.companyPlan}`
            }}</span>
            <!-- <span v-else>{{ `${scope.row.num}${scope.row.unit}` }}</span> -->
            <div v-else>
              <el-input
                v-model.number.trim="scope.row.num"
                class="liBInput"
                size="mini"
                placeholder="0"
                @change="
                  val => {
                    changeFn(val, scope.row);
                  }
                "
              />{{ scope.row.unit }}
            </div>
          </template>
        </el-table-column>
        <el-table-column v-if="routerType === 'progressType'" label="完成率">
          <template slot-scope="scope">
            <span>{{ scope.row.rate }}%</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div v-else style="height:70%;width:100%">
      <lineChart
        id="lineChaiChartRef"
        class="infinite_list_box box_shadow_common"
        :chart-data="chartDataFilter"
        width="100%"
        height="600px"
      />
    </div>
  </div>
</template>
<script>
import lineChart from "@/components/echarts/lineChart/index";
import { selectProgressDay } from "@/api/IndicatorProgress";
import {
  getDetailData,
  detailPreview,
  detailConfirmEffect
} from "@/api/indicatorDisassembly";

export default {
  components: { lineChart },
  data() {
    return {
      title: "",
      totalPoint: "",
      company: "",
      tableData: [],
      isShow: true,
      years: this.$route.query.years,
      month: Number(this.$route.query.month),
      day: Number(this.$route.query.day),
      routerType: this.$route.query.type,
      finishOneMonthList: [1, 3, 5, 7, 8, 10, 12],
      leftMonthBtnShow: true,
      rightMonthBtnShow: true,
      collectChangeData: [],
      submitParams: {
        totalId: this.$route.query.totalId
      },
      chartData: {
        textStyle: {
          fontSize: 16
        },
        xAxis: {
          type: "category",
          name: "航班",
          axisLabel: {
            fontSize: 14,
            interval: 0,
            rotate: 90
          },
          data: []
        },
        yAxis: {
          type: "value",
          name: "元",
          axisLabel: {
            fontSize: 18
          }
        },
        legend: {
          data: [{ name: "航班数据", icon: "rect" }],
          right: 20
        },
        series: {
          type: "line",
          name: "航班数据",
          symbolSize: 8,
          itemStyle: {
            normal: {
              label: { show: true }
            }
          },
          lineStyle: {
            width: 4
          },
          data: []
        }
      }
    };
  },
  computed: {
    chartDataFilter() {
      const dataArr = [];
      const xAxisData = [];
      this.tableData.forEach(i => {
        if (this.routerType === "progressType") {
          dataArr.push(i.amountActual);
          xAxisData.push(i.flightNo);
        } else {
          dataArr.push(i.num);
          xAxisData.push(i.type);
        }
      });
      this.chartData.series.data = dataArr;
      this.chartData.xAxis.data = xAxisData;
      return this.chartData;
    },
    titleFilter() {
      let str = `${this.years}年${
        this.month < 10 ? "0" + this.month : this.month
      }月${this.day < 10 ? "0" + this.day : this.day}日`;
      return str;
    }
  },
  created() {
    this.getData();
  },
  mounted() {
    this.day === 1 && (this.leftMonthBtnShow = false);
    if (this.month === 2) {
      this.day === 28 && (this.rightMonthBtnShow = false);
    } else if (this.finishOneMonthList.includes(this.month)) {
      this.day === 31 && (this.rightMonthBtnShow = false);
    } else {
      this.day === 30 && (this.rightMonthBtnShow = false);
    }
  },
  methods: {
    getData(queryDate) {
      const query = queryDate || this.$route.query;

      if (this.routerType === "progressType") {
        let info = {
          indicatorsId: query.indicatorsId,
          code: query.code,
          flyDay: `${query.years}${
            query.month < 10 ? "0" + query.month : query.month
          }${query.day < 10 ? "0" + query.day : query.day}`
        };
        query.id && (info.id = query.id);
        query.flightNo && (info.flightNo = query.flightNo);
        selectProgressDay(info)
          .then(res => {
            let response = res.data.data || {};
            this.totalPoint = response.total || "";
            this.company = response.company || "";
            this.tableData = response.list || [];
            this.title = response.title || "";
            this.tableData.length &&
              (this.chartData.yAxis.name = this.tableData[0].companyActual);
          })
          .catch(err => {
            console.log(err);
          });
      } else {
        let info = {
          totalId: query.totalId,
          dateTime: `${query.years}${
            query.month < 10 ? "0" + query.month : query.month
          }${query.day < 10 ? "0" + query.day : query.day}`
        };
        info[this.$route.query.flyType] = this.$route.query.flyValue;
        getDetailData(info)
          .then(res => {
            let response = res.data.data || {};
            this.totalPoint = response.currentMoney || "";
            this.company = response.currentMoneyUnit;
            this.tableData = response.detailList || [];
            this.title = response.current || this.$route.query.title;
            this.tableData.length &&
              (this.chartData.yAxis.name = this.tableData[0].unit);
          })
          .catch(err => {
            console.log(err);
          });
      }
    },
    onGoBack() {
      if (this.routerType !== "progressType") {
        this.$router.push({ name: "newIndicatorDisassembly" });
        return;
      }
      let query = {
        indicatorsId: this.$route.query.indicatorsId,
        code: this.$route.query.code,
        years: this.years,
        month: this.$route.query.month || 1, // 参数没有月份，默认1月
        title: this.$route.query.title
      };
      this.$route.query.id && (query.id = this.$route.query.id);
      this.$route.query.flightNo &&
        (query.flightNo = this.$route.query.flightNo);
      this.$router.push({ name: "MonthDetails", query });
    },
    getNowFormatDate() {
      // 获取当天时间
      var date = new Date();
      return this.myGetDate(date);
    },
    preDay() {
      // this.month.include()
      this.day--;
      this.day === 1 && (this.leftMonthBtnShow = false);
      if (this.month === 2) {
        this.day < 28 && (this.rightMonthBtnShow = true);
      } else if (this.finishOneMonthList.includes(this.month)) {
        this.day < 31 && (this.rightMonthBtnShow = true);
      } else {
        this.day < 30 && (this.rightMonthBtnShow = true);
      }
      let query = {
        ...this.$route.query,
        day: this.day
      };
      this.getData(query);
    },
    nextDay() {
      this.day++;
      this.day > 1 && (this.leftMonthBtnShow = true);
      if (this.month === 2) {
        this.day === 28 && (this.rightMonthBtnShow = false);
      } else if (this.finishOneMonthList.includes(this.month)) {
        this.day === 31 && (this.rightMonthBtnShow = false);
      } else {
        this.day === 30 && (this.rightMonthBtnShow = false);
      }

      let query = {
        ...this.$route.query,
        day: this.day
      };
      this.getData(query);
    },
    // 封装日期格式化的方法
    myGetDate(d) {
      return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
    },
    onSubmitFn() {
      detailConfirmEffect(this.submitParams)
        .then(res => {
          let response = res.data.data || {};
          this.totalPoint = response.currentMoney || "";
          this.company = response.currentMoneyUnit;
          this.tableData = response.detailList || [];
          this.title = response.current || this.$route.query.title;
          this.tableData.length &&
            (this.chartData.yAxis.name = this.tableData[0].unit);
        })
        .catch(err => {
          console.log(err);
        });
    },
    changeFn(val, item) {
      // 去重
      let deleteIndex = this.collectChangeData.findIndex((itm, index) => {
        return itm.changeType === item.type;
      });
      if (deleteIndex === -1) {
        this.collectChangeData.push({
          changeType: item.type,
          changeValue: val * 1,
          changeValueUnit: item.unit
        });
      } else {
        this.collectChangeData[deleteIndex] = {
          changeType: item.type,
          changeValue: val * 1,
          changeValueUnit: item.unit
        };
      }

      this.submitParams.paramList = this.collectChangeData;
      this.submitParams.dateTime = `${item.yyyymm}${
        this.$route.query.day < 10
          ? "0" + this.$route.query.day
          : this.$route.query.day
      }`;
      this.detailPreviewFn();
    },
    detailPreviewFn() {
      this.submitParams.departmentId = this.$route.query.flyValue || "";
      detailPreview(this.submitParams)
        .then(res => {
          let response = res.data.data || {};
          this.totalPoint = response.currentMoney || "";
          this.company = response.currentMoneyUnit;
          this.tableData = response.detailList || [];
          this.title = response.current || this.$route.query.title;
          this.tableData.length &&
            (this.chartData.yAxis.name = this.tableData[0].unit);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>

<style lang="scss" scoped>
.box {
  margin-top: 60px;
}
.title {
  height: 50px;
  font-size: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  // border:1px solid #fff
}
.title_right {
  // width: 20%;
  // display: flex;
  // justify-content: space-around;
  // align-items: center;
}
.neck {
  height: 80px;
  display: flex;
  flex-direction: column;
  color: #f59a23;
  align-items: center;
  h1,
  h2 {
    margin: 0;
    padding: 0;
  }
}
.changeBtn {
  cursor: pointer;
}
.infinite_list_box {
  border-radius: 20px;
  padding: 8px 20px;
  overflow: hidden;
  box-sizing: border-box;
}
.m-r-10 {
  margin-right: 10px;
}
.liBInput {
  width: 60px;
}
</style>
