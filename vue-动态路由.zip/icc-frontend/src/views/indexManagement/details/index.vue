<template>
  <div class="pageBox">
    <div class="title">
      <div style="margin-left:10px">
        {{ title }}
      </div>
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <el-radio-group
              v-model="radio1"
              class="m-r-10"
              size="mini"
              @change="changeClick"
            >
              <el-radio-button label="年" />
              <el-radio-button label="月" />
            </el-radio-group>
          </el-form-item>
          <el-form-item>
            <el-button
              v-if="isShow"
              type="primary"
              size="mini"
              @click="isShow = !isShow"
              >拆解图</el-button
            >
            <el-button
              v-if="!isShow"
              type="primary"
              size="mini"
              @click="isShow = !isShow"
              >拆解表</el-button
            >

            <el-button type="primary" size="mini" @click="onSubmitFn"
              >保存</el-button
            >
            <el-button type="primary" size="mini" @click="goDetails"
              >返回</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="neck">
      <h2 style="margin:0px;padding:0">
        <!-- <i class="el-icon-caret-left cursorPoint" @click="preMonth" /> -->
        {{ currentYear }}年{{ currentMonth }}月
        <!-- <i class="el-icon-caret-right cursorPoint" @click="nextMonth" /> -->
      </h2>
      <h3 style="margin:0;padding:0">
        销售额指标：{{ monthValue }}{{ monthUnit }}（{{ sumDValue }}）
      </h3>
    </div>

    <div v-if="isShow" class="zbox">
      <zp-calendar
        ref="detailsCalendarRef"
        :lines="6"
        :current-year="currentYear"
        :current-month="currentMonth"
        :module-type="2"
        :dayList="dayLists"
        :currentDiff="sumDValue"
        @dayMsg="getDayMsg"
        @dayLists="getDate"
        @collectData="collectData"
      />
    </div>
    <div v-else class="infinite_list_div">
      <lineChart
        id="dayChartRef"
        class="infinite_list_box box_shadow_common"
        :chart-data="chartDataFilter"
        width="100%"
        height="600px"
      />
    </div>
  </div>
</template>

<script>
import _ from "lodash";
import zpCalendar from "@/components/packages/calendar/calendaractive";
import lineChart from "@/components/echarts/lineChart/index";
import {
  getDetailData,
  detailPreview,
  detailConfirmEffect
} from "@/api/indicatorDisassembly";

export default {
  components: { zpCalendar, lineChart },
  data() {
    return {
      isShow: true,
      title: "",
      currentMonth: parseInt(this.$route.query.month),
      currentYear: parseInt(this.$route.query.years),
      radio1: "月",
      monthValue: "",
      monthUnit: "",
      dayLists: [],
      sumDValue: "±0",
      collectChangeData: [],
      submitParams: {
        totalId: this.$route.query.totalId
      },
      chartData: {
        textStyle: {
          fontSize: 16
        },
        xAxis: {
          type: "category",
          name: "日",
          axisLabel: {
            fontSize: 18
          },
          data: []
        },
        yAxis: {
          type: "value",
          name: "亿元",
          axisLabel: {
            fontSize: 18
          }
        },
        legend: {
          data: [{ name: "月数据", icon: "rect" }],
          right: 20
        },
        series: {
          type: "line",
          name: "月数据",
          symbolSize: 8,
          itemStyle: {
            normal: {
              label: { show: true }
            }
          },
          lineStyle: {
            width: 4
          },
          data: []
        }
      }
    };
  },
  computed: {
    chartDataFilter() {
      let dataArr = [];
      let xAxisData = [];
      this.dayLists.forEach(i => {
        dataArr.push(i.num);
        xAxisData.push(i.type);
      });
      this.chartData.series.data = dataArr;
      this.chartData.xAxis.data = xAxisData;
      return this.chartData;
    }
  },
  mounted() {
    // this.sumDValue = this.$refs.detailsCalendarRef.sumDValue;
    this.getDetailDataFn();
  },
  methods: {
    getDetailDataFn() {
      let info = {
        totalId: this.$route.query.totalId,
        month: this.$route.query.month
      };
      info[this.$route.query.flyType] = this.$route.query.flyValue + "";
      getDetailData(info)
        .then(res => {
          const response = res.data.data;
          this.dayLists = response.detailList || [];
          this.title = response.current || "";

          this.monthValue = response.currentMoney;
          this.monthUnit = response.currentMoneyUnit;
          response.currentDiff !== null &&
            (this.sumDValue = response.currentDiff);

          if (this.dayLists.length) {
            this.chartData.yAxis.name = this.dayLists[0].unit;
          }
        })
        .catch(err => {
          console.log(err);
        });
    },
    getDayMsg(day) {
      let query = {
        type: "indicatorDisassembly",
        totalId: this.$route.query.totalId,
        years: this.$route.query.years,
        month: this.$route.query.month,
        day: day.type,
        title: this.$route.query.title,
        flyType: this.$route.query.flyType,
        flyValue: this.$route.query.flyValue + ""
      };
      this.$router.push({
        name: "nextDetails",
        query
      });
    },

    // 上一月
    preMonth() {
      this.currentMonth--;
      if (this.currentMonth === 0) {
        this.currentMonth = 12;
        this.currentYear--;
      }
      this.initData(this.formatDate(this.currentYear, this.currentMonth, 1));
    },

    // 下一月
    nextMonth() {
      this.currentMonth++;
      if (this.currentMonth === 13) {
        this.currentMonth = 1;
        this.currentYear++;
      }
      this.initData(this.formatDate(this.currentYear, this.currentMonth, 1));
    },
    yearLeft() {
      this.years--;
    },
    yearRight() {
      this.years++;
    },
    goDetails() {
      this.$router.push({ name: "newIndicatorDisassembly" });
    },
    changeClick(data) {
      if (data == "年") {
        this.$router.push({ name: "indicatorDisassembly" });
      }
    },
    getDate(dayLists) {
      this.dayLists = dayLists;
    },
    onSubmitFn() {
      detailConfirmEffect(this.submitParams)
        .then(res => {
          const response = res.data.data;
          this.dayLists = response.detailList || [];
          this.title = response.current || "";

          this.monthValue = response.currentMoney;
          this.monthUnit = response.currentMoneyUnit;
          response.currentDiff !== null &&
            (this.sumDValue = response.currentDiff);

          if (this.dayLists.length) {
            this.chartData.yAxis.name = this.dayLists[0].unit;
          }
        })
        .catch(err => {
          console.log(err);
        });
    },
    collectData(collectData) {
      this.collectChangeData = _.cloneDeep(collectData);
      this.submitParams.paramList = this.collectChangeData;
      this.submitParams.month = this.$route.query.month;
      this.submitParams[this.$route.query.flyType] =
        this.$route.query.flyValue + "";
      this.detailPreviewFn();
    },
    detailPreviewFn() {
      detailPreview(this.submitParams)
        .then(res => {
          const response = res.data.data;
          this.dayLists = response.detailList || [];
          this.title = response.current || "";

          this.monthValue = response.currentMoney;
          this.monthUnit = response.currentMoneyUnit;
          response.currentDiff !== null &&
            (this.sumDValue = response.currentDiff);

          if (this.dayLists.length) {
            this.chartData.yAxis.name = this.dayLists[0].unit;
          }
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>

<style lang="scss" scoped>
.box {
  margin-top: 60px;
}
.title {
  height: 50px;
  font-size: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  // border:1px solid #fff
  ::v-deep .el-form-item {
    margin-bottom: 0;
  }
}
.title_right {
  // width: 20%;
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.neck {
  height: 80px;
  display: flex;
  flex-direction: column;
  color: #f59a23;
  align-items: center;
}
.zbox {
  height: 100%;
}
.infinite_list_div {
  padding: 4px 20px;
}
.infinite_list_box {
  border-radius: 20px;
  padding: 8px 20px;
  overflow: hidden;
  box-sizing: border-box;
}
.m-r-10 {
  margin-right: 10px;
}
</style>
