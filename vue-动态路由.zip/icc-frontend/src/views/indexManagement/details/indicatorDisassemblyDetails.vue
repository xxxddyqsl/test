<template>
  <div class="pageBox">
    <div class="title">
      <div class="title_right">
        <el-form :inline="true">
          <el-form-item>
            <el-select v-model="value" size="mini" placeholder="指标类型">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="neckBox">
      <el-form ref="task_form" :model="task_form" :rules="rules1">
        <el-form-item label="指标拆解日期区间" prop="skills">
          <!-- <el-select v-model="task_form.skills" placeholder="请选择"> -->
          <!-- <el-option v-for="item in xin_jian1" :key="item.skillId" :value="item.skillId" :label="item.skillName" /> -->
          <el-date-picker v-model="value2" type="daterange" placeholder="去年历史同期" />
        <!-- </el-select> -->
        </el-form-item>

      </el-form>
    </div>
    <div class="footer">
      <el-button type="info" @click="goBack">取消</el-button>
      <el-button type="primary" @click="goBack1">计算</el-button>
    </div>

  </div>

</template>

<script>

export default {

  data() {
    return {

      options: [{
        value: '选项1',
        label: '指标类型'
      }],
      value: ''
    }
  },

  methods: {
    goBack() {
      this.$router.push({ name: 'indexSetting' })
    },
    goBack1() {
      this.$router.go(-1)
    }
  }

}
</script>

<style lang="scss" scoped>

.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    border:1px solid
}
.title_right{
    width: 8%;
}
.neckBox{
    width: 300px;
    margin: 50px auto;
}
.footer{
display: flex;
justify-content: flex-end;
align-items: center;
}
</style>
