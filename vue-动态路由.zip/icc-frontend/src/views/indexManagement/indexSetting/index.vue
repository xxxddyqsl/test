<template>
  <!-- btx 指标管理-指标设置- -->
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">
        <el-form ref="queryForm" :inline="true" label-width="100px" size="small" :model="queryForm">

          <el-form-item>
            <el-select v-model="queryForm.indicatorsType" clearable size="mini" placeholder="指标类型">
              <el-option v-for="item in typeOptions" :key="item.indicatorsType" :label="item.label" :value="item.indicatorsType" />
            </el-select>
          </el-form-item>
          <!-- <el-form-item>
            <el-select v-model="queryForm.indicatorsStatus" multiple clearable collapse-tags size="mini" placeholder="指标状态">
              <el-option v-for="item in statusOptions" :key="item.indicatorsStatus" :label="item.label" :value="item.indicatorsStatus" />
            </el-select>
          </el-form-item> -->
          <el-form-item>
            <el-select v-model="queryForm.effectTime"  clearable collapse-tags size="mini" placeholder="请选择生效年份">
              <el-option v-for="item in effectTimeList" :key="item" :label="item" :value="item" />
            </el-select>
          </el-form-item>
          <el-form-item><el-button type="primary" size="mini" @click="query">查询</el-button></el-form-item>
          <el-form-item><el-button type="primary" size="mini" @click="reSet">重置</el-button></el-form-item>
          <el-form-item><el-button type="primary" size="mini" @click="addNew">新增</el-button>   </el-form-item>
          <el-form-item> <el-button type="primary" size="mini" @click="goIndexSettingDetails">指标估测</el-button>  </el-form-item>
        </el-form>

      </div>
    </div>
    <div>
      <el-table
        :data="tableData"
        size="large"
        border
      >
        <el-table-column prop="indicatorsType" label="指标类型" />
        <el-table-column prop="indicatorsValue" label="指标值" />
        <el-table-column prop="priorityLevel" label="优先级" />
        <el-table-column prop="effectTime" label="生效年份" />
        <el-table-column prop="joinDateTime" label="关联历史航班区间" />
        <el-table-column prop="coefficientNum" label="新需求系数" />
        <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <!-- <el-button
              type="primary"
              size="mini"
              :style="{background: scope.row.indicatorsStatus == '未启用' ? '' : 'rgba(245, 154, 35, 1)' ,borderColor: scope.row.indicatorsStatus == '未启用'? '' : 'rgba(245, 154, 35, 1)'}"
              @click="using(scope.row)"
            >{{ scope.row.indicatorsStatus == "未启用" ? "启用" : "启用中" }}</el-button> -->
            <el-button
              type="primary"
              size="mini"
              @click="amendClick(scope.row)"
            >修改</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="deletes(scope.row)"
            >删除</el-button>
          </template>

        </el-table-column>
      </el-table>
      <el-pagination
        background
        :current-page="page.currentPage"
        :page-size="page.pageSize"
        layout="total, prev, pager, next"
        :total="page.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
    <!-- 新增弹窗 -->
    <el-dialog
      v-dialogDrag
      :title="form.title"
      :visible.sync="dialogFormVisible"
      width="600px"
    >
      <el-form ref="form" :model="form" :rules="rules" label-width="140px" label-position="right">
        <el-form-item label="指标类型" prop="indicatorsType">
          <el-select v-model="form.indicatorsType" clearable size="small" placeholder="请选择指标类型">
            <el-option v-for="item in typeOptions" :key="item.indicatorsType" :label="item.label" :value="item.indicatorsType" />
          </el-select>
        </el-form-item>
        <el-form-item label="指标值" prop="indicatorsValue">
          <el-input v-model="form.indicatorsValue" size="small" style="width: 120px" placeholder="请输入指标值" />
        </el-form-item>
        <el-form-item label="生效年份" prop="effectYear">
          <el-select v-model="form.effectYear" @change="changeEffect" clearable collapse-tags size="small" placeholder="请选择生效年份">
            <el-option v-for="item in effectTimeList" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>

        <el-form-item prop="planList" class="plans">
          <template>
            <span slot="label">
              关联航班计划
              <el-tooltip class="item" effect="dark" placement="left-start" content="可选航班计划是与生效年份相关的航班计划">
                <i class="el-icon-question" />
              </el-tooltip>
            </span>
          </template>

          <el-select v-model="form.planList" filterable  collapse-tags multiple clearable  placeholder="请选择关联航班计划">
            <el-option v-for="item in plansList" :key="item.id" :label="item.name" :value="item.id"  />
          </el-select>
        </el-form-item>

        <el-form-item label="关联历史航班区间" prop="joindate">
          <el-date-picker
            v-model="form.joindate"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            size="small"
            placeholder="选择日期"
            value-format="yyyy-MM-dd HH:mm:ss"
          />
        </el-form-item>
        <el-form-item label="需求系数" prop="coefficientNum">
          <el-input v-model="form.coefficientNum" size="small" style="width: 120px" placeholder="指标值" />
        </el-form-item>

        <el-form-item label="优先级" prop="priorityLevel">
          <el-select v-model="form.priorityLevel" clearable size="small" placeholder="指标类型">
            <el-option v-for="item in priorityLevel" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button
          style="margin:0 5px"
          @click="dialogFormVisible = false"
        >取 消</el-button>
        <el-button
          style="margin:0 5px"
          type="primary"
          @click="amend"
        >确 定</el-button>
      </div>

    </el-dialog>
  </div>
</template>

<script>
import { initSet, initSelect, addSet, usingSet, amendSet, deletesSet, getTarget, getProblem , plansSelect} from '@/api/indexSetting.js'
export default {
  data() {
    return {
      effectTimeList: [], //生效年份列表
      queryForm: {
        effectTime: '',
        // indicatorsStatus: [],
        indicatorsType: ''
      },
      page: {
        currentPage: 1,//当前页码
        pageSize: 10,//每页数量
        pageNum: '1',//当前页码
        total: 0 //总数
      },
      form: {
        indicatorsType: '', //指标类型
        indicatorsValue: '',//指标值
        effectYear: '', //生效年份
        planList: [], //关联航班计划
        joindate: '', //关联历史航班区间
        joindateEnd: '', //关联历史日期结束	
        joindateStart: '', //关联历史日期开始	
        priorityLevel: '', // 优先级	
        title: '',
        coefficientNum: '' //需求系数
      },
      rules: {
        indicatorsType: [{ required: true, message: '请选择指标类型', trigger: 'change' }],
        indicatorsValue: [{ required: true, message: '请输入指标值', trigger: 'change' }],
        priorityLevel: [{ required: true, message: '请选择优先值', trigger: 'change' }],
        effectYear: [{ required: true, message: '请选择生效年份', trigger: 'change' }],
        joindate: [{ required: true, message: '请选择关联历史日期', trigger: 'change' }],
        coefficientNum: [{ required: true, message: '请输入需求系数', trigger: 'change' }],
        planList: [{ required: true, message: '请选择关联航班', trigger: 'change' }]
      },
      dialogFormVisible: false, //添加修改弹窗
      tableData: [], // 表格数据
      pickerOptions: { //没用到
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      typeOptions: [],//指标类型下拉列表
      statusOptions: [],
      priorityLevel: [ //优先级下拉列表
        { label: 1, value: 1 },
        { label: 2, value: 2 },
        { label: 3, value: 3 }
      ],
      plansList: [], //关联航班计划列表
      isAdd: true
    }
  },
  created() {
    
    this.getList()
    this.getSelect('zbzt')
    this.getSelect('zblx')
    getTarget().then(res =>{
      if(res.data.code == '200'){
        this.effectTimeList = res.data.data
      }
    })
   
    //  * 获取 关联航班计划 下拉列表
   
    plansSelect({pageSize: '999' , pageNum: '1'}).then(res =>{
      if(res.data.code == '200'){
        this.plansList = res.data.data.rows
      }
    })
  },
  methods: {
    /**
     * 选择生效日期出发事件
     */
    changeEffect(v){
      getProblem({effectYear: v}).then(res =>{
        if(res.data.code == '200'){
          this.form.joindate = [res.data.data.historicalDateStart, res.data.data.historicalDateEnd]
          this.form.planList = res.data.data.ids
        }
      })
    },
    /**
     * 获取字典下拉列表
     * zblx 指标类型
     * zbzt 指标状态
     */
    getSelect(data) {
      initSelect(data).then(res => {
        console.log(res)
        if (data === 'zbzt') {
          this.statusOptions = res.data.data
          this.statusOptions.forEach(v => {
            v.label = v.name
            v.indicatorsStatus = v.code
          })
        } else if (data === 'zblx') {
          this.typeOptions = res.data.data
          this.typeOptions.forEach(v => {
            v.label = v.name
            v.indicatorsType = v.code
          })
        }
      })
    },
    /**
     * 获取列表
     */
    getList() {
      initSet({
        ...this.queryForm,
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize
      }).then(res => {
        if (res.data.code == 200) {
          if (res.data.data.rows.length <= 0) {
            if (this.page.pageNum > 1) { this.page.pageNum = this.page.pageNum - 1 }
            initSet({
              ...this.queryForm,
              pageNum: this.page.pageNum,
              pageSize: this.page.pageSize
            }).then(res => {
              if (res.data.code == 200) {
                this.tableData = res.data.data.rows
                this.page.total = res.data.data.total
                this.page.pageNum = res.data.data.pageNum
              }
            })
          } else {
            this.tableData = res.data.data.rows
            this.page.total = res.data.data.total
            this.page.pageNum = res.data.data.pageNum
          }
        }
      })
    },
    /**
     * 重置按钮
     */
    reSet(){
      this.page.pageNum = 1
      this.queryForm={
        effectTime: '',
        indicatorsType: ''
      },
      this.getList()
    },
    /**
     * 更改每页数量-暂时没用
     */
    handleSizeChange(val) {
      this.page.pageSize = val
      this.getList()
    },
    /**
     * 切换页码
     */
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.getList()
    },
    /**
     * 添加点击
     */
    addNew() {
      this.isAdd = true
      this.dialogFormVisible = true
      this.$refs['form'] && this.$refs['form'].resetFields()
      this.form = { 
        indicatorsType: '', //指标类型
        indicatorsValue: '',//指标值
        effectYear: '', //生效年份
        planList: [], //关联航班计划
        joindate: '', //关联历史航班区间
        joindateEnd: '', //关联历史日期结束	
        joindateStart: '', //关联历史日期开始	
        priorityLevel: '', // 优先级	
        title: '',
        coefficientNum: '' //需求系数
      }
      this.form.title = '添加指标'
    },
    /**
     * 跳转指标估测
     */
    goIndexSettingDetails() {
      this.$router.push({ name: 'indexSettingDetails' })
    },

    /* 
    *添加修改提交确认
    */
    amend() {
      // eslint-disable-next-line no-undef
      this.$refs['form'].validate((valid) => {
        if (valid) {
          // this.form.indicatorsStatus = ''
          if (this.isAdd) {
            this.form.joindateStart = this.form.joindate[0]
            this.form.joindateEnd = this.form.joindate[1]
            addSet(this.form).then((res) => {
              this.page.pageNum = 1
              this.dialogFormVisible = false
              this.getList()
            })
          } else {
            amendSet(this.form).then((res) => {
              this.dialogFormVisible = false
              this.getList()
            })
          }
        }
      })
    },
    /**
     * 启用按钮-暂时没用
     */
    using(v) {
      this.$confirm(`此操作将永久${v.indicatorsStatus == '未启用' ? '启用' : '禁用'}这条数据, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          let indicatorsStatus = ''
          this.statusOptions.forEach(res => {
            if (res.name == v.indicatorsStatus) {
              indicatorsStatus = res.code
            }
          })
          usingSet({
            id: v.id,
            indicatorsStatus
          }).then((res) => {
            if (res.data.code == '200') {
              this.getList()
              this.$message({
                type: 'success',
                message: `${v.indicatorsStatus == '未启用' ? '启用' : '禁用'}成功!`
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: `已取消${v.indicatorsStatus == '未启用' ? '启用' : '禁用'}`
          })
        })
    },
    /**
     * 修改按钮
     */
    amendClick(v) {
      this.dialogFormVisible = true
      this.isAdd = false
      this.form = {}
      this.$refs['form'] && this.$refs['form'].resetFields()
      this.form = JSON.parse(JSON.stringify(v))
      this.form.joindate = [this.form.joindateStart, this.form.joindateEnd]
      this.form.title = '修改指标'
      this.form.effectYear = this.form.effectTime
      this.typeOptions.forEach(item => {
        if (item.label === v.indicatorsType) {
          this.form.indicatorsType = item.indicatorsType
        }
      })
      this.form.planList = this.form.planList.map(v => v.planId)
    },
    /**
     * 删除
     */
    deletes(v) {
      this.$confirm(`此操作将永久删除这条数据, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deletesSet(v.id).then((res) => {
            if (res.data.code == 200) {
              this.getList()
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    /**
     * 查询
     */
    query() {
      this.pageNum = 1
      this.getList()
    }
  }
}
</script>

<style scoped lang="scss">
.box {
  margin-top: 60px;
}
.plans {
  ::v-deep.el-input{
    width: 350px  !important;
  }
}

</style>

