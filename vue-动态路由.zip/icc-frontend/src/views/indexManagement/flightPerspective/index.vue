<template>
  <div class="pageBox">
    <el-form :inline="true" :model="formInline">
      <div class="seachBox">
        <div class="title_left">
          <el-form-item>
            <el-select
              v-model="formInline.indicatorsId"
              placeholder="请选择销售额"
              size="mini"
              @change="xsre"
            >
              <el-option
                v-for="item in xsr"
                :key="item.id"
                :label="item.indicatorsType"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
        </div>
        <div class="title_right">
          <el-form-item>
            <el-select
              v-model="formInline.molecularCompany"
              clearable
              placeholder="分子公司"
              size="mini"
            >
              <el-option
                v-for="item in departmentList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="formInline.routeId"
              clearable
              placeholder="航线"
              size="mini"
            >
              <el-option
                v-for="item in lineList"
                :key="item.id"
                :label="item.routesName"
                :value="item.routesCode"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="formInline.flightNo"
              clearable
              placeholder="航班"
              size="mini"
            >
              <el-option
                v-for="item in flyNumList"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onSearch"
              >查询</el-button
            >
            <el-button type="primary" size="mini" @click="onReset"
              >重置</el-button
            >
            <!-- <el-button type="primary" size="mini" @click="calenderPage">切换至日历视角</el-button> -->
            <el-button type="primary" size="mini" @click="controlCabin"
              >前往控舱管理</el-button
            >
          </el-form-item>
        </div>
      </div>
    </el-form>

    <!-- 表格 -->
    <div class="table-box">
      <el-table
        ref="multipleTable"
        v-loading="loading"
        spinner="加载中..."
        border
        :span-method="objectSpanMethod"
        :cell-class-name="tableRowClassName"
        :data="tableData"
        @cell-mouse-leave="cellMouseLeave"
        @cell-mouse-enter="cellMouseEnter"
      >
        <el-table-column label="总公司" align="center" width="140">
          <template slot-scope="scope">
            <div
              class="clickTextBtn"
              @click="calenderPage('总公司', 0, scope.row)"
            >
              {{ scope.row.headquarters }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="分子公司" align="center">
          <template slot-scope="scope">
            <div
              class="clickTextBtn"
              @click="calenderPage('分子公司', 1, scope.row)"
            >
              {{ scope.row.branchOffice }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="航线" align="center">
          <template slot-scope="scope">
            <div
              class="clickTextBtn"
              @click="calenderPage('航线', 2, scope.row)"
            >
              {{ scope.row.route }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="航班" align="center">
          <template slot-scope="scope">
            <div
              class="clickTextBtn"
              @click="calenderPage('航班', 3, scope.row)"
            >
              {{ scope.row.flight }}
            </div>
          </template>
        </el-table-column>
        <!-- <el-table-column label="航班" prop="flight" align="center" /> -->
      </el-table>
    </div>
  </div>
</template>

<script>
import {
  IndicatorProgress,
  IndicatorProgressSelect
} from "@/api/IndicatorProgress";
import {
  getDepartmentsSelectList,
  getLineList,
  getLineNumRemoteList,
  getLineNumNoPageList
} from "@/api/indicatorDisassembly";
import dayjs from "dayjs";
export default {
  data() {
    return {
      loading: false,
      indicatorsId: "",
      xsr: [],
      departmentList: [],
      lineList: [],
      flyNumList: [],
      formInline: {
        indicatorsId: "",
        molecularCompany: "",
        routeId: "",
        flightNo: ""
      },
      options: [{ label: "", value: "1" }],
      OrderIndexArr: [],
      OrderIndexArr2: [],
      OrderIndexArr3: [],
      hoverOrderArr: [],
      rowIndex: "-1",
      formSelect: {
        date: dayjs().format("YYYY-MM-DD")
      },
      multipleRowSelection: [],
      multipleColSelection: [],

      tableData: []
    };
  },
  watch: {
    $route(to, from) {
      if (to.fullPath.indexOf("indexManagement/flightPerspective") > -1) {
        this.IndicatorProgressSelects();
      }
    }
  },
  created() {},
  mounted() {
    this.initFn();
  },
  methods: {
    initFn() {
      this.IndicatorProgressSelects();
      this.getDepartmentsSelectListFn();
      this.lineRemoteMethod();
      this.getLineNumNoPageListFn();
    },
    onSearch() {
      this.IndicatorProgresse();
    },
    onReset() {
      this.formInline = {
        indicatorsId: this.xsr[0].id,
        molecularCompany: "",
        routeId: "",
        flightNo: ""
      };
      this.IndicatorProgresse();
    },
    xsre(row) {
      this.loading = true;
      this.formInline.indicatorsId = row;
      this.IndicatorProgresse();
    },
    IndicatorProgressSelects() {
      IndicatorProgressSelect().then(res => {
        this.xsr = res.data.data || [];
        this.xsr.length && (this.formInline.indicatorsId = this.xsr[0].id);
        this.IndicatorProgresse();
      });
    },
    // 分子公司列表
    getDepartmentsSelectListFn() {
      getDepartmentsSelectList()
        .then(res => {
          const response = res.data.data;
          this.departmentList = response || [];
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 获取航线列表
    lineRemoteMethod(query) {
      let info = { code: query ? query : "" };
      getLineList(info)
        .then(res => {
          const response = res.data.data;
          this.lineList = response;
        })
        .catch(err => {
          console.log(err);
        });
    },
    flyRemoteMethod(query) {
      if (!query) return;
      let info = {
        indicatorId: this.formInline.indicatorsId,
        flightNo: query
      };
      getLineNumRemoteList(info)
        .then(res => {
          const response = res.data.data;
          this.flyNumList = response;
        })
        .catch(err => {
          console.log(err);
        });
    },
    getLineNumNoPageListFn() {
      getLineNumNoPageList({ id: this.formInline.indicatorsId })
        .then(res => {
          const response = res.data.data;
          this.flyNumList = response;
        })
        .catch(err => {
          console.log(err);
        });
    },
    IndicatorProgresse() {
      var data = {
        indicatorsId: this.formInline.indicatorsId,
        flightNo: this.formInline.flightNo,
        molecularCompany: this.formInline.molecularCompany,
        routeId: this.formInline.routeId
      };
      IndicatorProgress(data).then(res => {
        this.tableData = res.data.data || [];

        this.getOrderNumber();
        this.getOrderNumber2();
        this.getOrderNumber3();
        this.loading = false;
      });
    },

    // 前10天
    pageUp() {
      if (this.formSelect.date) {
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(-10, "day")
          .format("YYYY-MM-DD");
      } else {
        this.formSelect.date = dayjs().format("YYYY-MM-DD");
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(-10, "day")
          .format("YYYY-MM-DD");
      }
    },
    // 后10天
    pageDown() {
      if (this.formSelect.date) {
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(+10, "day")
          .format("YYYY-MM-DD");
        // console.log(this.formSelect.date, 456);
      } else {
        this.formSelect.date = dayjs().format("YYYY-MM-DD");
        this.formSelect.date = dayjs(this.formSelect.date)
          .add(+10, "day")
          .format("YYYY-MM-DD");
      }
    },
    // 寻找应该合并行
    getOrderNumber() {
      const OrderObj = {};
      this.tableData.forEach((element, index) => {
        element.rowIndex = index;
        if (OrderObj[element.identification]) {
          OrderObj[element.identification].push(index);
        } else {
          OrderObj[element.identification] = [];
          OrderObj[element.identification].push(index);
        }
      });

      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const k in OrderObj) {
        // console.log('k', k, OrderObj[k])
        if (OrderObj[k].length > 1) {
          this.OrderIndexArr.push(OrderObj[k]);
        }
      }
    },
    getOrderNumber3() {
      const OrderObj3 = {};
      this.tableData.forEach((element, index) => {
        element.rowIndex = index;
        if (OrderObj3[element.routesId]) {
          OrderObj3[element.routesId].push(index);
        } else {
          OrderObj3[element.routesId] = [];
          OrderObj3[element.routesId].push(index);
        }
      });

      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const r in OrderObj3) {
        // console.log('r', r, OrderObj3[r])
        if (OrderObj3[r].length > 1) {
          this.OrderIndexArr3.push(OrderObj3[r]);
        }
      }
    },
    getOrderNumber2() {
      const OrderObj2 = {};
      this.tableData.forEach((element, index) => {
        element.rowIndex = index;
        if (OrderObj2[element.departmentId]) {
          OrderObj2[element.departmentId].push(index);
        } else {
          OrderObj2[element.departmentId] = [];
          OrderObj2[element.departmentId].push(index);
        }
      });
      // console.log("OrderObj", OrderObj2);
      // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
      for (const j in OrderObj2) {
        // console.log('j', j, OrderObj2[j])
        if (OrderObj2[j].length > 1) {
          this.OrderIndexArr2.push(OrderObj2[j]);
        }
      }
    },

    // 合并单元格
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        for (let i = 0; i < this.OrderIndexArr.length; i++) {
          const element = this.OrderIndexArr[i];
          for (let j = 0; j < element.length; j++) {
            const item = element[j];
            if (rowIndex == item) {
              if (j == 0) {
                return {
                  rowspan: element.length,
                  colspan: 1
                };
              } else if (j != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                };
              }
            }
          }
        }
      } else if (columnIndex === 1) {
        for (let i = 0; i < this.OrderIndexArr2.length; i++) {
          const element2 = this.OrderIndexArr2[i];
          for (let h = 0; h < element2.length; h++) {
            const item2 = element2[h];
            if (rowIndex == item2) {
              if (h == 0) {
                return {
                  rowspan: element2.length,
                  colspan: 1
                };
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                };
              }
            }
          }
        }
      } else if (columnIndex === 2) {
        for (let i = 0; i < this.OrderIndexArr3.length; i++) {
          const element3 = this.OrderIndexArr3[i];
          for (let h = 0; h < element3.length; h++) {
            const item3 = element3[h];
            if (rowIndex == item3) {
              if (h == 0) {
                return {
                  rowspan: element3.length,
                  colspan: 1
                };
              } else if (h != 0) {
                return {
                  rowspan: 0,
                  colspan: 0
                };
              }
            }
          }
        }
      }
    },
    tableRowClassName({ row, rowIndex }) {
      const arr = this.hoverOrderArr;
      for (let i = 0; i < arr.length; i++) {
        if (rowIndex == arr[i]) {
          return "hovered-row";
        }
      }
    },
    cellMouseEnter(row, column, cell, event) {
      this.rowIndex = row.rowIndex;
      this.hoverOrderArr = [];
      this.OrderIndexArr.forEach(element => {
        if (element.indexOf(this.rowIndex) >= 0) {
          this.hoverOrderArr = element;
        }
      });
    },

    cellMouseLeave(row, column, cell, event) {
      this.rowIndex = "-1";
      this.hoverOrderArr = [];
    },
    // 提交数据
    submitFunc() {
      console.log(this.multipleRowSelection);
    },

    // 跳转详情
    calenderPage(title, code, row) {
      let query = {
        title,
        code,
        indicatorsId: this.formInline.indicatorsId
      };
      if (code === 3) {
        query.flightNo = row.flightNo;
      }
      if (code === 1 || code === 2) {
        query.id = code === 1 ? row.departmentId : row.routesId;
      }
      this.$router.push({
        query,
        path: "/indexManagement/indicatorProgress"
      });
    },
    controlCabin() {
      this.$router.push({ path: "/spaceManagement" });
    }
  }
};
</script>

<style lang="scss" scoped>
.el-table ::v-deep .hovered-row {
  background: #f5f7fa;
}
</style>
