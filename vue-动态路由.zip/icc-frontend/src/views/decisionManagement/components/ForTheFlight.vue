<template>
  <!-- 预测参数 -->
  <div class="box">
    <header>适用航班条件</header>
    <el-form v-model="form" label-width="100px" label-position="left">

      <el-form-item label="航段&航班">
        <el-select v-model="form.flightSegment" style="width:300px" size="mini" multiple placeholder="请选择">
          <el-option v-for="item in form.options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="星期">
        <div style="height:16px">
          <el-checkbox v-for="(item,index) in form.week" :key="index" v-model="item.checked">{{ item.value }} </el-checkbox>
        </div>
      </el-form-item>
      <el-form-item label="经停/直达">
        <div style="height:16px">
          <el-checkbox v-for="(item,index) in form.stop_direct" :key="index" v-model="item.checked">{{ item.value }} </el-checkbox>
        </div>
      </el-form-item>
      <el-form-item label="航班优劣势">
        <div style="height:16px">
          <el-checkbox v-for="(item,index) in form.flightAdvantage" :key="index" v-model="item.checked">{{ item.value }} </el-checkbox>
        </div>
      </el-form-item>
      <el-form-item v-if="show" label="航班始发时间">
        <el-time-select v-model="form.startTime" size="mini" placeholder="00:00" :picker-options="{ start: '00:00', step: '00:15', end: '23:59' }" /> 至
        <el-time-select v-model="form.endTime" size="mini" placeholder="23:59" :picker-options="{ start: '00:00', step: '00:15', end: '23:59' }" />
      </el-form-item>
    </el-form>
  </div>
</template>
<script>

export default {
  components: {

  },
  props: {

    form: {
      type: Object,
      default: function() {
        return {
          options: [{
            value: '选项1',
            label: '黄金糕'
          }, {
            value: '选项2',
            label: '双皮奶'
          }, {
            value: '选项3',
            label: '蚵仔煎'
          }, {
            value: '选项4',
            label: '龙须面'
          }, {
            value: '选项5',
            label: '北京烤鸭'
          }],
          week: [
            { value: '全选', checked: false },
            { value: '周日', checked: false },
            { value: '周一', checked: false },
            { value: '周二', checked: false },
            { value: '周三', checked: false },
            { value: '周四', checked: false },
            { value: '周五', checked: false },
            { value: '周六', checked: false }
          ],
          stop_direct: [
            { value: '全选', checked: false },
            { value: '经停', checked: false },
            { value: '直达', checked: false }
          ],
          flightAdvantage: [
            { value: '全选', checked: false },
            { value: '极优势', checked: false },
            { value: '优势', checked: false },
            { value: '均势', checked: false },
            { value: '劣势', checked: false },
            { value: ' 极劣势', checked: false }
          ]
        }
      }
    }

  },
  data() {
    return {
      show: false
    }
  },
  created() {
    // 有-true---- 起飞日期，客座率，根据客座率设定配额，根据客座率调档，比舱，实时比价，超售，根据机型调舱
    // 无-false---- 特定日期舱位调整，特定日期设定配额，两舱倒挂，两舱优化
    const { name } = this.$route.query
    // eslint-disable-next-line eqeqeq
    if (name == '两舱优化' || name == '两舱倒挂' || name == '特定日期舱位调整' || name == '特定日期设定配额') {
      this.show = false
    } else {
      this.show = true
    }
  }
}
</script>
<style lang="scss" scoped>
.box{
  border: 1px solid #000;
  padding: 20px;
  border-radius: 20px;
  margin-bottom: 20px;
  header{
    margin-bottom: 20px;
  }
}
::v-deep .el-checkbox{
  margin-right: 10px;
}
::v-deep .el-form-item{
  height: 30px;
}
</style>
