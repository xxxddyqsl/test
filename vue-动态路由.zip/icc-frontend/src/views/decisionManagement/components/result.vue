<template>
  <div>
    <div class="title_right">
      <el-form :inline="true" :model="formInline">
        <el-form-item>
          <el-input v-model="formInline.name" size="mini" style="width:180px" placeholder="航段" />
        </el-form-item>
        <el-form-item>
          <el-input v-model="formInline.iataCode" size="mini" style="width:180px" placeholder="航班号" />
        </el-form-item>
        <el-form-item>
          <el-date-picker
            v-model="formInline.date"
            size="mini"
            type="date"
            placeholder="起飞日期"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="mini">查询</el-button>
          <el-button type="primary" size="mini" @click="onGoSet">算法设置</el-button>
        </el-form-item>

      </el-form>

    </div>
    <div class="search_box">

      <div class="title">
        <span style="color:#409EFF">预测参数结果</span>
      </div>
      <el-form
        ref="formSelect"
        :model="formSelect"
        label-width="160px"
        :inline="true"
        size="small"
      >
        <div style="border-bottom: 1px solid #D8E2E7;margin-bottom:20px">
          <el-form-item prop="value1" label="工作组:">
            <el-input v-model="formSelect.value1" disabled />
          </el-form-item>
          <el-form-item prop="value2" label="预测组:">
            <el-input v-model="formSelect.value2" disabled />
          </el-form-item>
          <el-form-item prop="value3" label="DCP:">
            <el-input v-model="formSelect.value3" disabled />
          </el-form-item>
          <el-form-item prop="value4" label="班期:">
            <el-input v-model="formSelect.value4" disabled />
          </el-form-item>
        </div>
        <el-form-item prop="value5" label="航线组:">
          <el-input v-model="formSelect.value5" disabled />
        </el-form-item>
        <el-form-item prop="value6" label="预测时间:">
          <el-input v-model="formSelect.value6" disabled />
        </el-form-item>
        <el-form-item prop="value7" label="离岗日期:">
          <el-input v-model="formSelect.value7" disabled />
        </el-form-item>
        <el-form-item prop="value8" label="舱级:">
          <el-input v-model="formSelect.value7" disabled />
        </el-form-item>
      </el-form>
      <div class="search_btn">
        <el-radio-group v-model="radio1" size="mini">
          <el-radio-button label="1">预测结果</el-radio-button>
          <el-radio-button label="2">优化结果</el-radio-button>
        </el-radio-group>
        <div>
          <el-button type="primary" size="mini" round plain>重新预测</el-button>
          <el-button
            icon="el-icon-search"
            type="primary"
            size="mini"
            round
            plain
          >查询</el-button>
        </div>
      </div>
    </div>
    <div class="conten_box">
      <div v-show="radio1 == '1'">
        <div class="flight">
          航班号：SC4927
        </div>
        <div>
          <div class="title">
            <span style="color:#409EFF">预测分析</span>
          </div>
          <LineCharts :chart-data="chartData" />
        </div>
        <div>
          <div class="title">
            <span style="color:#409EFF">航班列表</span>
          </div>
          <div>
            <el-table
              :data="tableData"
              border
              style="width: 100%"
              :header-cell-style="{ textAlign: 'center' }"
            >
              <el-table-column type="index" label="序号" />
              <el-table-column prop="date" label="离港日期" />
              <el-table-column prop="days" label="距离港天数" />
              <el-table-column prop="layout" label="布局" />
              <el-table-column label="FloatDCP">
                <el-table-column prop="vaule" label="提前天数" />
                <el-table-column prop="vaule1" label="订座数" />
                <el-table-column prop="vaule2" label="去限制订座数" />
                <el-table-column prop="vaule3" label="状态标识" />
              </el-table-column>
              <el-table-column label="FinalDCP">
                <el-table-column prop="vaule4" label="订座数" />
                <el-table-column prop="vaule5" label="去限制订座数" />
                <el-table-column prop="vaule6" label="状态标识" />
              </el-table-column>
              <el-table-column prop="vaule7" label="登机数" />
              <el-table-column prop="vaule8" label="离港标识" />
            </el-table>
          </div>
        </div>
        <div>
          <div class="title">
            <span style="color:#409EFF">模型数据</span>
          </div>
          <div>
            <el-table
              :data="tableData1"
              border
              style="width: 100%"
              :header-cell-style="{ textAlign: 'center' }"
            >
              <el-table-column prop="vaule1" label="模型" />
              <el-table-column prop="vaule2" label="状态" />
              <el-table-column prop="vaule3" label="常数a" />
              <el-table-column prop="vaule4" label="常数b" />
              <el-table-column prop="vaule5" label="标准差" />
              <el-table-column prop="vaule6" label="置信度" />
              <el-table-column prop="vaule7" label="样本数" />
            </el-table>
          </div>
        </div>
      </div>
      <div v-show="radio1 == '2'">
        <div>
          <div class="title">
            <span style="color:#409EFF">模型数据</span>
          </div>
          <div class="flight">
            航班号：SC4927
          </div>
          <div>
            <el-table
              :data="tableData2"
              border
              style="width: 100%"
              :header-cell-style="{ textAlign: 'center' }"
            >
              <el-table-column type="index" label="序号" />
              <el-table-column prop="vaule2" label="离港日期" />
              <el-table-column prop="vaule3" label="距离离港天数" />
              <el-table-column prop="vaule4" label="布局" />
              <el-table-column prop="vaule5" label="订座数" />
              <el-table-column prop="vaule6" label="登机数" />
            </el-table>
          </div>
          <div>
            <el-tabs v-model="activeName" type="card">
              <el-tab-pane label="升舱明细" name="first">
                <el-table
                  :data="tableData3"
                  border
                  style="width: 100%"
                  :header-cell-style="{ textAlign: 'center' }"
                >
                  <el-table-column type="index" label="序号" />
                  <el-table-column prop="vaule2" label="舱位" />
                  <el-table-column prop="vaule3" label="舱位订座数" />
                  <el-table-column prop="vaule4" label="物理布局" />
                  <el-table-column prop="vaule5" label="可达离港数" />
                  <el-table-column prop="vaule6" label="超额需求" />
                  <el-table-column prop="vaule7" label="空余需求" />
                  <el-table-column prop="vaule8" label="虚拟布局" />
                </el-table>
              </el-tab-pane>
              <el-tab-pane label="锁舱明细" name="second">锁舱明细</el-tab-pane>
              <el-tab-pane label="FMOB明细" name="third">FMOB明细</el-tab-pane>
              <el-tab-pane label="线性补仓明细" name="fourth">线性补仓明细</el-tab-pane>
              <el-tab-pane label="自动上传结果" name="end">自动上传结果</el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import LineCharts from './lineCharts'
export default {
  components: {
    LineCharts
  },
  data() {
    return {
      formInline: {},
      chartData: {},
      activeName: 'first',
      radio1: '1',
      formSelect: {
        value1: '测试航线组',
        value2: 'URC Depatures(06:30-07:30)',
        value3: '19',
        value4: '星期一',
        value5: 'TNA-URG',
        value6: '2021-10-25 00:00:00',
        value7: '',
        value8: 'A'
      },
      tableData: [
        {
          date: '2021-04-05',
          days: '-238',
          layout: '174',
          vaule: '0',
          vaule1: '0',
          vaule2: '0.0',
          vaule3: 'AC',
          vaule4: '0',
          vaule5: '0.0',
          vaule6: 'C',
          vaule7: '0',
          vaule8: 'C'
        },
        {
          date: '2021-04-05',
          days: '-238',
          layout: '174',
          vaule: '0',
          vaule1: '0',
          vaule2: '0.0',
          vaule3: 'AC',
          vaule4: '0',
          vaule5: '0.0',
          vaule6: 'C',
          vaule7: '0',
          vaule8: 'C'
        },
        {
          date: '2021-04-05',
          days: '-238',
          layout: '174',
          vaule: '0',
          vaule1: '0',
          vaule2: '0.0',
          vaule3: 'AC',
          vaule4: '0',
          vaule5: '0.0',
          vaule6: 'C',
          vaule7: '0',
          vaule8: 'C'
        }
      ],
      tableData1: [
        {
          vaule1: 'OBK',
          vaule2: 'BAD',
          vaule3: '0.0',
          vaule4: '1.0',
          vaule5: '0.0',
          vaule6: '0',
          vaule7: '0'
        },
        {
          vaule1: 'OBK',
          vaule2: 'BAD',
          vaule3: '0.0',
          vaule4: '1.0',
          vaule5: '0.0',
          vaule6: '0',
          vaule7: '0'
        },
        {
          vaule1: 'OBK',
          vaule2: 'BAD',
          vaule3: '0.0',
          vaule4: '1.0',
          vaule5: '0.0',
          vaule6: '0',
          vaule7: '0'
        }
      ],
      tableData2: [
        {
          vaule2: '2021-04-05',
          vaule3: '-238',
          vaule4: '174',
          vaule5: '10',
          vaule6: '无离港数据'
        },
        {
          vaule2: '2021-04-05',
          vaule3: '-238',
          vaule4: '174',
          vaule5: '10',
          vaule6: '无离港数据'
        },
        {
          vaule2: '2021-04-05',
          vaule3: '-238',
          vaule4: '174',
          vaule5: '10',
          vaule6: '无离港数据'
        }
      ],
      tableData3: [
        {
          vaule8: '8',
          vaule2: 'C',
          vaule3: '0',
          vaule4: '8',
          vaule5: '0',
          vaule6: '0',
          vaule7: '0'
        },
        {
          vaule8: '8',
          vaule2: 'W',
          vaule3: '0',
          vaule4: '8',
          vaule5: '0',
          vaule6: '0',
          vaule7: '0'
        }
      ]
    }
  },
  methods: {
    onGoSet() {
      this.$router.push({
        name: 'AlgorithmManagementRes'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.el-table {
  .el-table__header {
    text-align: center;
  }
  .el-table__body {
    .el-table__row {
      text-align: center !important;
    }
  }
}
.title {
  height: 35px;
  padding: 10px;
  border-left: 1px solid #d8e2e7;
  border: 1px solid #d8e2e7;
  span {
    display: block;
    height: 20px;
    padding-left: 10px;
    font-weight: 600;
    border-left: 4px solid #61bbfc;
    align-items: center;
  }
}
.search_box {
  form {
    padding-top: 10px;
    border: 1px solid #d8e2e7;
  }
  .search_btn {
    display: flex;
    padding: 0 10px;
    justify-content: space-between;
    background: #e1eaed;
    align-items: center;
    height: 50px;
  }
}
.conten_box {
  .flight {
    width: 150px;
    height: 40px;
    background: #f3f9fd;
    text-align: center;
    line-height: 40px;
  }
}
  .title_right{
    display: flex;
    justify-content: flex-end;
  }
</style>
