<template>
  <div class="box">
    <header>竞争航班条件</header>
    <el-form v-model="form" label-width="100px" label-position="left">

      <el-form-item label="对比模式">
        <el-select v-model="form.contrastPattern" style="width:300px" size="mini" placeholder="请选择">
          <el-option v-for="item in form.options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>

      <el-form-item label="航段&航班">
        <span slot="label">
          <span class="span-box">
            <span>航段&航班</span>
            <el-tooltip
              effect="dark"
              placement="right"
            >
              <div slot="content">他航竞争航班根据上方所选航班通过竞争规则已默认匹配，可手动调整。<br>本航班竞争航班默认为上方所选本航班所在航段的其他航班，可手动调整。</div>
              <i class="el-icon-question" style="color: #2bb1f5;" />
            </el-tooltip>
          </span>
        </span>
        <el-select v-model="form.flightSegment" style="width:300px" size="mini" multiple placeholder="请选择">
          <el-option v-for="item in form.options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>

      <el-form-item label="航班始发时间">
        <el-time-select v-model="form.startTime" size="mini" placeholder="00:00" :picker-options="{ start: '00:00', step: '00:15', end: '23:59' }" /> 至
        <el-time-select v-model="form.endTime" size="mini" placeholder="23:59" :picker-options="{ start: '00:00', step: '00:15', end: '23:59' }" />
      </el-form-item>

    </el-form>
  </div>
</template>
<script>

export default {
  components: {

  },
  props: {

    form: {
      type: Object,
      default: function() {
        return {
          options: [{
            value: '选项1',
            label: '黄金糕'
          }, {
            value: '选项2',
            label: '双皮奶'
          }, {
            value: '选项3',
            label: '蚵仔煎'
          }, {
            value: '选项4',
            label: '龙须面'
          }, {
            value: '选项5',
            label: '北京烤鸭'
          }]
        }
      }
    }

  },
  data() {
    return {
    }
  },
  created() {

  }
}
</script>
<style lang="scss" scoped>
.box{
  border: 1px solid #000;
  padding: 20px;
  border-radius: 20px;
  margin-bottom: 20px;
  header{
    margin-bottom: 20px;
  }
}
::v-deep .el-form-item{
  margin-bottom: 10px;
}
</style>
