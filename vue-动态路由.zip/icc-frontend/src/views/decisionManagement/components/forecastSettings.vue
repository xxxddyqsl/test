<template>
  <div class="forecast">
    <div class="left_table">
      <div v-for="(item, index) of list" :key="index" class="left_table_item">
        {{ item }}
      </div>
    </div>
    <div class="right_table">
      <el-checkbox-group v-model="checkList" class="checkList2">
        <el-checkbox label="AKU-XIY/TAO" />
        <el-checkbox label="TAO Departures(18:00-19:00)" />
        <el-checkbox label="AKU-TAO" />
        <el-checkbox label="XIY Departures(01:05-02:05)" />
      </el-checkbox-group>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Forecast',
  data() {
    return {
      list: [
        '东北地区',
        '华东地区',
        '北京地区',
        'XMNKWE测试组',
        'XMNHGH测试组',
        '测试航线组'
      ],
      checkList: [],
      checkList2: []
    }
  }
}
</script>

<style lang="scss" scoped>
.forecast {
  width: 100%;
  display: flex;
  background: #f2fafe;
  .left_table {
    width: 33%;
  }
  .right_table {
    padding: 40px 50px;
    flex: 1;
    .checkList2 {
      .el-checkbox{
        width: 45%;
        margin-bottom: 20px;
      }
    }
  }
}
.left_table_item {
  width: 100%;
  height: 36px;
  text-align: left;
  padding-left: 80px;
  box-sizing: border-box;
  line-height: 36px;
  background: #fff;
  box-shadow: #fff;
  margin-bottom: 5px;
}
</style>
