<template>
  <div class="box">
    <header>机型参数条件</header>
    <el-form v-model="form" label-width="100px" label-position="left">

      <el-form-item label="是否生效">
        <el-radio v-model="form.radio" label="1">生效</el-radio>
        <el-radio v-model="form.radio" label="2">不生效</el-radio>
      </el-form-item>

      <el-form-item label="机型">
        <el-select v-model="form.flightSegment" style="width:300px" size="mini" multiple placeholder="请选择">
          <el-option v-for="item in form.options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-select v-model="form.flightSegment" style="width:300px" size="mini" multiple placeholder="请选择">
          <el-option v-for="item in form.options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>

    </el-form>
  </div>
</template>
<script>

export default {
  components: {

  },
  props: {

    form: {
      type: Object,
      default: function() {
        return {
          radio: '1',
          options: [{
            value: '选项1',
            label: '黄金糕'
          }, {
            value: '选项2',
            label: '双皮奶'
          }, {
            value: '选项3',
            label: '蚵仔煎'
          }, {
            value: '选项4',
            label: '龙须面'
          }, {
            value: '选项5',
            label: '北京烤鸭'
          }]
        }
      }
    }

  },
  data() {
    return {
    }
  },
  created() {

  }
}
</script>
<style lang="scss" scoped>
.box{
  border: 1px solid #000;
  padding: 20px;
  border-radius: 20px;
  margin-bottom: 20px;
  header{
    margin-bottom: 20px;
  }
}
::v-deep .el-form-item{
  margin-bottom: 10px;
}
</style>
