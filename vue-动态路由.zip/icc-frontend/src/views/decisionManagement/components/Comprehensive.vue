<template>
  <!-- 预测参数 -->
  <div class="box">
    <el-form v-model="form" label-width="100px" label-position="left">
      <el-form-item label="航班起飞日期" prop="flightDate">
        <el-date-picker
          v-model="form.flightDate"
          size="mini"
          type="date"
          placeholder="选择日期"
        />
      </el-form-item>

      <el-form-item v-if="show" label="在航班起飞前">
        <el-input v-model="form.startTime" size="mini" style="width:100px" /> 至
        <el-input v-model="form.endTime" size="mini" style="width:100px" /> 天
        生效
      </el-form-item>

      <el-form-item label="规则可用日期" prop="ruleDate">
        <el-date-picker
          v-model="form.ruleDate"
          size="mini"
          type="date"
          placeholder="选择日期"
        />
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  components: {},
  props: {
    form: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      show: false
    };
  },
  created() {
    // 有-true---- 起飞日期，客座率，根据客座率设定配额，根据客座率调档，比舱，实时比价，超售，根据机型调舱
    // 无-false---- 特定日期舱位调整，特定日期设定配额，两舱倒挂，两舱优化
    const { name } = this.$route.query;
    // eslint-disable-next-line eqeqeq
    if (
      name == "两舱优化" ||
      name == "两舱倒挂" ||
      name == "特定日期舱位调整" ||
      name == "特定日期设定配额"
    ) {
      this.show = false;
    } else {
      this.show = true;
    }
  }
};
</script>
<style lang="scss" scoped>
.box {
  // border: 1px solid #000;
  // padding: 20px;
  // border-radius: 20px;
  // margin-bottom: 20px;
  header {
    margin-bottom: 20px;
  }
}
::v-deep .el-form-item {
  margin-bottom: 0;
}
</style>
