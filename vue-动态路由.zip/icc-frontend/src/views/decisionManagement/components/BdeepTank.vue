<template>
  <!-- 预测参数 -->
  <div class="box">
    <List :list="mfsc" title="免费升舱" small />
    <List :list="hccs" title="混舱参数" small />
    <List :list="cscs" title="超售参数" small />
  </div>
</template>
<script>
import List from './List.vue'
export default {
  components: {
    List
  },
  data() {
    return {
      mfsc: [
        { type: 'input', key: '非正常销售舱级', value: 'ABCDEFT' },
        { type: 'radio', key: '非正常销售舱级保护数为0', value: '否', radioList: [{ label: '是', value: '是' }, { label: '否', value: '否' }] }
      ],
      hccs: [
        { type: 'radio', key: 'EMSR逻辑', value: 'PartitionedA', radioList: [{ label: 'NestedA', value: 'NestedA' }, { label: 'PartitionedA', value: 'PartitionedA' }, { label: 'EMSRb', value: 'EMSRb' }] },
        { type: 'radio', key: '无价值座位分配方式', value: '全部分配到最低舱级', radioList: [{ label: '全部分配到最低舱级', value: '全部分配到最低舱级' }, { label: '由低到高平均分配', value: '由低到高平均分配' }, { label: '按比例分配', value: '按比例分配' }] },
        { type: 'input', key: '混舱超售迭代最大次数', value: '5' },
        { type: 'input', key: '无效EMSR绝对最小值', value: '40' },
        { type: 'input', key: '计算无效EMSR的平均票价百分比', value: '10' },
        { type: 'input', key: '舱级订座最大值', value: '999' }
      ],
      cscs: [
        { type: 'radio', key: '舱位ShowRate计算用EMSR计数为权重(超售)', value: '是', radioList: [{ label: '是', value: '是' }, { label: '否', value: '否' }] },
        { type: 'input', key: '等级率计算最小样本数', value: '3' },
        { type: 'input', key: '误差乘子', value: '80' },
        { type: 'input', key: '登机率', value: '95' }
      ]

    }
  },
  created() {
  }
}
</script>
<style lang="scss" scoped>

</style>
