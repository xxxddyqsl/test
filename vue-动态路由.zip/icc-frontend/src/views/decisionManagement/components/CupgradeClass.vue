<template>
  <!-- 升舱与锁舱参数 -->
  <div class="box">
    <List :list="top" title="升舱参数" small margin />
    <el-table
      :data="tableData"
      border
      style="width: 100%;margin: 20px 0"
      :header-cell-style="{'text-align':'center','backgroundColor':'rgb(246, 251, 252)'}"
    >
      <el-table-column
        prop="type"
        label=""
        width="180"
        align="center"
      />
      <el-table-column label="C">
        <template slot-scope="scope">
          <el-input v-model="scope.row.C" />
        </template>
      </el-table-column>
      <el-table-column label="W">
        <template slot-scope="scope">
          <el-input v-model="scope.row.W" />
        </template>
      </el-table-column>
      <el-table-column label="Y">
        <template slot-scope="scope">
          <el-input v-model="scope.row.Y" />
        </template>
      </el-table-column>
    </el-table>
    <List :list="bottom" title="锁仓参数" small margin lang />
  </div>
</template>
<script>
import List from './List.vue'

export default {
  components: {
    List
  },
  data() {
    return {
      top: [
        { type: 'input', key: '超额需求乘子', value: '5' },
        { type: 'input', key: '最小顶座因子', value: '5' },
        { type: 'input', key: '空余需求乘子', value: '2' }
      ],
      bottom: [
        { type: 'radio', key: '非正常销售舱级保护数为0', value: '是', radioList: [{ label: '是', value: '是' }, { label: '否', value: '否' }] }
      ],
      tableData: [
        {
          type: '最小增量',
          C: '3',
          Y: '3',
          W: '6'
        },
        {
          type: '最小减量',
          C: '4',
          Y: '6',
          W: '5'
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
