<template>

  <el-form v-model="form" label-width="100px" label-position="left">
    <div v-for="(v,i) in form.children" :key="i">
      <div class="box StrategyAdjustment">
        <header>
          调整策略
          <el-button
            v-if="i>0"
            style="padding-top: 5px;padding-bottom: 5px;"
            size="small"
            type="primary"
            icon="el-icon-minus"
            @click="dele(i)"
          />
          <el-button
            v-if="isAdd"
            style="padding-top: 5px;padding-bottom: 5px;"
            size="small"
            type="primary"
            icon="el-icon-plus"
            @click="copy()"
          />
        </header>
        <el-form-item
          v-if="$route.query.name == '起飞日期' || $route.query.name == '特定日期舱位调整' || $route.query.name == '特定日期设定配额'|| $route.query.name == '客座率'|| $route.query.name == '根据客座率设定配额' || $route.query.name == '根据机型调舱'"
          label="舱位"
        >
          <el-checkbox>F</el-checkbox>
          <el-checkbox>A</el-checkbox><p />
          <el-checkbox>U</el-checkbox><p />

          <el-checkbox>J</el-checkbox>
          <el-checkbox>C</el-checkbox>
          <el-checkbox>D</el-checkbox>
          <el-checkbox>Q</el-checkbox>
          <el-checkbox>I</el-checkbox>
          <el-checkbox>O</el-checkbox><p />

          <el-checkbox>W</el-checkbox>
          <el-checkbox>P</el-checkbox><p />

          <el-checkbox>Y</el-checkbox>
          <el-checkbox>B</el-checkbox>
          <el-checkbox>M</el-checkbox>
          <el-checkbox>E</el-checkbox>
          <el-checkbox>H</el-checkbox>
          <el-checkbox>K</el-checkbox><p />
          <el-checkbox>L</el-checkbox>
          <el-checkbox>N</el-checkbox>
          <el-checkbox>R</el-checkbox>
          <el-checkbox>S</el-checkbox>
          <el-checkbox>V</el-checkbox><p />
          <el-checkbox>T</el-checkbox>
          <el-checkbox>G</el-checkbox>
          <el-checkbox>Z</el-checkbox>
          <el-checkbox>X</el-checkbox><p />

        </el-form-item>

        <el-form-item
          v-if="$route.query.name == '根据机型调舱'"
          label="机型"
        >
          <el-select v-model="v.jx" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>

        <el-form-item
          v-if="$route.query.name == '起飞日期' ||$route.query.name == '特定日期舱位调整' ||$route.query.name == '客座率' ||$route.query.name == '根据机型调舱' ||$route.query.name == '两舱倒挂' "
          label="调整操作"
        >
          <el-select v-model="v.flightSegment" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>

        <el-form-item
          v-if="$route.query.name == '根据机型调舱' || $route.query.name == '起飞日期' || $route.query.name == '特定日期舱位调整' "
          label="调整时间"
        >
          <el-time-select v-model="v.startTime" size="mini" placeholder="00:00" :picker-options="{ start: '00:00', step: '00:15', end: '23:59' }" />
        </el-form-item>

        <!-- 根据客座率设定配额 -->
        <el-form-item v-if="$route.query.name == '特定日期设定配额' || $route.query.name == '根据客座率设定配额' " label="舱位配额">
          在原有配额上
          <el-select v-model="v.value" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options1" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          比率
          <el-input v-model="v.bilv" size="mini" style="width:100px" /> %
          绝对值
          <el-input v-model="v.jueduizhi" size="mini" style="width:100px" /> 个

        </el-form-item>

        <el-form-item v-if="$route.query.name == '特定日期设定配额' || $route.query.name == '根据客座率设定配额' " label="舱位配额 ">
          设为
          <el-input v-model="v.shewei" size="mini" style="width:100px" /> 个
        </el-form-item>

        <el-form-item v-if="$route.query.name == '特定日期设定配额' || $route.query.name == '根据客座率设定配额' " label="最大配额">
          比例
          <el-input v-model="v.bili" size="mini" style="width:100px" /> %
        </el-form-item>

        <!-- 根据客座率调档 -->
        <el-form-item v-if="$route.query.name == '根据客座率调档' " label="舱位调档">
          在原档位提高
          <el-input v-model="v.ydw" size="mini" style="width:100px" /> 个档
        </el-form-item>

        <el-form-item v-if="$route.query.name == '根据客座率调档' " label="调档上限">
          <el-select v-model="v.tdsx" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options2" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>

        <!-- 比舱 -->
        <el-form-item v-if="$route.query.name == '比舱'" label="外放舱位最低折扣率" label-width="150px">
          <span slot="label">
            <span class="span-box">
              <span>外放舱位最低价</span>
              <el-tooltip
                effect="dark"
                placement="right"
              >
                <div slot="content">外放舱位最低折扣率处，如果选择“忽略”，程序不会去参考共飞的最低舱位，直接放到您设置的最低折扣率；
                  <br>
                  如果您是想本航外放舱位最低折扣率和外航最低折扣率持平，建议选择“高于”或者“低于”外航0个点。
                </div>
                <i class="el-icon-question" style="color: #2bb1f5;" />
              </el-tooltip>
            </span>
          </span>
          <el-select v-model="v.value" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options3" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          竞争航班
          <el-input v-model="v.jzhb" size="mini" style="width:100px" /> 个点
        </el-form-item>

        <el-form-item v-if="$route.query.name == '比舱'" label="外放舱位最低折扣率" label-width="150px">
          <el-input v-model="v.zdzkl" size="mini" style="width:100px" /> %
        </el-form-item>

        <!-- 实时比价 -->
        <el-form-item v-if="$route.query.name == '实时比价' " label="外放舱位最低价" label-width="150px">
          <span slot="label">
            <span class="span-box">
              <span>外放舱位最低价</span>
              <el-tooltip
                effect="dark"
                placement="right"
              >
                <div slot="content">外放舱位最低价，如果选择“忽略”，程序不会去参考共飞的最低价，直接放到您设备的最低价；
                  <br>
                  如果您是想本舱外放舱位最低价和外舱最低价持平，建议选择“高位”或者“低于”外航0元。
                </div>
                <i class="el-icon-question" style="color: #2bb1f5;" />
              </el-tooltip>
            </span>
          </span>
          <el-select v-model="v.value" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options4" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          竞争航班
          <el-input v-model="v.jzhb" size="mini" style="width:100px" /> 个点
        </el-form-item>

        <el-form-item v-if="$route.query.name == '实时比价' " label="外放舱位最低价" label-width="150px">
          <el-input v-model="v.zdzkl" size="mini" style="width:100px" /> 元
        </el-form-item>

        <!-- 超售 -->
        <el-form-item v-if="$route.query.name == '超售'" label="超售上限">
          <span slot="label">
            <span class="span-box">
              <span>超售上限</span>
              <el-tooltip
                effect="dark"
                placement="right"
              >
                <div slot="content">超售仅针对经济舱。</div>
                <i class="el-icon-question" style="color: #2bb1f5;" />
              </el-tooltip>
            </span>
          </span>
          比率
          <el-input v-model="v.bilv" size="mini" style="width:100px" /> %
          绝对值
          <el-input v-model="v.jueduizhi" size="mini" style="width:100px" /> 个
        </el-form-item>

        <!-- 两舱优化 -->
        <el-form-item v-if="$route.query.name == '两舱优化' " label="外放两舱价格不低于" label-width="150px">
          <el-select v-model="v.value" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options4" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>价格
        </el-form-item>
        <el-form-item v-if="$route.query.name == '两舱优化' " label="外放两舱价格不高于" label-width="150px">
          <el-select v-model="v.value" size="mini" placeholder="请选择">
            <el-option v-for="item in v.options4" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>价格
        </el-form-item>
      </div>
    </div>

  </el-form>

</template>
<script>
export default {
  components: {

  },
  props: {

    form: {
      type: Object,
      default: function() {
        return {
          children: [
            {
              options: [{
                value: '开放',
                label: '开放'
              }, {
                value: '关闭',
                label: '关闭'
              }],
              options1: [{
                value: '增加',
                label: '增加'
              }, {
                value: '减少',
                label: '减少'
              }],
              options2: [{
                value: '1',
                label: '1'
              }, {
                value: '2',
                label: '2'
              }, {
                value: '3',
                label: '3'
              }],
              options3: [{
                value: '高于',
                label: '高于'
              }, {
                value: '低于',
                label: '低于'
              }, {
                value: '忽略',
                label: '忽略'
              }],
              options4: [{
                value: '高于',
                label: '高于'
              }, {
                value: '低于',
                label: '低于'
              }, {
                value: '忽略',
                label: '忽略'
              }]
            }
          ]

        }
      }
    }

  },
  data() {
    return {
      isAdd: true
    }
  },
  created() {
    const { name: type } = this.$route.query
    // eslint-disable-next-line eqeqeq
    if (type == '根据客座率调档' || type == '比舱' || type == '实时比价' || type == '超售' || type == '两舱倒挂' || type == '两舱优化') {
      this.isAdd = false
    }
  },
  methods: {
    dele(i) {
      this.form.children.splice(i, 1)
    },
    copy() {
      console.log(this.form)
      this.form.children.push({
        options: [{
          value: '开放',
          label: '开放'
        }, {
          value: '关闭',
          label: '关闭'
        }],
        options1: [{
          value: '增加',
          label: '增加'
        }, {
          value: '减少',
          label: '减少'
        }],
        options2: [{
          value: '1',
          label: '1'
        }, {
          value: '2',
          label: '2'
        }, {
          value: '3',
          label: '3'
        }],
        options3: [{
          value: '高于',
          label: '高于'
        }, {
          value: '低于',
          label: '低于'
        }, {
          value: '忽略',
          label: '忽略'
        }],
        options4: [{
          value: '高于',
          label: '高于'
        }, {
          value: '低于',
          label: '低于'
        }, {
          value: '忽略',
          label: '忽略'
        }]
      })
      this.$message({
        message: '复制成功',
        type: 'success'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.box{
  border: 1px solid #000;
  padding: 20px;
  border-radius: 20px;
  margin-bottom: 20px;
  header{
    margin-bottom: 20px;
  }
}
::v-deep .el-form-item{
  margin-bottom: 10px;
}
::v-deep .el-form-item__label{
  line-height: 25px;
}
::v-deep .el-form-item__content{
  line-height: 20px;
}

::v-deep .el-checkbox{
  height: 20px;
  line-height: 20px;
  margin-top: -10px;
  margin-right: 10px;
  min-width: 40px;
}
p{
  margin: 0;
}
</style>
