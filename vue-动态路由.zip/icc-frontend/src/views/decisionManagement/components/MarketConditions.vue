<template>

  <div class="box">
    <h3>市场条件</h3>
    <div class="partOne">
      <span>市场占有率范围:</span>
      <div class="one">
        <el-input
          v-model="input1"
          placeholder=""
        />
        <div>% 至&nbsp;&nbsp;</div>
      </div>
      <div class="one">
        <el-input
          v-model="input2"
          placeholder=""
        /> <span> %</span>
      </div>
    </div>
    <!-- <div class="partOne">
      <span>{{ titleTop }}:</span>
      <div class="one">
        <el-input
          v-model="input1"
          placeholder=""
        />
        <div>% 至&nbsp;&nbsp;</div>
      </div>
      <div class="one">
        <el-input
          v-model="input2"
          placeholder=""
        /> <span> %</span>
      </div>
    </div>
    <div class="partTwo">
      <span class="spa">{{ titleBottom }}:</span>
      <div class="Two">
        <el-select
          v-model="serviceType"
          placeholder="请选择"
          @change="changeServiceClick"
        >
          <el-option
            v-for="item in options"
            :key="item.Id"
            :label="item.Name"
            :value="item.Id"
          />
        </el-select>
        <span class="span">竞争航班</span>
      </div>
      <div class="Two">
        <el-input
          v-model="input3"
          placeholder=""
        />
        <div>% 至&nbsp;&nbsp;</div>
      </div>
      <div class="Two">
        <el-input
          v-model="input4"
          placeholder=""
        />
        <div>%</div>
      </div>
    </div> -->
  </div>
</template>

<script>
export default {
  name: 'MarketConditions',
  props: {
    titleTop: {
      type: String,
      default: '客座率范围'
    },
    titleBottom: {
      type: String,
      default: '客座率差'
    },
    service: {
      type: String,
      default: ''
    },
    input1: {
      type: String,
      default: ''
    },
    input2: {
      type: String,
      default: ''
    },
    input3: {
      type: String,
      default: ''
    },
    input4: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      options: [{ Id: 1, Name: '高于' }, { Id: 2, Name: '低于' }, { Id: 3, Name: '忽略' }],
      serviceType: this.service
    }
  },
  watch: {
    service: {
      handler: function(ee) {
        this.serviceType = ee
        console.log(ee)
      },
      deep: true
    }
  },
  methods: {
    changeServiceClick(e) {
      console.log(e)
      this.$emit('changeServiceClick', e)
    }
  }
}
</script>

<style lang="scss" scoped>
.box {
  width: 100%;
  // height: 20%;
  border: 1px solid #000;
    padding: 20px;
    border-radius: 20px;
    margin-bottom: 20px;
  .partOne {
    display: flex;
    // justify-content: space-between;
    align-items: center;
    span {
      width: 120px;
    }
    .one {
      display: flex;
      // justify-content: space-between;
      align-items: center;
      .el-input {
        width: 160px;
      }

    }
  }
  .partTwo {
    margin-top: 10px;
    display: flex;
    align-items: center;
    span {
      width: 10%;
    }
    .Two {
      display: flex;
      align-items: center;
      .el-input {
         width: 160px;
      }
        .el-select{
        width: 160px;
      }
      .span{
        margin-left: 5px;
        width: 70px;
      }
    }
  }
}
</style>
