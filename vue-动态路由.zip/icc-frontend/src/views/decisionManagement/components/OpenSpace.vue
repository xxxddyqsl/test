<template>
  <div class="box">
    <header>舱位开放条件</header>
    <el-form v-model="form" label-position="left">

      <el-form-item>
        <el-checkbox>F</el-checkbox>
        <el-checkbox>A</el-checkbox><br>
        <el-checkbox>U</el-checkbox><br>

        <el-checkbox>J</el-checkbox>
        <el-checkbox>C</el-checkbox>
        <el-checkbox>D</el-checkbox>
        <el-checkbox>Q</el-checkbox>
        <el-checkbox>I</el-checkbox>
        <el-checkbox>O</el-checkbox><br>

        <el-checkbox>W</el-checkbox>
        <el-checkbox>P</el-checkbox><br>

        <el-checkbox>Y</el-checkbox>
        <el-checkbox>B</el-checkbox>
        <el-checkbox>M</el-checkbox>
        <el-checkbox>E</el-checkbox>
        <el-checkbox>H</el-checkbox>
        <el-checkbox>K</el-checkbox><br>
        <el-checkbox>L</el-checkbox>
        <el-checkbox>N</el-checkbox>
        <el-checkbox>R</el-checkbox>
        <el-checkbox>S</el-checkbox>
        <el-checkbox>V</el-checkbox><br>
        <el-checkbox>T</el-checkbox>
        <el-checkbox>G</el-checkbox>
        <el-checkbox>Z</el-checkbox>
        <el-checkbox>X</el-checkbox><br>

      </el-form-item>

    </el-form>
  </div>
</template>
<script>

export default {
  components: {

  },
  props: {

    form: {
      type: Object,
      default: function() {
        return {
          options: [{
            value: '选项1',
            label: '黄金糕'
          }, {
            value: '选项2',
            label: '双皮奶'
          }, {
            value: '选项3',
            label: '蚵仔煎'
          }, {
            value: '选项4',
            label: '龙须面'
          }, {
            value: '选项5',
            label: '北京烤鸭'
          }]
        }
      }
    }

  },
  data() {
    return {
    }
  },
  created() {

  }
}
</script>
<style lang="scss" scoped>
.box{
  border: 1px solid #000;
  padding: 20px;
  border-radius: 20px;
  margin-bottom: 20px;
  header{
    margin-bottom: 20px;
  }
}
::v-deep .el-form-item{
  margin-bottom: 10px;
}
</style>
