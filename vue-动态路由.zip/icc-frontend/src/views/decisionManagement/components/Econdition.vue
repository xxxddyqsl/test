<template>
  <!-- 影响条件管理 -->
  <div>
    <div class="top">
      <div class="left">
        <header class="margin"><span class="title">影响条件管理</span></header>
        <div class="search">
          <el-form ref="ruleForm" :model="ruleForm" :inline="true" :rules="rules" class="demo-ruleForm">
            <el-form-item label="名称:" prop="name">
              <el-input v-model="ruleForm.name" />
            </el-form-item>
            <el-form-item label="类型:" prop="type">
              <el-select v-model="ruleForm.type" placeholder="请选择类型">
                <el-option label="区域一" value="shanghai" />
                <el-option label="区域二" value="beijing" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <span class="operation">| <i class="el-icon-search" />查询</span>
              <span class="operation">| <i class="el-icon-plus" />新增</span>
              <span class="operation">| <i class="el-icon-edit" />修改</span>
              <span class="operation">| <i class="el-icon-delete" />删除</span>
            </el-form-item>
          </el-form>
        </div>
        <el-table
          :data="tableData"
          border
          style="width: 100%"
        >
          <el-table-column
            prop="name"
            label="名称"
          />
          <el-table-column
            prop="cjr"
            label="创建人"
          />
          <el-table-column
            prop="zhxgr"
            label="最后修改人"
          />
          <el-table-column
            prop="cjrq"
            label="创建日期"
          />
          <el-table-column
            prop="zhxgrq"
            label="最后修改日"
          />
        </el-table>
        <h1 />
        <h1 />
        <h1 />
        <h1 />
        <el-pagination
          :page-sizes="[100, 200, 300, 400]"
          :page-size="100"
          layout="total, sizes, prev, pager, next, jumper"
          :total="1400"
        />
      </div>
      <div class="right">
        <header class="margin"><span class="operations">工作组/航线组/预测组</span></header>
        <el-tree
          :data="data"
          node-key="id"
          show-checkbox
        />
      </div>
    </div>

    <div class="conter">

      <header class="margin"><span class="title">关联展示</span></header>
      <el-table
        :data="tableDatac"
        height="150"
        border
        style="width: 100%"
      />
      <el-pagination
        :page-sizes="[10, 20, 30, 40]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="200"
      />
    </div>

    <div class="bottom">
      <header class="margin"><span class="title">航班信息</span></header>
      <el-table
        :data="tableDatab"
        height="150"
        border
        style="width: 100%"
      />
      <el-pagination
        :page-sizes="[50, 100, 150, 200]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400"
      />
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      data: [{
        label: '华北地区',
        children: [{
          label: '二级 1-1'
        }]
      }, {
        label: '华东地区',
        children: [{
          label: '二级 2-1'

        }, {
          label: '二级 2-2'

        }]
      },
      {
        label: '北京地区',
        children: [{
          label: '二级 3-1'

        }, {
          label: '二级 3-2'

        }]
      },
      {
        label: 'SSSXXX测试组',
        children: [{
          label: '二级 3-1'

        }, {
          label: '二级 3-2'

        }]
      },
      {
        label: 'EESQVX测试组',
        children: [{
          label: '二级 3-1',
          children: [{
            label: '三级 3-1-1'
          }]
        }, {
          label: '二级 3-2',
          children: [{
            label: '三级 3-2-1'
          }]
        }]
      },
      {
        label: '测试航线组',
        children: [{
          label: '二级 3-1',
          children: [{
            label: '三级 3-1-1'
          }]
        }, {
          label: '二级 3-2',
          children: [{
            label: '三级 3-2-1'
          }]
        }]
      }
      ],
      ruleForm: {
        name: '',
        type: ''
      },
      rules: {
        type: [
          { required: true, message: '请选择活动区域', trigger: 'change' }
        ]
      },
      tableData: [
        {
          name: 'AUT-HGG',
          chr: 'admin',
          zhxgr: 'amin',
          cjri: '20210706 09:52:12',
          zhxgrq: '20210706 19:52:12'
        },
        {
          name: 'BUT-HYG',
          chr: 'admin',
          zhxgr: 'amin',
          cjri: '20210706 19:52:12',
          zhxgrq: '20210706 09:52:12'
        }
      ],
      tableDatac: [],
      tableDatab: []
    }
  }
}
</script>
<style lang="scss" scoped>
header{
  width: 100%;
  border: 1px solid #eee;
  margin: 0;
  color: #409EFF;
  font-weight: 600;
  height: 40px;
  line-height: 40px;
  font-size: 14px;
  padding-left: 20px;
  border-radius: 5px;
  position: relative;
  &::before{
    content: " ";
    display: block;
    width: 5px;
    height: 100%;
    background-color: #409EFF;
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    position: absolute;
    top: 0;
    left: 0;
  }
  &.margin{
    border-bottom: none;
     border-bottom-left-radius: 0px;
    background-color: #fff;
    &::before{
      border-radius: 0;
      height: 70%;
      width: 3px;
      top: 5px;
      left: 10px;
    }
  }

}
.top{
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  border: 1px solid #eee;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  .left{
    width: 80%;
    header{
      border: none;
      border-bottom: 1px solid #eee;
      border-top-right-radius: 0;
      border-bottom-right-radius: 0;
    }
    .el-form{
      display: flex;
      justify-content: space-between;
      .el-form-item{
        height: 25px;
        margin: 10px;
        margin-bottom: 20px;
        .el-input{
          height: 25px !important;

        }
        >>> .el-input__inner{
            height: 25px !important;
        }
        span{
          cursor: pointer;
        }
      }
    }
  }
  .right{
    width: 29%;
    border-left: 1px solid #eee;
     background-color: rgb(246, 251, 252);
    header{
      border: none;
      border-bottom-right-radius: 0;
      border-top-left-radius: 0;
      border-bottom: 1px solid #eee;
    }
    .el-tree{
      background-color: rgb(246, 251, 252);
    }
  }
}
.conter, .bottom{
  header{
    border: none;
  }
  border: 1px solid #eee;
  margin-top: 15px;
  margin-bottom: 15px;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}

</style>
