<template>
  <!-- 预测组织管理 -->
  <div class="box">
    <div>
      <header>
        <span class="title">预测组</span>
        <span class="operations"><i class="el-icon-plus" />添加工作组</span>
      </header>
      <div class="tree">
        <el-tree
          :data="data"
          node-key="id"
          :expand-on-click-node="false"
          :render-content="renderContent"
        />
      </div>
    </div>
    <h1 />
    <div>
      <header>
        <span class="title">借用关系</span>
        <div class="operations">
          <span class=""><i class="el-icon-plus" />新增</span>
          <span class=""><i class="el-icon-edit" />修改</span>
          <span class="delete"><i class="el-icon-delete" />删除</span>
        </div>
      </header>

      <el-table v-loading="loading" :data="tableData" border style="width: 100%;border-top:none" row-key="id" stripe :header-cell-style="{'text-align':'center','backgroundColor':'rgb(246, 251, 252)'}">
        <el-table-column v-for="(planItem, index) in planList" :key="index" align="center" :label="planItem.planLable">
          <el-table-column v-for="(stageItem, indexChild) in planItem.stageList" :key="index+'-'+indexChild" align="center" :label="stageItem.stageLable">
            <template slot-scope="scope">
              <span>{{ scope.row.planList[index].stageList[indexChild].value }}</span>
            </template>
          </el-table-column>
        </el-table-column>
      </el-table>

    </div>
  </div>
</template>
<script>
const id = 1000
export default {
  components: {
  },
  data() {
    return {
      loading: false,
      // 表格组件 列表数据对象
      tableData: [],
      planList: [],
      data: [{
        label: '华北地区',
        children: [{
          label: '二级 1-1'
        }]
      }, {
        label: '华东地区',
        children: [{
          label: '二级 2-1'

        }, {
          label: '二级 2-2'

        }]
      },
      {
        label: '北京地区',
        children: [{
          label: '二级 3-1'

        }, {
          label: '二级 3-2'

        }]
      },
      {
        label: 'SSSXXX测试组',
        children: [{
          label: '二级 3-1'

        }, {
          label: '二级 3-2'

        }]
      },
      {
        label: 'EESQVX测试组',
        children: [{
          label: '二级 3-1',
          children: [{
            label: '三级 3-1-1'
          }]
        }, {
          label: '二级 3-2',
          children: [{
            label: '三级 3-2-1'
          }]
        }]
      },
      {
        label: '测试航线组',
        children: [{
          label: '二级 3-1',
          children: [{
            label: '三级 3-1-1'
          }]
        }, {
          label: '二级 3-2',
          children: [{
            label: '三级 3-2-1'
          }]
        }]
      }
      ]
    }
  },
  created() {
    this.initData()
  },
  methods: {
    /**
     * @method initData
     * @description 初始化数据
     */
    initData() {
      this.getList()
    },
    /**
     * @description 获取列表
     * @method getList
     */
    getList() {
      const list = [
        {
          planList: [
            {
              planLable: '借出方',
              stageList: [
                { stageLable: '航段', value: 'AKU-XIY' },
                { stageLable: '预测组', value: '200' },
                { stageLable: '航班', value: '300' },
                { stageLable: 'Holiday', value: '春节' },
                { stageLable: '舱位', value: 'A' },
                { stageLable: '数据池', value: '' }

              ]
            },
            {
              planLable: '借用方',
              stageList: [
                { stageLable: '航段', value: 'AKU-XIY' },
                { stageLable: '预测组', value: '20' },
                { stageLable: '航班', value: '30' },
                { stageLable: 'Holiday', value: '春节' },
                { stageLable: '舱位', value: 'G' },
                { stageLable: '数据池', value: '0' }

              ]
            }
          ]
        },
        {
          planList: [
            {
              planLable: '借出方',
              stageList: [
                { stageLable: '航段', value: 'TAO-PEK' },
                { stageLable: '预测组', value: '2001' },
                { stageLable: '航班', value: '3001' },
                { stageLable: 'Holiday', value: '元宵节' },
                { stageLable: '舱位', value: 'F' },
                { stageLable: '数据池', value: '1' }

              ]
            },
            {
              planLable: '借用方',
              stageList: [
                { stageLable: '航段', value: 'TAO-PEK' },
                { stageLable: '预测组', value: '201' },
                { stageLable: '航班', value: '301' },
                { stageLable: 'Holiday', value: '' },
                { stageLable: '舱位', value: 'C' },
                { stageLable: '数据池', value: '2' }

              ]
            }
          ]
        },
        {
          planList: [
            {
              planLable: '借出方',
              stageList: [
                { stageLable: '航段', value: 'AKU-XIY3' },
                { stageLable: '预测组', value: '2001' },
                { stageLable: '航班', value: '3001' },
                { stageLable: 'Holiday', value: '' },
                { stageLable: '舱位', value: 'F' },
                { stageLable: '数据池', value: '1' }

              ]
            },
            {
              planLable: '借用方',
              stageList: [
                { stageLable: '航段', value: 'AKU-XIY3' },
                { stageLable: '预测组', value: '201' },
                { stageLable: '航班', value: '301' },
                { stageLable: 'Holiday', value: '元宵节' },
                { stageLable: '舱位', value: 'C' },
                { stageLable: '数据池', value: '2' }

              ]
            }
          ]
        }
      ]
      //   拿到列表数据
      this.tableData = list
      this.planList = (list[0] && list[0]['planList']) || []
      console.log(this.tableData)
    },

    renderContent(h, { node, data, store }) {
      return (
        <span class='custom-tree-node'>
          <span class='title'>{node.label}</span>
          <span class='operation'>
            <el-button size='mini' type='text' on-click={ () => this.append(data) }><i class='el-icon-plus' /></el-button>
            <el-button size='mini' type='text' on-click={ () => this.amend(data)} ><i class='el-icon-edit' /></el-button>
            <el-button size='mini' type='text' on-click={ () => this.remove(node, data) }><i class='el-icon-minus'/></el-button>
          </span>
        </span>)
    },

    append(data) {
      console.log('添加', data, id)

      const newChild = { label: data.label + '子集' + Math.ceil(Math.random() * 10), children: [] }
      if (!data.children) {
        this.$set(data, 'children', [])
      }
      data.children.push(newChild)
    },
    amend(data) {
      console.log('修改', data)
    },
    remove(node, data) {
      const parent = node.parent
      const children = parent.data.children || parent.data
      const index = children.findIndex(d => d.$treeNodeId === data.$treeNodeId)
      children.splice(index, 1)
    }

  }
}
</script>
<style lang="scss" scoped>
header{
  width: 100%;
  border: 1px solid #eee;
  margin: 0;
  color: #409EFF;
  font-weight: 600;
  height: 40px;
  background-color: #fff;
  line-height: 40px;
  font-size: 14px;
  padding: 0 20px;
  border-radius: 5px;
  position: relative;
  display: flex;
  justify-content: space-between;
  .operations{
    cursor: pointer;
    color: #409EFF;
    .delete{
        color: red;
    }
    i{
      font-size: 16px;
      font-weight: 900;
      margin-right: 10px;
      margin-left: 20px;
    }
  }
  &::before{
    content: " ";
    display: block;
    width: 5px;
    height: 100%;
    background-color: #409EFF;
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    position: absolute;
    top: 0;
    left: 0;
  }
}
.tree{
  border: 1px solid #eee;
  border-top: none;
  .el-tree{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
  }
}
::v-deep .el-tree-node{
  // width: 24%;
  min-width: 400px;
  margin: 5px;
  background-color: rgb(246, 251, 252);

}
::v-deep .custom-tree-node{
  // border: 1px solid #000;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .operation{
    margin-right: 15px;
    i{
      font-weight: 900;
      font-size: 16px;
    }
  }

}
</style>
