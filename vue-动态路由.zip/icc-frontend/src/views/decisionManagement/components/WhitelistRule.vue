<template>
  <div>
    <el-table :data="list" border>
      <el-table-column prop="flightNo" label="航班号" width="100" />
      <el-table-column prop="flightLeg" label="航段" width="100" />
      <el-table-column prop="whiteListCabinRefList" label="舱位列表">
        <template slot-scope="scope">
          <span v-if="scope.row.whiteListCabinRefList">
            <span v-for="(v,i) in scope.row.whiteListCabinRefList" :key="i">{{ v.code }} &nbsp;</span>
          </span>
        </template>
      </el-table-column>
      <el-table-column label="规则类型">
        <template slot-scope="scope">
          <span v-if="scope.row.whitelistRuleModelRefList.length > 0 ">
            <span v-for="(v, i) in scope.row.whitelistRuleModelRefList" :key="i">
              {{ v.name }}
              <span v-if="v.children">
                (<span v-for="(item, j) in v.children" :key="j">{{ item.name }} <span v-if="j+1 < v.children.length ">、</span> </span>)
              </span>
              <span v-if="i+1 < scope.row.whitelistRuleModelRefList.length ">、</span>
            </span>
          </span>
          <span v-else />
        </template>
      </el-table-column>
      <el-table-column label="航班日期 开始/结束">
        <template slot-scope="scope">
          {{ scope.row.fromDate }} ~ {{ scope.row.toDate }}
        </template>
      </el-table-column>
      <el-table-column label="距离起飞日期 开始/结束">
        <template slot-scope="scope">
          {{ scope.row.fromOffset }} ~ {{ scope.row.toOffset }}
        </template>
      </el-table-column>
      <el-table-column prop="createUser" label="创建用户" width="100" />
      <el-table-column prop="updateTime" label="更新日期" />
      <el-table-column label="操作" width="160">
        <template slot-scope="scope">
          <div>
            <el-button type="primary" size="mini" @click="beRevised(scope.row)">修改</el-button>
            <el-button type="primary" size="mini" @click="deletes(scope.row)">删除</el-button>
          </div>
        </template>

      </el-table-column>
    </el-table>
    <el-pagination background layout="total, prev, pager, next" :total="total" @current-change="chengePage" />

    <el-dialog v-dialogDrag :title="dialogTitle" width="500px" :visible.sync="dialog">
      <el-form ref="task_form_two" :model="dialogForm" :rules="rules" label-width="110px">
        <el-form-item label="起飞日期" prop="data">
          <el-date-picker
            v-model="dialogForm.data"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd HH:mm:ss"
            type="daterange"
            range-separator="至"
            start-placeholder="开始"
            end-placeholder="结束"
            @change="changeData"
          />
        </el-form-item>
        <el-form-item label="距离起飞日期" prop="fromOffset">
          <el-input v-model="dialogForm.fromOffset" style="width:120px" placeholder="" /> -
          <el-input ref="toOffset" v-model="dialogForm.toOffset" style="width:120px" placeholder="" /> 天
        </el-form-item>
        <el-form-item label="航班" prop="flightNo">
          <el-cascader ref="flightNo" v-model="dialogForm.flightNo" :props="flightListProps" :show-all-levels="false" :options="flightList" clearable collapse-tags />
        </el-form-item>
        <el-form-item label="舱位" prop="whiteListCabinRefList">
          <el-select v-model="dialogForm.whiteListCabinRefList" multiple placeholder="请选择舱位">
            <el-option v-for="item in cabintList" :key="item.cabinId" :value="item.cabinId" :label="item.cabinCode" />
          </el-select>
        </el-form-item>
        <el-form-item label="规则类型" prop="whitelistRuleModelRefList">
          <el-cascader v-model="dialogForm.whitelistRuleModelRefList" :props="whitelistRuleModelRefProps" :show-all-levels="false" :options="RuleModelRefList" clearable collapse-tags />
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button style="margin:0 5px" @click="callOff">取 消</el-button>
        <el-button style="margin:0 5px" type="primary" @click="makeSure">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { getList, deletesSet, getRuleModelRefList, addSet, beRevisedSet } from '@/api/WhitelistRule'
import { flightList } from '@/api/settingRules'
export default {
  components: {

  },
  props: {
    cabintList: {//仓位列表
      type: Array,
      default: function() {
        return []
      }
    },
    form: { //查询条件
      type: Object,
      default: function() {
        return {}
      }
    }

  },
  data() {
    return {
      list: [], //列表数据
      total: 0,//总数
      pageSize: 10,//每页条数
      pageNum: 1,//当前页码
      dialogForm: {//弹窗表单数据
        data: [],//日期
        fromDate: '',//
        toDate: '',//
        fromOffset: '',//
        toOffset: '',//
        flightNo: [],//航班号
        whiteListCabinRefList: [], //仓位列表
        whitelistRuleModelRefList: []//规则列表
      },
      dialog: false, //添加修改弹窗状态
      dialogTitle: '',//添加修改弹窗标题
      flightList: [],//航班下拉列表
      flightListProps: {
        label: 'flightNo',
        value: 'flightNo',
        children: 'flightNoParam',
        multiple: true
        // emitPath: false
      },
      whitelistRuleModelRefProps: {
        label: 'name',
        value: 'code',
        children: 'children',
        multiple: true
        // emitPath: false
      },
      RuleModelRefList: [], //规则下拉列表
      rules: {
        data: [{ required: true, message: '起飞日期不能为空', trigger: 'change' }],
        fromOffset: [{ required: true, message: '不能为空', trigger: 'change', validator: (rule, value, callback) => {
          const toOffset = this.$refs.toOffset.value
          if (value && toOffset) {
            callback()
          } else {
            if (!value) {
              callback(new Error('1不能为空'))
            }
            if (!toOffset) {
              callback(new Error('2不能为空'))
            }
          }
        } }],
        flightNo: [{ required: true, message: '航班不能为空', trigger: 'change' }],
        whiteListCabinRefList: [{ required: true, message: '舱位不能为空', trigger: 'change' }],
        whitelistRuleModelRefList: [{ required: true, message: '规则类型不能为空', trigger: 'change' }]
      }

    }
  },
  created() {
    this.getTableList()
    this.getRuleModelRefLists()
  },
  mounted() {
    this.$nextTick(() => {
      this.$on('WhitelistRuleFormQuery', () => {
        this.getTableList()
      })
      this.$on('WhitelistRuleFormAdd', () => {
        this.add()
      })
    })
  },
  methods: {
    // 重置
    reSet(v) {
      console.log(v)
      this.pageNum = 1
      // 列表查询
      getList({
        ...v,
        isAll: !v.isValid,
        endDate: v.date[1] || '',
        startDate: v.date[0] || '',
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(res => {
        this.list = res.data.data.rows
        this.total = res.data.data.total
      })
    },
    /**
     * 切换分页
     */
    chengePage(v) {
      this.pageNum = v
      this.getTableList()
    },
    /**
     * 时间范围改变获航班数据
     */
    changeData() {
      const data = {
        fromDateDefault: this.dialogForm.data[0],
        toDateDefault: this.dialogForm.data[1]
      }
      flightList(data).then(res => {
        this.flightList = res.data.data || []
      })
    },
    /**
     * 取消
     */
    callOff() {
      this.dialog = false
    },
    /**
     * 修改添加确认
     */
    makeSure() {
      this.$refs['task_form_two'].validate((valid) => {
        if (valid) {
          console.log(valid)
          const disposeFrom = JSON.parse(JSON.stringify(this.dialogForm))
          disposeFrom.whitelistRuleModelRefList = disposeFrom.whitelistRuleModelRefList.map(v => {
            return {
              parent: v[0] ? v[0] : null,
              children: v[1] ? v[1] : null
            }
          })
          disposeFrom.flightNo = disposeFrom.flightNo.map(v => {
            return {
              flightLeg: v[0] ? v[0] : null,
              flightNo: v[1] ? v[1] : null
            }
          })
          disposeFrom.fromDate = disposeFrom.data[0]
          disposeFrom.toDate = disposeFrom.data[1]

          if (this.dialogTitle === '添加航班白名单规则') {
            addSet(disposeFrom).then(res => {
              if (res.data.code === '200') {
                this.dialog = false
                this.$message({
                  type: 'success',
                  message: '添加成功!'
                })
                this.dialogFormSet()
                this.getTableList()
              }
            })
          } else {
            beRevisedSet(disposeFrom).then(res => {
              if (res.data.code === '200') {
                this.dialog = false
                this.$message({
                  type: 'success',
                  message: '修改成功!'
                })
                this.dialogFormSet()
                this.getTableList()
              }
            })
          }
        } else {
          return false
        }
      })
    },
    /**
     * 获取规则下拉
     */
    getRuleModelRefLists() {
      getRuleModelRefList().then(res => {
        if (res.data.code == '200') {
          this.RuleModelRefList = res.data.data
        }
      })
    },
    /**
     * 重置修改添加表单
     */
    dialogFormSet() {
      this.dialogForm = {
        data: [],
        fromDate: '',
        toDate: '',
        fromOffset: '',
        toOffset: '',
        flightNo: [],
        whiteListCabinRefList: [],
        whitelistRuleModelRefList: []
      }
      this.flightList = []
      this.$refs['task_form_two'] && this.$refs['task_form_two'].resetFields()
    },
    /**
     * 列表查询
     */
    getTableList() {
      getList({
        ...this.form,
        isAll: !this.form.isValid,
        endDate: this.form.date[1] || '',
        startDate: this.form.date[0] || '',
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(res => {
        this.list = res.data.data.rows
        this.total = res.data.data.total
      })
    },
    /**
     * 删除某条数据
     */
    deletes(v) {
      this.$confirm(`此操作将永久删除这条数据, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deletesSet(v.id).then(res => {
            if (res.data.code == 200) {
              this.getTableList()
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
            } else {
              this.$message({
                type: 'warning',
                message: res.data.message
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    /**
     * 修改
     */
    beRevised(v) {
      this.dialogTitle = '修改航班白名单规则'
      this.dialog = true
      this.dialogFormSet()
      v.data = [v.fromDate + ' ' + '00:00:00', v.toDate + ' ' + '00:00:00']
      this.dialogForm = JSON.parse(JSON.stringify(v))

      this.dialogForm.whiteListCabinRefList = this.dialogForm.whiteListCabinRefList.map(item => item.id)

      const arr = []
      this.dialogForm.whitelistRuleModelRefList.map(item => {
        if (item.children) {
          item.children.map(j => {
            arr.push([item.code, j.code])
          })
        } else {
          arr.push([item.code])
        }
      })
      this.dialogForm.whitelistRuleModelRefList = arr

      const data = {
        fromDate: this.dialogForm.data[0],
        toDate: this.dialogForm.data[1]
      }
      flightList(data).then(res => {
        this.flightList = res.data.data
        this.dialogForm.flightNo = [[this.dialogForm.flightLeg, this.dialogForm.flightNo]]
      })
    },
    /**
     * 添加
     */
    add(v) {
      console.log('添加弹窗')
      this.dialogTitle = '添加航班白名单规则'
      this.dialog = true
      this.dialogFormSet()
    }

  }
}
</script>



