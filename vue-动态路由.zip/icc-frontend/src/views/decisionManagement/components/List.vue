<template>
  <!-- 预测参数 -->
  <div class="box">
    <header v-if="title" :class="margin ? 'margin' : ''">{{ title }}</header>
    <ul :class="margin ? 'margin' : ''">
      <li v-for="(v, i) in list" :key="i" :class="[small ? 'small' : '', lang ? 'lang': '']">
        <div :class="['label', v.type]">{{ v.key }}</div>
        <div class="conter">
          <el-input v-if="v.type == 'input'" v-model="v.value" />
          <el-checkbox v-if="v.type == 'checkbox'" v-model="v.value" />
          <el-radio-group v-if="v.type == 'radio'" v-model="v.value">
            <el-radio v-for="j in v.radioList" :key="j.value" :label="j.label">{{ j.label }}</el-radio>
          </el-radio-group>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>

export default {
  components: {

  },
  props: {
    title: {
      type: String,
      default: ''
    },
    list: {
      type: Array,
      default: function() {
        return []
      }
    },
    small: {
      type: Boolean,
      default: false // 短的label
    },
    margin: {
      type: Boolean,
      default: false // 标题没有底部边框 而且 左侧小图标有所改变
    },
    lang: {
      type: Boolean,
      default: false// label边长
    }
  },
  data() {
    return {

    }
  },
  created() {
    console.log(this.list)
  }
}
</script>
<style lang="scss" scoped>
header{
  width: 100%;
  border: 1px solid #eee;
  margin: 0;
  color: #409EFF;
  font-weight: 600;
  height: 40px;
  background-color: rgb(246, 251, 252);
  line-height: 40px;
  font-size: 14px;
  padding-left: 20px;
  border-radius: 5px;
  position: relative;
  &::before{
    content: " ";
    display: block;
    width: 5px;
    height: 100%;
    background-color: #409EFF;
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    position: absolute;
    top: 0;
    left: 0;
  }
  &.margin{
    border-bottom: none;
     border-bottom-left-radius: 0px;
    background-color: #fff;
    &::before{
      border-radius: 0;
      height: 70%;
      width: 3px;
      top: 5px;
      left: 10px;
    }
  }

}
ul{
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 0;
  li{
    width: 49%;
    display: flex;
    list-style: none;
    border: 1px solid #eee;
    height: 50px;
    border-top: none;
    &:nth-child(1), &:nth-child(2){
      border-top: 1px solid #eee;
    }
    .label{
      width: 60%;
      border-right: 1px solid #eee;
      line-height: 50px;
      padding-left: 20px;
      background-color: rgb(246, 251, 252);
      text-overflow: ellipsis;white-space: nowrap;
      font-weight: 600;
      color: #333;
      overflow:hidden;
      &.input{
      padding-left: 30px;
      position: relative;
        &::before{
          display: block;
          content: '*';
          // border: 1px solid #000;
          width: 15px;
          height: 15px;
          position: absolute;
          left: 20px;
          top: 0;
          color: red;
          font-weight: 900;
        }
      }
    }
    .conter{
      padding-left: 10px;
      display: flex;
      align-items: center;
      width: 60%;
    }
    &.small{
      .label{
        width: 30%;
        padding-left: 20px;
        &.input{
          &::before{
            content: "";
          }
        }
      }
    }
    &.lang{
      width: 100% !important;
    }
  }
  &.margin{
    margin-top: 0;
    li{
      width: 50%;
    }
  }
}
::v-deep .el-input__inner{
  height: 30px;
  width: 80%;
}
</style>
