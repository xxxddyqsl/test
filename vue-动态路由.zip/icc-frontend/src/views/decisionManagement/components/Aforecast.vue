<template>
  <!-- 预测参数 -->
  <div class="box">
    <List :list="list" />
  </div>
</template>
<script>
import List from './List.vue'
export default {
  components: {
    List
  },
  data() {
    return {
      list: [
        { type: 'input', key: '节假日数据池最小样本数', value: 1 },
        { type: 'input', key: 'ADD模型做小样本数', value: 2 },
        { type: 'input', key: 'OBK模型做小样本数', value: 3 },
        { type: 'input', key: 'LNR和LOG模型的置信度百分比', value: 4 },
        { type: 'input', key: 'LNR和LOG模型的置信度百分比', value: 5 },
        { type: 'input', key: 'LNR和LOG模型的置信度百分比', value: 6 },
        { type: 'input', key: 'LNR和LOG模型的置信度百分比', value: 7 },
        { type: 'checkbox', key: 'DCP1之前预测AI模型是否优先Last Year模型', value: true },
        { type: 'checkbox', key: 'DCP1之前预测AI模型是否优先Last Year模型', value: true },
        { type: 'radio', key: '去限制化方法', value: 'EM', radioList: [{ label: 'Baseline', value: 'Baseline' }, { label: 'EM', value: 'EM' }] },
        { type: 'input', key: '非整型数据最小值', value: 11 },
        { type: 'input', key: '历史一场数据低乘子', value: 12 },
        { type: 'input', key: '误差下限', value: 13 },
        { type: 'input', key: 'ESP模型远期本数', value: 14 },
        { type: 'input', key: 'ESP模型置信度百分比', value: 15 },
        { type: 'input', key: '非整型数据最小值', value: 16 },
        { type: 'input', key: '历史一场数据低乘子', value: 17 },
        { type: 'input', key: '误差下限', value: 18 },
        { type: 'input', key: 'ESP模型远期本数', value: 19 }
        // { key: 'ESP模型置信度百分比', value: 2 }
      ]
    }
  },
  created() {
  }
}
</script>
<style lang="scss" scoped>

</style>
