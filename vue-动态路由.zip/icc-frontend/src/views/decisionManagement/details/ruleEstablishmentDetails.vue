
<template>
  <div class="pageBox">
    <!-- 规则建立详情 -->
    <div class="title">
      <h3>国内自动舱位调整规则——{{ $route.query.name }} ({{ $route.query.date }}) </h3>
      <div>
        <el-button>复制</el-button>
        <el-button>编辑</el-button>
        <el-button @click="$router.go(-1) ">返回</el-button>
      </div>
    </div>
    <main>
      <div class="left">
        <!-- 规则综合有效期 -->
        <Comprehensive />
        <!-- 适用航班条件 -->
        <ForTheFlight />
        <!-- 舱位开放条件 -->
        <OpenSpace v-if="OpenSpace" />
        <!-- 机型参数条件 超售-->
        <ModelParameters v-if="ModelParameters" />
        <!-- 竞争航班条件  -->
        <RaceCondition v-if="raceCondition" />
        <!-- 市场条件 -->
        <MarketConditions />
      </div>
      <div class="right">
        <StrategyAdjustment />
      </div>
    </main>
  </div>
</template>

<script>
import Comprehensive from '../components/Comprehensive.vue'
import ForTheFlight from '../components/ForTheFlight.vue'
import RaceCondition from '../components/RaceCondition.vue'
import OpenSpace from '../components/OpenSpace.vue'
import ModelParameters from '../components/ModelParameters.vue'
import StrategyAdjustment from '../components/StrategyAdjustment.vue'
import MarketConditions from '../components/MarketConditions.vue'

export default {
  components: {
    Comprehensive,
    ForTheFlight,
    RaceCondition,
    OpenSpace,
    ModelParameters,
    StrategyAdjustment,
    MarketConditions
  },
  data() {
    return {
      raceCondition: false,
      OpenSpace: false,
      ModelParameters: false
    }
  },
  created() {
    console.log(this.$route.query)
    const { name: type } = this.$route.query
    console.log(type)
    // eslint-disable-next-line eqeqeq
    if (type == '比舱' || type == '实时比价') {
      this.raceCondition = true
      console.log(this.raceCondition)
    }
    // eslint-disable-next-line eqeqeq
    if (type == '根据客座率调档') {
      this.OpenSpace = true
      console.log(this.OpenSpace)
    }
    // eslint-disable-next-line eqeqeq
    if (type == '超售') {
      this.ModelParameters = true
    }
  },
  methods: {

  }
}
</script>

<style lang='scss' scoped >
.pageBox{
  overflow-x: scroll;
  .title{
    padding: 20px;
    display: flex;
    justify-content: space-between;
  }
  main{
    display: flex;
    justify-content: space-between;
    width: 100%;
    min-height: 800px;
    .left{
      width: 50%;
      min-width: 700px;
      border-right: 1px dashed red;
      padding: 0 40px;
    }

    .right{
      width: 50%;
      min-width: 700px;
      padding: 0 40px;

    }
  }
}
.box{
  min-width: 650px;
}
</style>

