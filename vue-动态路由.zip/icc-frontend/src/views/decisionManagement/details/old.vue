
<template>
  <div class="pageBox">
    <!-- 规则建立详情 -->
    <div class="title">   规则一（起飞日期）————规则编号50000073850503  </div>
    <div class="neck">  模型说明：由于所选算法，支持0-365天航班；请根据需要设置合理的航班日期范围   </div>
    <div class="mind">
      <div class="mind_left">
        <!-- <el-form ref="form" :model="form" label-width="80px"> -->
        <el-form label-width="80px">
          <el-form-item label="生效日期" size="mini">
            <el-date-picker v-model="value1" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" />
            <!-- <el-input v-model="form.name" /> -->
          </el-form-item>
          <el-form-item>
            <div style="width:100%;height:16px">
              <el-checkbox v-for="(item,index) in week" :key="index" v-model="item.checked" @change="Checked(item,index)">{{ item.aa }} </el-checkbox>
            </div>
          </el-form-item>
          <el-form-item>
            <div style="width:100%;height:16px">
              <el-checkbox>经停 </el-checkbox>
              <el-checkbox>直达</el-checkbox>
            </div>
          </el-form-item>
          <el-form-item>
            <div style="width:100%;height:16px">
              <el-checkbox v-for="(item,index) in type" :key="index" v-model="item.checked" @change="allCheck(item,index)">{{ item.aa }} </el-checkbox>
            </div>
          </el-form-item>
          <el-form-item label="航段">
            <div>
              <el-input v-model="input" size="mini" style="width:100px" />--<el-input v-model="input1" size="mini" style="width:100px" />
              <el-button size="mini" style="margin-left:10px" type="primary" @click="Add">添加</el-button>
              <el-button size="mini" type="primary" @click="remove()">清空</el-button>
            </div>
            <ul class="ul_list">
              <li v-for="(itm,index) in List" :key="index">
                <span>{{ itm.value1 }}</span> -- <span>{{ itm.value2 }}</span>
                <!-- <el-button v-show="itm.showbox" size="mini" type="primary" @click="remove1(index)">删除</el-button> -->
                <span v-show="itm.showbox" style="margin-left:10px" @click="remove1(index)">删除</span>
              </li>
            </ul>
          </el-form-item>

          <el-form-item>
            舱位<br>
            <el-checkbox>F</el-checkbox>
            <el-checkbox>A</el-checkbox><br>
            <el-checkbox>U</el-checkbox><br>

            <el-checkbox>J</el-checkbox>
            <el-checkbox>C</el-checkbox>
            <el-checkbox>D</el-checkbox>
            <el-checkbox>Q</el-checkbox>
            <el-checkbox>I</el-checkbox>
            <el-checkbox>O</el-checkbox><br>

            <el-checkbox>W</el-checkbox>
            <el-checkbox>P</el-checkbox><br>

            <el-checkbox>Y</el-checkbox>
            <el-checkbox>B</el-checkbox>
            <el-checkbox>M</el-checkbox>
            <el-checkbox>E</el-checkbox>
            <el-checkbox>H</el-checkbox>
            <el-checkbox>K</el-checkbox><br>
            <el-checkbox>L</el-checkbox>
            <el-checkbox>N</el-checkbox>
            <el-checkbox>R</el-checkbox>
            <el-checkbox>S</el-checkbox>
            <el-checkbox>V</el-checkbox><br>
            <el-checkbox>T</el-checkbox>
            <el-checkbox>G</el-checkbox>
            <el-checkbox>Z</el-checkbox>
            <el-checkbox>X</el-checkbox><br>

          </el-form-item>
          <el-form-item label="备注(考虑市场)" label-width="150px">
            <el-input v-model="input2" size="mini" style="width:200px;" />
          </el-form-item>
          <el-form-item label="备注(模型描述)" label-width="150px">
            <el-input v-model="input2" size="mini" style="width:200px;" />
          </el-form-item>
        </el-form>
      </div>

      <div class="mind_right">
        <el-form label-width="80px">
          <el-form-item label="航班日期">
            <el-date-picker v-model="value1" size="mini" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" />
          </el-form-item>
          <el-form-item label="航班日期 距今日" label-width="125px">
            <el-input v-model="input4" size="mini" placeholder="2" style="width:100px" /> 天 至<el-input v-model="input5" size="mini" style="width:100px" placeholder="5" />天
          </el-form-item>
          <el-form-item label="施法时间 范围 " label-width="112.5px">
            <el-time-select v-model="startTime" size="mini" placeholder="00:00" :picker-options="{ start: '00:00', step: '00:15', end: '23:59' }" /> 至
            <el-time-select v-model="endTime" size="mini" placeholder="23:59" :picker-options="{ start: '00:00', step: '00:15', end: '23:59' }" />
          </el-form-item>

          <el-form-item label="航班号">
            <div>
              <el-input v-model="input6" size="mini" style="width:100px" />
              <el-button size="mini" style="margin-left:10px" type="primary" @click="Add1">添加</el-button>
              <el-button size="mini" type="primary" @click="Remove()">清空</el-button>
              <el-button size="mini" type="primary">导入</el-button> 规则排除航班
            </div>
            <ul class="ul_list">
              <li v-for="(itm,index) in List1" :key="index">
                <span>{{ itm.value1 }}</span>
                <!-- <el-button v-show="itm.showbox" size="mini" type="primary" @click="Remove1(index)">删除</el-button> -->
                <span v-show="itm.showbox" style="margin-left:10px" @click="Remove1(index)">删除</span>
              </li>
            </ul>
          </el-form-item>
          <el-form-item label="市场占有率 范围" label-width="130px">
            <el-input v-model="input7" size="mini" placeholder="50" style="width:100px" /> % 至<el-input v-model="input8" style="width:100px" placeholder="70" />%
          </el-form-item>

          <el-form-item label="调整操作" label-width="85px">
            <el-select v-model="value2" size="mini" placeholder="关闭">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item label="调整时间" size="mini" label-width="85px">
            <el-input v-model="input9" size="mini" style="width:100px" />
          </el-form-item>
          <el-form-item>
            <el-button size="mini" style="margin-left:-60px" type="primary">生成</el-button>
          </el-form-item>
          <el-form-item>
            <div style="border:1px solid ;margin-left:-60px;width:40%;  display: flex;  flex-direction: column;   align-items: center; justify-content: center;">
              <p style="width:80%">建议市场占有率：60% </p>
              <p style="width:80%">调整市场占有率：<el-input v-model="input9" size="mini" style="width:100px" /> </p>

            </div>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="footer">
      <el-button type="primary" size="mini">保存</el-button>
      <el-button type="primary" size="mini" @click="close">关闭</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      checked1: '',
      checked: false,
      startTime: '',
      endTime: '',
      week: [
        { aa: '全选', checked: false },
        { aa: '周日', checked: false },
        { aa: '周一', checked: false },
        { aa: '周二', checked: false },
        { aa: '周三', checked: false },
        { aa: '周四', checked: false },
        { aa: '周五', checked: false },
        { aa: '周六', checked: false }
      ],
      type: [
        { aa: '全选', checked: false },
        { aa: '极优势', checked: false },
        { aa: '优势', checked: false },
        { aa: '均势', checked: false },
        { aa: '劣势', checked: false },
        { aa: '极劣势', checked: false }
      ],
      input: '',
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      input5: '',
      input6: '',
      input7: '',
      input8: '',
      input9: '',
      input10: '',
      value1: '',
      value2: '',
      List: [{
        value1: 'PVG',
        value2: 'BPE',
        showbox: false
      }],
      List1: [{
        value1: 'YY9141',
        showbox: false
      }],
      options: [{
        value: 1,
        label: '11'
      }, {
        value: 2,
        label: '22'
      }, {
        value: 3,
        label: '33'
      }]

    }
  },
  methods: {
    Add() {
      if (this.input == '' || this.input1 == '') {
        this.$message.error('航段不能为空')
      } else {
        this.List.push({
          value1: this.input,
          value2: this.input1,
          showbox: true
        })
        this.input = ''
        this.input1 = ''
      }
    },
    Add1() {
      if (this.input6 == '') {
        this.$message.error('航班号不能为空')
      } else {
        this.List1.push({
          value1: this.input6,
          showbox: true
        })
        this.input6 = ''
      }
    },
    Remove1(id) {
      this.List1.splice(id, 1)
    },
    remove1(id) {
      this.List.splice(id, 1)
    },
    remove() {
      this.List = []
    },
    Remove() {
      this.List1 = []
    },
    Checked(item, index) {
      if (item.aa == '全选') {
        this.week.forEach(value => {
          value.checked = true
        })
      }
      if (item.aa != '全选') {
        this.week[0].checked = false
      }
      if (this.week[1].checked == true && this.week[2].checked == true && this.week[3].checked == true && this.week[4].checked == true && this.week[5].checked == true && this.week[6].checked == true && this.week[7].checked == true) {
        this.week[0].checked = true
      }
    },
    allCheck(item) {
      if (item.aa == '全选') {
        this.type.forEach(value => {
          value.checked = true
        })
      }
      if (item.aa != '全选') {
        this.type[0].checked = false
      }
      if (this.type[1].checked == true && this.type[2].checked == true && this.type[3].checked == true && this.type[4].checked == true && this.type[5].checked == true) {
        this.type[0].checked = true
      }
    },
    close() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang='scss' scoped >

.ul_list{
    width: 50%;
    height: 200px;
    border:1px solid;
    list-style-type: none;
   overflow-y:scroll;
}
.title{
    height: 50px;
    font-size: 20px;
    line-height: 50px;
}
.neck{
    height: 30px;
    font-size: 12px;
    color: orangered;

}
.mind{
    display: flex;
    min-height: 500px;
    justify-content: space-between;
.mind_left{
    width: 40%;
}
.mind_mid{
    width: 20%;
    // background-color: aqua;
    display: flex;
    flex-direction: column;
    justify-content: center;
    // align-items: center;
    font-size: 16px;
}
.mind_right{
    width: 40%;
    //   background-color: blue;
}
}
.footer{
    margin-top: -50px;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>

