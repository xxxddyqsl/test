<template>
  <div class=" pageBox">
    <div class="seachBox">
      <div class="title_left">
        <!-- 动态规划算法 -->
      </div>
      <div class="title_right">
        <el-form :inline="true" :model="form">

          <el-form-item>
            <el-input v-model="form.flightLeg" style="width:120px" size="mini" placeholder="请输入内容航段" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="form.flightNo" style="width:120px" size="mini" placeholder="请输入航班号" />
          </el-form-item>

          <el-form-item>
            <el-date-picker
              v-model="form.date"
              format="yyyy 年 MM 月 dd 日"
              value-format="yyyy-MM-dd HH:mm:ss"
              size="mini"
              type="daterange"
              range-separator="至"
              start-placeholder="开始航班日期"
              end-placeholder="结束航班日期"
            />
          </el-form-item>

          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onAdd">添加</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onReset">重置</el-button>
            <el-button type="primary" size="mini" @click="goBack">返回</el-button>
          </el-form-item>
          <el-form-item />

        </el-form>
      </div>
    </div>
    <el-table :data="tableData" border>
      <el-table-column label="航班号" align="center">
        <template slot-scope="scope" width="160">
          <div>{{ scope.row.flightNo }}</div>
        </template>
      </el-table-column>
      <el-table-column label="航段" align="center">
        <template slot-scope="scope">
          <p>{{ scope.row.flightLeg }}
            <br><i class="el-icon-star-on" />
          </p>
        </template>
      </el-table-column>

      <el-table-column prop="hbq" label="航班起飞日期范围">
        <template slot-scope="scope">
          <p>{{ scope.row.fromDate }} ~ {{ scope.row.toDate }}
          </p>
        </template>
      </el-table-column>
      <el-table-column prop="xq" label="班期">
        <template slot-scope="scope">
          <span v-for="(v,i) in scope.row.weekday" :key="i">
            <span v-if="v != '.'"> {{ v }} &nbsp;</span>
          </span>
        </template>
      </el-table-column>

      <el-table-column prop="coefficient" label="新需求参数" />
      <el-table-column label="操作" align="center" width="160">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="onEditBtn(scope.row)">修改</el-button>
          <el-button type="primary" size="mini" @click="onDeleteBtn(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination background layout="total, prev, pager, next" :total="total" />
    <div>
      <el-dialog v-dialogDrag :title="title" width="50%" :visible.sync="Dialog">
        <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="200px">
          <el-form-item label="日期" prop="date">
            <el-date-picker
              v-model="taskForm.date"
              value-format="yyyy-MM-dd HH:mm:ss"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              @change="dateChange"
            />
          </el-form-item>
          <el-form-item label="航班号" prop="flightBo">
            <el-input v-if="title === '修改规则算法'" v-model="taskForm.flightBo" disabled />
            <el-cascader v-else v-model="taskForm.flightBo" :props="props" :show-all-levels="false" :options="flightList" clearable collapse-tags />
          </el-form-item>
          <el-form-item label="班期" prop="weekday">
            <el-select v-model="taskForm.weekday" clearable collapse-tags multiple placeholder="请选择">
              <el-option v-for="item in weekday" :key="item.id" :label="item.value" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item label="新需求参数" prop="coefficient">
            <el-input v-model="taskForm.coefficient" clearable size="mini" style="width:180px" placeholder="请输入" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="Dialog = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary" @click="onMakeSure('taskForm')">确 定</el-button>
        </div>
      </el-dialog>
    </div>

  </div>
</template>

<script>
import { initTable, deleteTarget, addBtn, editBtn } from '@/api/algorithmisSetUp'
import { flightList } from '@/api/settingRules'

export default {
  components: {
  },
  data() {
    return {
      flightBo: [],
      exitId: '',
      weekday: [
        { id: '1', value: 1 }, { id: '2', value: 2 },
        { id: '3', value: 3 }, { id: '4', value: 4 },
        { id: '5', value: 5 },
        { id: '6', value: 6 }, { id: '7', value: 7 }],
      flightList: [],
      props: {
        label: 'flightNo',
        value: 'flightNo',
        children: 'flightNoParam',
        multiple: true
      },
      title: '',
      Dialog: false,
      taskForm: {

        flightBo: '',
        weekday: [],
        date: [],
        coefficient: ''
      },
      rules: {

        flightBo: [{ required: true, message: '不能为空', trigger: 'blur' }],
        weekday: [{ required: true, message: '不能为空', trigger: 'blur' }],
        date: [{ required: true, message: '不能为空', trigger: 'blur' }],
        coefficient: [{ required: true, message: '不能为空', trigger: 'blur' }]

      },
      form: {
        flightNo: '',
        flightLeg: '',
        date: [],
        fromDate: '',
        toDate: ''
      },
      pageNum: 1,
      pageSize: 10,
      tableData: [],
      total: 10

    }
  },

  created() {
    this.getTable()
  },
  methods: {
    // 重置按钮
    onReset() {
      this.form = {
        flightNo: '',
        flightLeg: '',
        date: [],
        fromDate: '',
        toDate: ''
      }
      this.getTable()
    },
    clear() {
      this.taskForm = {
        flightBo: '',
        weekday: [],
        date: [],
        coefficient: ''
      }
    },
    // 弹窗确定按钮
    onMakeSure(formName) {
      if (this.title === '添加规则算法') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.flightBo = this.taskForm.flightBo.map(v => {
              return {
                flightLeg: v[0] ? v[0] : '',
                flightNo: v[1] ? v[1] : ''
              }
            })
            const data = {
              fromDate: this.taskForm.date[0],
              toDate: this.taskForm.date[1],
              flightBo: this.flightBo,
              weekday: this.taskForm.weekday,
              coefficient: this.taskForm.coefficient

            }
            addBtn(data).then(res => {
              if (res.data.code === '200') {
                this.getTable()
                this.$message.success('添加成功')
              } else {
                this.$message.error('添加失败')
              }
              this.Dialog = false
              this.clear()
            })
          } else {
            return false
          }
        })
      } else if (this.title === '修改规则算法') {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            var data = {
              id: this.exitId,
              fromDate: this.taskForm.date[0],
              toDate: this.taskForm.date[1],
              weekday: this.taskForm.weekday,
              coefficient: this.taskForm.coefficient,
              flightBo: this.flightBo

            }
            editBtn(data).then(res => {
              if (res.data.code === '200') {
                this.getTable()
                this.$message.success('修改成功')
              } else {
                this.$message.info('修改失败')
              }
              this.Dialog = false
              this.clear()
            })
          } else {
            return false
          }
        })
      }
    },
    // 时间范围改变获航班数据
    dateChange() {
      const data = {
        fromDate: this.taskForm.date[0],
        toDate: this.taskForm.date[1]
      }
      flightList(data).then(res => {
        this.flightList = res.data.data || []
      })
      // }
    },
    // 修改按钮
    onEditBtn(item) {
      console.log(item, 1111)
      this.Dialog = true
      this.title = '修改规则算法'
      const set = new Set(item.weekday)
      const weekdays = [...set]
      weekdays.forEach((value, index) => {
        if (value === '.') {
          weekdays.splice(index, 1)
        }
      })
      this.exitId = item.id
      this.taskForm.flightBo = item.flightNo
      this.taskForm.date = [item.fromDate + ' ' + '00:00:00', item.toDate + ' ' + '00:00:00']
      this.taskForm.weekday = weekdays
      this.taskForm.coefficient = item.coefficient
    },
    // 增加按钮
    onAdd() {
      this.Dialog = true
      this.title = '添加规则算法'
    },
    // 查询表格
    getTable() {
      this.form.fromDate = this.form.date[0] || ''
      this.form.toDate = this.form.date[1] || ''
      console.log(this.form)
      initTable({
        pageNum: this.pageNum || 1,
        pageSize: this.pageSize || 10,
        ...this.form
      }).then(res => {
        console.log(res)
        if (res.data.code === '200') {
          this.total = res.data.data.total
          this.tableData = res.data.data.rows
        }
      })
    },
    // 条件查询
    onQuery() {
      this.getTable()
    },
    onDeleteBtn(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteTarget(item.id).then(res => {
          if (res.data.code === '200') {
            this.getTable()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    goBack() {
      // this.$router.go(-1)
      this.$router.push({ name: 'AlgorithmManagement', query: { radio: '智能控舱算法' }})
    }

  }

}

</script>

<style lang="scss" scoped>

</style>

