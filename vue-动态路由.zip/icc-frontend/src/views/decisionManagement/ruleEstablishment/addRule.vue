<template>
  <div class="addRulePage">
    <div class="titleBox">
      <span
        >国内自动舱位调整模型 -
        {{
          modeTypeList.find(i => {
            return i.code === formDate.modelType;
          }).name
        }}</span
      >
      <div>
        <el-button
          v-if="isPreviewFlag"
          type="primary"
          size="mini"
          @click="onCloneData"
          >复制</el-button
        >
        <el-button
          v-if="isDisabledFlag"
          type="primary"
          size="mini"
          @click="onEdit"
          >编辑</el-button
        >
        <el-button v-else type="primary" size="mini" @click="onSubmit"
          >保存</el-button
        >
        <el-button
          type="primary"
          size="mini"
          @click="$router.push({ name: 'ruleEstablishment' })"
          >返回</el-button
        >
      </div>
    </div>
    <el-form
      label-width="110px"
      ref="formDateRef"
      :model="formDate"
      :rules="rules"
    >
      <el-form-item label="调舱规则" prop="modelType" ref="modelType">
        <el-radio-group
          v-model="formDate.modelType"
          size="mini"
          :disabled="isDisabledFlag"
          @change="changeModeType"
        >
          <el-radio-button
            v-for="i in modeTypeList"
            :key="i.code"
            :label="i.code"
            >{{ i.name }}</el-radio-button
          >
        </el-radio-group>
      </el-form-item>
      <div class="contentBox">
        <!---------------------------- 分割线左侧表单 ---------------------------->
        <div class="leftBox">
          <!-- 规则有效期条件 -->
          <div class="itemBox">
            <p class="itemTitle">规则有效期条件</p>
            <el-form-item label="航班起飞日期" prop="flightDepartureTime">
              <el-date-picker
                size="mini"
                v-model="formDate.ruleValidityTimeParam.flightDepartureTime"
                type="daterange"
                value-format="yyyy-MM-dd"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :disabled="isDisabledFlag"
                @change="flightDepartureTimeChangeFn"
              >
              </el-date-picker>
            </el-form-item>
            <!-- 规则类型为【特定日期舱位调整】和【特定日期设定配额】时，不展示该列 -->
            <el-form-item
              v-if="
                !(
                  formDate.modelType === 'SPECIALDATECABIN' ||
                  formDate.modelType === 'SPECIALDATEQUOTA' ||
                  formDate.modelType === 'UPSIDEDOWN' ||
                  formDate.modelType === 'OPTIMIZE'
                )
              "
              label="在航班起飞前"
              prop="cost_value"
              ref="cost_value"
            >
              <el-input
                type="text"
                size="mini"
                v-model.number="
                  formDate.ruleValidityTimeParam.departureTimeLeft
                "
                placeholder="请输入天数"
                clearable
                style="width:30%;"
                :disabled="isDisabledFlag"
                @change="departureTimeChange"
              ></el-input
              >天 至
              <el-input
                type="text"
                size="mini"
                v-model.number="
                  formDate.ruleValidityTimeParam.departureTimeRight
                "
                placeholder="请输入天数"
                clearable
                style="width:30%;"
                :disabled="isDisabledFlag"
                @change="departureTimeChange"
              ></el-input
              >天 生效
            </el-form-item>
            <el-form-item
              label="规则可用日期"
              prop="start_time"
              ref="start_time"
            >
              <el-date-picker
                size="mini"
                v-model="formDate.ruleValidityTimeParam.ruleEnableTime"
                type="daterange"
                value-format="yyyy-MM-dd"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :picker-options="startPickerOptions"
                :disabled="isDisabledFlag"
                @change="ruleEnableTimeChange"
              >
              </el-date-picker>
            </el-form-item>
            <el-form-item label="综合有效期">
              <span
                >{{
                  `${formDate.ruleValidityTimeParam.finalDateLeft} 至 ${
                    formDate.ruleValidityTimeParam.finalDateRight
                  }`
                }}（自动生成）</span
              >
            </el-form-item>
          </div>

          <!-- 适用航班条件 -->
          <div class="itemBox">
            <p class="itemTitle">适用航班条件</p>
            <el-form-item label="航段&航班">
              <el-cascader
                v-model="formDate.applicableFlightParam.legNoParams"
                :props="flyNoListProps"
                :show-all-levels="false"
                :options="flyNoList"
                placeholder="请选择航段-航班"
                size="mini"
                clearable
                collapse-tags
                :disabled="isDisabledFlag"
              />
            </el-form-item>
            <el-form-item label="星期" prop="week">
              <el-checkbox-group
                v-model="formDate.applicableFlightParam.weeks"
                :disabled="isDisabledFlag"
                @change="handleCheckedweekChange"
              >
                <el-checkbox
                  v-for="item in weekList"
                  :key="item.code"
                  :label="item.code"
                  >{{ item.name }}</el-checkbox
                >
              </el-checkbox-group>
            </el-form-item>
            <el-form-item label="经停/直达" prop="flightModel">
              <el-radio-group
                class="radioBg"
                v-model="formDate.applicableFlightParam.flightModel"
                :disabled="isDisabledFlag"
                @change="handleCheckedflightModelChange"
              >
                <el-radio
                  v-for="item in flightModelList"
                  :key="item.code"
                  :label="item.code"
                  >{{ item.name }}</el-radio
                >
              </el-radio-group>
            </el-form-item>
            <el-form-item label="航班优劣势" prop="vantage">
              <el-checkbox-group
                v-model="formDate.applicableFlightParam.vantages"
                :disabled="isDisabledFlag"
                @change="handleCheckedvantageChange"
              >
                <el-checkbox
                  v-for="item in vantageList"
                  :key="item.code"
                  :label="item.code"
                  >{{ item.name }}</el-checkbox
                >
              </el-checkbox-group>
            </el-form-item>
            <el-form-item
              label="航班始发时间"
              v-if="
                !(
                  formDate.modelType === 'SPECIALDATECABIN' ||
                  formDate.modelType === 'SPECIALDATEQUOTA' ||
                  formDate.modelType === 'UPSIDEDOWN' ||
                  formDate.modelType === 'OPTIMIZE'
                )
              "
            >
              <el-time-picker
                is-range
                v-model="formDate.applicableFlightParam.flightDate"
                size="mini"
                value-format="HH:mm:ss"
                range-separator="至"
                start-placeholder="开始时间"
                end-placeholder="结束时间"
                placeholder="选择时间范围"
                :disabled="isDisabledFlag"
                @change="val => flightDateChange(val)"
              >
              </el-time-picker>
            </el-form-item>
          </div>

          <div class="itemBox" v-if="formDate.modelType === 'CHANGER'">
            <p class="itemTitle">舱位开放条件</p>
            <el-form-item label="" prop="marketParam" ref="marketParam">
              <el-checkbox-group
                v-model="formDate.cabinOpenParam.cabinIds"
                :disabled="isDisabledFlag"
              >
                <div v-for="(itm, idx) in cabinListsObj" :key="idx">
                  <el-checkbox
                    v-for="i in itm"
                    :key="i.cabinId"
                    :label="i.cabinId"
                    >{{ i.cabinCode }}</el-checkbox
                  >
                </div>
              </el-checkbox-group>
            </el-form-item>
          </div>
          <!-- 竞争航班条件 -->
          <div
            class="itemBox"
            v-if="
              formDate.modelType === 'PRICECOMPARISON' ||
                formDate.modelType === 'BC'
            "
          >
            <p class="itemTitle">竞争航班条件</p>
            <el-form-item label="对比模式">
              <el-select
                v-model="formDate.competeFlightParam.contrastMode"
                size="mini"
                :disabled="isDisabledFlag"
                placeholder="请选择"
              >
                <el-option
                  v-for="i in competeFlightList"
                  :key="i.code"
                  :label="i.name"
                  :value="i.code"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="航段&航班">
              <el-cascader
                v-model="formDate.competeFlightParam.legNoParams"
                :props="competeFlyNoProps"
                :show-all-levels="false"
                :options="competeFlyNoList"
                placeholder="请选择航段-航班"
                size="mini"
                clearable
                collapse-tags
                :disabled="isDisabledFlag"
              />
            </el-form-item>
            <el-form-item label="航班始发时间">
              <el-time-picker
                is-range
                v-model="formDate.competeFlightParam.flightDate"
                size="mini"
                value-format="HH:mm:ss"
                range-separator="至"
                start-placeholder="开始时间"
                end-placeholder="结束时间"
                placeholder="选择时间范围"
                :disabled="isDisabledFlag"
                @change="val => flightDateChange(val, 'competeFlightParam')"
              >
              </el-time-picker>
            </el-form-item>
          </div>
          <!-- 市场条件 -->
          <div
            class="itemBox"
            v-if="
              formDate.modelType === 'TAKEOFFDATE' ||
                formDate.modelType === 'SEATRATE' ||
                formDate.modelType === 'SSETTING' ||
                formDate.modelType === 'CHANGER' ||
                formDate.modelType === 'BC' ||
                formDate.modelType === 'PRICECOMPARISON'
            "
          >
            <p class="itemTitle">市场条件</p>
            <el-form-item
              label="市场占有率范围"
              prop="marketParam"
              ref="marketParam"
              v-if="
                formDate.modelType !== 'SSETTING' &&
                  formDate.modelType !== 'CHANGER' &&
                  formDate.modelType !== 'PRICECOMPARISON' &&
                  formDate.modelType !== 'BC'
              "
            >
              <el-input
                type="text"
                size="mini"
                v-model.number="formDate.marketParam.marketRangeLeft"
                placeholder="请输入"
                clearable
                style="width:30%;"
                :disabled="isDisabledFlag"
              ></el-input
              >% 至
              <el-input
                type="text"
                size="mini"
                v-model.number="formDate.marketParam.marketRangeRight"
                placeholder="请输入"
                clearable
                style="width:30%;"
                :disabled="isDisabledFlag"
              ></el-input
              >%
            </el-form-item>
            <el-form-item
              label="客座率范围"
              v-if="
                formDate.modelType === 'SEATRATE' ||
                  formDate.modelType === 'SSETTING' ||
                  formDate.modelType === 'CHANGER' ||
                  formDate.modelType === 'PRICECOMPARISON' ||
                  formDate.modelType === 'BC'
              "
            >
              <span
                v-if="
                  formDate.modelType === 'SEATRATE' ||
                    formDate.modelType === 'PRICECOMPARISON'
                "
              >
                <el-select
                  class="width100"
                  v-model="formDate.marketParam.seatingRateType"
                  size="mini"
                  :disabled="isDisabledFlag"
                  placeholder="请选择范围"
                >
                  <el-option
                    v-for="item in plfTypeList"
                    :key="item.code"
                    :label="item.name"
                    :value="item.code"
                  />
                </el-select>
                在
              </span>
              <el-input
                class="width100"
                type="text"
                size="mini"
                v-model.number="formDate.marketParam.seatingRateLeft"
                placeholder="请输入范围值"
                clearable
                :disabled="isDisabledFlag"
              ></el-input
              >% 至
              <el-input
                class="width100"
                type="text"
                size="mini"
                v-model.number="formDate.marketParam.seatingRateRight"
                placeholder="请输入范围值"
                clearable
                :disabled="isDisabledFlag"
              ></el-input
              >%
            </el-form-item>
            <el-form-item
              label="人数差"
              v-if="formDate.modelType === 'PRICECOMPARISON'"
            >
              <el-select
                v-model="formDate.marketParam.peopleSubType"
                size="mini"
                :disabled="isDisabledFlag"
                placeholder="请选择"
              >
                <el-option
                  v-for="i in highOLowList"
                  :key="i.code"
                  :label="i.name"
                  :value="i.code"
                />
              </el-select>
              竞争航班
              <el-input
                class="width100"
                type="text"
                size="mini"
                v-model.number="formDate.marketParam.peopleSubNumLeft"
                placeholder="请输入"
                clearable
                :disabled="isDisabledFlag"
              />个 至
              <el-input
                class="width100"
                type="text"
                size="mini"
                v-model.number="formDate.marketParam.peopleSubNumRight"
                placeholder="请输入"
                clearable
                :disabled="isDisabledFlag"
              />个
            </el-form-item>
            <el-form-item label="客座率差" v-if="formDate.modelType === 'BC'">
              <el-select
                v-model="formDate.marketParam.seatingSubType"
                size="mini"
                :disabled="isDisabledFlag"
                placeholder="请选择"
              >
                <el-option
                  v-for="i in highOLowList"
                  :key="i.code"
                  :label="i.name"
                  :value="i.code"
                />
              </el-select>
              竞争航班
              <el-input
                class="width100"
                type="text"
                size="mini"
                v-model.number="formDate.marketParam.seatingSubNum"
                placeholder="请输入"
                clearable
                :disabled="isDisabledFlag"
              />%
            </el-form-item>
          </div>
          <!-- 机型参考条件-超售 -->
          <div class="itemBox" v-if="formDate.modelType === 'OVERSOLD'">
            <p class="itemTitle">机型参数条件</p>
            <el-form-item label="是否生效" prop="enable" ref="enable">
              <el-radio-group v-model="formDate.aircraftTypeParam.enable">
                <el-radio
                  v-for="i in enableTypeList"
                  :key="i.code"
                  :label="i.code"
                  >{{ i.name }}</el-radio
                >
              </el-radio-group>
            </el-form-item>
            <el-form-item label="机型">
              <el-select
                class="width100"
                v-model="formDate.aircraftTypeParam.action"
                size="mini"
                :disabled="isDisabledFlag"
                placeholder="请选择"
              >
                <el-option
                  v-for="i in actionTypeList"
                  :key="i.code"
                  :label="i.name"
                  :value="i.code"
                />
              </el-select>
              <el-select
                v-model="formDate.aircraftTypeParam.aircraftTypes"
                size="mini"
                :disabled="isDisabledFlag"
                multiple
                collapse-tags
                placeholder="请选择机型"
              >
                <el-option
                  v-for="i in aircraftTypeList"
                  :key="i.id"
                  :label="i.code"
                  :value="i.id"
                />
              </el-select>
            </el-form-item>
          </div>
        </div>

        <!---------------------------- 分割线右侧表单 ---------------------------->
        <div class="rightBox">
          <div
            v-if="
              formDate.modelType === 'TAKEOFFDATE' ||
                formDate.modelType === 'SPECIALDATECABIN' ||
                formDate.modelType === 'SEATRATE' ||
                formDate.modelType === 'MODELCHANGECABIN'
            "
            class="itemBox"
            v-for="(item, index) of formDate.cabinSwitchParam"
            :key="index"
          >
            <div>
              <span class="itemTitle">{{ `调整策略${index + 1}` }}</span>
              <span
                v-if="
                  !(
                    formDate.modelType === 'CHANGER' ||
                    formDate.modelType === 'BC' ||
                    formDate.modelType === 'PRICECOMPARISON' ||
                    formDate.modelType === 'OVERSOLD' ||
                    isDisabledFlag
                  )
                "
              >
                <i
                  v-if="index === 0"
                  class="el-icon-circle-plus-outline curPoint"
                  @click="addItemBox('cabinSwitchParam')"
                ></i>
                <i
                  v-else
                  class="el-icon-remove-outline curPoint"
                  @click="subItemBox(index, 'cabinSwitchParam')"
                ></i>
              </span>
            </div>
            <el-form-item label="舱位" label-width="70px">
              <el-checkbox-group
                v-model="item.cabinIds"
                :disabled="isDisabledFlag"
              >
                <div v-for="(itm, idx) in cabinListsObj" :key="idx">
                  <el-checkbox
                    v-for="i in itm"
                    :key="i.cabinId"
                    :label="i.cabinId"
                    >{{ i.cabinCode }}</el-checkbox
                  >
                </div>
              </el-checkbox-group>
            </el-form-item>
            <el-form-item
              label="机型"
              label-width="70px"
              v-if="formDate.modelType === 'MODELCHANGECABIN'"
            >
              <el-select
                v-model="item.aircraftTypes"
                size="mini"
                :disabled="isDisabledFlag"
                multiple
                collapse-tags
                placeholder="请选择机型"
              >
                <el-option
                  v-for="i in aircraftTypeList"
                  :key="i.id"
                  :label="i.code"
                  :value="i.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item
              label="调整操作"
              label-width="70px"
              v-if="
                formDate.modelType === 'TAKEOFFDATE' ||
                  formDate.modelType === 'SPECIALDATECABIN' ||
                  formDate.modelType === 'SEATRATE' ||
                  formDate.modelType === 'MODELCHANGECABIN'
              "
            >
              <el-select
                v-model="item.operationType"
                size="mini"
                placeholder="请选择"
                :disabled="isDisabledFlag"
              >
                <el-option
                  v-for="itm in operationTypeList"
                  :key="itm.code"
                  :label="itm.name"
                  :value="itm.code"
                />
              </el-select>
            </el-form-item>
            <el-form-item
              label="调整时间"
              label-width="70px"
              v-if="
                formDate.modelType === 'TAKEOFFDATE' ||
                  formDate.modelType === 'SPECIALDATECABIN' ||
                  formDate.modelType === 'MODELCHANGECABIN'
              "
            >
              <el-time-picker
                v-model="item.operationTime"
                value-format="HH:mm:ss"
                size="mini"
                placeholder="任意时间点"
                :disabled="isDisabledFlag"
              >
              </el-time-picker>
            </el-form-item>
          </div>
          <!-- 特定日期设定配额 、 根据客座率设定配额 -->
          <div
            v-if="
              formDate.modelType === 'SPECIALDATEQUOTA' ||
                formDate.modelType === 'SSETTING'
            "
            class="itemBox"
            v-for="(item, index) of formDate.cabinQuotaParam"
            :key="index"
          >
            <div>
              <span class="itemTitle">{{ `调整策略${index + 1}` }}</span>
              <span
                v-if="
                  !(
                    formDate.modelType === 'CHANGER' ||
                    formDate.modelType === 'BC' ||
                    formDate.modelType === 'PRICECOMPARISON' ||
                    formDate.modelType === 'OVERSOLD' ||
                    isDisabledFlag
                  )
                "
              >
                <i
                  v-if="index === 0"
                  class="el-icon-circle-plus-outline curPoint"
                  @click="addItemBox('cabinQuotaParam')"
                ></i>
                <i
                  v-else
                  class="el-icon-remove-outline curPoint"
                  @click="subItemBox(index, 'cabinQuotaParam')"
                ></i>
              </span>
            </div>
            <el-form-item label="舱位" label-width="70px">
              <el-checkbox-group
                v-model="item.cabinIds"
                :disabled="isDisabledFlag"
              >
                <div v-for="(itm, idx) in cabinListsObj" :key="idx">
                  <el-checkbox
                    v-for="i in itm"
                    :key="i.cabinId"
                    :label="i.cabinId"
                    >{{ i.cabinCode }}</el-checkbox
                  >
                </div>
              </el-checkbox-group>
            </el-form-item>
            <div
              v-if="
                formDate.modelType === 'SPECIALDATEQUOTA' ||
                  formDate.modelType === 'SSETTING'
              "
            >
              <el-form-item label="舱位配额" label-width="70px">
                <el-radio-group
                  v-model="item.quotaBoxType"
                  @change="
                    val => {
                      quotaTypeBoxChange(val, item, index);
                    }
                  "
                >
                  <el-radio :label="1">动态设置</el-radio>
                  <el-radio :label="2">固定设置</el-radio>
                </el-radio-group>
                <div v-if="item.quotaBoxType === 1">
                  在原有配额上
                  <el-select
                    v-model="item.quotaType"
                    size="mini"
                    placeholder="请选择"
                    class="width100"
                    clearable
                    :disabled="isDisabledFlag"
                  >
                    <el-option
                      v-for="itm in quotaTypeList"
                      :key="itm.code"
                      :label="itm.name"
                      :value="itm.code"
                    />
                  </el-select>
                  <el-radio-group
                    v-model="item.rateOrAbsType"
                    clearable
                    @change="
                      val => {
                        rateOrAbsTypeBoxChange(val, item, index);
                      }
                    "
                  >
                    <el-radio label="RATE">
                      比率<el-input
                        class="width100"
                        type="text"
                        size="mini"
                        v-model.number="item.rate"
                        placeholder="请输入比率"
                        clearable
                        :disabled="
                          isDisabledFlag ||
                            item.rateOrAbsType === 'ABS' ||
                            item.rateOrAbsType === ''
                        "
                      ></el-input
                      >%
                    </el-radio>
                    <el-radio label="ABS">
                      绝对值<el-input
                        class="width100"
                        type="text"
                        size="mini"
                        v-model.number="item.abs"
                        placeholder="请输入绝对值"
                        clearable
                        :disabled="
                          isDisabledFlag ||
                            item.rateOrAbsType === 'RATE' ||
                            item.rateOrAbsType === ''
                        "
                      ></el-input
                      >个
                    </el-radio>
                  </el-radio-group>
                </div>
                <div v-else>
                  设为<el-input
                    class="width100"
                    type="text"
                    size="mini"
                    v-model.number="item.num"
                    placeholder="请输入比率"
                    clearable
                    :disabled="isDisabledFlag"
                  ></el-input
                  >个
                </div>
              </el-form-item>
              <el-form-item label="最大配额" label-width="70px">
                比率<el-input
                  class="width100"
                  type="text"
                  size="mini"
                  v-model.number="item.max"
                  placeholder="请输入比率"
                  clearable
                  :disabled="isDisabledFlag"
                ></el-input
                >%
              </el-form-item>
            </div>
          </div>
          <!-- 超售 -->
          <div v-if="formDate.modelType === 'OVERSOLD'" class="itemBox">
            <div>
              <span class="itemTitle">调整策略</span>
            </div>
            <el-form-item label="超售上限" label-width="70px">
              <el-radio-group
                v-model="formDate.oversoldParam.rateOrAbsType"
                clearable
              >
                <el-radio label="RATE">
                  比率<el-input
                    class="width100"
                    type="text"
                    size="mini"
                    v-model.number="formDate.oversoldParam.rate"
                    placeholder="请输入比率"
                    clearable
                    :disabled="
                      isDisabledFlag ||
                        formDate.oversoldParam.rateOrAbsType === 'ABS' ||
                        formDate.oversoldParam.rateOrAbsType === ''
                    "
                  ></el-input
                  >%
                </el-radio>
                <el-radio label="ABS">
                  绝对值<el-input
                    class="width100"
                    type="text"
                    size="mini"
                    v-model.number="formDate.oversoldParam.abs"
                    placeholder="请输入绝对值"
                    clearable
                    :disabled="
                      isDisabledFlag ||
                        formDate.oversoldParam.rateOrAbsType === 'RATE' ||
                        formDate.oversoldParam.rateOrAbsType === ''
                    "
                  ></el-input
                  >个
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
          <!-- 根据客座率调档 -->
          <div v-if="formDate.modelType === 'CHANGER'" class="itemBox">
            <div>
              <span class="itemTitle">调整策略</span>
            </div>
            <el-form-item label="舱位调档" label-width="70px">
              在原档位提高<el-input
                class="width100"
                type="text"
                size="mini"
                v-model.number="formDate.adjustCabinParam.cabinAdjust"
                placeholder="请输入"
                clearable
                :disabled="isDisabledFlag"
              />个档
            </el-form-item>
            <el-form-item label="调档上限" label-width="70px">
              <el-checkbox-group v-model="formDate.adjustCabinParam.adjustMax">
                <el-checkbox
                  v-for="item in adjustMaxList"
                  :key="item.value"
                  :label="`${item.value}-${item.num}`"
                >
                  <span>{{ item.label }}</span>
                  <el-input
                    class="width100"
                    type="text"
                    size="mini"
                    v-model.number="item.num"
                    placeholder="请输入"
                    clearable
                    :disabled="isDisabledFlag"
                    @change="
                      val => {
                        adjustMaxInputChange(val, item);
                      }
                    "
                  />
                </el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </div>
          <!-- 两舱倒挂 -->
          <div v-if="formDate.modelType === 'UPSIDEDOWN'" class="itemBox">
            <div>
              <span class="itemTitle">调整策略</span>
            </div>
            <el-form-item label="调整操作" label-width="70px">
              <el-select
                v-model="formDate.reverseTwoCabinParam.operation"
                size="mini"
                :disabled="isDisabledFlag"
                placeholder="请选择"
              >
                <el-option
                  v-for="i in operationList"
                  :key="i.code"
                  :label="i.name"
                  :value="i.code"
                />
              </el-select>
            </el-form-item>
          </div>

          <!-- 两舱优化 -->
          <div
            v-if="formDate.modelType === 'OPTIMIZE'"
            class="itemBox"
            v-for="(item, index) of formDate.optimizeTwoCabinParam"
            :key="index"
          >
            <div>
              <span class="itemTitle">{{ `调整策略${index + 1}` }}</span>
              <span>
                <i
                  v-if="index === 0"
                  class="el-icon-circle-plus-outline curPoint"
                  @click="addItemBox('optimizeTwoCabinParam')"
                ></i>
                <i
                  v-else
                  class="el-icon-remove-outline curPoint"
                  @click="subItemBox(index, 'optimizeTwoCabinParam')"
                ></i>
              </span>
            </div>
            <el-radio-group
              v-model="item.optimizeTwoCabinType"
              clearable
              @change="val => optimizeTwoCabinTypeChange(val, item, index)"
            >
              <el-radio label="NOT_LESS" style="display:block;">
                <el-form-item
                  label="外放两舱价格不低于"
                  label-width="150px"
                  class="inlineB"
                >
                  <el-cascader
                    v-model="item.notLessIdList"
                    :props="cabinNotListProps"
                    :show-all-levels="false"
                    :options="cabinNotLessThanList"
                    placeholder="请选择"
                    size="mini"
                    clearable
                    collapse-tags
                    @change="
                      val => {
                        cabinNotListChange(val, item, index);
                      }
                    "
                    :disabled="
                      isDisabledFlag ||
                        item.optimizeTwoCabinType === 'NOT_HIGH' ||
                        item.optimizeTwoCabinType === ''
                    "
                  />
                </el-form-item>
              </el-radio>
              <el-radio label="NOT_HIGH" style="display:block;">
                <el-form-item
                  label="外放经济舱价格不高于"
                  label-width="150px"
                  class="inlineB"
                >
                  <el-cascader
                    v-model="item.notHighIdList"
                    :props="cabinNotListProps"
                    :show-all-levels="false"
                    :options="cabinNotHigherThanList"
                    placeholder="请选择"
                    size="mini"
                    clearable
                    collapse-tags
                    @change="
                      val => {
                        cabinNotListChange(val, item, index);
                      }
                    "
                    :disabled="
                      isDisabledFlag ||
                        item.optimizeTwoCabinType === 'NOT_LESS' ||
                        item.optimizeTwoCabinType === ''
                    "
                  />
                </el-form-item>
              </el-radio>
            </el-radio-group>
          </div>

          <!-- 比价 -->
          <div v-if="formDate.modelType === 'PRICECOMPARISON'" class="itemBox">
            <div>
              <span class="itemTitle">调整策略</span>
            </div>
            <el-form-item
              label="外放舱位最低价"
              label-width="150px"
              class="inlineB"
            >
              <el-radio-group
                v-model="formDate.comparePriceParam.statusType"
                clearable
                @change="val => compareTypeChange(val, 'PRICECOMPARISON')"
              >
                <el-radio label="FIXED">动态设置</el-radio>
                <el-radio label="MIN">固定设置</el-radio>
              </el-radio-group>
              <div v-if="formDate.comparePriceParam.statusType === 'FIXED'">
                <el-select
                  v-model="formDate.comparePriceParam.minimumRateType"
                  size="mini"
                  :disabled="isDisabledFlag"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="i in highOLowList"
                    :key="i.code"
                    :label="i.name"
                    :value="i.code"
                  />
                </el-select>
                竞争航班
                <el-input
                  class="width100"
                  type="text"
                  size="mini"
                  v-model.number="formDate.comparePriceParam.value"
                  placeholder="请输入"
                  clearable
                  :disabled="isDisabledFlag"
                />个点
              </div>
              <div v-if="formDate.comparePriceParam.statusType === 'MIN'">
                <el-input
                  class="width100"
                  type="text"
                  size="mini"
                  v-model.number="formDate.comparePriceParam.minMoney"
                  placeholder="请输入"
                  clearable
                  :disabled="isDisabledFlag"
                />元
              </div>
            </el-form-item>
          </div>
          <!-- 比舱 -->
          <div v-if="formDate.modelType === 'BC'" class="itemBox">
            <div>
              <span class="itemTitle">调整策略</span>
            </div>
            <el-form-item
              label="外放舱位最低折扣率"
              label-width="150px"
              class="inlineB"
            >
              <el-radio-group
                v-model="formDate.compareCabinParam.statusType"
                clearable
                @change="val => compareTypeChange(val, 'BC')"
              >
                <el-radio label="FIXED">动态设置</el-radio>
                <el-radio label="MIN">固定设置</el-radio>
              </el-radio-group>
              <div v-if="formDate.compareCabinParam.statusType === 'FIXED'">
                <el-select
                  v-model="formDate.compareCabinParam.minimumRateType"
                  size="mini"
                  :disabled="isDisabledFlag"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="i in highOLowList"
                    :key="i.code"
                    :label="i.name"
                    :value="i.code"
                  />
                </el-select>
                竞争航班
                <el-input
                  class="width100"
                  type="text"
                  size="mini"
                  v-model.number="formDate.compareCabinParam.value"
                  placeholder="请输入"
                  clearable
                  :disabled="isDisabledFlag"
                />个点
              </div>
              <div v-if="formDate.compareCabinParam.statusType === 'MIN'">
                <el-input
                  class="width100"
                  type="text"
                  size="mini"
                  v-model.number="formDate.compareCabinParam.rate"
                  placeholder="请输入"
                  clearable
                  :disabled="isDisabledFlag"
                />%
              </div>
            </el-form-item>
          </div>
        </div>
      </div>
    </el-form>
  </div>
</template>

<script>
import _ from "lodash";
import { set_time } from "@/utils";
import {
  addDomestic,
  domesticCabinList,
  flightList,
  getRuleDetailsById,
  updateDomestic,
  queryAirTypeList,
  queryAdjustList,
  queryTwoCabinList
} from "@/api/settingRules";
import {
  modeTypeList,
  weekList,
  flightModelList,
  vantageList,
  operationTypeList,
  plfTypeList,
  quotaTypeList,
  enableTypeList,
  actionTypeList,
  operationList,
  highOLowList,
  competeFlightList
} from "./common";

export default {
  data() {
    return {
      formDate: {
        modelType: "TAKEOFFDATE", // 调整规则类型
        ruleValidityTimeParam: {
          flightDepartureTime: "", // 航班起飞日期集合
          flightDepartureFromTime: "", // 起飞日期开始时间
          flightDepartureToTime: "", // 起飞日期结束时间
          departureTimeLeft: 0, // 起飞日期区间开始时间
          departureTimeRight: 0, // 起飞日期区间结束时间
          ruleEnableTime: "", // 规则可用时间集合
          ruleEnableTimeLeft: "", // 规则可用开始时间
          ruleEnableTimeRight: "", // 规则可用结束时间
          finalDateLeft: "", // 综合有效期开始时间
          finalDateRight: "" // 综合有效期结束时间
        },
        applicableFlightParam: {
          legNoParams: [], // 航段&航班
          weeks: [], // 星期
          flightModel: "", // 经停/直达
          vantages: [], // 航班优劣势
          flightDate: "", // 航班始发时间集合
          flightFromDate: "", // 航班开始时间
          flightToDate: "" // 航班结束时间
        },
        cabinOpenParam: {
          // 舱位开放条件
          cabinIds: []
        },
        competeFlightParam: {
          //竞争航班条件
          contrastMode: "",
          legNoParams: [],
          flightDate: "", // 航班始发时间集合
          flightFromDate: "",
          flightToDate: ""
        },
        marketParam: {
          marketRangeLeft: "", // 市场占有率范围
          marketRangeRight: "", // 市场占有率范围
          seatingRateType: "", //  客座率范围类型
          seatingRateLeft: "", //  客座率范围L
          seatingRateRight: "", //  客座率范围R
          peopleSubType: "", // 人数差
          peopleSubNumLeft: "", // 竞争航班from
          peopleSubNumRight: "", // 竞争航班to
          seatingSubType: "",
          seatingSubNum: ""
        },
        aircraftTypeParam: {
          enable: "", // 是否生效
          action: "", // 机型 应用于/排除于
          aircraftTypes: []
        },
        cabinSwitchParam: [
          {
            cabinIds: [],
            aircraftTypes: [],
            operationType: "",
            operationTime: ""
          }
        ],
        cabinQuotaParam: [
          {
            cabinIds: [],
            quotaBoxType: 1,
            rateOrAbsType: "",
            quotaType: "",
            rate: "",
            abs: "",
            num: "",
            max: ""
          }
        ],
        oversoldParam: {
          rateOrAbsType: "",
          abs: "",
          rate: ""
        },
        adjustCabinParam: {
          cabinAdjust: "",
          adjustMax: []
        },
        // 比舱
        compareCabinParam: {
          statusType: "FIXED",
          minimumRateType: "",
          value: "",
          rate: "" //最低折扣率
        },
        // 比价
        comparePriceParam: {
          statusType: "FIXED",
          minimumRateType: "",
          value: "",
          minMoney: "" //外放舱位最低价
        },
        // 两舱倒挂
        reverseTwoCabinParam: {
          operation: ""
        },
        // 两舱优化
        optimizeTwoCabinParam: [
          {
            optimizeTwoCabinType: "", // 'NOT_LESS' : 'NOT_HIGH'
            notLessId: "", //外放两舱价格不低于
            notHighId: "", //外放经济舱价格不高于
            notLessIdList: [], //外放经济舱价格不低于集合
            notHighIdList: [] //外放经济舱价格不高于集合
          }
        ]
      },
      rules: {
        modelType: [
          { required: !0, message: "请选择调仓规则", trigger: "change" }
        ]
      },
      modeTypeList, // 规则类型列表
      weekList, // 星期
      flightModelList, // 经停/直达
      vantageList, // 航班优劣势
      operationTypeList, // 调整操作
      quotaTypeList, // 配额类型列表
      plfTypeList, // 客座率范围
      enableTypeList, // 生效类型列表
      actionTypeList, // 机型作用类型列表
      operationList, // 两舱倒挂策略类型列表
      highOLowList, // 比舱比价折扣率高低列表
      competeFlightList, // 竞争航班条件对比模式列表
      cabinListsObj: [],
      competeFlyNoList: [],
      competeFlyNoProps: {
        label: "flightNo",
        value: "flightNo",
        children: "flightNoParam",
        multiple: true
      },
      flyNoList: [],
      flyNoListProps: {
        label: "flightNo",
        value: "flightNo",
        children: "flightNoParam",
        multiple: true
      },
      cabinNotLessThanList: [], // 外放两舱价格不低于列表
      cabinNotHigherThanList: [], // 外放经济舱价格不高于列表
      cabinNotListProps: {
        label: "code",
        value: "id",
        children: "cabins"
        // multiple: true
        // checkStrictly: true
      },
      cabinNotCollectList: [],
      minTime: 1618891200000, //时间戳，对应时间为：'2021-04-20 12:00:00'
      maxTime: 1619323200000, //时间戳，对应时间为：'2021-04-25 12:00:00'
      startPickerOptions: {
        disabledDate: time => {
          //小于最小时间或者大于最大时间都不可选
          return time.getTime() < this.minTime || time.getTime() > this.maxTime;
        }
      },
      isEditFlag: false,
      isPreviewFlag: this.$route.query.isPreviewFlag,
      aircraftTypeList: [
        {
          id: "1101", //机型id
          code: "AVC738" //机型code
        },
        {
          id: "1102", //机型id
          code: "AVC739" //机型code
        }
      ],
      adjustMaxList: [
        {
          value: "toudengcang",
          label: "头等舱",
          num: 0
        },
        {
          value: "jingjicang",
          label: "经济舱",
          num: 0
        },
        {
          value: "gaojicang",
          label: "高级舱",
          num: 0
        },
        {
          value: "gaojijignjicang",
          label: "高级经济舱",
          num: 0
        }
      ]
    };
  },
  watch: {
    "formDate.ruleValidityTimeParam.finalDateLeft": {
      deep: true,
      handler(val) {
        this.getFlightList();
      }
    },
    "formDate.ruleValidityTimeParam.finalDateRight": {
      deep: true,
      handler(val) {
        this.getFlightList();
      }
    }
  },
  computed: {
    // isPreviewFlag() {
    //   return this.$route.query.isPreviewFlag;
    // },
    isDisabledFlag() {
      let flag = this.isPreviewFlag && !this.isEditFlag;
      return flag;
    }
  },
  created() {},
  mounted() {
    this.getDomesticCabinList(); //  舱位列表
    this.getQueryAdjustList(); //  调档上限列表
    this.getQueryAirTypeList(); //  机型列表
    this.getCabinNotFlightList(); // 两舱优化下拉框列表
    if (this.isPreviewFlag) {
      this.getPreviewData();
    }
  },
  methods: {
    init(val) {
      // this.$refs["formDateRef"] && this.$refs["formDateRef"].resetFields();
      this.formDate = {
        modelType: val || "TAKEOFFDATE",
        ruleValidityTimeParam: {
          flightDepartureTime: "", // 航班起飞日期集合
          flightDepartureFromTime: "", // 起飞日期开始时间
          flightDepartureToTime: "", // 起飞日期结束时间
          departureTimeLeft: 0, // 起飞日期区间开始时间
          departureTimeRight: 0, // 起飞日期区间结束时间
          ruleEnableTime: "", // 规则可用时间集合
          ruleEnableTimeLeft: "", // 规则可用开始时间
          ruleEnableTimeRight: "", // 规则可用结束时间
          finalDateLeft: "", // 综合有效期开始时间
          finalDateRight: "" // 综合有效期结束时间
        },
        applicableFlightParam: {
          legNoParams: [], // 航段&航班
          weeks: [], // 星期
          flightModel: "", // 经停/直达
          vantages: [], // 航班优劣势
          flightDate: "", // 航班始发时间集合
          flightFromDate: "", // 航班开始时间
          flightToDate: "" // 航班结束时间
        },
        cabinOpenParam: {
          // 舱位开放条件
          cabinIds: []
        },
        competeFlightParam: {
          //竞争航班条件
          contrastMode: "",
          legNoParams: [],
          flightDate: "", // 航班始发时间集合
          flightFromDate: "",
          flightToDate: ""
        },
        marketParam: {
          marketRangeLeft: "", // 市场占有率范围
          marketRangeRight: "", // 市场占有率范围
          seatingRateType: "", //  客座率范围类型
          seatingRateLeft: "", //  客座率范围L
          seatingRateRight: "", //  客座率范围R
          peopleSubType: "", // 人数差
          peopleSubNumLeft: "", // 竞争航班from
          peopleSubNumRight: "", // 竞争航班to
          seatingSubType: "",
          seatingSubNum: ""
        },
        aircraftTypeParam: {
          enable: "", // 是否生效
          action: "", // 机型 应用于/排除于
          aircraftTypes: []
        },
        cabinSwitchParam: [
          {
            cabinIds: [],
            aircraftTypes: [],
            operationType: "",
            operationTime: ""
          }
        ],
        cabinQuotaParam: [
          {
            cabinIds: [],
            quotaBoxType: 1,
            rateOrAbsType: "",
            quotaType: "",
            rate: "",
            abs: "",
            num: "",
            max: ""
          }
        ],
        oversoldParam: {
          rateOrAbsType: "",
          abs: "",
          rate: ""
        },
        adjustCabinParam: {
          cabinAdjust: "",
          adjustMax: []
        },
        // 比舱
        compareCabinParam: {
          statusType: "FIXED",
          minimumRateType: "",
          value: "",
          rate: "" //最低折扣率
        },
        // 比价
        comparePriceParam: {
          statusType: "FIXED",
          minimumRateType: "",
          value: "",
          minMoney: "" //外放舱位最低价
        },
        // 两舱倒挂
        reverseTwoCabinParam: {
          operation: ""
        },
        // 两舱优化
        optimizeTwoCabinParam: [
          {
            optimizeTwoCabinType: "", // 'NOT_LESS' : 'NOT_HIGH'
            notLessId: "", //外放两舱价格不低于
            notHighId: "",
            notLessIdList: [], //外放经济舱价格不低于集合
            notHighIdList: [] //外放经济舱价格不高于集合
          }
        ]
      };
      this.flyNoList = [];

      // 获取舱位列表
      this.getDomesticCabinList();
    },
    adjustMaxInputChange(val, item) {
      if (this.formDate.adjustCabinParam.adjustMax.length) {
        let deleteIdx = -1;
        this.formDate.adjustCabinParam.adjustMax.forEach((i, idx) => {
          let id = i.split("-")[0];
          if (id === item.value) {
            deleteIdx = idx;
          }
        });
        deleteIdx != -1 &&
          this.formDate.adjustCabinParam.adjustMax.splice(deleteIdx, 1);
      }
      this.formDate.adjustCabinParam.adjustMax.push(`${item.value}-${val}`);
    },
    getPreviewData() {
      let info = {
        id: this.$route.query.id,
        autoModelEnum: this.$route.query.autoModelEnum
      };
      getRuleDetailsById(info)
        .then(res => {
          const response = _.cloneDeep(res.data.data);
          this.setFormData(response);
        })
        .catch();
    },
    setFormData(res) {
      this.formDate = { ...this.formDate, ...res };

      if (
        res.ruleValidityTimeParam.flightDepartureFromTime &&
        res.ruleValidityTimeParam.flightDepartureToTime
      ) {
        this.formDate.ruleValidityTimeParam.flightDepartureTime = [
          res.ruleValidityTimeParam.flightDepartureFromTime,
          res.ruleValidityTimeParam.flightDepartureToTime
        ];
      }

      if (
        res.ruleValidityTimeParam.ruleEnableTimeLeft &&
        res.ruleValidityTimeParam.ruleEnableTimeRight
      ) {
        this.formDate.ruleValidityTimeParam.ruleEnableTime = [
          res.ruleValidityTimeParam.ruleEnableTimeLeft,
          res.ruleValidityTimeParam.ruleEnableTimeRight
        ];
      }

      if (
        res.applicableFlightParam.flightFromDate &&
        res.applicableFlightParam.flightToDate
      ) {
        this.formDate.applicableFlightParam.flightDate = [
          res.applicableFlightParam.flightFromDate,
          res.applicableFlightParam.flightToDate
        ];
      }
      if (
        res.competeFlightParam.flightFromDate &&
        res.competeFlightParam.flightToDate
      ) {
        this.formDate.competeFlightParam.flightDate = [
          res.competeFlightParam.flightFromDate,
          res.competeFlightParam.flightToDate
        ];
      }

      if (
        res.applicableFlightParam.legNoParams &&
        res.applicableFlightParam.legNoParams.length
      ) {
        let arr = [];
        res.applicableFlightParam.legNoParams.forEach(itm => {
          arr.push([itm.flightLeg, itm.flightNo]);
        });
        this.formDate.applicableFlightParam.legNoParams = arr;
      }
      if (
        res.competeFlightParam.legNoParams &&
        res.competeFlightParam.legNoParams.length
      ) {
        let arr = [];
        res.competeFlightParam.legNoParams.forEach(itm => {
          arr.push([itm.flightLeg, itm.flightNo]);
        });
        this.formDate.competeFlightParam.legNoParams = arr;
      }

      if (res.adjustCabinParam && res.adjustCabinParam.adjustMax.length) {
        let arr = [];
        res.adjustCabinParam.adjustMax.forEach(itm => {
          arr.push(`${itm.name}-${itm.max}`);

          this.adjustMaxList.forEach(i => {
            if (i.value === itm.name) {
              i.num = itm.max;
            }
          });
        });
        this.formDate.adjustCabinParam.adjustMax = arr;
      }
      // 两舱优化策略
      if (res.optimizeTwoCabinParam && res.optimizeTwoCabinParam.length) {
        res.optimizeTwoCabinParam.forEach(itm => {
          if (itm.optimizeTwoCabinType === "NOT_LESS") {
            itm["notLessIdList"] = [null, itm.notLessId];
          } else {
            itm["notHighIdList"] = [null, itm.notHighId];
          }
        });
        this.formDate.optimizeTwoCabinParam = res.optimizeTwoCabinParam;
      }
    },
    // 获取航段航班列表
    getFlightList() {
      let info = {};
      this.formDate.ruleValidityTimeParam.finalDateLeft &&
        (info.fromDateDefault =
          this.formDate.ruleValidityTimeParam.finalDateLeft + " 00:00:00");
      this.formDate.ruleValidityTimeParam.finalDateRight &&
        (info.toDateDefault =
          this.formDate.ruleValidityTimeParam.finalDateRight + " 00:00:00");
      flightList(info)
        .then(res => {
          const response = _.cloneDeep(res.data.data);
          this.flyNoList = response || [];
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 获取两舱价格列表
    getCabinNotFlightList() {
      queryTwoCabinList()
        .then(res => {
          const response = _.cloneDeep(res.data.data);
          this.cabinNotLessThanList = response.twoCabins || [];
          this.cabinNotHigherThanList = response.notTwoCabins || [];
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 获取舱位列表
    getDomesticCabinList() {
      domesticCabinList()
        .then(res => {
          const response = _.cloneDeep(res.data.data);
          this.cabinListsObj = response || [];
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 获取调档上限列表
    getQueryAdjustList() {
      queryAdjustList()
        .then(res => {
          const response = _.cloneDeep(res.data.data);
          this.adjustMaxList = response || [];
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 获取机型列表
    getQueryAirTypeList() {
      queryAirTypeList()
        .then(res => {
          const response = _.cloneDeep(res.data.data);
          this.aircraftTypeList = response || [];
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 调仓规则切换钩子
    changeModeType(val) {
      this.init(val);
    },
    // 起飞日期切换钩子
    flightDepartureTimeChangeFn() {
      this.formDate.ruleValidityTimeParam.flightDepartureFromTime = this.formDate.ruleValidityTimeParam.flightDepartureTime[0];
      this.formDate.ruleValidityTimeParam.flightDepartureToTime = this.formDate.ruleValidityTimeParam.flightDepartureTime[1];

      this.formDate.ruleValidityTimeParam.ruleEnableTime = "";
      this.formDate.ruleValidityTimeParam.ruleEnableTimeLeft = "";
      this.formDate.ruleValidityTimeParam.ruleEnableTimeRight = "";
      this.departureTimeChange();
    },
    // 规则可用日期钩子
    ruleEnableTimeChange() {
      this.formDate.ruleValidityTimeParam.ruleEnableTimeLeft = this.formDate.ruleValidityTimeParam.ruleEnableTime[0];
      this.formDate.ruleValidityTimeParam.ruleEnableTimeRight = this.formDate.ruleValidityTimeParam.ruleEnableTime[1];
    },
    // 航班起飞时间范围日期
    departureTimeChange() {
      if (
        !(
          this.formDate.ruleValidityTimeParam.flightDepartureToTime &&
          this.formDate.ruleValidityTimeParam.flightDepartureFromTime
        )
      ) {
        this.$message.warning("请先填写起飞日期！");
        return !1;
      }

      if (
        this.formDate.ruleValidityTimeParam.departureTimeLeft <=
        this.formDate.ruleValidityTimeParam.departureTimeRight
      ) {
        let fromTime = this.formDate.ruleValidityTimeParam.flightDepartureFromTime.replace(
          /-/g,
          "/"
        );
        let fromDate = new Date(fromTime);
        let fromTimeStr = fromDate.getTime();

        let toTime = this.formDate.ruleValidityTimeParam.flightDepartureToTime.replace(
          /-/g,
          "/"
        );
        let toDate = new Date(toTime);
        let toTimeStr = toDate.getTime();

        this.minTime =
          fromTimeStr -
          this.formDate.ruleValidityTimeParam.departureTimeRight *
            24 *
            60 *
            60 *
            1000;
        this.formDate.ruleValidityTimeParam.finalDateLeft = set_time(
          fromTimeStr -
            this.formDate.ruleValidityTimeParam.departureTimeRight *
              24 *
              60 *
              60 *
              1000
        );
        this.maxTime =
          toTimeStr -
          this.formDate.ruleValidityTimeParam.departureTimeLeft *
            24 *
            60 *
            60 *
            1000;
        this.formDate.ruleValidityTimeParam.finalDateRight = set_time(
          toTimeStr -
            this.formDate.ruleValidityTimeParam.departureTimeLeft *
              24 *
              60 *
              60 *
              1000
        );
      } else {
        this.$message.warning("请正确填写时间！");
      }
    },

    // 星期勾选钩子
    handleCheckedweekChange(val) {
      let arr = _.cloneDeep(val);
      if (arr[arr.length - 1] === "ALL") {
        this.formDate.applicableFlightParam.weeks = ["ALL"];
      } else {
        arr.includes("ALL") &&
          arr.splice(
            arr.findIndex(i => {
              return i === "ALL";
            }),
            1
          );
        this.formDate.applicableFlightParam.weeks = arr;
      }
    },
    // 经停/直达勾选钩子
    handleCheckedflightModelChange(val) {},
    // 航班优劣势勾选钩子
    handleCheckedvantageChange(val) {
      let arr = _.cloneDeep(val);
      if (arr[arr.length - 1] === "ALL") {
        this.formDate.applicableFlightParam.vantages = ["ALL"];
      } else {
        arr.includes("ALL") &&
          arr.splice(
            arr.findIndex(i => {
              return i === "ALL";
            }),
            1
          );
        this.formDate.applicableFlightParam.vantages = arr;
      }
    },
    flightDateChange(val, type) {
      if (type === "competeFlightParam") {
        this.formDate.competeFlightParam.flightFromDate = this.formDate.competeFlightParam.flightDate[0];
        this.formDate.competeFlightParam.flightToDate = this.formDate.competeFlightParam.flightDate[1];
      } else {
        this.formDate.applicableFlightParam.flightFromDate = this.formDate.applicableFlightParam.flightDate[0];
        this.formDate.applicableFlightParam.flightToDate = this.formDate.applicableFlightParam.flightDate[1];
      }
    },

    // 新增新的调整策略框
    addItemBox(type) {
      if (type === "cabinSwitchParam") {
        this.formDate.cabinSwitchParam.push({
          cabinIds: [],
          aircraftTypes: [],
          operationType: "",
          operationTime: ""
        });
      }
      if (type === "cabinQuotaParam") {
        this.formDate.cabinQuotaParam.push({
          cabinIds: [],
          quotaBoxType: 1,
          rateOrAbsType: "",
          quotaType: "",
          rate: "",
          abs: "",
          num: "",
          max: ""
        });
      }
      if (type === "optimizeTwoCabinParam") {
        this.formDate.optimizeTwoCabinParam.push({
          optimizeTwoCabinType: "", // 'NOT_LESS' : 'NOT_HIGH'
          notLessId: "", //外放两舱价格不低于
          notHighId: "",
          notLessIdList: "", //外放经济舱价格不低于集合
          notHighIdList: ""
        });
      }
    },
    // 删除调整策略框
    subItemBox(index, type) {
      type === "cabinSwitchParam" &&
        this.formDate.cabinSwitchParam.splice(index, 1);
      type === "cabinQuotaParam" &&
        this.formDate.cabinQuotaParam.splice(index, 1);
      type === "optimizeTwoCabinParam" &&
        this.formDate.optimizeTwoCabinParam.splice(index, 1);
    },
    quotaTypeBoxChange(val, item, index) {
      this.formDate.cabinQuotaParam[index].quotaBoxType = val;
      if (val === 1) {
        this.formDate.cabinQuotaParam[index].num = "";
      } else {
        this.formDate.cabinQuotaParam[index].quotaType = "";
        this.formDate.cabinQuotaParam[index].rateOrAbsType = "";
        this.formDate.cabinQuotaParam[index].rate = "";
        this.formDate.cabinQuotaParam[index].abs = "";
      }
    },
    rateOrAbsTypeBoxChange(val, item, index) {
      this.formDate.cabinQuotaParam[index].rateOrAbsType = val;
      if (val === "RATE") {
        this.formDate.cabinQuotaParam[index].abs = "";
      } else {
        this.formDate.cabinQuotaParam[index].rate = "";
      }
    },
    optimizeTwoCabinTypeChange(val, item, index) {
      if (val === "NOT_LESS") {
        this.formDate.optimizeTwoCabinParam[index].notHighId = "";
        this.formDate.optimizeTwoCabinParam[index].notHighIdList = [];
      } else {
        this.formDate.optimizeTwoCabinParam[index].notLessId = "";
        this.formDate.optimizeTwoCabinParam[index].notLessIdList = [];
      }
    },
    cabinNotListChange(val, item, index) {
      if (item.optimizeTwoCabinType === "NOT_LESS") {
        this.formDate.optimizeTwoCabinParam[index].notLessId =
          item.notLessIdList[1];
      } else {
        this.formDate.optimizeTwoCabinParam[index].notHighId =
          item.notHighIdList[1];
      }
    },

    compareTypeChange(val, type) {
      if (type === "BC") {
        if (val === "FIXED") {
          this.formDate.compareCabinParam.rate = "";
        } else {
          this.formDate.compareCabinParam.minimumRateType = "";
          this.formDate.compareCabinParam.value = "";
        }
      } else {
        if (val === "FIXED") {
          this.formDate.comparePriceParam.minMoney = "";
        } else {
          this.formDate.comparePriceParam.minimumRateType = "";
          this.formDate.comparePriceParam.value = "";
        }
      }
    },

    getQuery() {
      let query = _.cloneDeep(this.formDate);
      query.finalDateLeft = this.formDate.ruleValidityTimeParam.finalDateLeft;
      query.finalDateRight = this.formDate.ruleValidityTimeParam.finalDateRight;
      if (query.applicableFlightParam.legNoParams.length) {
        let arr = [];
        query.applicableFlightParam.legNoParams.forEach(item => {
          arr.push({
            flightLeg: item[0],
            flightNo: item[1]
          });
        });
        query.applicableFlightParam.legNoParams = arr;
      }
      if (query.competeFlightParam.legNoParams.length) {
        let arr = [];
        query.competeFlightParam.legNoParams.forEach(item => {
          arr.push({
            flightLeg: item[0],
            flightNo: item[1]
          });
        });
        query.competeFlightParam.legNoParams = arr;
      }

      if (query.adjustCabinParam && query.adjustCabinParam.adjustMax.length) {
        let arr = [];
        query.adjustCabinParam.adjustMax.forEach(i => {
          arr.push({
            name: i.split("-")[0],
            max: i.split("-")[1]
          });
        });
        query.adjustCabinParam.adjustMax = arr;
      }

      console.log("最终参数", query);
      return query;
    },
    // 最终提交
    onSubmit() {
      this.$refs["formDateRef"].validate((valid, rules) => {
        if (valid) {
          const query = _.cloneDeep(this.getQuery());
          if (this.isEditFlag) {
            query.id = this.$route.query.id;
            updateDomestic(query)
              .then(res => {
                if (res.data.code === "200") {
                  this.$message.success("更新成功！");
                  this.$router.push({ name: "ruleEstablishment" });
                }
              })
              .catch(err => {
                console.log(err);
              });
          } else {
            addDomestic(query)
              .then(res => {
                if (res.data.code === "200") {
                  this.$message.success("新增成功！");
                  this.$router.push({ name: "ruleEstablishment" });
                }
              })
              .catch(err => {
                console.log(err);
              });
          }
        } else {
          this.$message.warning("提交失败，请填写完整信息");
          return !1;
        }
      });
    },
    onEdit() {
      this.isEditFlag = true;
    },
    onCloneData() {
      const query = _.cloneDeep(this.getQuery());
    }
  }
};
</script>

<style lang="scss" scoped>
.addRulePage {
  padding: 70px 10px 0;
  .titleBox {
    box-sizing: border-box;
    padding: 10px 2px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .contentBox {
    margin-top: 10px;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    box-sizing: border-box;
    .leftBox {
      flex: 1;
      border-right: 1px dashed #999;
      box-sizing: border-box;
    }
    .rightBox {
      flex: 1;
      box-sizing: border-box;
    }
    .itemBox {
      box-sizing: border-box;
      border: 1px solid #999;
      border-radius: 10px;
      margin: 8px 8px 10px;
      padding: 10px;
      .itemTitle {
        margin: 0;
        padding: 4px 0;
        font-weight: 600;
        color: #f59a23;
        vertical-align: middle;
      }
    }
  }
}
::v-deep .el-form-item {
  margin-bottom: 8px;
}
::v-deep .el-form-item__error {
  padding-top: 0;
}
::v-deep .el-checkbox {
  margin-right: 10px;
}
.curPoint {
  vertical-align: middle;
  cursor: pointer;
  font-size: 18px;
  &:hover {
    color: #f59a23;
  }
}
.width100 {
  width: 100px;
}
.radioBg {
  background-color: #fff !important;
  padding-left: 0 !important;
}
.inlineB {
  display: inline-block;
}
</style>
