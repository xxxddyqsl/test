// 规则状态列表
export const statusList = [
  { name: "启用中", code: 1 },
  { name: "禁用中", code: 2 },
  { name: "有效", code: 3 },
  { name: "失效", code: 4 }
];

// 规则类型列表
export const modeTypeList = [
  { name: "起飞日期", code: "TAKEOFFDATE" },
  { name: "特定日期舱位调整", code: "SPECIALDATECABIN" },
  { name: "特定日期设定配额", code: "SPECIALDATEQUOTA" },
  { name: "超售", code: "OVERSOLD" },
  { name: "客座率", code: "SEATRATE" },
  { name: "根据客座率设定配额", code: "SSETTING" },
  { name: "根据客座率调档", code: "CHANGER" },
  { name: "根据机型调舱", code: "MODELCHANGECABIN" },
  { name: "比舱", code: "BC" },
  { name: "实时比价", code: "PRICECOMPARISON" },
  { name: "两舱倒挂", code: "UPSIDEDOWN" },
  { name: "两舱优化", code: "OPTIMIZE" }
];

// 星期
export const weekList = [
  { name: "全部", code: "ALL" },
  { name: "周日", code: "SUN" },
  { name: "周一", code: "MON" },
  { name: "周二", code: "TUE" },
  { name: "周三", code: "WED" },
  { name: "周四", code: "THU" },
  { name: "周五", code: "FRI" },
  { name: "周六", code: "SAT" }
];

// 经停/直达
export const flightModelList = [
  { name: "全部", code: "ALL" },
  { name: "经停", code: "STOPOVER" },
  { name: "直达", code: "DIRECT" }
];

// 航班优劣势
export const vantageList = [
  { name: "全部", code: "ALL" },
  { name: "极优势", code: "MOST_ADVANTAGE" },
  { name: "优势", code: "ADVANTAGE" },
  { name: "均势", code: "BALANCE" },
  { name: "劣势", code: "INFERIOR" },
  { name: "极劣势", code: "MOST_INFERIOR" }
];

// 调整操作
export const operationTypeList = [
  { name: "开放", code: "OPEN" },
  { name: "关闭", code: "CLOSE" }
];

// 配额类型列表
export const quotaTypeList = [
  { name: "增加", code: "INCREASE" },
  { name: "减少", code: "REDUCE" }
];
// 生效类型列表
export const enableTypeList = [
  { name: "生效", code: "ENABLE" },
  { name: "不生效", code: "DISABLE" }
];
// 机型作用类型列表
export const actionTypeList = [
  { name: "应用于", code: "EFFECT" },
  { name: "排除于", code: "EXCLUDE" }
];
// 两舱倒挂策略类型列表
export const operationList = [
  { name: "关闭高价的低仓位", code: "CLOSE_HIGH_ECONOMY" },
  { name: "关闭低价的高仓位", code: "CLOSE_LOW_BUSINESS" }
];
// 客座率范围
export const plfTypeList = [
  { name: "头等舱", code: "FIRST" },
  { name: "商务舱", code: "BUSINESS" },
  { name: "两舱", code: "TWO_CABIN" },
  { name: "经济舱", code: "ECONOMY" },
  { name: "整体", code: "ALL" }
];
// 比舱比价折扣率高低列表
export const highOLowList = [
  { name: "高于", code: "HIGH" },
  { name: "低于", code: "LOW" }
];
// 竞争航班条件对比模式列表
export const competeFlightList = [
  { name: "本外航对比", code: "COMPETE_OUTSIDE_FLIGHT" },
  { name: "本航间对比", code: "COMPETE_INSIDE_FLIGHT" }
];
