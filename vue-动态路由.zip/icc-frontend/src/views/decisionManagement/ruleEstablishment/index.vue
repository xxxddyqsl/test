<template>
  <div class="pageBox">
    <div class="seachBox">
      <div class="title_left">
        <el-radio-group v-model="radio" @change="pageChange">
          <el-radio-button label="国内自动调舱规则" />
          <el-radio-button label="航班人工关舱规则" />
          <el-radio-button label="航班白名单规则" />
        </el-radio-group>
      </div>

      <div v-if="radio == '国内自动调舱规则'" class="title_right">
        <el-form :inline="true" :model="formInlineOne">
          <el-form-item>
            <el-input
              v-model="formInlineOne.modelSerialNumber"
              style="width:120px"
              size="mini"
              placeholder="规则编号"
            />
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="formInlineOne.modelType"
              clearable
              size="mini"
              style="width:120px"
              placeholder="规则模型"
            >
              <el-option
                v-for="item in modeTypeList"
                :key="item.code"
                :label="item.name"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="formInlineOne.flightLeg"
              size="mini"
              style="width:120px"
              placeholder="航段"
            />
          </el-form-item>

          <el-form-item>
            <el-date-picker
              v-model="formInlineOne.date"
              type="date"
              size="mini"
              placeholder="生效日期"
              style="width:140px"
              value-format="yyyy-MM-dd"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="formInlineOne.createUser"
              size="mini"
              style="width:120px"
              placeholder="创建用户"
            />
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="formInlineOne.status"
              clearable
              size="mini"
              style="width:120px"
              placeholder="规则状态"
            >
              <el-option
                v-for="item in statusList"
                :key="item.code"
                :label="item.name"
                :value="item.code"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              size="mini"
              @click="getListOne(1)"
            >查询</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="onResetOne"
            >重置</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="onAddNewOne(false)"
            >添加</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div v-if="radio == '航班人工关舱规则'" class="title_right">
        <!-- 航班人工关舱规则 -->
        <el-form :inline="true" :model="formInline1">
          <el-form-item>
            <el-switch
              v-model="formInline1.value1"
              active-text="有效规则"
              inactive-text="全部规则"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="formInline1.flightLeg"
              style="width:100px"
              size="mini"
              placeholder="航段"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="formInline1.flightNo"
              style="width:100px"
              size="mini"
              placeholder="航班号"
            />
          </el-form-item>

          <el-form-item>
            <el-select
              v-model="formInline1.closeList"
              clearable
              size="mini"
              multiple
              collapse-tags
              style="width:120px"
              placeholder="舱位"
            >
              <el-option
                v-for="item in cabintList"
                :key="item.cabinId"
                :value="item.cabinId"
                :label="item.cabinCode"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="formInline1.flightDate"
              value-format="yyyy-MM-dd HH:mm:ss"
              size="mini"
              type="datetime"
              style="width:180px"
              placeholder="航班日期"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="formInline1.createUser"
              style="width:100px"
              size="mini"
              placeholder="创建用户"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              size="mini"
              @click="onQueryTwo"
            >查询</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="onAddNewTwo"
            >添加</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="onResetTwo"
            >重置</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div v-if="radio == '航班白名单规则'" class="title_right">
        <!-- 航班白名单规则 -->
        <el-form :inline="true" :model="WhitelistRuleForm">
          <el-form-item>
            <el-switch
              v-model="WhitelistRuleForm.isValid"
              active-text="有效规则"
              inactive-text="全部规则"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="WhitelistRuleForm.flightLeg"
              style="width:100px"
              size="mini"
              placeholder="航段"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="WhitelistRuleForm.flightNo"
              style="width:100px"
              size="mini"
              placeholder="航班号"
            />
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="WhitelistRuleForm.whiteListCabinRefList"
              clearable
              multiple
              size="mini"
              style="width:120px"
              placeholder="舱位"
            >
              <el-option
                v-for="item in cabintList"
                :key="item.cabinId"
                :label="item.cabinCode"
                :value="item.cabinId"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="WhitelistRuleForm.date"
              format="yyyy 年 MM 月 dd 日"
              value-format="yyyy-MM-dd HH:mm:ss"
              size="mini"
              type="daterange"
              range-separator="至"
              start-placeholder="开始航班日期"
              end-placeholder="结束航班日期"
            />
          </el-form-item>
          <el-form-item>
            <el-input
              v-model="WhitelistRuleForm.createUser"
              style="width:120px"
              size="mini"
              placeholder="创建用户"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              size="mini"
              @click="WhitelistRuleFormQuery"
            >查询</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="whitelistRuleFormSet"
            >重置</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="WhitelistRuleFormAdd"
            >添加</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <!-- 列表 -->
    <div v-if="radio == '国内自动调舱规则'">
      <el-table ref="tableOne" :data="tableDataOne" border>
        <el-table-column prop="serialNumber" label="规则编号" min-width="120" />
        <el-table-column prop="modelName" label="规则类型" min-width="100">
          <template slot-scope="scope">
            <div @click="onAddNewOne(true, scope.row)">
              {{ scope.row.modelName }}
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="flightLeg" label="航线概况" min-width="100" />
        <el-table-column label="生效日期" width="160">
          <template slot-scope="scope">
            <span>
              {{ `${scope.row.finalDateLeft}-${scope.row.finalDateRight}` }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="createUser" label="创建用户" width="100" />
        <el-table-column prop="updateTime" label="更新时间" width="100" />
        <el-table-column label="操作" width="260" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="primary"
              size="mini"
              @click="onAddNewOne(true, scope.row)"
            >预览/编辑</el-button>
            <el-button type="primary" size="mini">{{
              statusBtnRender(scope.row)
            }}</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="onDeleteOne(scope.row)"
            >删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        :page-size="pageOne.pageSize"
        layout="total, prev, pager, next"
        :total="pageOne.total"
        @current-change="handleCurrentChangeOne"
      />
    </div>
    <div v-if="radio == '航班人工关舱规则'">
      <el-table ref="tableTwo" :data="tableDataTwo" border>
        <el-table-column prop="flightNo" label="航班号" />
        <el-table-column label="航段">
          <template slot-scope="scope">
            {{ scope.row.flightLeg }}
          </template>
        </el-table-column>
        <el-table-column label="关舱列表">
          <template slot-scope="scope">
            <span v-for="(item, index) in scope.row.closeListCode" :key="index">
              {{ item }}
            </span>
          </template>
        </el-table-column>

        <el-table-column label="航班日期" width="300">
          <template slot-scope="scope">
            {{ scope.row.fromDate }}-{{ scope.row.toDate }}
          </template>
        </el-table-column>

        <el-table-column prop="offSet" label="提前天数" />
        <el-table-column prop="createUser" label="创建用户" />
        <el-table-column prop="updateTime" label="更新时间">
          <template slot-scope="scope">
            {{ scope.row.updateTime }}
          </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="primary"
              style="margin:0 5px"
              size="mini"
              @click="onEditTwo(scope.row)"
            >修改</el-button>
            <el-button
              type="primary"
              style="margin:0 5px"
              size="mini"
              @click="onDeleteTwo(scope.row)"
            >删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        :page-size="pageTwo.pageSize"
        layout="total, prev, pager, next"
        :total="pageTwo.total"
        @size-change="handleSizeChange_two"
        @current-change="handleCurrentChangeTwo"
      />
      <div>
        <el-dialog
          v-dialogDrag
          :title="title"
          width="50%"
          :visible.sync="dialogAddNewTwo"
        >
          <el-form
            ref="taskFormTwo"
            :model="taskFormTwo"
            :rules="rulesTwo"
            label-width="200px"
          >
            <el-form-item label="航班日期" prop="date">
              <el-date-picker
                v-model="taskFormTwo.date"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                @change="dateChange"
              />
            </el-form-item>

            <el-form-item label="提前天数" prop="offSet">
              <el-input v-model="taskFormTwo.offSet" placeholder="请输入内容" />
            </el-form-item>
            <el-form-item label="航班" prop="flightNo">
              <el-input
                v-if="title === '修改航班人工关舱规则'"
                v-model="taskFormTwo.flightNo"
                disabled
              />
              <el-cascader
                v-else
                v-model="taskFormTwo.flightNo"
                :props="props"
                :show-all-levels="false"
                :options="flightList"
                clearable
                collapse-tags
              />
            </el-form-item>
            <el-form-item label="关闭舱位" prop="salesCabinIds">
              <el-select
                v-model="taskFormTwo.salesCabinIds"
                collapse-tags
                multiple
                clearable
                placeholder="请选择"
              >
                <el-option
                  v-for="item in cabintList"
                  :key="item.cabinId"
                  :value="item.cabinId"
                  :label="item.cabinCode"
                />
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button
              style="margin:0 5px"
              @click="dialogAddNewTwo = false"
            >取 消</el-button>
            <el-button
              style="margin:0 5px"
              type="primary"
              @click="onMakeSureTwo('taskFormTwo')"
            >确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </div>

    <div v-if="radio == '航班白名单规则'">
      <WhitelistRule
        ref="WhitelistRule"
        :form="WhitelistRuleForm"
        :whitelist-rule-form-set="whitelistRuleFormSet"
        :cabint-list="cabintList"
      />
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import {
  AllTwoFace,
  flightList,
  cabintList,
  cabinAdd,
  cabinDeleteTwo,
  cabinEditTwo,
  getRuleList,
  cabinDeleteOne
} from '@/api/settingRules'
import { statusList, modeTypeList } from './common'
import WhitelistRule from '../components/WhitelistRule.vue'
export default {
  components: {
    WhitelistRule
  },
  data() {
    return {
      statusList,
      modeTypeList,
      legNoParams: [],
      title: '',
      exitId: '',
      flightList: [],
      cabintList: [],
      props: {
        label: 'flightNo',
        value: 'flightNo',
        children: 'flightNoParam',
        multiple: true
      },
      WhitelistRuleForm: { //航班白名单规则查询条件
        isValid: false, //规则类型
        createUser: '',//创建用户
        flightLeg: '',//航段
        flightNo: '',//航班号

        date: [],//航班日期区间
        whiteListCabinRefList: []//规则模型
      },
      pageOne: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      pageTwo: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      taskFormTwo: {
        flightNo: '',
        salesCabinIds: [],
        date: [],
        offSet: ''
      },
      rulesTwo: {
        flightNo: [{ required: true, message: '不能为空', trigger: 'blur' }],
        salesCabinIds: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        date: [{ required: true, message: '不能为空', trigger: 'blur' }],
        offSet: [{ required: true, message: '不能为空', trigger: 'blur' }]
      },
      dialogAddNewTwo: false,
      formInlineOne: {
        modelSerialNumber: '',
        modelType: '',
        flightLeg: '',
        date: '',
        createUser: '',
        status: ''
      },
      formInline1: {
        value1: true,
        flightLeg: '',
        flightNo: '',
        closeList: [],
        flightDate: '',
        createUser: ''
      },

      radio: '国内自动调舱规则',
      tableDataOne: [],
      tableDataTwo: []
    }
  },
  // watch: {
  //   radio: function(val) {
  //     this.whitelistRuleFormSet()
  //   }
  // },
  created() {
    this.cabintLists()
    this.getListOne()
  },

  methods: {
    // 页面显示数据切换
    pageChange() {
      if (this.radio === '国内自动调舱规则') {
        this.getListOne()
      } else if (this.radio === '航班人工关舱规则') {
        this.AllTwoFaces()
      } else if (this.radio === '航班白名单规则') {
        this.whitelistRuleFormSet() //重置
      }
    },
    onResetOne() {
      this.formInlineOne = {
        modelSerialNumber: '',
        modelType: '',
        flightLeg: '',
        date: '',
        createUser: '',
        status: ''
      }
      this.getListOne(1)
    },
    onAddNewOne(isPreviewFlag, row) {
      const query = {
        isPreviewFlag
      }
      row && (query.id = row.id)
      row && (query.autoModelEnum = row.modelType)
      this.$router.push({ name: 'addRule', query })
    },
    // 获取自动调仓规则列表
    getListOne(page) {
      const info = {
        pageNum: page || this.pageOne.pageNum,
        pageSize: this.pageOne.pageSize || 20,
        ...this.formInlineOne
      }
      getRuleList(info)
        .then(res => {
          const response = _.cloneDeep(res.data.data)
          this.tableDataOne = response.rows || []
          this.pageOne = {
            pageNum: response.pageNum || 1,
            pageSize: response.pageSize || 20,
            total: response.total || 0
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 自动调仓规则列表分页钩子
    handleCurrentChangeOne(page) {
      this.pageOne.pageNum = page
      this.getListOne()
    },
    statusBtnRender(row) {
      const status = row.status
      let str = ''
      if (
        statusList.filter(i => {
          return i.code === status
        }).length
      ) {
        str = statusList.filter(i => {
          return i.code === status
        })[0].name
      }
      return str
    },
    onDeleteOne(row) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          cabinDeleteOne(row.id).then(res => {
            if (res.data.code === '200') {
              this.getListOne(1)
              this.$message.success('删除成功!')
            }
          })
        })
        .catch()
    },

    // Delete_two  人工关舱规则删除按钮
    onDeleteTwo(item) {
      this.$confirm('是否继续删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          cabinDeleteTwo(item.id).then(res => {
            if (res.data.code === '200') {
              this.AllTwoFaces()
              this.$message.success('删除成功!')
            }
          })
        })
        .catch()
    },

    // 舱位
    cabintLists() {
      cabintList().then(res => {
        if (res.data.code === '200') {
          this.cabintList = res.data.data || []
        }
      })
    },
    // 时间范围改变获航班数据
    dateChange() {
      if (this.title === '新增航班人工关舱规则') {
        const data = {
          fromDateDefault: this.taskFormTwo.date[0],
          toDateDefault: this.taskFormTwo.date[1]
        }
        flightList(data).then(res => {
          this.flightList = res.data.data || []
        })
      }
    },
    // 清空数据
    clear() {
      this.taskFormTwo = {
        flightNo: '',
        salesCabinIds: [],
        date: [],
        offSet: ''
      }
    },
    //  人工关舱规则确定按钮
    onMakeSureTwo(formName) {
      if (this.title === '新增航班人工关舱规则') {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.legNoParams = this.taskFormTwo.flightNo.map(v => {
              return {
                flightLeg: v[0] ? v[0] : '',
                flightNo: v[1] ? v[1] : ''
              }
            })
            var data = {
              fromDate: this.taskFormTwo.date[0],
              toDate: this.taskFormTwo.date[1],
              legNoParams: this.legNoParams,
              offSet: this.taskFormTwo.offSet,
              salesCabinIds: this.taskFormTwo.salesCabinIds
            }
            cabinAdd(data).then(res => {
              if (res.data.code === '200') {
                this.dialogAddNewTwo = false
                this.clear()
                this.AllTwoFaces()
                this.$message.success('添加成功')
              } else {
                this.dialogAddNewTwo = false
                this.clear()
                this.$message.error('添加失败')
              }
            })
          } else {
            return false
          }
        })
      } else if (this.title === '修改航班人工关舱规则') {
        this.$refs[formName].validate(valid => {
          if (valid) {
            var data = {
              id: this.exitId,
              fromDate: this.taskFormTwo.date[0],
              toDate: this.taskFormTwo.date[1],
              offSet: this.taskFormTwo.offSet,
              salesCabinIds: this.taskFormTwo.salesCabinIds
            }
            cabinEditTwo(data).then(res => {
              if (res.data.code === '200') {
                this.dialogAddNewTwo = false
                this.clear()
                this.AllTwoFaces()
                this.$message.success('修改成功')
              } else {
                this.dialogAddNewTwo = false
                this.clear()
                this.$message.info('修改失败')
              }
            })
          } else {
            return false
          }
        })
      }
    },
    // 分页带参查询人工关舱规则
    onQueryTwo() {
      this.AllTwoFaces()
    },
    // 分页带参重置人工关舱规则
    onResetTwo() {
      this.formInline1.flightLeg = ''
      this.formInline1.flightNo = ''
      this.formInline1.closeList = []
      this.formInline1.flightDate = ''
      this.formInline1.createUser = ''
      this.AllTwoFaces()
    },
    // 分页带参查询人工关舱规则
    AllTwoFaces() {
      const data = {
        flightLeg: this.formInline1.flightLeg,
        flightNo: this.formInline1.flightNo,
        closeList: this.formInline1.closeList,
        flightDate: this.formInline1.flightDate,
        createUser: this.formInline1.createUser,
        pageNum: this.pageTwo.pageNum,
        pageSize: this.pageTwo.pageSize
      }
      AllTwoFace(data).then(res => {
        if (res.data.code === '200') {
          this.tableDataTwo = res.data.data.rows || []
          this.pageTwo.total = res.data.data.total
        }
      })
    },
    // 分页
    handleSizeChange_two(val) {
      this.pageTwo.pageSize = val
      this.AllTwoFaces()
    },
    handleCurrentChangeTwo(val) {
      this.pageTwo.pageNum = val
      this.AllTwoFaces()
    },
    // 添加按钮
    onAddNewTwo() {
      this.title = '新增航班人工关舱规则'
      this.dialogAddNewTwo = true
      this.clear()
    },
    // 修改按钮
    onEditTwo(item) {
      this.title = '修改航班人工关舱规则'
      this.dialogAddNewTwo = true
      this.exitId = item.id
      this.taskFormTwo.flightNo = item.flightNo
      this.taskFormTwo.salesCabinIds = item.closeList
      this.taskFormTwo.date = [item.fromDate, item.toDate]
      this.taskFormTwo.offSet = item.offSet
    },

    goRuleEstablishmentDetails(row) {
      const demo = {
        date: '50000073850500',
        name: '起飞日期',
        address: 'PVG-BPE',
        dd: '2021-11-6',
        cc: '2021-11-6'
      }
      this.$router.push({
        path: 'ruleEstablishmentDetails',
        query: { ...demo }
      })
    },
    /**
     * 重置航班白名单规则查询条件
     */
    whitelistRuleFormSet() {
      this.WhitelistRuleForm = {
        isValid: false,
        createUser: '',
        flightLeg: '',
        flightNo: '',
        date: [],
        whiteListCabinRefList: []
      }
      this.$refs.WhitelistRule &&
        this.$refs.WhitelistRule.reSet(this.WhitelistRuleForm)
    },
    /**
     * 航班白名单添加
     */
    WhitelistRuleFormAdd() {
      this.$refs.WhitelistRule.$emit('WhitelistRuleFormAdd')
    },
    /**
     * 航班白名单查询
     */
    WhitelistRuleFormQuery() {
      this.$refs.WhitelistRule.$emit('WhitelistRuleFormQuery')
    }
  }
}
</script>

<style scoped>
.title {
  height: 50px;
  font-size: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  /* border:1px solid #fff */
}

/* @media screen and (max-width: 1910px) {
  .seachBox {
    flex-direction: column;
    justify-content: start;
    align-items: start;
  }
  .title_left {
    margin-bottom: 10px;
    min-width: 460px;
  }
} */
.seachBox {
  display: block;
}
</style>
