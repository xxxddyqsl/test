<template>
  <div class=" pageBox">
    <div class="title">
      <div class="left">RMS算法设置</div>
      <el-button type="primary" size="mini" @click="$router.go(-1)">返回</el-button>
    </div>
    <h2 style="color:#333">分组设置</h2>
    <ForecastSettings />
    <div v-for="(v,i) in list" :key="v.img">
      <h2 style="color:#333">{{ v.title }}</h2>
      <Aforecast v-if="i == 0" />
      <BdeepTank v-if="i == 1" />
      <CupgradeClass v-if="i == 2" />
      <Dorganization v-if="i == 3" />
      <Econdition v-if="i == 4" />
      <!-- <img v-if="i == 4" :src="v.img" alt="" style="width:100%;height:100%"> -->
    </div>

  </div>
</template>

<script>
import Aforecast from '../components/Aforecast.vue'
import BdeepTank from '../components/BdeepTank.vue'
import CupgradeClass from '../components/CupgradeClass.vue'
import Dorganization from '../components/Dorganization.vue'
import Econdition from '../components/Econdition.vue'
import ForecastSettings from '../components/forecastSettings'

export default {
  components: {
    Aforecast,
    BdeepTank,
    CupgradeClass,
    Dorganization,
    Econdition,
    ForecastSettings
  },
  data() {
    return {
      list: [
        {
          title: '预测参数—基本参数',
          img: require('@/assets/rms/u16542.png')
        },
        {
          title: '优化参数—混舱与超顶参数',
          img: require('@/assets/rms/u16544.png')
        },
        {
          title: '优化参数—升舱与锁舱参数',
          img: require('@/assets/rms/u16546.png')
        },
        {
          title: '预测组织管理',
          img: require('@/assets/rms/u16548.png')
        },
        {
          title: '影响条件管理',
          img: require('@/assets/rms/u16550.png')
        }
      ]
    }
  },
  methods: {
    addNew() {
      this.dialogAddNew = true
    }
  }

}

</script>

<style scoped >

.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    border:1px solid #eee
}
.title_right{
    margin-right: 0;
    width: 60%;
    height: 100%;
    float: right;
    display: flex;
    align-items: center;
    justify-content: space-around;

}

</style>

