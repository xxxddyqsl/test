<template>
  <div class="conter">
    <!-- 决策监控-规则 -->
    <div class="">
      <div class="title_right" >
       <el-form :inline="true" :model="form">
          <el-form-item>
            <el-select v-model="form.flightNo" size="mini" placeholder="请选择航班号" clearable filterable>
              <el-option
                v-for="(item,i) in flightNoList"
                :key="i"
                :label="item.flightNo"
                :value="item.flightNo"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="form.flightDate"
              type="date"
              size="small"
              placeholder="航班日期"
              value-format="yyyy-MM-dd"
              style="width:180px"
            />
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.zllx" size="mini" placeholder="请选择指令类型" clearable filterable>
              <el-option
                v-for="(item,i) in zllxList"
                :key="i"
                :label="item.zllx"
                :value="item.zllx"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-input v-model="form.gzbh" size="mini" placeholder="请输入规则编号"></el-input>
          </el-form-item>
          <el-form-item>
            <el-select v-model="form.gzlx" size="mini" placeholder="请选择指规则类型" clearable filterable>
              <el-option
                v-for="(item,i) in gzlxList"
                :key="i"
                :label="item.gzlx"
                :value="item.gzlx"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-input v-model="form.jlyh" size="mini" placeholder="请输入建立用户"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" >查询</el-button>
            <el-button type="primary" size="mini" >重置</el-button>
            <el-button type="primary" size="mini" >下载</el-button>
          </el-form-item>
       </el-form>
      </div>
    </div>
      <el-table :data="tableData" border>
        <el-table-column prop="flightNo" label="航班号" />
        <el-table-column prop="flightDate" label="航班日期" />
        <el-table-column prop="zl" label="指令" />
        <el-table-column prop="zllx" label="指令类型" />
        <el-table-column prop="gzbh" label="规则编号" />
        <el-table-column prop="gzlx" label="规则类型" />
        <el-table-column prop="jlyh" label="建立用户" />
        <el-table-column prop="zlscsj" label="指令生成时间" />
      </el-table>

      <el-pagination
        background
        :current-page="pageNum"
        :page-size="pageSize"
        layout="total, prev, pager, next"
        :total="total"
        @current-change="handleCurrentChange"
      />


  </div>

</template>

<script>
export default {

  data() {
    return {
      form: {
        flightNo: '', // 航班号
        flightDate: '', // 航班日期
        zllx: '', // 指令类型
        gzbh: '', //规则编号
        gzlx: '', //规则类型
        jlyh: '', //建立用户
      },
      flightNoList: [], // 航班号下拉列表
      zllxList: [], // 指令类型下拉列表
      gzlxList: [], // 规则类型下拉列表
      pageSize: 10, // 页码个数
      pageNum: 1, // 页数
      total: 0, // 总数
      tableData: [{
        flightNo: 'YY7237',
        flightDate: '2020.07.12',
        zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
        zllx: '**',
        gzbh: '50000073822768',
        gzlx: '航班日期',
        jlyh: '上三',
        zlscsj: '2020.07.13  16:39:00',
      }] // 列表数据
    }
  },
  methods: {
    /**
     * 切换分页
     */
    handleCurrentChange(){}
  }

}

</script>

