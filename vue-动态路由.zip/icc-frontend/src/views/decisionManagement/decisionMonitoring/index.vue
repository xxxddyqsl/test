<template>
  <div class="pageBox">
    <!-- 决策监控 -->
    <div class="seachBox top">
         <el-radio-group v-model="radio" >
          <el-radio-button label="规则" />
          <el-radio-button label="算法" />
        </el-radio-group>
    </div>
    <rule   v-if="radio == '规则'"/>
    <arithmetic v-if="radio == '算法'"/>

  </div>

</template>

<script>
import arithmetic from './arithmetic'
import rule from './rule'
export default {
  components:{
    arithmetic, //算法页面
    rule // 规则页面
  },
  data() {
    return {
      radio: '规则', //切换
    }
  },
  methods: {

  }

}

</script>


