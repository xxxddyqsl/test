<template>
  <div class="conter">
    <!-- 决策监控-算法 -->
    <div class="">
      <div class="title_right">
        <el-form :inline="true" :model="form">
          <el-form-item>
            <el-input v-model="form.flightNo" size="mini" placeholder="请输入航班号" />
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="form.flightDate"
              type="date"
              size="mini"
              placeholder="航班日期"
              value-format="yyyy-MM-dd HH:mm:ss"
              style="width:180px"
            />
          </el-form-item>
          <!-- <el-form-item>
            <el-select v-model="form.commandType" size="mini" placeholder="请选择指令类型" clearable filterable>
              <el-option
                v-for="(item,i) in commandTypeList"
                :key="i"
                :label="item.commandType"
                :value="item.commandType"
              />
            </el-select>
          </el-form-item> -->
          <el-form-item>
            <el-select v-model="form.algorithm" size="mini" placeholder="请选择算法类型" clearable filterable>
              <el-option
                v-for="(item,i) in algorithmList"
                :key="i"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" size="mini" @click="query">查询</el-button>
            <el-button type="primary" size="mini" @click="reSet">重置</el-button>
            <el-button type="primary" size="mini">下载</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-table :data="tableData" border>
      <el-table-column prop="flightNo" label="航班号" />
      <el-table-column prop="flightDate" label="航班日期" />
      <el-table-column prop="command" label="指令" />
      <el-table-column prop="commandType" label="指令类型" />
      <el-table-column prop="algorithm" label="算法" />
      <el-table-column prop="createTime" label="指令生成时间" />
    </el-table>

    <el-pagination
      background
      :current-page="pageNum"
      :page-size="pageSize"
      layout="total, prev, pager, next"
      :total="total"
      @current-change="handleCurrentChange"
    />

  </div>

</template>

<script>
import { get, getAlgorithm } from '@/api/decisionMonitoring'
export default {
  data() {
    return {
      form: {
        flightNo: '', // 航班号
        flightDate: '', // 航班日期
        // commandType: '', // 指令类型
        algorithm: '' // 算法类型
      },
      // commandTypeList: [], // 指令类型下拉列表
      // gzlxList: [], // 规则类型下拉列表
      algorithmList: [], // 算法类型下拉框
      pageSize: 10, // 页码个数
      pageNum: 1, // 页数
      total: 0, // 总数
      tableData: [] // 列表数据
    }
  },
  created() {
    this.init()
    this.getAlgorithm()
  },
  methods: {
    /**
    *初始化
    */
    init() {
      get({
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        ...this.form
      }).then(res => {
        console.log(res)
        if (res.data.code == '200') {
          this.tableData = res.data.data.rows
        }
      })
    },
    /**
    *初始化
    */
    getAlgorithm() {
      getAlgorithm().then(res => {
        if (res.data.code == '200') {
          this.algorithmList = res.data.data
        }
      })
    },
    /**
    *查询
    */
    query() {
      this.pageNum = 1
      this.init()
    },
    /**
   *重置
   */
    reSet() {
      this.form = {
        flightNo: '', // 航班号
        flightDate: '', // 航班日期
        // commandType: '', // 指令类型
        algorithm: '' // 算法类型
      }
      this.query()
    },
    /**
     * 切换分页
     */
    handleCurrentChange(v) {
      this.pageNum = v
      this.init()
    }
  }

}

</script>

