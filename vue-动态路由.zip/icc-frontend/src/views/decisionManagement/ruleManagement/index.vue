<template>
  <div class="pageBox">
    <!-- 规则管理 -->
    <div class="seachBox">
      <div class="title_left" />
      <div class="title_right">

        <el-form :inline="true" :model="formSelect" size="small">
          <el-form-item>
            <el-select v-model="formSelect.value1" size="mini" placeholder="航段">
              <el-option v-for="item in options1" :key="item.id" :label="item.label" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formSelect.value2" size="mini" placeholder="航班号">
              <el-option v-for="item in options2" :key="item.id" :label="item.label" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="formSelect.value"
              size="mini"
              type="date"
              placeholder="航班起飞日期"
            />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formSelect.value3" size="mini" placeholder="控舱方式">
              <el-option v-for="item in options3" :key="item.id" :label="item.label" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-select v-model="formSelect.value4" size="mini" placeholder="优先级状态">
              <el-option v-for="item in options4" :key="item.id" :label="item.label" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="PLBS">批量部署</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData">
        <!-- <el-table-column type="expand">
          <template slot-scope="props">
            <el-table :data="props.row.list" :span-method="objectSpanMethodi" align="center" border stripe>
              <el-table-column align="center" prop="dataValue" label="航班起飞日期" />
              <el-table-column align="center" prop="dataValue1" label="控舱方式" />
              <el-table-column align="center" prop="dataValue2" label="规则模型/算法" />
              <el-table-column align="center" prop="dataValue3" label="优先级状态" />
              <el-table-column align="center" prop="dataValue4" label="操作">
                <el-button type="primary" size="mini">修改</el-button>
              </el-table-column>
              <el-table-column align="center" prop="dataValue5" label="启用">
                <template slot-scope="scope">
                  <el-switch
                    v-model="scope.row.dataValue5"
                    active-color="#13ce66"
                    inactive-color="#eee"
                  />
                </template>

              </el-table-column>

            </el-table>
          </template>
        </el-table-column> -->
        <el-table-column label="航班号" align="center">
          <template slot-scope="scope">
            <div>
              <div style="margin-left:10px">
                <p @click="onGoNest"> {{ scope.row.hbh }}</p>
                <p>{{ scope.row.sz }}  {{ scope.row.wz }}</p>
              </div>

            </div>

          </template>
        </el-table-column>
        <el-table-column prop="hx" label="航段" align="center" />
        <!-- <el-table-column prop="sfjt" label="是否经停" align="center" /> -->
        <el-table-column prop="mxy" label="航班起飞日期" align="center" />
        <el-table-column prop="mxg" label="控舱方式" align="center" />
        <el-table-column prop="mxgz" label="规则模型 / 算法" align="center" />
        <el-table-column prop="gxsj" label="优先级状态" align="center" />
      </el-table>
    </div>
    <div>
      <el-dialog v-dialogDrag title="批量部署" width="40%" :visible.sync="dialogAddNew">
        <el-form ref="task_form" :model="task_form" label-width="200px">
          <el-form-item label="航班" prop="deskId">
            <el-select v-model="task_form.value1" multiple size="mini">
              <el-option v-for="item in option1" :key="item.id" :label="item.label" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item label="控舱方式" prop="">
            <el-select v-model="task_form.value3" size="mini">
              <el-option v-for="item in option2" :key="item.id" :label="item.label" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item label="航班起飞日期范围" prop="">
            <el-date-picker
              v-model="task_form.value2"
              size="mini"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            />

          </el-form-item>

        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button style="margin:0 5px" @click="dialogAddNew = false">取 消</el-button>
          <el-button style="margin:0 5px" type="primary">确 定</el-button>
        </div>

      </el-dialog>
    </div>

  </div>

</template>

<script>
export default {
  data() {
    return {
      task_form: {
        value1: [],
        value2: '',
        value3: ''
      },
      dialogAddNew: false,
      formSelect: {
        value: '',
        value1: '航段',
        value2: '航班号',
        value3: '控舱方式',
        value4: '优先级状态'

      },
      option1: [{ id: 1, label: 'PVG-PEK' }, { id: 2, label: 'PEK-PVG' }, { id: 3, label: 'SHA-PEK' }, { id: 4, label: 'PEK-SHA' }, { id: 5, label: 'CAN-KMG' }],
      option2: [{ id: 1, label: '算法' }, { id: 2, label: '规则' }],
      options1: [{ id: 1, label: '航段' }],
      options2: [{ id: 1, label: '航班号' }],
      options3: [{ id: 1, label: '控舱方式' }, { id: 2, label: '手动' }, { id: 3, label: '算法' }, { id: 4, label: '规则' }],
      options4: [{ id: 1, label: '优先级状态' }, { id: 2, label: '默认' }, { id: 3, label: '已调整' }],

      tableData: [{
        hx: 'SHA-LZH',
        hbh: 'YY9141',
        sz: 737,
        wz: '优势',
        sfjt: '',
        mxy: '2022.01.01',
        mxg: '算法',
        mxgz: '客座率、起飞日期、比舱、超售',
        gxsj: '默认',
        list: [
          {
            dataValue: '2022-01-01',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱、超售',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-01',
            dataValue1: '规则',
            dataValue2: '动态规划算法',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '算法',
            dataValue2: '起飞日期、比舱、超售',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '规则',
            dataValue2: 'RMS算法',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-03',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱、超售',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-03',
            dataValue1: '规则',
            dataValue2: '动态规划算法',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          }, {
            dataValue: '2022-01-04',
            dataValue1: '算法',
            dataValue2: '起飞日期、比舱、超售',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-04',
            dataValue1: '规则',
            dataValue2: 'RMS算法',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          }

        ]

      },
      {
        hx: 'SHA-LZH',
        hbh: 'YY9141',
        sz: 737,
        wz: '优势',
        sfjt: 'TAO',
        mry: '默认',
        mxy: '2022.01.01',
        // mxy: '2022.01.01',
        mxg: '手动',
        mxgz: '客座率、起飞日期、比舱、超售',
        gxsj: '———',
        list: [
          {
            dataValue: '2022-01-01',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-01',
            dataValue1: '规则',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '规则',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          }
        ]

      },
      {
        hx: 'SHA-LZH',
        hbh: 'YY9141',
        sz: 737,
        wz: '优势',
        sfjt: '',
        mry: '默认',
        mxg: '规则',
        mxy: '2022.01.01',
        mxgz: '客座率、起飞日期、比舱、超售',
        gxsj: '已调整',
        list: [
          {
            dataValue: '2022-01-01',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱、超售',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-01',
            dataValue1: '规则',
            dataValue2: '动态规划算法',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '算法',
            dataValue2: '起飞日期、比舱、超售',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '规则',
            dataValue2: 'RMS算法',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          }
        ]

      },
      {
        hx: 'SHA-LZH',
        hbh: 'YY9141',
        sz: 737,
        wz: '优势',
        mxy: '2022.01.01',
        sfjt: '',
        mry: '默认',
        mxg: '算法',
        mxgz: '客座率、起飞日期、比舱、超售',
        gxsj: '已调整',
        list: [
          {
            dataValue: '2022-01-01',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-01',
            dataValue1: '规则',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '规则',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          }
        ]

      },
      {
        hx: 'SHA-LZH',
        hbh: 'YY9141',
        sz: 737,
        wz: '优势',
        sfjt: '',
        mxy: '2022.01.01',
        mry: '默认',
        mxg: '算法',
        mxgz: '客座率、起飞日期、比舱、超售',
        gxsj: '已调整',
        list: [
          {
            dataValue: '2022-01-01',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-01',
            dataValue1: '规则',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '算法',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          },
          {
            dataValue: '2022-01-02',
            dataValue1: '规则',
            dataValue2: '客座率、起飞日期、比舱',
            dataValue3: '已调整',
            dataValue4: '',
            dataValue5: false
          }
        ]

      }
      ],

      OrderIndexArr: []
    }
  },
  created() {
    // this.getOrderNumber()
  },
  methods: {

    PLBS() {
      this.dialogAddNew = true
    },
    // 寻找应该合并行
    // getOrderNumber() {
    //   const OrderObj = {}
    //   this.tableData.forEach((element, index) => {
    //     element.rowIndex = index
    //     if (OrderObj[element.list.dataValue]) {
    //       OrderObj[element.list.dataValue].push(index)
    //     } else {
    //       OrderObj[element.list.dataValue] = []
    //       OrderObj[element.list.dataValue].push(index)
    //     }
    //   })

    //   // 将数组长度大于1的值 存储到this.OrderIndexArr（也就是需要合并的项）
    //   for (const k in OrderObj) {
    //     console.log('k', k, OrderObj[k])
    //     if (OrderObj[k].length > 1) {
    //       this.OrderIndexArr.push(OrderObj[k])
    //     }
    //   }
    // },
    // 去下一个页面航班信息
    onGoNest() {
      this.$router.push({ name: 'ruleManagementNestIndex' })
    },
    // 合并单元格
    objectSpanMethodi({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex % 2 === 0) {
          return {
            rowspan: 2,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    } }
}

</script>

<style scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    /* border:1px solid #fff */
    display: flex;
    justify-content: space-between;
    align-items: center;
}

</style>

