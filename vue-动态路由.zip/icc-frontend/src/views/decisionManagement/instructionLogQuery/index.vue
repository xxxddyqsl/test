<template>
  <div class="pageBox">
    <div class="title">
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.input" style="width:120px" size="mini" placeholder="规则编号" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input1" style="width:120px" size="mini" placeholder="航班号" />
          </el-form-item>
          <el-form-item>
            <el-date-picker v-model="formInline.value1" style="width:150px" size="mini" type="date" placeholder="航班日期" />
          </el-form-item>
          <el-form-item>

            <el-button type="primary" size="mini">查询</el-button>
            <el-button type="primary" size="mini" @click="addNew">下载</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div>
      <el-table :data="tableData">
        <el-table-column prop="gzbh" label="规则编号" width="180" />
        <el-table-column prop="gly" label="管理员" width="180" />
        <el-table-column prop="zllx" label="指令类型" />
        <el-table-column prop="zl" label="指令" />
        <el-table-column prop="zlscsj" label="指令生成时间" />
      </el-table>
      <div style="display:flex; align-items: center; ">
        <!-- style="display:inline-block"  -->
        <el-pagination background layout="prev, pager, next" :total="10" />
        <span>共 27 条数据 3 页  当前显示第 1 页</span>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      formInline: {
        input: '规则编号',
        input1: '航班号',
        value1: ''
      },
      dialogAddNew: false,
      tableData: [
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        },
        {
          gzbh: '50000073850500',
          gly: '***',
          zllx: '放舱',
          zl: 'ICM:N/YY7237/12JUL20/12JUL20/D/PVGKOW/LNRSVTZ/S',
          zlscsj: '2020.07.13  16:39:00'
        }
      ]

    }
  },
  methods: {

  }

}

</script>

<style scoped >
.box{
    margin-top: 60px
}
.title{
    height: 50px;
    font-size: 20px;
    /* border:1px solid #fff */
}
.title_right{
    margin-right: 0;
    width: 32%;
    height: 100%;
    float: right;
    display: flex;
    align-items: center;
    justify-content: space-around;

}

</style>

