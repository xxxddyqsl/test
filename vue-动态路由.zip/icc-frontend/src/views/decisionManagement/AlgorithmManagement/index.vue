<template>
  <div class=" pageBox">
    <div class="page_box">
      <el-radio-group v-model="radio">
        <el-radio-button label="智能控舱算法" />
        <el-radio-button label="rms算法" />
      </el-radio-group>
    </div>
    <!-- 1111 -->
    <div v-if="radio== '智能控舱算法'">
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-input v-model="formInline.flightLeg" size="mini" style="width:180px" placeholder="航段" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.flightNo" size="mini" style="width:180px" placeholder="航班号" />
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="formInline.flightDate"
              size="mini"
              type="date"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="起飞日期"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onQuery">查询</el-button>
            <el-button type="primary" size="mini" @click="onReset">重置</el-button>
            <el-button type="primary" size="mini" @click="onGoSetUp">算法设置</el-button>
          </el-form-item>

        </el-form>

      </div>
      <div>
        <el-table :data="tableData" border stripe>
          <el-table-column prop="flightNo" label="航班号" />
          <el-table-column prop="flightLeg" label="航段" />
          <el-table-column prop="flightDate" label="航班起飞日期" />
          <el-table-column prop="weekday" label="班期" />
          <el-table-column label="舱位销售建议">
            <template slot-scope="scope">
              <span v-for="(item,index) in scope.row.advice" :key="index">
                {{ item.cabinCode }}
                <span v-for="(it,i) in item.map" :key="i">
                  ({{ it.rawValue }} →{{ it.advisedValue }})
                </span>
                {{ scope.row.advice.length -1==index ? '' :',' }}
              </span>
            </template>
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button v-if="scope.row.enable==0" type="primary" style="margin:0 5px" size="mini" @click="onEdit(scope.row)">启用建议</el-button>
              <el-button v-if="scope.row.enable==1" type="primary" style="margin:0 5px" size="mini" @click="onEditTwo(scope.row)">已启用</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination background :page-size="page.pageSize" layout="total, prev, pager, next" :total="page.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
      </div>
    </div>
    <div v-else>
      <Result />
    </div>
  </div>
</template>

<script>
import { allData, adviceChange } from '@/api/AlgorithmManagement'
import Result from '../components/result'
export default {
  components: {
    Result

  },
  data() {
    return {
      radio: '智能控舱算法',
      formInline: {
        flightDate: '',
        flightNo: '',
        flightLeg: ''
      },
      tableData: [],
      page: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      value2: '',
      input: '航线',
      input1: '航班号',
      img: require('@/assets/rmsyc/u16684.png'),
      img1: require('@/assets/rmsyc/u16687.png'),
      img2: require('@/assets/rmsyc/u16689.png'),
      img3: require('@/assets/rmsyc/u16690.png'),
      imgShow: true
    }
  },
  created() {
    if (this.$route.query.radio) {
      this.radio = this.$route.query.radio
    }
    this.allDatas()
  },
  methods: {
    onEdit(item) {
      var data = {
        id: item.id,
        enable: 1
      }
      adviceChange(data).then(res => {
        if (res.data.code === '200') {
          this.allDatas()
        }
        console.log(res)
      })
    },
    onEditTwo(item) {
      var data = {
        id: item.id,
        enable: 0
      }
      adviceChange(data).then(res => {
        if (res.data.code === '200') {
          this.allDatas()
        }
      })
    },
    // 重置按钮
    onReset() {
      this.allDatas()
      this.formInline = {
        flightDate: '',
        flightNo: '',
        flightLeg: ''
      }
    },
    // 查询按钮
    onQuery() {
      this.allDatas('查询')
    },

    // 列表数据
    allDatas(item) {
      const data = {
        pageNum: this.page.pageNum,
        pageSize: this.page.pageSize,
        flightNo: this.formInline.flightNo,
        flightLeg: this.formInline.flightLeg,
        flightDate: this.formInline.flightDate

      }
      allData(data).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.rows || []
          this.page.total = res.data.data.total
        }
        if (item === '查询') {
          this.$message.success('查询成功')
        }
      })
    },
    onGoSetUp() {
      this.$router.push({ name: 'algorithmisSetUp' })
    },
    goEarlyWarningRules() {
      this.$router.push({ name: 'earlyWarningRules' })
    },
    // 分页
    handleSizeChange(val) {
      this.page.pageSize = val
      this.allDatas()
    },
    handleCurrentChange(val) {
      this.page.pageNum = val
      this.allDatas()
    }
  }

}

</script>

<style lang="scss" scoped>
.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    /* border:1px solid #fff */
}

.fileName {
  cursor: pointer;
  &:hover{
      text-decoration: underline;
  color: #86c5e4;
  }
}

@media screen and (max-width: 1600px) {
  .seachBox{
    flex-direction: column;
    justify-content: start;
    align-items: start;

  }
  .title_left{
    margin-bottom: 10px;
    min-width: 270px;
  }

}
  .title_right{
    display: flex;
    justify-content: flex-end;
  }
</style>

