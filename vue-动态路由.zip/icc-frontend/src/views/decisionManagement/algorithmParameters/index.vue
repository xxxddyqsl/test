<template>
  <div class=" pageBox">
    <div class="seachBox">
      <div class="title_left">
        <el-radio-group v-model="radio1">
          <el-radio-button label="需求参数修改" />
          <el-radio-button label="RMS算法参数" />
        </el-radio-group>
      </div>
      <div class="title_right">
        <el-form :inline="true" :model="formInline">
          <el-form-item>
            <el-switch v-model="formInline.value1" active-text="我的规则" inactive-text="我的航班" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input" style="width:120px" size="mini" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input1" style="width:120px" size="mini" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item>
            <el-select v-model="formInline.value" size="mini" style="width:120px">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-input v-model="formInline.input2" style="width:120px" size="mini" placeholder="请输入内容" />
          </el-form-item>
          <el-form-item>
            <el-date-picker v-model="formInline.value2" type="date" size="mini" placeholder="选择日期" style="width:120px" />
          </el-form-item>
          <el-form-item>
            <el-date-picker v-model="formInline.value3" type="date" size="mini" placeholder="选择日期" style="width:120px" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini">查询</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="goTo">算法设置</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
    <div v-show="radio1 == &quot;需求参数修改&quot;">
      <el-table :data="tableData" border>
        <el-table-column label="航班号" align="center">
          <template slot-scope="scope" width="160">
            <div>{{ scope.row.hbh }}<br>
              {{ scope.row.sz }} {{ scope.row.wz }}</div>
          </template>
        </el-table-column>
        <el-table-column label="航线" align="center">
          <template slot-scope="scope">
            <p>{{ scope.row.hx }}
              <br><i class="el-icon-star-on" />
            </p>
          </template>
        </el-table-column>

        <el-table-column prop="hbq" label="航班起飞日期" />
        <el-table-column prop="xq" label="星期" />

        <el-table-column prop="xx" label="新需求参数" />
        <el-table-column prop="cjz" label="创建者" />
        <el-table-column prop="dang" label="当前是否算法控制" />
        <el-table-column label="航班号" align="center" min-width="160">
          <el-button type="primary" size="mini">修改</el-button>
          <el-button type="primary" size="mini">删除</el-button>
        </el-table-column>
      </el-table>
      <el-pagination background layout="total, prev, pager, next" :total="1000" />
    </div>

    <div v-show="radio1 == &quot;RMS算法参数&quot;">
      <el-table :data="tableData2" border>
        <el-table-column label="分组概况" align="center">
          <template slot-scope="scope">
            <span class="fileName" @click="inTo(scope.$index,scope.row)">{{ scope.row.fzgk }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="gxsj" label="更新时间" width="180" align="center" />
        <el-table-column label="操作" align="center" min-width="160">
          <el-button type="primary" size="mini">修改</el-button>
          <el-button type="primary" size="mini">删除</el-button>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>

export default {
  components: {
  },
  data() {
    return {
      formInline: {
        value1: true,
        value: '',
        value2: '',
        value3: '',
        input: '起始站点',
        input1: '到达站点',
        input2: '5203'
      },
      radio1: '需求参数修改',
      task_form: {
        deskId: '',
        skills: '',
        newDate: this.$route.query.date
      },
      rules1: {
        deskId: [
          { required: true, message: '不能为空', trigger: 'change' }
        ],
        skills: [
          { required: true, message: '不能为空', trigger: 'change' }
        ],

        newDate: [
          { required: true, message: '请选择时间', trigger: 'change' }
        ]
      },
      dialogAddNew: false,
      tableData: [
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        },
        {
          hbh: 'YY9141',
          sz: 737,
          wz: '优势',
          hx: 'PVG-TAO',
          hbq: '2021.11.01-2022.01.03',
          xq: '2,3',
          xx: 1.5,
          cjz: 'A',
          dang: '是'
        }
      ],
      tableData2: [
        {
          fzgk: '东北地区  互动地区',
          gxsj: '2021.10.01  07:18 '
        },
        {
          fzgk: '北京地区、华南地区',
          gxsj: '2021.10.02  07:18 '
        },
        {
          fzgk: '华中地区',
          gxsj: '2021.10.03  07:18 '
        }
      ],
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },

      options: [{
        value: '选项1',
        label: '规则模型'
      }],

      list: [
        {
          title: '预测参数—基本参数',
          img: require('@/assets/rms/u16542.png')
        },
        {
          title: '优化参数—混舱与超顶参数',
          img: require('@/assets/rms/u16544.png')
        },
        {
          title: '优化参数—升舱与锁舱参数',
          img: require('@/assets/rms/u16546.png')
        },
        {
          title: '预测组织管理',
          img: require('@/assets/rms/u16548.png')
        },
        {
          title: '影响条件管理',
          img: require('@/assets/rms/u16550.png')
        }
      ]
    }
  },
  methods: {
    addNew() {
      this.dialogAddNew = true
    },
    inTo(i, data) {
      this.$router.push({ path: '/decisionManagement/algorithmParametersDetails' })
    },
    goTo() {
      this.$router.push({ path: '/decisionManagement/algorithmisSetUp' })
    }
  }

}

</script>

<style lang="scss" scoped>
.title{
    height: 50px;
    font-size: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    /* border:1px solid #fff */
}

.fileName {
  cursor: pointer;
  &:hover{
      text-decoration: underline;
  color: #86c5e4;
  }
}

@media screen and (max-width: 1600px) {
  .seachBox{
    flex-direction: column;
    justify-content: start;
    align-items: start;

  }
  .title_left{
    margin-bottom: 10px;
    min-width: 270px;
  }
}
</style>

