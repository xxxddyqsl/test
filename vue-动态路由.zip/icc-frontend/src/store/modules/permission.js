import {
  constantRoutes
} from '@/router'// 本地路由
import {
  validatenull,
  validateURL
} from '@/utils/validate'
import { getMenu } from '@/api/user'
const permission = {
  state: {
    routers: constantRoutes,
    addRouters: []
  },
  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers
      state.routers = constantRoutes
    },
    ADD_ROUTERS: (state, addRouters) => { // 本地路由和获取合并
      state.routers = constantRoutes.concat(addRouters)
    }
  },
  actions: {
    GenerateRoutes({
      commit
    }, data) {
      return new Promise(resolve => {
        resolve()
      })
    },
    // 获取系统菜单
    GetMenu({
      commit
    }) {
      return new Promise(resolve => {
        getMenu().then((res) => {
          const data = res.data.data
          if (data.length) {
            data.forEach(ele => {
              if (ele.children) {
                ele.children.forEach(child => { // 封装网络路径
                  if (!validatenull(child.component)) {
                    if (validateURL(child.path)) {
                      child.path = `${child.path}`
                    } else {
                      child.path = `${ele.path}/${child.path}`
                    }
                  }
                })
              }
            })
            commit('SET_ROUTERS', data)
            resolve(data)
          }
        })
      })
    }
  }
}

export default permission
