const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  token: state => state.user.token,
  avatar: state => state.user.avatar,
  userInfo: state => state.user.userInfo,
  permission_routers: state => state.permission.routers,
  routers: state => state.permission.addRouters
}
export default getters
