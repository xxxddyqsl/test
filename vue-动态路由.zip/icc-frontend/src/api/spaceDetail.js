import httpRequest from '@/utils/request'

export function getFlinghtDetails(params) {
  return httpRequest({
    url: '/core/api/v1/cabinDetails',
    method: 'get',
    params
  })
}
export function getFlinght(params) {
  return httpRequest({
    url: '/core/api/v1/cabinDetails/getRouteList',
    method: 'get',
    params
  })
}

