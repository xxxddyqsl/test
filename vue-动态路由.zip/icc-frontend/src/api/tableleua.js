import httpRequest from "@/utils/request";

// /admin/api/v1/tableau/analysis?tableauIp=10.23.101.240&user=test&view=${view}&port=80 GET tableleua

export function initTableleua(view) {
  return httpRequest({
    url: `/admin/api/v1/tableau/analysis?view=${view}`,
    method: "get"
  });
}
// 首页
// Homepage-MonthlyReport/Homepage-MonthlyReport
// Homepage-DailyReport/Homepage-DailyReport
