import httpRequest from "@/utils/request";
export function initData(data) {
  return httpRequest({
    url: "/admin/api/v1/holiday/pageInfo",
    method: "get",
    params: data
  });
}
export function addHoliday(data) {
  return httpRequest({
    url: "/admin/api/v1/holiday/addHoliday",
    method: "post",
    data
  });
}
export function updateHoliday(data) {
  return httpRequest({
    url: "/admin/api/v1/holiday/updateHolidays",
    method: "post",
    data
  });
}
export function deleteHoliday(data) {
  return httpRequest({
    url: "/admin/api/v1/holiday/deleteHolidays/" + data.id,
    method: "DELETE"
  });
}
export function update(data) {
  return httpRequest({
    url: "/admin/api/v1/holiday/updateHoliday",
    method: "post",
    data
  });
}
export function selectOption(data) {
  return httpRequest({
    url: "/admin/api/v1/holiday/selectHolidaysByYear?holidayYear=" + data,
    method: "get"
  });
}
