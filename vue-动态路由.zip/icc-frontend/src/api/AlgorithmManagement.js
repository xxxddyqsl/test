import httpRequest from '@/utils/request'
export function allData(data) {
  return httpRequest({
    url: `/core/api/v1/advice/pages`,
    method: 'POST',
    data
  })
}

// /core/api/v1/advice/{id}/active      参数enable
export function adviceChange(data) {
  return httpRequest({
    url: '/core/api/v1/advice/' + data.id + '/active',
    method: 'PUT',
    data
  })
}
