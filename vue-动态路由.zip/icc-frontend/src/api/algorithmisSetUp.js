// algorithmisSetUp
// btx-航班算法系数
import httpRequest from '@/utils/request'

// /admin/api/v1/dataCenter/routes GET根据查询条件查询预警监管信息
export function initTable(data) {
  return httpRequest({
    url: `/core/api/v1/tFlightCoefficients/pages`,
    method: 'post',
    data
  })
}
// 删除按钮
export function deleteTarget(data) {
  return httpRequest({
    url: `/core/api/v1/tFlightCoefficients/` + data,
    method: 'DELETE'

  })
}

// 添加按钮
// /core/api/v1/tFlightCoefficients
export function addBtn(data) {
  return httpRequest({
    url: `/core/api/v1/tFlightCoefficients`,
    method: 'post',
    data

  })
}

// 修改按钮
// /core/api/v1/tFlightCoefficients
export function editBtn(data) {
  return httpRequest({
    url: `/core/api/v1/tFlightCoefficients/` + data.id,
    method: 'put',
    data

  })
}
