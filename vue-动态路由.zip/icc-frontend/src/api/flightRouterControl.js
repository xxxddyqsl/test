// earlyWarningSupervision
// btx-航线管理接口
import httpRequest from "@/utils/request";

// /admin/api/v1/dataCenter/routes GET根据查询条件查询预警监管信息
export function initTable(data) {
  return httpRequest({
    url: `/admin/api/v1/routes?routesCode=${data.routesCode}&pageNum=${
      data.pageNum
    }&pageSize=${data.pageSize}`,
    method: "get"
  });
}
export function initSelect(data) {
  return httpRequest({
    // 原本就是admin
    url: `/admin/api/v1/airport`,
    method: "get"
  });
}

export function removeData(data) {
  return httpRequest({
    url: "/admin/api/v1/routes/" + data.id,
    method: "delete"
  });
}

export function getEit(id) {
  return httpRequest({
    url: `/admin/api/v1/routes/${id}`,
    method: "get"
  });
}
export function eitDatafcn(data) {
  return httpRequest({
    url: "/admin/api/v1/routes",
    method: "put",
    data
  });
}

export function addDatafcn(data) {
  return httpRequest({
    url: "/admin/api/v1/routes",
    method: "post",
    data
  });
}
