import httpRequest from '@/utils/request'

export function login(data) {
  return httpRequest({
    url: '/auth/api/v1/login',
    method: 'post',
    data
  })
}

export function getInfo() {
  return httpRequest({
    url: `/admin/api/v1/resources`,
    method: 'get'
  })
}
export function getMenu() {
  return httpRequest({
    url: `/admin/api/v1/resources/userMenus`,
    method: 'get'
  })
}
// export function logout() {
//   return httpRequest({
//     url: '/api/v1/logout',
//     method: 'post'
//   })
// }
// export function getVerify() {
//   return httpRequest({
//     url: '/user/getVerify',
//     method: 'get'
//   })
// }

// export function getRouter(airportId) {
//   return httpRequest({
//     url: '/auth/api/v1/users/me/pages?airportId=' + airportId,
//     method: 'get'
//   })
// }

// export function getUserRouter() {
//   return httpRequest({
//     url: '/auth/api/v1/users/me/pages',
//     method: 'get'
//   })
// }
