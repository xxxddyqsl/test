import httpRequest from '@/utils/request'
// 机型列表
export function ModelList(data) {
  return httpRequest({
    url: '/admin/api/v1/aircraftType',
    method: 'GET',
    params: data
  })
}
// 机型列表添加按钮 /admin/api/v1/aircraftType
export function addModelList(data) {
  return httpRequest({
    url: '/admin/api/v1/aircraftType',
    method: 'POST',
    data
  })
}

// 机型列表删除按钮 /admin/api/v1/aircraftType/{id}
export function deleteModelList(data) {
  return httpRequest({
    url: '/admin/api/v1/aircraftType/' + data,
    method: 'DELETE'
    // data
  })
}
// 机型列表修改按钮
export function editModelList(data) {
  return httpRequest({
    url: '/admin/api/v1/aircraftType/' + data.id,
    method: 'PUT',
    data
  })
}

// /admin/api/v1/cabinType
// 物理舱位管理列表
export function cabinTypeList() {
  return httpRequest({
    url: '/admin/api/v1/cabinType',
    method: 'GET'
  })
}
// // 物理舱位管理列表添加按钮
export function addcabinTypeList(data) {
  return httpRequest({
    url: '/admin/api/v1/cabinType',
    method: 'POST',
    data
  })
}
// // 物理舱位管理列表修改按钮 /admin/api/v1/cabinType/{id}
export function EditCabinTypeList(data) {
  return httpRequest({
    url: '/admin/api/v1/cabinType/' + data.id,
    method: 'PUT',
    data
  })
}
// 物理舱位管理列表删除按钮 /admin/api/v1/cabinType/{id}
// // 物理舱位管理列表修改按钮 /admin/api/v1/cabinType/{id}
export function DeleteCabinTypeList(data) {
  return httpRequest({
    url: '/admin/api/v1/cabinType/' + data,
    method: 'DELETE'
  })
}
// 航站列表
export function TerminalList(data) {
  return httpRequest({
    url: '/admin/api/v1/airport',
    method: 'GET',
    params: data
  })
}

// 舱位列表 Class list
export function ClassList(data) {
  return httpRequest({
    url: '/admin/api/v1/cabin/page',
    method: 'GET',
    params: data
  })
}

// 舱位列表 子舱位管理
export function ClassListDetails(data) {
  return httpRequest({
    url:
      '/admin/api/v1/cabinType?pageNum=' +
      data.pageNum +
      '&pageSize=' +
      data.pageSize,
    method: 'GET'
  })
}

// 舱位列表 物理舱位对应关系
export function physicalClassCorrespondence(data) {
  return httpRequest({
    url:
      '/admin/api/v1/physicalClass?pageNum=' +
      data.pageNum +
      '&pageSize=' +
      data.pageSize,
    method: 'GET'
  })
}
//  航季航班计划列表/admin/api/v1/seasonPlan
export function quarterlylightlanist(data) {
  return httpRequest({
    url: '/admin/api/v1/seasonPlan/page',
    method: 'GET',
    params: data
    // data
  })
}
// 航迹航班删除
// /admin/api/v1/seasonPlan/plan/{id}
export function quarterlylightlanistDelete(data) {
  return httpRequest({
    url: '/admin/api/v1/seasonPlan/plan/' + data,
    method: 'DELETE'
  })
}
// /admin/api/v1/seasonPlan/planId/1493127609322610738
export function quarterlylightlanistDetail(data) {
  return httpRequest({
    url: '/admin/api/v1/seasonPlan/plan/' + data.id,
    method: 'POST',
    data
  })
}
// 航季航班计划  状态
// /admin/api/v1/dictionaries/items?code=FLIGHT_PLAN_STATUS
export function quarterlylightlanistState(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/items',
    method: 'GET',
    params: data
  })
}

// 航季航班计划 导入按钮
export function updateImportDatas(data) {
  return httpRequest({
    url: '/admin/api/v1/seasonPlan/import',
    method: 'POST',
    data
  })
}

// 添加航站
// /admin/api/v1/airport
export function addFLyCLass(data) {
  return httpRequest({
    url: '/admin/api/v1/airport',
    method: 'POST',
    data
  })
}
// /admin/api/v1/airport/{id}

// 航站修改按钮
export function editFLyCLass(data) {
  return httpRequest({
    url: '/admin/api/v1/airport/' + data.id,
    method: 'PUT',
    data
  })
}
// /admin/api/v1/airport/{id}
// 航站删除按钮
export function deleteFLyCLass(data) {
  return httpRequest({
    url: '/admin/api/v1/airport/' + data.id,
    method: 'DELETE',
    data
  })
}

// 航站 导入按钮 /admin/api/v1/airport/upload

export function daoRuButton(data) {
  return httpRequest({
    url: '/admin/api/v1/airport/upload',
    method: 'POST',
    data
  })
}

// 销售舱位机型销售舱位表
// /admin/api/v1/cabin/saleCabinPage
export function saleCabinPageList(data) {
  return httpRequest({
    url: '/admin/api/v1/cabin/saleCabinPage',
    method: 'GET',
    params: data
  })
}
// 销售舱位 /admin/api/v1/cabin/page    子仓位查询
export function cabinPageList(data) {
  return httpRequest({
    url: '/admin/api/v1/cabin/page',
    method: 'GET',
    params: data
  })
}
// 近期航班计划allList
// /admin/api/v1/flightInfo/recentFlights/page
export function RecentFlightPlanList(data) {
  return httpRequest({
    url: '/admin/api/v1/flightInfo/recentFlights/page',
    method: 'GET',
    params: data
  })
}

// 航班近期计划  状态
// /admin/api/v1/dictionaries/{id}/items  /admin/api/v1/dictionaries
export function stateList(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/10/items',
    method: 'GET'
    // params: data
  })
}

// 航班近期计划  航线机型 admin/api/v1/routes/all
// lightAcType
export function lightAcType(data) {
  return httpRequest({
    url: '/admin/api/v1/routes/all',
    method: 'GET'
    // params: data
  })
}

// /admin/api/v1/aircraftType/all 机型
export function flyAcType(data) {
  return httpRequest({
    url: '/admin/api/v1/aircraftType/all',
    method: 'GET'
    // params: data
  })
}

// /admin/api/v1/flightInfo/recentFlights/flightNo 航班号
export function flightNoList(data) {
  return httpRequest({
    url: '/admin/api/v1/flightInfo/recentFlights/flightNo',
    method: 'GET',
    params: data
  })
}
// 对比航班图标里的查询按钮
// /admin/api/v1/flightInfo/recentFlights/flightHistory
export function iconList(data) {
  return httpRequest({
    url: '/admin/api/v1/flightInfo/recentFlights/flightHistory',
    method: 'GET',
    params: data
  })
}

// 对比航班图标里的table表格
// /admin/api/v1/flightInfo/recentFlights/flightHistoryComparison
export function iconTableList(data) {
  return httpRequest({
    url: '/admin/api/v1/flightInfo/recentFlights/flightHistoryComparison',
    method: 'GET',
    params: data
  })
}

// 填入之后确定按钮 /admin/api/v1/flightInfo/recentFlights/
export function iconMakeSure(data) {
  return httpRequest({
    url: '/admin/api/v1/flightInfo/recentFlights/saveFlightHistoryId',
    method: 'PUT',
    data
  })
}

// 填入历史数据
// /admin/api/v1/flightInfo/recentFlights/flightHistory/{id}
export function iconWrite(data) {
  return httpRequest({
    url: '/admin/api/v1/flightInfo/recentFlights/flightHistory/' + data.id,
    method: 'GET'

  })
}

// 侧边栏 数据中心=>基础数据=》舱位 新增按钮 内部等级排序下拉框
// /admin/api/v1/dictionaries/items
export function cabinLever(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/items',
    method: 'GET',
    params: data

  })
}

// /admin/api/v1/cabin 添加确定按钮
export function cabinAdd(data) {
  return httpRequest({
    url: '/admin/api/v1/cabin',
    method: 'POST',
    data

  })
}

// 舱位列表删除按钮
export function cabinDelete(data) {
  return httpRequest({
    url: '/admin/api/v1/cabin/' + data,
    method: 'DELETE'

  })
}

// 舱位列表修改按钮
export function cabinEdit(data) {
  return httpRequest({
    url: '/admin/api/v1/cabin/' + data.id,
    method: 'PUT',
    data

  })
}
// 导入按钮
// // /admin/api/v1/cabin/upload
export function RuButton(data) {
  return httpRequest({
    url: '/admin/api/v1/cabin/upload',
    method: 'POST',
    data

  })
}

// 数据中心 基础数据 机型 应用列表

export function acTypeList(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/items',
    method: 'GET',
    params: data

  })
}

// /admin/api/v1/routes/upload
// 数据中心 基础数据 航线 导入按钮
export function flightDaoRuBtn(data) {
  return httpRequest({
    url: '/admin/api/v1/routes/upload',
    method: 'POST',
    data

  })
}

// // 数据中心 基础数据 航司 分页查询
export function queryDictionaryManagement(data) {
  return httpRequest({
    url: '/admin/api/v1/airline/page',
    method: 'GET',
    params: data

  })
}

// 数据中心 基础数据 航司 添加按钮
export function addsDictionaryManagement(data) {
  return httpRequest({
    url: '/admin/api/v1/airline',
    method: 'POST',
    data

  })
}

// 数据中心 基础数据 航司 删除按钮
export function deleteDictionaryManagement(data) {
  return httpRequest({
    url: '/admin/api/v1/airline/' + data,
    method: 'DELETE'

  })
}
// 数据中心 基础数据 航司 删除按钮
export function editDictionaryManagement(data) {
  return httpRequest({
    url: '/admin/api/v1/airline/' + data.id,
    method: 'PUT',
    data

  })
}

// 数据中心 基础数据 航司 导入按钮
export function daoRuDictionaryManagement(data) {
  return httpRequest({
    url: '/admin/api/v1/airline/upload',
    method: 'POST',
    data

  })
}
