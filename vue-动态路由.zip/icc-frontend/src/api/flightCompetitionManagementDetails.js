
import httpRequest from '@/utils/request'
// btx预警监管规则-接口

/**
 * 新增/alert/api/v1/alarmRule/alarmRule POST
 */
export function addSet(data) {
  return httpRequest({
    url: `/core/api/v1/rule`,
    method: 'post',
    data
  })
}

/**
 * 修改/alert/api/v1/alarmRule/alarmRule PUt
 */
export function amendSet(data) {
  return httpRequest({
    url: `/core/api/v1/rule`,
    method: 'put',
    data
  })
}

// /core/api/v1/alarmRule/获取规则列表 12
export function getMarketCRules(params) {
  return httpRequest({
    url: `/core/api/v1/rule`,
    method: 'get',
    params
  })
}
// /alert/api/v1/alarmRule/getAlarmRule获取适用航班 12
export function getMarketCRulesRight(params) {
  return httpRequest({
    url: `/core/api/v1/rule/${params.id}`,
    method: 'get',
    params
  })
}
// /admin/api/v1/marketCompetition/selectRouteRode获取航班列表12
export function getFlightList(params) {
  return httpRequest({
    url: `/admin/api/v1/seasonPlan/selectRouteRode`,
    method: 'get',
    params
  })
}
/**
*预警监管条件下拉字典
*/
export function getTreeitemsSelect(params) {
  return httpRequest({
    url: `/admin/api/v1/dictionaries/treeitems`,
    method: 'get',
    params
  })
}
//
export function getSelectByConditionType(params) {
  return httpRequest({
    url: `/admin/api/v1/dictionaries/selectByConditionType`,
    method: 'get',
    params
  })
}

// /admin/api/v1/marketCompetition/selectRouteRode获取指标预警下拉框字典
export function getSelect(params) {
  return httpRequest({
    url: `/admin/api/v1/dictionaries/alarmRuleByCode`,
    method: 'get',
    params
  })
}

// /core/api/v1/Rule/updateFocus设置标记状态
export function setStar(id) {
  return httpRequest({
    url: `/core/api/v1/rule/${id}`,
    method: 'put'
  })
}
/**
 * 删除/core/api/v1/flightWhitelists/{id}
 */
export function deletesSet(id) {
  return httpRequest({
    url: `/core/api/v1/rule/${id}`,
    method: 'delete'
  })
}

// 获取竞争规则列表
// /admin/api/v1/flightQuality
export function getFlightCompetitionManagement(params) {
  return httpRequest({
    url: `/admin/api/v1/marketData`,
    method: 'get',
    params
  })
}
// 航班号航段字典
export function getSelectFlightNoAndRouteCode(params) {
  return httpRequest({
    url: `/admin/api/v1/marketData/selectFlightNoAndRouteCode`,
    method: 'get',
    params
  })
}
/**
*竞争条件字典/admin/api/v1/dictionaries/treeitems
*/
export function getCondition(params) {
  return httpRequest({
    url: `/admin/api/v1/dictionaries/treeitems`,
    method: 'get',
    params
  })
}

/**
*预警监管列表/alert/api/v1/warningSupervise
*/
export function getWarningSupervise(params) {
  return httpRequest({
    url: `/alert/api/v1/warningSupervise`,
    method: 'get',
    params
  })
}
/**
*预警监管列表更改状态/alert/api/v1/warningSupervise
*/
export function changeState(id, data) {
  return httpRequest({
    url: `/alert/api/v1/warningSupervise/${id}`,
    method: 'put',
    data
  })
}

/**
 * /admin/api/v1/dictionaries/getCptRuleDicts
 * 竞争预警下拉列表字典
 */
export function getCptRuleDicts() {
  return httpRequest({
    url: `/admin/api/v1/dictionaries/getCptRuleDicts`,
    method: 'get'
  })
}
