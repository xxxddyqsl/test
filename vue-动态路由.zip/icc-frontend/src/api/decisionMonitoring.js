
import httpRequest from '@/utils/request'
// btx=预警监管-接口

/**
 * 算法查询 -core/api/v1/algorithm
 */
export function get(data) {
  return httpRequest({
    url: `/core/api/v1/algorithm`,
    method: 'post',
    data
  })
}
/**
 * 算法查询 -core/api/v1/algorithm算法下拉框
 */
export function getAlgorithm() {
  return httpRequest({
    url: `/core/api/v1/algorithm`,
    method: 'get'
  })
}

