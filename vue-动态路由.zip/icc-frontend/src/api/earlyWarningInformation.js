import httpRequest from '@/utils/request'
// btx-指标预警规则
export function get(params) {
  return httpRequest({
    url: `/alert/api/v1/alarmRule`,
    method: 'get',
    params
  })
}
/**
 * 设置读取状态
 * @returns
 */
export function setList(id) {
  return httpRequest({
    url: `/alert/api/v1/alarmRule/${id}`,
    method: 'put'
  })
}
// btx-指航班字典
export function selectFlightNoList(data) {
  return httpRequest({
    url: `/admin/api/v1/seasonPlan/selectFlightNoList`,
    method: 'get'
  })
}
// btx-指标航线字典
export function selectRouteRodeList(data) {
  return httpRequest({
    url: `/admin/api/v1/seasonPlan/selectRouteRodeList`,
    method: 'get'
  })
}

/**
*数据预警-----列表获取
*/
export function getDataAlarm(params) {
  return httpRequest({
    url: `/alert/api/v1/dataAlarm/page`,
    method: 'get',
    params
  })
}
/**
*数据预警-----获取dataType数据类型
*/
export function getDataType(params) {
  return httpRequest({
    url: `/alert/api/v1/dataAlarm/dataType`,
    method: 'get',
    params
  })
}
/**
*数据预警-----获取dataSource数据来源
*/
export function getDataSource(params) {
  return httpRequest({
    url: `/alert/api/v1/dataAlarm/dataSource`,
    method: 'get',
    params
  })
}
