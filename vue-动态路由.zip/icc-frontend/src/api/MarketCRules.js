
import httpRequest from '@/utils/request'
// btx指标预警规则-接口

/**
 * 新增/alert/api/v1/alarmRule/alarmRule POST
 */
export function addSet(data) {
  return httpRequest({
    url: `/alert/api/v1/alarmRule/alarmRule`,
    method: 'post',
    data
  })
}

/**
 * 修改/alert/api/v1/alarmRule/alarmRule PUt
 */
export function amendSet(data) {
  return httpRequest({
    url: `/alert/api/v1/alarmRule/alarmRule`,
    method: 'put',
    data
  })
}

/**
 * 删除/core/api/v1/flightWhitelists/{id}
 */
export function deletesSet(id) {
  return httpRequest({
    url: `/core/api/v1/flightWhitelists/${id}`,
    method: 'delete'
  })
}

// /alert/api/v1/alarmRule/getAlarmRulePo获取规则列表 12
export function getMarketCRules(params) {
  return httpRequest({
    url: `/alert/api/v1/alarmRule/getAlarmRulePO`,
    method: 'get',
    params
  })
}
// /alert/api/v1/alarmRule/getAlarmRule获取适用航班 12
export function getMarketCRulesRight(params) {
  return httpRequest({
    url: `/alert/api/v1/alarmRule/getAlarmRule`,
    method: 'get',
    params
  })
}
// /admin/api/v1/marketCompetition/selectRouteRode获取航班列表12
export function getFlightList(params) {
  return httpRequest({
    url: `/admin/api/v1/seasonPlan/selectRouteRode`,
    method: 'get',
    params
  })
}
// /admin/api/v1/dictionaries/treeitems获取竞争匹配规则下拉框字典
export function getTreeitemsSelect(params) {
  return httpRequest({
    url: `/admin/api/v1/dictionaries/treeitems`,
    method: 'get',
    params
  })
}

// /admin/api/v1/marketCompetition/selectRouteRode获取指标预警下拉框字典
export function getSelect(params) {
  return httpRequest({
    url: `/admin/api/v1/dictionaries/alarmRuleByCode`,
    method: 'get',
    params
  })
}
// /core/api/v1/Rule/updateFocus设置标记状态
export function setStar(id) {
  return httpRequest({
    url: `/core/api/v1/rule/${id}`,
    method: 'put'
  })
}

