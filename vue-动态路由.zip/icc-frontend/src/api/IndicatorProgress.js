import httpRequest from "@/utils/request";
// 指标进度表格
export function IndicatorProgress(data) {
  return httpRequest({
    url: "/index/api/v1/indicatorsProgress",
    method: "POST",
    data
  });
}

// 指标进度表格slecet
export function IndicatorProgressSelect(data) {
  return httpRequest({
    url: "/index/api/v1/indicatorsProgress/selectAllIndicators",
    method: "get"
  });
}

// 月份数据
export function selectScheduleType(params) {
  return httpRequest({
    url: "/index/api/v1/indicatorsProgress/selectScheduleType",
    method: "get",
    params
  });
}

// 日数据
export function selectProgressMonth(params) {
  return httpRequest({
    url: "/index/api/v1/indicatorsProgress/selectProgressMonth",
    method: "get",
    params
  });
}

// 日数据
export function selectProgressDay(params) {
  return httpRequest({
    url: "/index/api/v1/indicatorsProgress/selectProgressDay",
    method: "get",
    params
  });
}
