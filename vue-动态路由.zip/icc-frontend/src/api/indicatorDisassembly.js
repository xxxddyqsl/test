import httpRequest from "@/utils/request";

// 指标拆解首页列表
export function getIndicatorsSplit(data) {
  return httpRequest({
    url: "/index/api/v1/indicatorsSplit",
    method: "post",
    data
  });
}
// 指标拆解首页确认生效
export function indicatorsSplitConfirmEffect(data) {
  return httpRequest({
    url: "/index/api/v1/indicatorsSplit/confirmEffect",
    method: "put",
    data
  });
}
// 指标拆解首页数据预览
export function indicatorsSplitPreview(data) {
  return httpRequest({
    url: "/index/api/v1/indicatorsSplit/preview",
    method: "post",
    data
  });
}
// 指标拆解详细数据确认生效保存
export function detailConfirmEffect(data) {
  return httpRequest({
    url: "/index/api/v1/indicatorsSplit/detail/confirmEffect",
    method: "put",
    data
  });
}
// 指标拆解详细数据预览
export function detailPreview(data) {
  return httpRequest({
    url: "/index/api/v1/indicatorsSplit/detail/preview",
    method: "post",
    data
  });
}
// 指标销售额下拉框数据
export function getIndicatorsSelectList(params) {
  return httpRequest({
    url: "/index/api/v1/indicators/noPage",
    method: "get",
    params
  });
}
// 指标列表查询部门表
export function getDepartmentsSelectList(params) {
  return httpRequest({
    url: "/admin/api/v1/departments",
    method: "get",
    params
  });
}
// 航线列表查询
export function getLineList(params) {
  return httpRequest({
    url: "/admin/api/v1/routes/fuzzy",
    method: "get",
    params
  });
}
// 航班列表查询-模糊查询
export function getLineNumRemoteList(params) {
  return httpRequest({
    url: `/index/api/v1/dayFlight/${params.indicatorId}/${params.flightNo}`,
    method: "get",
    params
  });
}
// 航班列表查询-部分也搜全部航班
export function getLineNumNoPageList(params) {
  return httpRequest({
    url: `/index/api/v1/dayFlight/noPage`,
    method: "get",
    params
  });
}

// 航班列表查询-部分也搜全部航班
export function getDetailData(data) {
  return httpRequest({
    url: `/index/api/v1/indicatorsSplit/detail`,
    method: "post",
    data
  });
}


