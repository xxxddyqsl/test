
import httpRequest from '@/utils/request'

// 查询
export function initTable(params) {
  return httpRequest({
    url: `/admin/api/v1/resources`,
    method: 'get',
    params
  })
}
// 新增
export function addMenu(data) {
  return httpRequest({
    url: `/admin/api/v1/resources`,
    method: 'post',
    data

  })
}
// 删除
export function remove(data) {
  return httpRequest({
    url: `/admin/api/v1/resources`,
    method: 'DELETE',
    data

  })
}
// 修改
export function edit(data) {
  return httpRequest({
    url: `/admin/api/v1/resources`,
    method: 'PUT',
    data
  })
}
