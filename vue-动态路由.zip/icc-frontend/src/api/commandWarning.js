import httpRequest from '@/utils/request'

// 指令预警-页面接口

//  新增提交接口

/**
*查询预警信息列表
*/
export function getList(params) {
  return httpRequest({
    url: '/alert/api/v1/commandWarring/page',
    method: 'get',
    params
  })
}
/**
*是否已读修改
*/
export function setList(id) {
  return httpRequest({
    url: `/alert/api/v1/commandWarring/read/${id}`,
    method: 'put'
  })
}
/**
*规则列表字典
*/
export function getConflictRuleCode(data) {
  return httpRequest({
    url: '/alert/api/v1/commandWarring/conflictRuleCode',
    method: 'get',
    data
  })
}
/**
*航班列表字典
*/
export function getFlightNo(data) {
  return httpRequest({
    url: '/alert/api/v1/commandWarring/flightNo',
    method: 'get',
    data
  })
}
