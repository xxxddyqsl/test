// /core/api/v1/manualRules/pages 分页带参查询人工关舱规则
import httpRequest from "@/utils/request";

export function AllTwoFace(data) {
  return httpRequest({
    url:
      "/core/api/v1/manualRules/pages?closeList=" +
      data.closeList +
      "&flightLeg=" +
      data.flightLeg +
      "&flightNo=" +
      data.flightNo +
      "&flightDate=" +
      data.flightDate +
      "&createUser=" +
      data.createUser +
      "&pageNum=" +
      data.pageNum +
      "&pageSize=" +
      data.pageSize,
    method: "GET"
  });
}
// 航班接口
// /core/api/v1/manualRules/flight
export function flightList(params) {
  return httpRequest({
    url: "/admin/api/v1/flightInfo/recentFlights/choseDateWithFlight",
    method: "GET",
    params,
    headers: {
      Authentication:
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdHkiOiJ1c2VyLGZsaWdodCIsIm5hbWUiOiJhZG1pbiIsImlkIjoiMSIsImV4cCI6MTY0OTQwMDA2NCwidXNlcm5hbWUiOiJhZG1pbiJ9.CAvxNsH_igcVXBiDkei75iUaEgAi8f6M3U5d0ITBO2I"
    }
  });
}

// 舱位接口
// ​/core​/api​/v1​/manualRules​/salesCabinIdsAndCode
export function cabintList(data) {
  return httpRequest({
    url: "/core/api/v1/manualRules/salesCabinIdsAndCode",
    method: "GET"
    // params: data
  });
}
//  人工关舱添加接口/core/api/v1/manualRules
export function cabinAdd(data) {
  return httpRequest({
    url: "/core/api/v1/manualRules",
    method: "post",
    data
  });
}

//  人工关舱删除接口/core/api/v1/manualRules
export function cabinDeleteTwo(data) {
  return httpRequest({
    url: "/core/api/v1/manualRules/" + data,
    method: "DELETE"
  });
}

//  人工关修改除接口/core/api/v1/manualRules
export function cabinEditTwo(data) {
  return httpRequest({
    url: "/core/api/v1/manualRules",
    method: "PUT",
    data
  });
}

// 国内自动调舱

export function cabinDeleteOne(id) {
  return httpRequest({
    url: "/core/api/v1/domestic/" + id,
    method: "DELETE"
  });
}
//  获取首页调舱规则列表
export function getRuleList(params) {
  return httpRequest({
    url: "/core/api/v1/domestic/pages",
    method: "get",
    params
  });
}
//  获取调舱规则详情
export function getRuleDetailsById(params) {
  return httpRequest({
    url: "/core/api/v1/domestic/details",
    method: "get",
    params
  });
}
//  新增提交接口
export function addDomestic(data) {
  return httpRequest({
    url: "/core/api/v1/domestic",
    method: "post",
    data
  });
}
//  编辑提交接口
export function updateDomestic(data) {
  return httpRequest({
    url: "/core/api/v1/domestic/update/" + data.id,
    method: "put",
    data
  });
}
//  获取仓位展示列表
export function domesticCabinList(params) {
  return httpRequest({
    url: "/core/api/v1/domestic/cabin",
    method: "get",
    params
  });
}
//  获取机型列表
export function queryAirTypeList(params) {
  return httpRequest({
    url: "/core/api/v1/domestic/queryAirType",
    method: "get",
    params
  });
}
//  获取调档上限列表
export function queryAdjustList(params) {
  return httpRequest({
    url: "/core/api/v1/domestic/queryAdjust",
    method: "get",
    params
  });
}
//  获取两舱优化下拉框列表
export function queryTwoCabinList(params) {
  return httpRequest({
    url: "/core/api/v1/domestic/queryTwoCabin",
    method: "get",
    params
  });
}
