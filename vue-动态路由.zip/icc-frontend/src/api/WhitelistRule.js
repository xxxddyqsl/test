
import httpRequest from '@/utils/http-request'
// btx 航班白名单规则-航班白名单规则-接口

export function getList(data) {
  return httpRequest({
    url: `/core/api/v1/flightWhitelists/pages`,
    method: 'POST',
    data
  })
}

/**
 * 新增/core/api/v1/flightWhitelists POST
 */
export function addSet(data) {
  return httpRequest({
    url: `/core/api/v1/flightWhitelists`,
    method: 'post',

    data
  })
}
/**
 * 新增/core/api/v1/flightWhitelists/{id} PUT
 */
export function beRevisedSet(data) {
  return httpRequest({

    url: `/core/api/v1/flightWhitelists/${data.id}`,
    method: 'PUT',

    data
  })
}

/**
 * 删除/core/api/v1/flightWhitelists/{id}
 */
export function deletesSet(id) {
  return httpRequest({
    url: `/core/api/v1/flightWhitelists/${id}`,
    method: 'delete'
  })
}

// //core/api/v1/flightWhitelists/items 获取规则列表
export function getRuleModelRefList() {
  return httpRequest({
    url: `/core/api/v1/flightWhitelists/items`,
    method: 'get'
  })
}

