// 控舱概览

import httpRequest from '@/utils/request'

/**
 * 获取表头结构数据
 * @param {*} params
 * @returns
 */
export function getHeader(params) {
  return httpRequest({
    url: '/core/api/v1/classOverview/getListTitle',
    method: 'get',
    params
  })
}

// 获取表格结构数据
/**
 * 获取表格结构数据
 * @param {*} params
 * @returns
 */
export function getTable(params) {
  return httpRequest({
    url: '/core/api/v1/classOverview',
    method: 'get',
    params
  })
}

// /admin/api/v1/seasonPlan/selectRouteRodeList  航段
/**
 * 获取航段下拉列表
 * @param {*} params
 * @returns
 */
export function getSelectRouteRodeList(params) {
  return httpRequest({
    url: '/admin/api/v1/seasonPlan/selectRouteRodeList',
    method: 'get',
    params
  })
}

// /admin/api/v1/seasonPlan/selectFlightList  航班
/**
 * 获取航班下拉查询列表
 * @param {*} params
 * @returns
 */
export function getSelectFlightList(params) {
  return httpRequest({
    url: '/admin/api/v1/seasonPlan/selectFlightList',
    method: 'get',
    params
  })
}
// /admin/api/v1/seasonPlan/selectFlightList  航班
/**
 * 批量设置弹窗/admin/api/v1/dictionaries/treeitems   code cwglcs
 * @param {*} params
 * @returns
 */
export function setVolumeSet(params) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/treeitems',
    method: 'get',
    params
  })
}

/**
 * 获取航段列表/core/api/v1/cabinDetails/getRouteList
 * @param {*} params
 * @returns
 */
export function getRouteList(params) {
  return httpRequest({
    url: '/core/api/v1/cabinDetails/getRouteList',
    method: 'get',
    params
  })
}

/**
 * 获取批量控舱表格结构数据
 * @param {*} params
 * @returns
 */
export function getVolTable(params) {
  return httpRequest({
    url: '/core/api/v1/batchControlCabin',
    method: 'get',
    params
  })
}
