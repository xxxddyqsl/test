import httpRequest from '@/utils/request'
// 字典管理树结构
export function treeData(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries',
    method: 'GET'
  })
}

// 新增字典目录接口
// 接口地址：/admin/api/v1/dictionaries    请求方式：GET
export function rootAddData(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries',
    method: 'POST',
    data
  })
}

// 根据字典目录的code查询该字典目录下所有的子级
// 接口地址：/admin/api/v1/dictionaries/treeitems    请求方式：GET
// 请求参数：code = zbzt
export function queryRootList(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/treeitems',
    method: 'GET',
    params: data
  })
}

// 删除字典的接口
// 接口地址：/admin/api/v1/dictionaries/items/123
export function deleteRootList(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/' + data,
    method: 'DELETE'

  })
}

// 接口地址：/admin/api/v1/dictionaries/123/items
// 请求方式：POST
export function addRootValue(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/' + data.dictionaryId + '/items',
    method: 'POST',
    data

  })
}

// 删除字典值的接口
export function deleteValues(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/items/' + data,
    method: 'DELETE'

  })
}

// 查询s字典值的接口
export function queryValue(data) {
  return httpRequest({

    url: '/admin/api/v1/dictionaries/items',
    method: 'GET',
    params: data

  })
}

// 修改字典目录接口
// 接口地址：/admin/api/v1/dictionaries    请求方式：PUT
export function editRoot(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries',
    method: 'PUT',
    data

  })
}
// 修改字典值的接口
export function editValue(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/items',
    method: 'PUT',
    data

  })
}
// 刷新缓存
// /admin/api/v1/dictionaries/clearDictionaryCaches
export function refreshCache(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/clearDictionaryCaches',
    method: 'GET'

  })
}
