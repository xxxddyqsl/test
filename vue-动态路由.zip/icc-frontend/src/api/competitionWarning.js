import httpRequest from '@/utils/request'

// 竞争预警-页面接口


/**
*查询预警信息列表
*/
export function getList(params) {
  return httpRequest({
    url: '/alert/api/v1/competitionWarning/page',
    method: 'get',
    params
  })
}
/**
*是否已读修改
*/
export function setList(id) {
  return httpRequest({
    url: `/alert/api/v1/competitionWarning/read/${id}`,
    method: 'put'
  })
}
/**
*航线列表字典
*/
export function getRouteCode(data) {
  return httpRequest({
    url: '/alert/api/v1/competitionWarning/routeCode',
    method: 'get',
    data
  })
}
/**
*航班列表字典
*/
export function getFlightNo(data) {
  return httpRequest({
    url: '/alert/api/v1/competitionWarning/flightNo',
    method: 'get',
    data
  })
}
