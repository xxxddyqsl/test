import httpRequest from '@/utils/http-request'
// 航班优劣势管理列表
export function advantagesAndDisadvantagesManagementLst(data) {
  return httpRequest({
    url: '/admin/api/v1/flightQuality',
    method: 'GET',
    params: data,
    headers: {
      'Authentication': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdHkiOiJ1c2VyLGZsaWdodCIsIm5hbWUiOiJhZG1pbiIsImlkIjoiMSIsImV4cCI6MTY0OTQwMDA2NCwidXNlcm5hbWUiOiJhZG1pbiJ9.CAvxNsH_igcVXBiDkei75iUaEgAi8f6M3U5d0ITBO2I'
    }

  })
}

// 航班优劣势修改
export function advantagesAndDisadvantagesEdit(data) {
  return httpRequest({
    url: '/admin/api/v1/flightQuality',
    method: 'PUT',
    data,
    headers: {
      'Authentication': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdHkiOiJ1c2VyLGZsaWdodCIsIm5hbWUiOiJhZG1pbiIsImlkIjoiMSIsImV4cCI6MTY0OTQwMDA2NCwidXNlcm5hbWUiOiJhZG1pbiJ9.CAvxNsH_igcVXBiDkei75iUaEgAi8f6M3U5d0ITBO2I'
    }

  })
}
// select 竞争优劣势 选择框
// /admin/api/v1/dictionaries/treeitems
export function advantagesAndDisadvantages(data) {
  return httpRequest({
    url: '/admin/api/v1/dictionaries/treeitems',
    method: 'GET',
    params: data,
    headers: {
      'Authentication': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdHkiOiJ1c2VyLGZsaWdodCIsIm5hbWUiOiJhZG1pbiIsImlkIjoiMSIsImV4cCI6MTY0OTQwMDA2NCwidXNlcm5hbWUiOiJhZG1pbiJ9.CAvxNsH_igcVXBiDkei75iUaEgAi8f6M3U5d0ITBO2I'
    }
  })
}
