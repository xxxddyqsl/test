import httpRequest from "@/utils/request";
// btx 指标管理-指标设置-接口
export function initSet(data) {
  return httpRequest({
    url: `/index/api/v1/indicators/selectIndicators`,
    method: "post",
    data
  });
}
export function initSelect(data) {
  return httpRequest({
    // 本身就是admin
    url: `/admin/api/v1/dictionaries/items?code=${data}`,
    method: "get"
  });
}
// 获取 关联航班计划 下拉列表
export function plansSelect(data) {
  return httpRequest({
    url: `/admin/api/v1/seasonPlan/page`,
    method: "POST",
    data
  });
}

/**
 * 新增指标设置/index/api/freightRate/add POST
 */
export function addSet(data) {
  return httpRequest({
    url: `/index/api/v1/indicators`,
    method: "post",
    data
  });
}

/**
 * 启用指标设置 /index/api/freightRate/updateById/{id} GET
 */
export function usingSet(data) {
  return httpRequest({
    url: `/index/api/v1/indicators/indicatorsStatus`,
    method: "post",
    data
  });
}

/**
 * 编辑指标设置 /index/api/freightRate/{id} PUT
 */
export function amendSet(data) {
  return httpRequest({
    url: `/index/api/v1/indicators`,
    method: "put",
    data
  });
}

/**
 * 删除指标设置/index/api/freightRate/{id}
 */
export function deletesSet(id) {
  return httpRequest({
    url: `/index/api/v1/indicators/${id}`,
    method: "delete"
  });
}

// /index/api/v1/indicators/dateInterval 指标    //  * 获取 生效年份 下拉列表
export function getTarget(data) {
  return httpRequest({
    url: `/index/api/v1/indicators/dateInterval`,
    method: "get"
  });
}
// /index/api/v1/indicators/dateInterval 指标估测 - 指标估测日期区间
export function getProblem(params) {
  return httpRequest({
    url: `/index/api/v1/indicators/returnPlan`,
    method: "get",
    params
  });
}
/**
 * 指标估测-计算结果预览 /index/api/v1/indicators/predictList POST
 */
export function getResults(data) {
  return httpRequest({
    url: `/index/api/v1/indicators/predictList`,
    method: "post",
    data
  });
}

/**
 * 指标估测-提交计算结果 /index/api/v1/indicators/indexEstimation POST
 */
export function submitResults(data) {
  return httpRequest({
    url: `/index/api/v1/indicators/indexEstimation`,
    method: "post",
    data
  });
}
