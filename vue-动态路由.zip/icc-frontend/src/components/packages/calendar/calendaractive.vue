<template>
  <div class="calenBox">
    <div class="calendar box_shadow_common">
      <div class="neck" v-if="moduleType === 1">
        <h2 style="margin:0px;padding:0">
          <!-- <i
            v-if="leftMonthBtnShow"
            class="el-icon-caret-left cursorPoint"
            @click="preMonth"
          /> -->
          {{ titleFilter }}
          <!-- <i
            v-if="rightMonthBtnShow"
            class="el-icon-caret-right cursorPoint"
            @click="nextMonth"
          /> -->
        </h2>
        <h3 v-if="moduleType === 2" style="margin:0;padding:0">
          销售额指标：1000亿（{{ currentDiff }}）
        </h3>
        <h3 v-else style="margin:0;padding:0">
          {{ `销售额指标：${total}${company}` }}
        </h3>
      </div>

      <!-- <ul class="weekdays">
        <li v-for="item in fromsun ? weekDaysFromSun : weekDays" :key="item">
          {{ item }}
        </li>
      </ul> -->
      <!-- 日期 -->
      <ul class="days">
        <li v-for="(dayobject, i) in days" :key="i">
          <div class="liTop" @click="getClickDay(dayobject)">
            <span class="cday">{{ dayobject.lunarCalendar || "" }}</span>
            <span v-if="dayobject.festival" class="idaycn">{{
              dayobject.festival
            }}</span>
            <span ref="cday" class="cday">
              {{ moduleType === 1 ? dayobject.num : dayobject.type }}日
            </span>
          </div>
          <div class="liBottom">
            <span class="liBottomSpan" v-if="moduleType === 1">{{
              `${dayobject.amountActual}${dayobject.companyActual} / ${
                dayobject.amountPlan
              }${dayobject.companyPlan}`
            }}</span>
            <p v-else class="liBInput">
              <el-input
                class="liBotLeft"
                v-model="dayobject.num"
                placeholder="0"
                @change="
                  val => {
                    changeFn(val, dayobject);
                  }
                "
              ></el-input>
              <span class="liBotRight"
                >{{ dayobject.unit }}(<span>{{
                  dayobject.difference || "±0"
                }}</span
                >)</span
              >
            </p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { title } from "@/settings";
import calendar from "./util/date";
export default {
  name: "ZpCalendar",
  props: {
    company: {
      type: String,
      default: ""
    },
    currentYear: {
      type: Number,
      default: 2021
    },
    currentMonth: {
      type: Number,
      default: 1
    },
    moduleType: {
      type: Number,
      default: 1 // 插件类型：1：用于进度当月展示；2：用于指标拆解可修改；
    },
    total: {
      type: String,
      default: "1000亿"
    },
    dayList: {
      type: Array,
      default: []
    },
    currentDiff: {
      type: String,
      default: "±0"
    }
  },
  data() {
    return {
      // currentMonth: this.$route.query.month,
      currentDay: 1,
      currentWeek: 1,
      days: [],
      // curDayMsg: [],
      // weekDays: ["一", "二", "三", "四", "五", "六", "日"],
      // weekDaysFromSun: ["日", "一", "二", "三", "四", "五", "六"],
      leftMonthBtnShow: true,
      rightMonthBtnShow: true,
      collectChangeData: []
    };
  },
  watch: {
    dayList: {
      handler(newValue, oldValue) {
        this.days = newValue;
      },
      immediate: true
    }
  },
  computed: {
    titleFilter() {
      let str = `${this.currentYear}年${
        this.currentMonth < 10 ? "0" + this.currentMonth : this.currentMonth
      }月`;
      return str;
    }
  },
  created() {
    // this.initData(this.formatDate(this.currentYear, this.currentMonth, 1));
  },
  mounted() {
    this.currentMonth * 1 === 1 && (this.leftMonthBtnShow = false);
    this.currentMonth * 1 === 12 && (this.rightMonthBtnShow = false);
  },

  methods: {
    // 上一月
    preMonth() {
      let month = this.currentMonth;
      month--;
      month < 12 && (this.rightMonthBtnShow = true);
      month === 1 && (this.leftMonthBtnShow = false);
      this.$emit(`update:currentMonth`, month);
      this.$emit("monthChangeFn", month);
    },

    // 下一月
    nextMonth() {
      let month = this.currentMonth;
      month++;
      month > 1 && (this.leftMonthBtnShow = true);
      month === 12 && (this.rightMonthBtnShow = false);
      this.$emit(`update:currentMonth`, month);
      this.$emit("monthChangeFn", month);
    },

    // 点击日期
    getClickDay(curData) {
      this.$emit("dayMsg", curData);
    },

    changeFn(val, item) {
      // 去重
      let deleteIndex = this.collectChangeData.findIndex((itm, index) => {
        return (
          itm.changeType ===
          `${item.yyyymm}${item.type * 1 < 10 ? "0" + item.type : item.type}`
        );
      });
      if (deleteIndex === -1) {
        this.collectChangeData.push({
          changeType: `${item.yyyymm}${
            item.type * 1 < 10 ? "0" + item.type : item.type
          }`,
          changeValue: val * 1,
          changeValueUnit: item.unit
        });
      } else {
        this.collectChangeData[deleteIndex] = {
          changeType: `${item.yyyymm}${
            item.type * 1 < 10 ? "0" + item.type : item.type
          }`,
          changeValue: val * 1,
          changeValueUnit: item.unit
        };
      }

      this.$emit("collectData", this.collectChangeData);
    }
  }
};
</script>
<style lang="scss" scoped>
.neck {
  height: 80px;
  display: flex;
  flex-direction: column;
  color: #f59a23;
  align-items: center;
}
.cursorPoint {
  cursor: pointer;
}
.calenBox {
  padding: 0 20px;
}
.calendar {
  border-radius: 20px;
  padding: 10px 20px 0;
  font-size: 20px;
  color: #000;
  overflow: hidden;
  background-color: #fff;
  box-sizing: border-box;
}
.calendaractive {
  font-size: 20px;
}
.mouth_left {
  margin-top: 10px;
  margin-left: 20px;
  font-weight: bold;
  font-size: 16px;
}
.months {
  /* display: flex;
  justify-content: space-around;
  margin-top: 3%;
  margin-bottom: 3%; */
  width: 20%;
  height: 30px;
  /* margin-right: 20px; */
  margin-top: 10px;
  margin-bottom: 10px;
}
.months .year-month {
  margin-left: -10%;
  /* font-size: 0.875rem; */
}
.months .toggle-month {
  width: 100%;
  /* margin-right: 20px; */
  text-align: center;
  border: 1px solid #000;
  cursor: pointer;
}
.months .toggle-month .lt,
.months .toggle-month .rt {
  display: inline-block;
  width: 24%;
  color: #000;
  text-align: center;
}
.months .toggle-month .ct {
  display: inline-block;
  width: 48%;
  text-align: center;
  border-right: 1px solid #000;
  border-left: 1px solid #000;
  color: #000;
}
// .weekdays {
//   padding: 0;
//   display: flex;
//   color: #000;
//   justify-content: space-around;
//   background-color: #fff;
//   font-size: 22px;
// }
// .weekdays li {
//   display: flex;
//   flex-direction: column;
//   width: 13.6%;
//   text-align: center;
//   margin-top: 15px;
// }
.days {
  padding: 0;
  margin-top: 10px;
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
  background-color: #fff;
  border-left: 1px solid #000;
  border-top: 1px solid #000;
}
.days li {
  display: flex;
  justify-content: space-around;
  flex-direction: column;
  width: calc(100% / 6);
  height: 105px;
  padding: 10px;
  border-bottom: 1px solid #000;
  border-right: 1px solid #000;
  text-align: center;
  color: #000;
  cursor: pointer;
}
.vishidden {
  visibility: hidden;
}
.days li .active {
  display: inline-block;

  text-align: center;
  border-radius: 50%;
  color: #5cc18d !important;
}
.days li .liTop {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.days li .liBottom {
  overflow: hidden;

  .liBottomSpan {
    font-size: 16px !important;
  }
  p {
    padding: 0;
    margin: 0;
  }
}
.liBottom .liBInput {
  font-size: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  // width: 40px;
  .liBotLeft {
    flex: 4;

    ::v-deep .el-input__inner {
      padding: 0 2px;
      // font-size: 16px;
      font-weight: 800;
    }
  }
  .liBotRight {
    flex: 3;
  }
}
.days li .other-month {
  color: #cccccccc;
}
.days li .cday {
  display: inline-block;
  text-align: center;
  font-size: 16px;
}
.days li:hover .cday {
  color: #f59a23;
}
.recday {
  display: inline-block;
  width: 1.5625rem;
  height: 1.5625rem;
  line-height: 1.5625rem;
  text-align: center;
  border-radius: 50%;
  background: #e1e1e1;
  color: #fff;
}
.idaycn {
  font-size: 16px;
  color: #f59a23;
}
ul li {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
</style>
