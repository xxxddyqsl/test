<!--
 * @Description:
 * @Author: lzp
 * @Date: 2021-06-23 16:55:55
 * @LastEditTime: 2021-07-02 12:25:17
 * @LastEditors: xxx
-->
<template>
  <div class="calendar" style="margin-top:20px;h300px">
    <div class="neck">
      <h1 style="margin:0px;padding:0">
        <i class="el-icon-caret-left" @click="preMonth" />
        {{ currentYear }}年{{ currentMonth }}月
        <i class="el-icon-caret-right" @click="nextMonth" />
      </h1>
      <h2 style="margin:0;padding:0">销售额指标：1000亿（±0）</h2>
    </div>
    <!-- 年份 月份 -->
    <!-- <div class="months">
      <div class="year-month">{{ currentYear }}年{{ currentMonth }}月</div>
      <div class="toggle-month">
        <span class="lt" @click="preMonth()">&lt;上一月</span>
        <span class="ct" @click="initData()">今天</span>
        <span class="rt" @click="nextMonth()">下一月&gt;</span>
      </div>
    </div> -->
    <!-- 星期 -->
    <ul class="weekdays">
      <li v-for="item in (fromsun ? weekDaysFromSun : weekDays)" :key="item">{{ item }}</li>
    </ul>
    <!-- 日期 -->
    <ul class="days">
      <li v-for="(dayobject,i) in days" :key="i" style="display:flex;justify-content:space-around;border:1px solid #ccc;padding-top:20px" @click="getClickDay(dayobject)">
        <div v-if="showlunar" class="idaycn">{{ dayobject.festival ? dayobject.festival: (dayobject.IDayCn == '初一'? dayobject.IMonthCn:dayobject.IDayCn) }}</div>
        <span ref="cday" class="cday" :class="{'other-month': dayobject.cMonth!= currentMonth, 'active': curDayMsg.date == dayobject.date}">
          {{ dayobject.cDay }} 日
        </span>
        <!-- 优先展示节日，其次，如果农历初一，展示当前农历月份，否则展示农历日期 -->
        <slot />
        <div class="showNum">
          10亿(±0)
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import calendar from './util/date'
export default {
  name: 'ZpCalendar',
  props: {
    showlunar: {
      type: Boolean,
      default: false
    },
    lines: {
      type: Number,
      default: 5
    },
    fromsun: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      currentDay: 1,
      currentMonth: 1,
      currentYear: 2021,
      currentWeek: 1,
      days: [],
      curDayMsg: [],
      weekDays: ['一', '二', '三', '四', '五', '六', '日'],
      weekDaysFromSun: ['日', '一', '二', '三', '四', '五', '六']
    }
  },

  created() {
    this.initData()
  },

  methods: {
    // 初始化
    initData(cur) {
      let now, curMonthStartDay, curMonthStartWeek, curPageStartDay
      if (cur) {
        now = new Date(cur)
      } else {
        now = new Date()
      }
      this.currentYear = now.getFullYear()
      this.currentMonth = now.getMonth() + 1
      this.currentDay = now.getDay()
      // 获取当前月第一天
      curMonthStartDay = new Date(
        this.formatDate(now.getFullYear(), now.getMonth() + 1, 1)
      )
      // 当前月第一天是周几
      curMonthStartWeek = curMonthStartDay.getDay() // 1,2,3,4,5,6,0
      if (curMonthStartWeek == 0) {
        curMonthStartWeek = 7
      }
      // 日历当前页开始日期
      curPageStartDay = curMonthStartDay -
        (this.fromsun ? curMonthStartWeek : curMonthStartWeek - 1) *
          24 *
          60 *
          60 *
          1000
      // 循环获取日历当前页所有日期（7*this.lines \5/6\）
      this.days = []
      for (let i = 0; i < this.lines * 7; i++) {
        const year = new Date(
          curPageStartDay + i * 24 * 60 * 60 * 1000
        ).getFullYear()
        const month =
          new Date(curPageStartDay + i * 24 * 60 * 60 * 1000).getMonth() + 1
        const day = new Date(curPageStartDay + i * 24 * 60 * 60 * 1000).getDate()
        this.days.push(calendar.solar2lunar(year, month, day))
      }
      if (!cur) {
        this.curDayMsg = calendar.solar2lunar(
          this.currentYear,
          this.currentMonth,
          now.getDate()
        )
        // this.$emit('dayMsg', this.curDayMsg)
      }
    },

    // 上一月
    preMonth() {
      this.currentMonth--
      if (this.currentMonth === 0) {
        this.currentMonth = 12
        this.currentYear--
      }
      this.initData(this.formatDate(this.currentYear, this.currentMonth, 1))
    },

    // 下一月
    nextMonth() {
      this.currentMonth++
      if (this.currentMonth === 13) {
        this.currentMonth = 1
        this.currentYear++
      }
      this.initData(this.formatDate(this.currentYear, this.currentMonth, 1))
    },

    // 点击日期
    getClickDay(el) {
      this.curDayMsg = el
      this.$emit('dayMsg', this.curDayMsg)
      // this.$router.push({ name: 'nextDetails' })
    },

    // 格式化 -> 2020-11-20
    formatDate(year, month, day) {
      if (month < 10) month = '0' + month
      if (day < 10) day = '0' + day
      return year + '-' + month + '-' + day
    }
  }
}
</script>
<style scoped>
.neck{
    height: 80px;
    display: flex;
    flex-direction: column;
    color: #F59A23;
    align-items: center;
}
ul li {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
.calendar {
  font-size: 20px;
  width: 100%;
  height: 100%;
  color: #fff;
  margin: 0 auto;
  overflow: hidden;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.1),
    0 1px 5px 0 rgba(0, 0, 0, 0.12);
}
.months {
  /* display: flex;
  justify-content: space-around;
  margin-top: 3%;
  margin-bottom: 3%; */
  width: 20%;
  height: 30px;
  /* margin-right: 20px; */
  margin-top: 10px;
  margin-bottom: 10px;
}
.months .year-month {
  margin-left: -10%;
  font-size: 0.875rem;
}
.months .toggle-month {
  width: 100%;
  /* margin-right: 20px; */
  text-align: center;
  border: 1px solid #3f4949;
  cursor: pointer;
}
.months .toggle-month .lt,
.months .toggle-month .rt {
  display: inline-block;
  width: 24%;
  color: #bebdbe;
  text-align: center;
}
.months .toggle-month .ct {
  display: inline-block;
  width: 48%;
  text-align: center;
  border-right: 1px solid #edeeee;
  border-left: 1px solid #edeeee;
  color:#fff;
}
.weekdays {
  padding: 0;
  display: flex;
  color: #000;
  justify-content: space-around;
  background-color: #fff;
  font-size: 22px;

}
.weekdays li {
  display: inline-block;
  width: 13.6%;
  text-align: center;
  margin-top: 15px;
}
.days {
  margin: 0;
  padding: 1% 0;
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
    background-color: #fff;
    color: #000;
}
.days li {
  display: inline-block;
  width: 14.2%;
  height: 95px;
  /* padding-bottom: 5%;
  padding-top: 2%; */
  text-align: center;
  color: #000;
  cursor: pointer;
 position: relative;

}
.days .showNum{
position:absolute;
top: 55px;
left: 70px;
}
.vishidden {
  visibility: hidden;
}
.days li .active {
  display: inline-block;
  /* width: 1.5625rem;
  height: 1.5625rem;
  line-height: 1.5625rem; */
  text-align: center;
  border-radius: 50%;
  /* background: #5cc18d !important; */
 color: #5cc18d!important;
  /* color: #fff; */
}
.days li .other-month {
  /* color: gainsboro; */
  color: #cccccccc;
}
.days li .cday {
  display: inline-block;
  /* width: 1.5625rem;
  height: 1.5625rem;
  line-height: 1.5625rem; */
  text-align: center;
}
.days li:hover .cday {
  /* border-radius: 50%;
  background: #e1e1e1; */
  color: #5cc18d;
  /* background-color: #5cc18d; */
}
.recday {
  display: inline-block;
  width: 1.5625rem;
  height: 1.5625rem;
  line-height: 1.5625rem;
  text-align: center;
  border-radius: 50%;
  background: #e1e1e1;
  color: #fff;
}
.idaycn {
  /* margin-top: 10%; */
  color: #fff;
}
</style>

