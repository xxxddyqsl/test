<template>
  <div
    v-loading.fullscreen.lock="fullscreenLoading"
    class="index"
    element-loading-text="拼命加载中..."
  >
    <el-row>
      <el-button
        type="primary"
        class="button"
        :size="size"
        @click="downloadFile()"
      >{{ name }}</el-button>
    </el-row>
  </div>
</template>
<script>
import axios from 'axios'
export default {
  name: 'ExcelExport',
  props: {
    name: {
      type: String,
      default: '导 出'
    },
    urlData: {
      type: String,
      default: ''
    },
    typeData: {
      type: String,
      default: 'get'
    },
    size: {
      type: String,
      default: 'mini'
    },
    formData: {
      type: Object,
      default: function() {}
    }
  },
  data() {
    return {
      fullscreenLoading: false // 加载中
    }
  },
  mounted() {
    console.log(this.formData, 132132)
  },
  methods: {
    downloadFile: function() {
      // 按钮导出
      if (this.typeData === 'get') {
        axios
          .get(this.urlData, {
            responseType: 'blob', // 或者responseType: 'blob'
            params: this.formData,
            headers: {
              // Authorization:
              Authentication:
                // JSON.parse(localStorage.getItem('SET_USERINFO')).token
                'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdHkiOiJ1c2VyLGZsaWdodCIsIm5hbWUiOiJhZG1pbiIsImlkIjoiMSIsImV4cCI6MTY0OTQwMDA2NCwidXNlcm5hbWUiOiJhZG1pbiJ9.CAvxNsH_igcVXBiDkei75iUaEgAi8f6M3U5d0ITBO2I'
            }
          })
          .then((res) => {
            var fileName =
              res.headers['content-disposition'].match(
                /filename=(.*?).xlsx/
              )
            var blob = new Blob([res.data], {
              type: 'application/vnd.ms-excel'
            })
            var elink = document.createElement('a')
            elink.download = decodeURIComponent(fileName[1]) + '.xlsx'
            elink.href = window.URL.createObjectURL(blob)
            elink.click()
            window.URL.revokeObjectURL(elink.href)
          })
          .catch((err) => {
            console.log(err)
          })
      } else if (this.typeData === 'post') {
        axios({
          method: 'post',
          url: this.urlData, // 请求地址
          data: this.formData, // 参数
          headers: {
            // Authorization:
            Authentication:
                // JSON.parse(localStorage.getItem('SET_USERINFO')).token
                'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdHkiOiJ1c2VyLGZsaWdodCIsIm5hbWUiOiJhZG1pbiIsImlkIjoiMSIsImV4cCI6MTY0OTQwMDA2NCwidXNlcm5hbWUiOiJhZG1pbiJ9.CAvxNsH_igcVXBiDkei75iUaEgAi8f6M3U5d0ITBO2I'
            //       Authorization:
            //  JSON.parse(localStorage.getItem('SET_USERINFO')).token
          },
          responseType: 'blob' // 表明返回服务器返回的数据类型
        }).then((response) => {
          var blob = new Blob([response.data], {
            type: 'application/vnd.ms-excel'
          })
          var name =
            response.headers['content-disposition'].match(/=(.*).$/)[1]
     
          var fileName = decodeURIComponent(name)
          console.log(fileName)
          if (window.navigator.msSaveOrOpenBlob) {
            // console.log(2)
            navigator.msSaveBlob(blob, fileName)
          } else {
            // console.log(3)
            var link = document.createElement('a')
            link.href = window.URL.createObjectURL(blob)
            link.download = fileName
            link.click()
            // 释放内存
            window.URL.revokeObjectURL(link.href)
          }
        })
      }
      this.$emit('exportClick', false)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.el-table th > .cell {
  text-align: center;
}
.button {
}
.index {
  display: inline-block;
}
</style>
