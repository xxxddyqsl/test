<template>
  <div :id="id" :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import echarts from 'echarts'
// import resize from './mixins/resize'
import resize from '../mixins/resize'
// require('echarts/theme/macarons') // echarts theme
export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '450px'
    },
    chartData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    chartData: {
      handler: function() {
        this.initChart()
      },
      deep: true
    }
  },
  mounted() {
    this.initChart()

    const _this = this
    window.onresize = function() {
      _this.chart.resize()
    }
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      this.setOptions(this.chartData)

      // console.log(this.chartData, 110)
    },
    setOptions({ expectedData } = {}) {
      this.chart.setOption({
        xAxis: {
          type: 'category',
          data: ['08/10', '08/11', '08/12', '08/13', '08/14', '08/15', '08/16', '08/17', '08/18', '08/19', '08/20', '08/21', '08/22', '08/23', '08/24']
        },
        legend: {
          data: ['CZ', 'MU', '3U', 'ZH', 'EU', 'JD', 'CA', 'HU'],
          // { name: 'CZ', icon: 'rectangle' },
          right: 10
        },
        grid: {
          left: '8%',
          right: '5%',
          bottom: '25%',
          top: '10%'
          // containLabel: true
        },
        yAxis: {
          type: 'value'
          // name: '万元'
        },
        series: [
          {
            type: 'line',
            name: 'CZ',
            data: [550, 1130, 884, 213, 535, 647, 250, 1130, 884, 213, 535, 647, 250]
          },
          {
            name: 'MU',
            data: [120, 250, 180, 190, 140, 80, 884, 213, 535, 647, 250, 1130, 884, 290],
            type: 'line'
          },
          {
            name: '3U',
            data: [125, 250, 250, 140, 740, 866, 884, 213, 1130, 884, 290, 535, 647, 250],
            type: 'line'
          },
          {
            name: 'ZH',
            data: [120, 213, 884, 250, 180, 190, 140, 80, 884, 290, 535, 647, 250, 1130],
            type: 'line'
          },
          {
            name: 'EU',
            data: [180, 190, 140, 80, 884, 213, 535, 120, 250, 647, 250, 1130, 884, 290],
            type: 'line'
          },
          {
            name: 'JD',
            data: [120, 250, 180, 190, 140, 535, 647, 250, 1130, 884, 290, 80, 884, 213],
            type: 'line'
          },
          {
            name: 'CA',
            data: [120, 884, 250, 647, 250, 1130, 290, 180, 190, 140, 80, 884, 213, 535],
            type: 'line'
          },
          {
            name: 'HU',
            data: [190, 140, 80, 884, 213, 535, 647, 250, 1130, 884, 120, 250, 180, 290],
            type: 'line'
          }
        ]
      })
    }
  }
}
</script>
