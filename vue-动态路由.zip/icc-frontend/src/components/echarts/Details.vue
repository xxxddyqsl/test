<template>
  <div>
    <div id="myChart" ref="myChart" :style="{width: '100%', height: '800px'}" />

  </div>
</template>
<script>
import echarts from 'echarts'
export default {
  data() {
    return {
    }
  },
  mounted() {
    this.drawLine()
  },
  methods: {
    drawLine() {
    // 初始化echarts实例
      const myChart = this.$echarts.init(this.$refs.myChart)
      // 绘制图表
      myChart.setOption({
        title: { text: '' },
        tooltip: {},
        xAxis: {
          data: ['YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101', 'YY101']
        },
        yAxis: {
        //   data: [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
        },
        series: [
          {
            name: 'echarts表格', // 系列名称，用于tooltip的显示，legend 的图例筛选，在 setOption 更新数据和配置项时用于指定对应的系列。
            type: 'bar',
            itemStyle: {//
              normal: {
                color: 'red'
              }
            },
            label: {// label要加入normal才可生效,label即为x轴对应Y轴的值
              normal: {
                show: true,
                color: 'red', // 设置渐变时候控制不到颜色，只能通过全局textStyle来控制
                position: 'top'
              }
            },
            barWidth: '40%',
            data: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 13.5, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 13.5, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 13.5, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 13.5, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 13.5, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 13.5, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 13.5]
          }

        ]
      })
    }
  }
}
</script>

<style>

</style>
