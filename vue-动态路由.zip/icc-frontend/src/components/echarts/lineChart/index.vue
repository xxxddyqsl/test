<template>
  <div :id="id" :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import echarts from "echarts";
// import resize from './mixins/resize'
import resize from "../mixins/resize";
// require('echarts/theme/macarons') // echarts theme
export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: "chart"
    },
    id: {
      type: String,
      default: "chart"
    },
    width: {
      type: String,
      default: "100%"
    },
    height: {
      type: String,
      default: "300px"
    },
    chartData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      chart: null
    };
  },
  watch: {
    chartData: {
      handler: function() {
        this.initChart();
      },
      deep: true
    }
  },
  mounted() {
    this.initChart();

    const _this = this;
    window.onresize = function() {
      _this.chart.resize();
    };
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, "macarons");
      this.setOptions(this.chartData);
    },
    setOptions(chartData) {
      this.chart.setOption(
        chartData || {
          xAxis: {
            type: "category",
            data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
          },
          legend: {
            data: [{ name: "实际", icon: "rectangle" }, "预测"],
            right: 10
          },
          grid: {
            left: "8%",
            right: "5%",
            bottom: "25%",
            top: "10%"
            // containLabel: true
          },
          yAxis: {
            type: "value",
            name: "万元"
          },
          series: [
            {
              type: "line",
              name: "实际",
              data: [150, 230, 224, 218, 135, 147, 260]
            },
            {
              name: "预测",
              data: [120, 250, 180, 190, 140, 80, 290],
              type: "line"
            }
          ]
        }
      );
    }
  }
};
</script>
