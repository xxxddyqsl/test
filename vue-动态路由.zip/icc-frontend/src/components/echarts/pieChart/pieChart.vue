<template>
  <div :id="id" :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import echarts from 'echarts'
// import resize from './mixins/resize'
import resize from '../mixins/resize'
// require('echarts/theme/macarons') // echarts theme
export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '5.12rem'
    },
    height: {
      type: String,
      default: '2rem'
    },
    chartData: {
      type: Object,
      required: true,
      default: function() {
        return {}
      }
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    chartData: {
      handler: function() {
        this.initChart()
      },
      deep: true
    }
  },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      this.setOptions(this.chartData)
      // console.log(this.chartData, 110)
    },
    setOptions({ expectedData } = {}) {
      this.chart.setOption({
        // legend: {
        //   data: ['邮件营销', '联盟广告']
        // },
        tooltip: {
          show: false,
          trigger: 'none',
          // formatter: '{a} : {c} ({d}%)',
          textStyle: { color: 'yellow' },
          alwaysShowContent: false
        },
        color: ['#276AA8', '#29BED9'],
        series: [
          {
            hoverAnimation: false,
            name: '访问来源',
            type: 'pie',
            radius: ['40%', '80%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: true,
                color: '#000', // formatter: '{b}',
                position: 'center',
                lineHight: 20
              },
              textStyle: {
                color: 'white'
              },
              show: false,
              position: 'center'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: '12'
                // fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: [
              { value: 484, name: 'U' },
              { value: 300 }
            ]
          }
        ]
      })
    }
  }
}
</script>
