<template>
  <div>
    <logo v-if="showLogo" :collapse="isCollapse" />
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <el-menu
        :unique-opened="true"
        :default-active="$router.path"
        :collapse="isCollapse"
        :background-color="navBgColor"
        :text-color="variables.menuText"
        :active-text-color="variables.navSelectColor"
        :collapse-transition="false"
        mode="vertical"
      >
        <sidebar-item
          v-for="route in permission_routers"
          :key="route.path"
          :item="route"
          :base-path="route.path"
        />
      </el-menu>
    </el-scrollbar>

  </div>
</template>

<script>
import Logo from './Logo'
import { mapGetters } from 'vuex'
import SidebarItem from './SidebarItem'
import variables from '@/styles/variables.scss'
export default {
  components: { SidebarItem, Logo },
  computed: {
    ...mapGetters(['permission_routers', 'sidebar']),
    navBgColor() {
      return this.$store.state.settings.navBgColor
    },
    navSelectColor() {
      return this.$store.state.settings.navSelectColor
    },
    variables() {
      return variables
    },
    isCollapse() {
      return !this.sidebar.opened
    },
    showLogo() {
      return this.$store.state.settings.sidebarLogo
    }
  },
  created() {
    console.log(this.permission_routers, 'luyou ')
  }
}
</script>
