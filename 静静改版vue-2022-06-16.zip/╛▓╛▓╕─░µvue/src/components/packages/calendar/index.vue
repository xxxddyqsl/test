<!--
 * @Description:
 * @Author: lzp
 * @Date: 2021-06-23 16:55:55
 * @LastEditTime: 2021-07-02 12:25:17
 * @LastEditors: xxx
-->
<template>
  <div class="calendar">
    <slot name="neckBox" />
    <slot name="titleSlot" />
    <ul class="weekdays">
      <li v-for="item in fromsun ? weekDaysFromSun : weekDays" :key="item">
        {{ item }}
      </li>
    </ul>
    <!-- 日期 -->
    <ul class="days" style="padding:0">
      <li v-for="(dayobject, i) in days" :key="i">
        <div v-if="showlunar" class="idaycn">
          {{
            dayobject.festival
              ? dayobject.festival
              : dayobject.IDayCn == "初一"
                ? dayobject.IMonthCn
                : dayobject.IDayCn
          }}
        </div>
        <span
          ref="cday"
          class="cday"
          :class="{ 'other-month': dayobject.cMonth != currentMonth }"
          @click="onClickcDay(dayobject)"
        >
          {{ dayobject.cDay }}
        </span>
        <!-- 优先展示节日，其次，如果农历初一，展示当前农历月份，否则展示农历日期 -->
        <slot name="value" />
      </li>
    </ul>
  </div>
</template>
<script>
import calendar from './util/date'
export default {
  name: 'ZpCalendar',
  props: {
    showlunar: {
      type: Boolean,
      default: false
    },
    lines: {
      type: Number,
      default: 5
    },
    fromsun: {
      type: Boolean,
      default: false
    },
    currentYear: {
      type: Number,
      default: 2021
    },
    currentMonth: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      currentDay: 1,
      currentWeek: 1,
      days: [],
      curDayMsg: [],
      weekDays: ['一', '二', '三', '四', '五', '六', '日'],
      weekDaysFromSun: ['日', '一', '二', '三', '四', '五', '六']
    }
  },
  watch: {
    currentYear: {
      handler(newName, oldName) {
        this.initData(this.formatDate(newName, this.currentMonth, 1))
      },
      immediate: true
    },
    currentMonth: {
      handler(newName, oldName) {
        this.initData(this.formatDate(this.currentYear, newName, 1))
      },
      immediate: true
    }
  },

  created() {
    this.initData(this.formatDate(this.currentYear, this.currentMonth, 1))
  },

  methods: {
    // 初始化
    initData(cur) {
      let now, curMonthStartDay, curMonthStartWeek, curPageStartDay
      if (cur) {
        now = new Date(cur)
      } else {
        now = new Date()
      }
      // this.currentYear = now.getFullYear();
      // this.currentMonth = now.getMonth() + 1;
      this.$emit('update:currentYear', now.getFullYear())
      this.$emit('update:currentMonth', now.getMonth() + 1)
      this.currentDay = now.getDay()
      // 获取当前月第一天
      // eslint-disable-next-line prefer-const
      curMonthStartDay = new Date(
        this.formatDate(now.getFullYear(), now.getMonth() + 1, 1)
      )
      // 当前月第一天是周几
      curMonthStartWeek = curMonthStartDay.getDay() // 1,2,3,4,5,6,0
      if (curMonthStartWeek === 0) {
        curMonthStartWeek = 7
      }
      // 日历当前页开始日期
      // eslint-disable-next-line prefer-const
      curPageStartDay =
        curMonthStartDay -
        (this.fromsun ? curMonthStartWeek : curMonthStartWeek - 1) *
          24 *
          60 *
          60 *
          1000
      // 循环获取日历当前页所有日期（7*this.lines \5/6\）
      this.days = []
      for (let i = 0; i < this.lines * 7; i++) {
        const year = new Date(
          curPageStartDay + i * 24 * 60 * 60 * 1000
        ).getFullYear()
        const month =
          new Date(curPageStartDay + i * 24 * 60 * 60 * 1000).getMonth() + 1
        const day = new Date(
          curPageStartDay + i * 24 * 60 * 60 * 1000
        ).getDate()
        this.days.push(calendar.solar2lunar(year, month, day))
      }
      if (!cur) {
        this.curDayMsg = calendar.solar2lunar(
          this.currentYear,
          this.currentMonth,
          now.getDate()
        )
        this.$emit('dayMsg', this.curDayMsg)
      }
    },

    // 上一月
    // preMonth() {
    //   this.currentMonth--
    //   if (this.currentMonth === 0) {
    //     this.currentMonth = 12
    //     this.currentYear--
    //   }
    //   this.initData(this.formatDate(this.currentYear, this.currentMonth, 1))
    // },

    // // 下一月
    // nextMonth() {
    //   this.currentMonth++
    //   if (this.currentMonth === 13) {
    //     this.currentMonth = 1
    //     this.currentYear++
    //   }
    //   this.initData(this.formatDate(this.currentYear, this.currentMonth, 1))
    // },

    // 点击日期
    getClickDay(el) {
      this.curDayMsg = el
      this.$emit('dayMsg', this.curDayMsg)
    },

    // 格式化 -> 2020-11-20
    formatDate(year, month, day) {
      if (month < 10) month = '0' + month
      if (day < 10) day = '0' + day
      return year + '-' + month + '-' + day
    },
    onClickcDay(data) {
      const query = {
        indicatorsId: this.$route.query.indicatorsId,
        code: this.$route.query.code,
        years: data.cYear,
        month: data.cMonth,
        day: data.cDay,
        title: this.$route.query.title,
        type: 'progressType'
      }
      this.$route.query.id && (query.id = this.$route.query.id)
      this.$route.query.flightNo &&
        (query.flightNo = this.$route.query.flightNo)

      this.$router.push({
        name: 'nextDetails',
        query
      })
    }
  }
}
</script>
<style scoped>
.calendar {
  margin: 6px;
  font-size: 12px;
  color: #000;
  background-color: #fff;
  box-sizing: border-box;
  overflow: hidden;
  border-radius: 10px;
  border: 1px solid #eff2f7;
}
.calendaractive {
  font-size: 20px;
}
.mouth_left {
  margin-top: 10px;
  margin-left: 20px;
  font-weight: bold;
  font-size: 16px;
}
.months {
  /* display: flex;
  justify-content: space-around;
  margin-top: 3%;
  margin-bottom: 3%; */
  width: 20%;
  height: 30px;
  /* margin-right: 20px; */
  margin-top: 10px;
  margin-bottom: 10px;
}
.months .year-month {
  margin-left: -10%;
  /* font-size: 0.875rem; */
}
.months .toggle-month {
  width: 100%;
  /* margin-right: 20px; */
  text-align: center;
  border: 1px solid #000;
  cursor: pointer;
}
.months .toggle-month .lt,
.months .toggle-month .rt {
  display: inline-block;
  width: 24%;
  color: #bebdbe;
  text-align: center;
}
.months .toggle-month .ct {
  display: inline-block;
  width: 48%;
  text-align: center;
  border-right: 1px solid #edeeee;
  border-left: 1px solid #edeeee;
  color: #000;
}
.weekdays {
  padding: 0;
  margin: 0 0 10px;
  display: flex;
  color: #333;
  justify-content: space-around;
  background-color: #fff;
  font-size: 12px;
}
.weekdays li {
  display: inline-block;
  width: 13.6%;
  text-align: center;
  /* margin-top: 15px; */
}
.days {
  height: 180px;
  margin: 0;
  /* padding: 1% 0; */
  padding: 0;
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  background-color: #fff;
}
.days li {
  display: flex;
  justify-content: center;
  width: calc(100% / 7);
  /* height: 95px; */
  /* padding-bottom: 5%;
  padding-top: 2%; */
  text-align: center;
  color: #000;
  cursor: pointer;
}
.vishidden {
  visibility: hidden;
}
.days li .active {
  display: inline-block;
  /* width: 1.5625rem;
  height: 1.5625rem;
  line-height: 1.5625rem; */
  text-align: center;
  border-radius: 50%;
  /* background: #5cc18d !important; */
  color: #5cc18d !important;
  /* color: #fff; */
}
.days li .other-month {
  /* color: gainsboro; */
  color: #cccccccc;
}
.days li .cday {
  display: inline-block;
  /* width: 1.5625rem;
  height: 1.5625rem;
  line-height: 1.5625rem; */
  text-align: center;
}
.days li:hover .cday {
  /* border-radius: 50%;
  background: #e1e1e1; */
  color: #5cc18d;
  /* background-color: #5cc18d; */
}
.recday {
  display: inline-block;
  width: 1.5625rem;
  height: 1.5625rem;
  line-height: 1.5625rem;
  text-align: center;
  border-radius: 50%;
  background: #e1e1e1;
  color: #000;
}
.idaycn {
  /* margin-top: 10%; */
  color: #000;
}
ul li {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
</style>
