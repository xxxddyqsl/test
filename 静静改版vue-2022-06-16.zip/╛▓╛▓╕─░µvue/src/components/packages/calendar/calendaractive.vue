<template>
  <div class="calenBox">
    <div class="calendar">
      <div v-if="moduleType === 1" class="neck">
        <!-- <h2 style="margin:0px;padding:0"> -->
        <!-- <i
            v-if="leftMonthBtnShow"
            class="el-icon-caret-left cursorPoint"
            @click="preMonth"
          /> -->
        <!-- {{ titleFilter }} -->
        <!-- <i
            v-if="rightMonthBtnShow"
            class="el-icon-caret-right cursorPoint"
            @click="nextMonth"
          /> -->
        <!-- </h2> -->
        <!-- <h3 v-if="moduleType === 2" style="margin:0;padding:0">
          销售额指标：1000亿（{{ currentDiff }}）
        </h3>
        <h3 v-else style="margin:0;padding:0">
          {{ `销售额指标：${total}${company}` }}
        </h3> -->
        <span>{{ titleFilter }}</span>
        <span v-if="moduleType === 1">{{
          `销售额指标：${total}${company}`
        }}</span>
        <span v-else>销售额指标：1000亿（{{ currentDiff }}）</span>
      </div>

      <!-- <ul class="weekdays">
        <li v-for="item in fromsun ? weekDaysFromSun : weekDays" :key="item">
          {{ item }}
        </li>
      </ul> -->
      <!-- 日期 -->
      <ul class="days">
        <li v-for="(dayobject, i) in days" :key="i">
          <div class="liTop" @click="getClickDay(dayobject)">
            <div>
              <span ref="cday" class="cday">
                {{ moduleType === 1 ? dayobject.num : dayobject.type }}日
              </span>
              <span class="cday">{{ dayobject.lunarCalendar || "" }}</span>
              <span v-if="dayobject.festival">{{ dayobject.festival }}</span>
            </div>
            <span v-if="moduleType != 1">{{
              dayobject.difference
                ? `${dayobject.difference}${dayobject.diffUnit}`
                : "±0"
            }}</span>
          </div>
          <div class="liBottom">
            <span v-if="moduleType === 1" class="liBottomSpan">{{
              `${dayobject.amountActual}${dayobject.companyActual} / ${
                dayobject.amountPlan
              }${dayobject.companyPlan}`
            }}</span>
            <p v-else class="liBInput">
              <el-input
                v-model="dayobject.num"
                class="liBotLeft"
                placeholder="0"
                size="small"
                @change="
                  val => {
                    changeFn(val, dayobject);
                  }
                "
              />
              <span class="liBotRight">{{ dayobject.unit }}</span>
            </p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  name: 'ZpCalendar',
  props: {
    company: {
      type: String,
      default: ''
    },
    currentYear: {
      type: Number,
      default: 2021
    },
    currentMonth: {
      type: Number,
      default: 1
    },
    moduleType: {
      type: Number,
      default: 1 // 插件类型：1：指标进度；2：指标拆解可编辑；
    },
    total: {
      type: String,
      default: '1000亿'
    },
    dayList: {
      type: Array,
      // eslint-disable-next-line vue/require-valid-default-prop
      default: []
    },
    currentDiff: {
      type: String,
      default: '±0'
    }
  },
  data() {
    return {
      // currentMonth: this.$route.query.month,
      currentDay: 1,
      currentWeek: 1,
      days: [],
      // curDayMsg: [],
      // weekDays: ["一", "二", "三", "四", "五", "六", "日"],
      // weekDaysFromSun: ["日", "一", "二", "三", "四", "五", "六"],
      leftMonthBtnShow: true,
      rightMonthBtnShow: true,
      collectChangeData: []
    }
  },
  computed: {
    titleFilter() {
      const str = `${this.currentYear}年${
        this.currentMonth < 10 ? '0' + this.currentMonth : this.currentMonth
      }月`
      return str
    }
  },
  watch: {
    dayList: {
      handler(newValue, oldValue) {
        this.days = newValue
      },
      immediate: true
    }
  },
  created() {
    // this.initData(this.formatDate(this.currentYear, this.currentMonth, 1));
  },
  mounted() {
    this.currentMonth * 1 === 1 && (this.leftMonthBtnShow = false)
    this.currentMonth * 1 === 12 && (this.rightMonthBtnShow = false)
  },

  methods: {
    // 上一月
    preMonth() {
      let month = this.currentMonth
      month--
      month < 12 && (this.rightMonthBtnShow = true)
      month === 1 && (this.leftMonthBtnShow = false)
      this.$emit(`update:currentMonth`, month)
      this.$emit('monthChangeFn', month)
    },

    // 下一月
    nextMonth() {
      let month = this.currentMonth
      month++
      month > 1 && (this.leftMonthBtnShow = true)
      month === 12 && (this.rightMonthBtnShow = false)
      this.$emit(`update:currentMonth`, month)
      this.$emit('monthChangeFn', month)
    },

    // 点击日期
    getClickDay(curData) {
      this.$emit('dayMsg', curData)
    },

    changeFn(val, item) {
      // 去重
      const deleteIndex = this.collectChangeData.findIndex((itm, index) => {
        return (
          itm.changeType ===
          `${item.yyyymm}${item.type * 1 < 10 ? '0' + item.type : item.type}`
        )
      })
      if (deleteIndex === -1) {
        this.collectChangeData.push({
          changeType: `${item.yyyymm}${
            item.type * 1 < 10 ? '0' + item.type : item.type
          }`,
          changeValue: val * 1,
          changeValueUnit: item.unit
        })
      } else {
        this.collectChangeData[deleteIndex] = {
          changeType: `${item.yyyymm}${
            item.type * 1 < 10 ? '0' + item.type : item.type
          }`,
          changeValue: val * 1,
          changeValueUnit: item.unit
        }
      }

      this.$emit('collectData', this.collectChangeData)
    }
  }
}
</script>
<style lang="scss" scoped>
.neck {
  height: 60px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  margin: 0;
  border: 2px solid #eff2f7;
  border-radius: 10px;
  font-size: 18px;
  font-weight: 600;
  color: #5664d2;
}
.cursorPoint {
  cursor: pointer;
}
.calenBox {
  padding: 0 20px;
}
.calendar {
  border-radius: 20px;
  padding: 10px 20px 0;
  font-size: 20px;
  color: #000;
  overflow: hidden;
  background-color: #fff;
  box-sizing: border-box;
}
.calendaractive {
  font-size: 20px;
}
.mouth_left {
  margin-top: 10px;
  margin-left: 20px;
  font-weight: bold;
  font-size: 16px;
}
.months {
  width: 20%;
  height: 30px;
  margin-top: 10px;
  margin-bottom: 10px;
}
.months .year-month {
  margin-left: -10%;
}
.months .toggle-month {
  width: 100%;
  text-align: center;
  border: 1px solid #000;
  cursor: pointer;
}
.months .toggle-month .lt,
.months .toggle-month .rt {
  display: inline-block;
  width: 24%;
  color: #000;
  text-align: center;
}
.months .toggle-month .ct {
  display: inline-block;
  width: 48%;
  text-align: center;
  border-right: 1px solid #000;
  border-left: 1px solid #000;
  color: #000;
}
.days {
  padding: 0;
  margin-top: 10px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: wrap;
}
.days li {
  display: flex;
  justify-content: flex-start;
  flex-direction: column;
  // width: calc(100% / 6);
  width: 16%;
  margin: 3px;
  border: 1px solid #eaeaea;
  border-radius: 10px;
  overflow: hidden;
  text-align: center;
  color: #000;
  cursor: pointer;
}
.vishidden {
  visibility: hidden;
}
.days li .active {
  display: inline-block;

  text-align: center;
  border-radius: 50%;
  color: #5cc18d !important;
}
.days li .cday {
  display: inline-block;
  text-align: center;
  font-size: 16px;
}
.days li:hover .cday {
  color: #f59a23;
  text-decoration: underline;
}
.days li .liTop {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #eff2f7;
  height: 30px;
  line-height: 30px;
  padding: 0 10px;
  span {
    font-size: 16px;
    font-weight: 600;
    color: #5664d2;
    &:last-child {
      color: #999;
    }
  }
}
.days li .liBottom {
  overflow: hidden;
  p{margin: 0;}
  .liBottomSpan {
    display: block;
    font-size: 16px;
    text-align: center;
    padding: 20px 0;
  }
}
.liBottom .liBInput {
  font-size: 16px;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px 0;
  // width: 40px;
  .liBotLeft {
    width: 80px;

    ::v-deep .el-input__inner {
      padding: 0 2px;
      // font-size: 16px;
      font-weight: 800;
    }
  }
}

ul li {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
</style>
