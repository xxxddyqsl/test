<template>
  <div class="components-Search-box gg-flex-3" :class="isFocus!=''?'gg-input-focus':''">
    <img draggable="false" :src="SearchVal!=''?require('../assets/images/clean.png'):require('../assets/images/search.png')" @click="deleSearch" class="components-Search-icon" alt="">
    <el-input @input="changeSearch" type="text" @focus="focusFunc" @blur="blurFunc" ref="input_Search" class="components-Search-inpt" v-model="SearchVal" placeholder="Search">
    </el-input>
  </div>
</template>
<script>
// import services from '../../static/utils/services'
// import utils from '../../static/utils/utils'

// import filter from '../../static/utils/filter'
import Message from './Message.vue'
// var htmlOverviewMsgTemp = filter.htmlOverviewMsgTemp();
export default {
  name: 'search',
  components: {
    // 聊天消息-子组件
    Message,
  },
  props: {
    info: {
      default: ''
    },
    user: {
      default: ''
    }
  },

  data() {
    return {
      SearchVal: '',
      isFocus: false,
    };
  },
  watch: {

  },
  mounted() {
    console.log(this.user, this.info)
    // this.$refs.editDiv.focus();
  },

  methods: {
    hideHistory() {
      this.$emit('hideHistory',)
    },
    // 清空 搜索框
    deleSearch() {
      this.isFocus = false;
      this.SearchVal = '';
      this.$emit('changeSearch', '');
    },
    //监听 搜索输入框 调用父组件查询
    changeSearch(val) {
      //  this.isFocus=true;
      this.SearchVal = val;
      this.$emit('changeSearch', val);
      //   console.log(val)
    },
    // 获取焦点
    focusFunc() {
      this.isFocus = true;
    },
    // 失去焦点
    blurFunc() {
      this.isFocus = false;
    }
  }
};
</script>

<style scoped>
@import "../assets/css/Search.css";
/* 使用  ::v-deep 深度选择器  修改element 样式  必须在 scoped 中使用 或者在全局css中 否则无效*/
.components-Search-box /deep/ .el-input__inner {
  width: 100%;
  height: 100%;
  background: #f1f3f4;
  border-radius: 25px;
  border: 0px;
  padding-left: 0;
  font-family: "Futura-Medium, Futura" !important;
}
</style>

